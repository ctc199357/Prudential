from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.knowledgeinput_data import (
        DataManager as KnowledgeInputDataManager,
        CreateRequest as KnowledgeInputCreateRequest, 
        BatchCreateRequest as KnowledgeInputBatchCreateRequest,
        UpdateRequest as KnowledgeInputUpdateRequest, 
        CommonRequest as KnowledgeInputRequest,
        BatchCommonRequest as KnowledgeInputBatchRequest,
        get_db_api
    )

router = APIRouter(tags=["Registry-General"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


@router.post("/general/knowledgeinput/single/create", status_code=status.HTTP_201_CREATED)
def general_create_knowledgeinput(request: KnowledgeInputCreateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputCreateRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/knowledgeinput/single/update", status_code=status.HTTP_200_OK)
def general_update_knowledgeinput(request: KnowledgeInputUpdateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputUpdateRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledgeinput/single/delete", status_code=status.HTTP_200_OK)
def general_delete_knowledgeinput(request: KnowledgeInputRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledgeinput/single/drop", status_code=status.HTTP_200_OK)
def general_drop_knowledgeinput(request: KnowledgeInputRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledgeinput/single/force_drop", status_code=status.HTTP_200_OK)
def general_force_drop_knowledgeinput(request: KnowledgeInputRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).force_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledgeinput/single/activate", status_code=status.HTTP_200_OK)
def general_activate_knowledgeinput(request: KnowledgeInputRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledgeinput/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_knowledgeinput(request: KnowledgeInputRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledgeinput/batch/create", status_code=status.HTTP_201_CREATED)
def general_batch_create_knowledgeinput(request: KnowledgeInputBatchCreateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputBatchCreateRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledgeinput/batch/delete", status_code=status.HTTP_200_OK)
def general_batch_delete_knowledgeinput(request: KnowledgeInputBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputBatchRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledgeinput/batch/drop", status_code=status.HTTP_200_OK)
def general_batch_drop_knowledgeinput(request: KnowledgeInputBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputBatchRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledgeinput/batch/activate", status_code=status.HTTP_200_OK)
def general_batch_activate_knowledgeinput(request: KnowledgeInputBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputBatchRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledgeinput/batch/deactivate", status_code=status.HTTP_200_OK)
def general_batch_deactivate_knowledgeinput(request: KnowledgeInputBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputBatchRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response
