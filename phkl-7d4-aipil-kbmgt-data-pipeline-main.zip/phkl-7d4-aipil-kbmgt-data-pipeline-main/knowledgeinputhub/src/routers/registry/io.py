from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.knowledgeinput_data import (
        DataManager as KnowledgeInputDataManager,
        SystemDataRequest as SystemKnowledgeInputRequest, 
        SystemDataResponse as SystemKnowledgeInputResponse,
        DataBackupRequest as KnowledgeInputBackupRequest, 
        DataBackupListRequest as KnowledgeInputBackupListRequest,
        DataBackupListResponse as KnowledgeInputBackupListResponse,
        DBRestoreRequest as KnowledgeInputRestoreRequest,
        DataImportRequest as KnowledgeInputImportRequest,
        DataExportRequest as KnowledgeInputExportRequest,
        get_db_api
    )

router = APIRouter(tags=["Registry-IO"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


@router.post("/system/knowledgeinput/export", status_code=status.HTTP_200_OK)
def system_export_knowledgeinput(request: KnowledgeInputExportRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputExportRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/knowledgeinput/import", status_code=status.HTTP_200_OK)
def system_import_knowledgeinput(request: KnowledgeInputImportRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputImportRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/knowledgeinput/backup", status_code=status.HTTP_200_OK)
def system_backup_knowledgeinput(request: KnowledgeInputBackupRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputBackupRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/knowledgeinput/backup/list", status_code=status.HTTP_200_OK, response_model=KnowledgeInputBackupListResponse)
def system_backup_list_knowledgeinput(request: KnowledgeInputBackupListRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> KnowledgeInputBackupListResponse:
    request = KnowledgeInputBackupListRequest(**request.__dict__)
    response_table, response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/system/knowledgeinput/restore/backup", status_code=status.HTTP_200_OK)
def system_restore_backup_knowledgeinput(request: KnowledgeInputRestoreRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeInputRestoreRequest(**request.__dict__)
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response