from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.knowledgeinput_data import (
        DataManager as KnowledgeInputDataManager,
        UserDataRequest as UserKnowledgeInputRequest, 
        UserDataResponse as UserKnowledgeInputResponse,
        get_db_api
    )

router = APIRouter(tags=["Registry-User"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


@router.post("/user/knowledgeinput/query", status_code=status.HTTP_200_OK, response_model=UserKnowledgeInputResponse)
def user_query_knowledgeinput(request: UserKnowledgeInputRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> UserKnowledgeInputResponse:
    request = UserKnowledgeInputRequest(**request.__dict__)
    response_data, response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data
