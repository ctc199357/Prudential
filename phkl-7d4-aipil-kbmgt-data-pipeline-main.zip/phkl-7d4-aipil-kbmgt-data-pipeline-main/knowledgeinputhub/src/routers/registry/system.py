from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.knowledgeinput_data import (
        DataManager as KnowledgeInputDataManager,
        SystemDataRequest as SystemKnowledgeInputRequest, 
        SystemDataResponse as SystemKnowledgeInputResponse,
        DataBackupRequest as KnowledgeInputBackupRequest, 
        DataBackupListRequest as KnowledgeInputBackupListRequest,
        DataBackupListResponse as KnowledgeInputBackupListResponse,
        DBRestoreRequest as KnowledgeInputRestoreRequest,
        DataImportRequest as KnowledgeInputImportRequest,
        DataExportRequest as KnowledgeInputExportRequest,
        get_db_api
    )

router = APIRouter(tags=["Registry-Admin"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


@router.post("/system/knowledgeinput/query", status_code=status.HTTP_200_OK, response_model=SystemKnowledgeInputResponse)
def system_query_knowledgeinput(request: SystemKnowledgeInputRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> SystemKnowledgeInputResponse:
    request = SystemKnowledgeInputRequest(**request.__dict__)
    response_data, response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/knowledgeinput/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_knowledgeinput(db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    response = KnowledgeInputDataManager(db_api=db_api, api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response


