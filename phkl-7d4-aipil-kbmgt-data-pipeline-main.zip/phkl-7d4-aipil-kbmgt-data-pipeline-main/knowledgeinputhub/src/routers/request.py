from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..services.knowledgeinput_service import KnowledgeInputServiceManager

from ..schemas.knowledgeinput import (
    KnowledgeInputUploadRequest,
    KnowledgeInputUploadResponse,
    KnowledgeInputIngestRequest,
    KnowledgeInputIngestResponse
)

router = APIRouter(tags=["Request"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


@router.post("/request/knowledgeinput/upload", status_code=status.HTTP_200_OK, response_model=KnowledgeInputUploadResponse)
def request_knowledgeinput_upload(request: KnowledgeInputUploadRequest, api_call: bool = default_api_call) -> KnowledgeInputUploadResponse:
    request = KnowledgeInputUploadRequest(**request.__dict__)
    response_knowledgeinput, response = KnowledgeInputServiceManager(api_call=api_call).knowledgeinput_upload(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_knowledgeinput

@router.post("/request/knowledgeinput/ingest", status_code=status.HTTP_200_OK, response_model=KnowledgeInputIngestResponse)
def request_knowledgeinput_ingest(request: KnowledgeInputIngestRequest, api_call: bool = default_api_call) -> KnowledgeInputIngestResponse:
    request = KnowledgeInputIngestRequest(**request.__dict__)
    response_knowledgeinput, response = KnowledgeInputServiceManager(api_call=api_call).knowledgeinput_ingest(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_knowledgeinput
