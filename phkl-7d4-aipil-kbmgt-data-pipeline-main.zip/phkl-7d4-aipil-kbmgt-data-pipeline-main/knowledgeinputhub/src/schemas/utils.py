from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

