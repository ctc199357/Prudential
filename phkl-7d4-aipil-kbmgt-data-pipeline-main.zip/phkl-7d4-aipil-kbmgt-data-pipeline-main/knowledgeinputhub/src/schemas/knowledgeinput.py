from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone
from fastapi import UploadFile

from ..settings import SETTINGS

from ..database.registry.schemas.knowledgeinput import *

"""
    Request and Response for KnowledgeHub
"""
class KnowledgeInputUploadObject(BaseModel):
    storage_directory_origin: str | None = ''
    upload_file:              UploadFile | None = None

class KnowledgeInputUploadRequest(BaseModel):
    knowledgeinput_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_id:                   str | None = None
    user_requestid:            str | None = None
    knowledgeinput_uploads:    list[KnowledgeInputUploadObject]=[]
    
    # Time Information
    knowledgeinput_request_at: datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class KnowledgeInputObject(BaseModel):
    knowledgeinput_sequence:      int=1
    knowledgeinput_id:            str=Field(default_factory=lambda: str(uuid.uuid4()))
    storage_type:                 str='LOCAL'
    storage_provider:             str='LOCAL'
    storage_type_origin:          str='LOCAL'
    storage_provider_origin:      str='LOCAL'
    storage_directory:            str=''
    storage_directory_origin:     str=''
    knowledgeinput_filename:      str=''
    knowledgeinput_fileextension: str  | None = None
    knowledgeinput_filesize:      float=0.0

class KnowledgeInputUploadResponse(BaseModel):
    knowledgeinput_requestid:       str

    # Results
    knowledgeinput_success_objects: list[KnowledgeInputObject]=[]
    knowledgeinput_fail_objects:    list[KnowledgeInputObject]=[]

    # Statistics
    knowledgeinput_total_no:        int=0
    knowledgeinput_success_no:      int=0
    knowledgeinput_fail_no:         int=0
    knowledgeinput_upload_time:     float=0.0

    # Time Information
    knowledgeinput_response_at:     datetime | None = None

class KnowledgeInputIngestRequest(BaseModel):
    knowledgeinput_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_id:                   str | None = None
    user_requestid:            str | None = None
    
    # Request Info
    knowledgeinput_creates:    list[KnowledgeInputCreate]=[]

    # Time Information
    knowledgeinput_request_at: datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class KnowledgeInputIngestObject(BaseModel):
    knowledgeinput_sequence:      int=1
    
    knowledgeinput_code:          str=SETTINGS.KWIN.STATUS_CODE.get("FAIL", "500")
    knowledgeinput_reason:        str='DEFAULT'

    knowledgeinput_id:            str=''
    knowledgeinput_name:          str=''

    knowledgeinput_filename:      str=''
    knowledgeinput_fileextension: str  | None = None
    knowledgeinput_filesize:      float=0.0
    
    storage_type:                 str='LOCAL'
    storage_type_origin:          str='LOCAL'
    storage_provider:             str='LOCAL'
    storage_provider_origin:      str='LOCAL'
    storage_directory:            str='' # file path / url
    storage_directory_origin:     str=''
    storage_secrets:              dict=dict()
    storage_secrets_origin:       dict=dict()

    knowledgeinput_filename:      str=''
    knowledgeinput_fileextension: str=''

class KnowledgeInputIngestResponse(BaseModel):
    knowledgeinput_requestid:       str
    
    # Results
    knowledgeinput_success_objects: list[KnowledgeInputIngestObject]=[]
    knowledgeinput_fail_objects:    list[KnowledgeInputIngestObject]=[]

    # Statistics
    knowledgeinput_total_no:        int=0
    knowledgeinput_success_no:      int=0
    knowledgeinput_fail_no:         int=0
    knowledgeinput_ingest_time:     float=0.0

    # Time Information
    knowledgeinput_response_at:     datetime | None = None