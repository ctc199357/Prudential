import os

from fastapi import HTTPException

from .settings import SETTINGS

from .schemas.format import Response

from azure.storage.blob import BlobClient, BlobServiceClient, ContentSettings

from .logger.log_handler import get_logger

from docx import Document
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

from spire.presentation import *
from spire.presentation.common import *

from spire.doc import *
from spire.doc.common import *

logger = get_logger(__name__)

def normalize_path(long_path: str) -> str:
    if os.name == 'nt':
        long_path = os.path.abspath(long_path)
        if not long_path.startswith('\\\\?\\'):
            long_path = '\\\\?\\' + long_path
    return long_path

# Router Response Handler
def router_response_handler(response: Response, api_call: bool):
    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
        if api_call == True:
            raise HTTPException(status_code=response.status_code, detail=response.detail)
        else:
            raise Exception(response.detail)

def get_blob_file_size(blob_file_url: str) -> int:
    try: 
        # Initialize blob service client
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        
        blob_client = BlobClient.from_blob_url(
            blob_file_url,
            credential=blob_service_client.credential
        )
        # Get blob properties
        blob_properties = blob_client.get_blob_properties()
        # Get the size of the blob in bytes
        blob_size = blob_properties.size
        return blob_size
    except Exception as e:
        logger.error(f"Failed to get blob file size: {str(e)}")
        raise

def download_from_blob_by_url(blob_file_url: str, local_path: str):
    try:
        # Initialize blob service client
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        
        blob_client = BlobClient.from_blob_url(
            blob_file_url,
            credential=blob_service_client.credential
        )
        # Download the blob
        with open(local_path, "wb") as file:
            file.write(blob_client.download_blob().readall())

        logger.info(f"Downloaded blob from {blob_file_url} to {local_path}")
    except Exception as e:
        logger.error(f"Failed to download {blob_file_url} from blob storage: {str(e)}")
        raise

def get_blob_path(blob_url: str) -> str:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = BlobClient.from_blob_url(
            blob_url,
            credential=blob_service_client.credential
        )
        
        return blob_client.blob_name
    except Exception as e:
        logger.error(f"Failed to get blob path for {blob_url}: {str(e)}")
        raise

def upload_to_blob(local_path: str, blob_path: str, content_type: str="application/pdf") -> str:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob_path)
        content_settings = ContentSettings(content_type=content_type)

        with open(local_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True, content_settings=content_settings)

        logger.info(f"Uploaded {local_path} to blob storage as {blob_client.url}")

        return blob_client.url
    except Exception as e:
        logger.error(f"Failed to upload {local_path} to blob storage: {str(e)}")
        raise

def convert_to_pdf(file_extension: str, file_path: str) -> str:
    output_path = file_path.replace(file_extension, '.pdf')
    # Check if the file is a DOCX
    if file_extension.lower() == '.docx':
        # Convert .docx to PDF
        try:
            doc = Document(file_path)
            pdf = SimpleDocTemplate(output_path)
            elements = []
            styles = getSampleStyleSheet()

            for para in doc.paragraphs:
                elements.append(Paragraph(para.text, styles['Normal']))
                elements.append(Spacer(1, 12))  # Add spacing between paragraphs

            pdf.build(elements)
            logger.info(f"Successfully Converted {file_extension} to PDF")
            return output_path
        except Exception as e:
            logger.error(f"Failed to convert {file_path} to PDF: {str(e)}")
            raise
    # Check if the file is a DOC
    elif file_extension.lower() == '.doc':
        # Convert .doc to PDF
        try:
            document = Document()
            document.LoadFromFile(file_path)

            document.SaveToFile(output_path, FileFormat.PDF)
            document.Close()
            logger.info(f"Successfully Converted {file_extension} to PDF")
            return output_path
        except Exception as e:
            logger.error(f"Failed to convert {file_path} to PDF: {str(e)}")
            raise

    # Check if the file is a PPTX
    elif file_extension.lower() == '.pptx':
        # Convert .pptx to PDF
        try:
            # Create an object of Presentation class
            presentation = Presentation()

            # Load a PPT or PPTX file
            presentation.LoadFromFile(file_path)

            # Convert the presentation file to PDF and save it
            presentation.SaveToFile(output_path, FileFormat.PDF)
            presentation.Dispose()
            logger.info(f"Successfully Converted {file_extension} to PDF")
            return output_path
        except Exception as e:
            logger.error(f"Failed to convert {file_path} to PDF: {str(e)}")
            raise
    
    else:
        raise ValueError(f"Unsupported file extension: {file_extension}")
    