import os
import urllib.parse
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import OperationalError
from contextlib import contextmanager

from ....settings import SETTINGS
from ..models.registry_models import Base
from ....logger.log_handler import get_logger

logger = get_logger(__name__)

if SETTINGS.DATB.FORM.upper() == "PGDB":
    # Access Database Settings
    DB_URL = '{user}:{pswd}@{host}:{port}/{name}'.format(
        host=urllib.parse.quote_plus(SETTINGS.DATB.HOST),  # DB host
        port=urllib.parse.quote_plus(SETTINGS.DATB.PORT),  # DB port
        name=urllib.parse.quote_plus(SETTINGS.DATB.NAME),  # DB name
        user=urllib.parse.quote_plus(SETTINGS.DATB.USER),  # DB user
        pswd=urllib.parse.quote_plus(SETTINGS.DATB.PSWD)   # DB pswd
    )
    DATABASE_URL = f"postgresql://{DB_URL}" 

elif SETTINGS.DATB.FORM.upper() == "SLDB":
    if SETTINGS.DATB.LOCA.lower() == "local":
        # Check/Create Local Database Directory
        if not SETTINGS.DATB.SDIR:
            db_dir = SETTINGS.DATB.RDIR
        else:
            db_dir = os.path.join(SETTINGS.DATB.RDIR, SETTINGS.DATB.SDIR)
        db_dir = os.path.join(SETTINGS.DATB.RDIR, SETTINGS.DATB.SDIR)
        
        if not os.path.exists(db_dir):
            try:
                os.makedirs(db_dir)
            except:
                err_msg = f"Local DB Creation Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.DATB.NAME}> Database"
                logger.error(err_msg)
                raise Exception(err_msg)
            
        # Access Database Settings
        DB_URL = os.path.join(SETTINGS.DATB.RDIR, SETTINGS.DATB.SDIR, SETTINGS.DATB.NAME)

        DATABASE_URL = f"sqlite:///{DB_URL}??check_same_thread=False"

else:
    err_msg = f"Unknown DB Error : <{SETTINGS.DATB.NAME}> Database"
    logger.error(err_msg)
    raise Exception(err_msg)

# Test DB Connection
try:
    engine = create_engine(DATABASE_URL, pool_pre_ping=True)
    with engine.connect():
        logger.info(f"Connected : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.DATB.NAME}> Database")

# Handle any operational errors that might occur
except OperationalError as e:
    err_msg = f"Connection Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.DATB.NAME}> Database"
    logger.error(err_msg)
    raise Exception(err_msg)

# Handle any other exceptions that might occur
except:
    err_msg = f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.DATB.NAME}> Database"
    logger.error(err_msg)
    raise Exception(err_msg)

# Init Table
Base.metadata.create_all(engine)

SessionLocal = sessionmaker(
    autocommit=False, 
    autoflush=False, 
    bind=engine
)

# DB via Function Call
@contextmanager
def get_db_func():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# DB via API Call
def get_db_api():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()