from sqlalchemy import Column, String, Integer, Float, DateTime, JSON, Boolean, UniqueConstraint
from sqlalchemy import Table, MetaData
from sqlalchemy.engine import Engine

from sqlalchemy.orm import declarative_base
from sqlalchemy.sql import func

import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS


def set_io_db_table(table_name: str, engine: Engine):
    Base = declarative_base()

    class IOKnowledgeInputDB(Base):

        __tablename__ = table_name

        # Trace Information
        knowledgeinput_id            = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True, unique=True)
        knowledgeinput_traceid       = Column(String,  default=lambda: str(uuid.uuid4())) # trace the changes of knowledgeinput
        knowledgeinput_version       = Column(Integer, default=1)   # 1=original    
        knowledgeinput_name          = Column(String,  default='')

        # Category Information
        knowledgeinput_group         = Column(String,  default='default') # default, user, group, agent
        knowledgeinput_type          = Column(String,  default="default") # general, chain-of-thought
        knowledgeinput_location      = Column(String,  default='default')
        storage_type                 = Column(String,  default='default')
        storage_type_origin          = Column(String,  default='default')
        storage_provider             = Column(String,  default='default')
        storage_provider_origin      = Column(String,  default='default')
        storage_directory            = Column(String,  default='')
        storage_directory_origin     = Column(String,  default='')
        storage_secrets              = Column(JSON,    default=dict())
        storage_secrets_origin       = Column(JSON,    default=dict())
        
        # Control Information
        knowledgeinput_status        = Column(Integer, default=1)   # 0=inactvie, 1=active
        knowledgeinput_permission    = Column(Integer, default=1)   # 0=default, related to user permission
        knowledgeinput_management    = Column(Integer, default=10)  # relate to management permission

        # Configuration
        knowledgeinput_secrets       = Column(JSON,    default=dict())
        knowledgeinput_record        = Column(Boolean, default=False)
        knowledgeinput_key           = Column(String,  default='')

        # Specification
        knowledgeinput_filename      = Column(String,  default='')
        knowledgeinput_fileextension = Column(String,  default='')
        knowledgeinput_filesize      = Column(Float,   default=0.0)

        # Tags
        _knowledgeinput_tags         = Column("knowledgeinput_tags",  String, default='')
        
        # Creator Information
        creator_id                   = Column(String,  default='') # user or group ID
        creator_name                 = Column(String,  default='') # user or group name
        approver_id                  = Column(String,  default='admin')
        approver_name                = Column(String,  default='admin')
        
        # Time Information
        created_at                   = Column(DateTime(timezone=True), server_default=func.now(), default=datetime.now(timezone.utc))
        updated_at                   = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), default=datetime.now(timezone.utc))

        @property
        def knowledgeinput_tags(self):
            """Convert value from str to list."""
            if self._knowledgeinput_tags:
                return [value.strip() for value in self._knowledgeinput_tags.split(SETTINGS.DATB.SEP)]
            return []

        @knowledgeinput_tags.setter
        def knowledgeinput_tags(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._knowledgeinput_tags = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._knowledgeinput_tags = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        def to_dict(self):
            return {**self.__dict__,
                "knowledgeinput_tags":  self.knowledgeinput_tags
            }

        # __table_args__ = (
        #     UniqueConstraint("prompt_group", "prompt_name", "prompt_version", name="skill_name-version"),
        # )
    
    Base.metadata.create_all(engine)
    return IOKnowledgeInputDB

def get_io_db_table(table_name: str, engine: Engine) -> Table:
    metadata = MetaData()
    table = Table(table_name, metadata, autoload_with=engine)
    return table