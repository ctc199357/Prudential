import os
import shutil

from ..settings import SETTINGS

from ..utils import normalize_path

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

if SETTINGS.BASE.APP_FUNC == False and SETTINGS.BASE.APP_API == False:
    err_msg = f"Failed to Inititate <{SETTINGS.BASE.APP_NAME}> : APP_FUNC and APP_API cannot be ALL False"
    logger.error(err_msg)
    raise Exception(err_msg)

def init_temp_storage():
    # Init Temp Storage
    if SETTINGS.KWIN.STORAGE_TEMP_LOCA.upper() == "LOCAL":
        # Check/Create Local Temp Storage
        if not SETTINGS.KWIN.STORAGE_TEMP_SDIR:
            temp_storage_dir = SETTINGS.KWIN.STORAGE_TEMP_RDIR
        else:
            temp_storage_dir = os.path.join(SETTINGS.KWIN.STORAGE_TEMP_RDIR, SETTINGS.KWIN.STORAGE_TEMP_SDIR)
        temp_storage_dir = os.path.join(SETTINGS.KWIN.STORAGE_TEMP_RDIR, SETTINGS.KWIN.STORAGE_TEMP_SDIR)
        
        if SETTINGS.KWIN.STORAGE_TEMP_INIT and os.path.exists(temp_storage_dir):
            try:
                temp_storage_dir = normalize_path(temp_storage_dir)
                shutil.rmtree(temp_storage_dir)
            except:
                err_msg = f"Local Temp Storage Init Error : <{SETTINGS.BASE.APP_NAME}> Failed to Clear Local Storage <{temp_storage_dir}>"
                logger.error(err_msg)
                raise Exception(err_msg)
        
        if not os.path.exists(temp_storage_dir):
            try:
                os.makedirs(temp_storage_dir)
            except:
                err_msg = f"Local Temp Storage Creation Error : <{SETTINGS.BASE.APP_NAME}> Failed to Create Local Storage <{temp_storage_dir}>"
                logger.error(err_msg)
                raise Exception(err_msg)

init_temp_storage()

# Init Perm Storage
if SETTINGS.KWIN.STORAGE_PERM_LOCA.upper() == "LOCAL":
    # Check/Create Local Temp Storage
    if not SETTINGS.KWIN.STORAGE_PERM_SDIR:
        perm_storage_dir = SETTINGS.KWIN.STORAGE_PERM_RDIR
    else:
        perm_storage_dir = os.path.join(SETTINGS.KWIN.STORAGE_PERM_RDIR, SETTINGS.KWIN.STORAGE_PERM_SDIR)
    perm_storage_dir = os.path.join(SETTINGS.KWIN.STORAGE_PERM_RDIR, SETTINGS.KWIN.STORAGE_PERM_SDIR)
    
    if not os.path.exists(perm_storage_dir):
        try:
            os.makedirs(perm_storage_dir)
        except:
            err_msg = f"Local Perm Storage Creation Error : <{SETTINGS.BASE.APP_NAME}> Failed to Create Local Storage <{temp_storage_dir}>"
            logger.error(err_msg)
            raise Exception(err_msg)