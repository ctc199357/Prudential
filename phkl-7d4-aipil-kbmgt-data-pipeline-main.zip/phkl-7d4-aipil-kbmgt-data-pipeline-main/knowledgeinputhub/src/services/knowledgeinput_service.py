from datetime import datetime, timezone
import time
import os
import shutil
import inspect
from sqlalchemy.orm import Session
import urllib.parse

from ..settings import SETTINGS

from ..utils import (
    download_from_blob_by_url, 
    get_blob_file_size, 
    get_blob_path,
    upload_to_blob,
    convert_to_pdf
)

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.knowledgeinput import(
    KnowledgeInputCreate,
    KnowledgeInputCreateRequest,
    KnowledgeInputUploadObject,
    KnowledgeInputObject,
    KnowledgeInputUploadRequest,
    KnowledgeInputUploadResponse,
    KnowledgeInputIngestObject,
    KnowledgeInputIngestRequest,
    KnowledgeInputIngestResponse
)

from ..routers.registry.general import (
    general_create_knowledgeinput
)

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class KnowledgeInputServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool):
        self.api_call = api_call

    """
        Request Operation
    """
    def knowledgeinput_upload(self, request: KnowledgeInputUploadRequest) -> tuple[KnowledgeInputUploadResponse, Response]:
        """
            Directly upload file to temp storage via API call 
        """
        response_knowledgeinput = KnowledgeInputUploadResponse(**request.__dict__)
        start_at = time.time()

        _knowledgeinput_success_objects = []
        _knowledgeinput_fail_objects    = []
        for i, _upload_object in enumerate(request.knowledgeinput_uploads, start=1):
            input_object, response = self.upload_temp_storage(upload_object=_upload_object)
            input_object.knowledgeinput_sequence = i

            if response.status_code <= SETTINGS.STAT.SUCC_CODE_END:
                _knowledgeinput_success_objects.append(input_object)
            else:
                _knowledgeinput_fail_objects.append(input_object)
        
        response_knowledgeinput.__dict__.update(
            knowledgeinput_success_objects = _knowledgeinput_success_objects,
            knowledgeinput_fail_objects    = _knowledgeinput_fail_objects,
            knowledgeinput_total_no        = len(request.knowledgeinput_uploads),
            knowledgeinput_success_no      = len(_knowledgeinput_success_objects),
            knowledgeinput_fail_no         = len(_knowledgeinput_fail_objects),
            knowledgeinput_upload_time     = time.time() - start_at,
            knowledgeinput_response_at     = datetime.now(timezone.utc)
        )

        response = Response(status_code=200, detail=self.response_format.ok(f"KnowledgeInput Upload Completed : <{SETTINGS.BASE.APP_NAME}> Completed File Uploading to Temp Storage"))

        return response_knowledgeinput, response


    def upload_temp_storage(self, upload_object: KnowledgeInputUploadObject) -> tuple[KnowledgeInputObject, Response]:
       
        # Define Origin Storage Type and Provider
        input_object = KnowledgeInputObject(storage_type_origin = 'API')

        # Get File Name and Size
        try:
            _filename, _fileextension = os.path.splitext(upload_object.upload_file.filename)
            _filesize = upload_object.upload_file.size

            input_object.knowledgeinput_filename      = _filename
            input_object.knowledgeinput_fileextension = _fileextension
            input_object.knowledgeinput_filesize      = _filesize 
        
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"UploadFile Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve File Name / Size from UploadFile"))
            logger.error(response.detail)
            return input_object, response

        if SETTINGS.KWIN.STORAGE_TEMP_LOCA.upper() == 'LOCAL':
            storage_type     = SETTINGS.KWIN.STORAGE_TEMP_LOCA.upper()
            storage_provider = 'LOCAL'
            temp_file_path   = os.path.join(SETTINGS.KWIN.STORAGE_TEMP_RDIR, SETTINGS.KWIN.STORAGE_TEMP_SDIR, _filename + _fileextension)
            
            # Check if File Exists
            if os.path.isfile(temp_file_path):
                response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Upload Failed : <{SETTINGS.BASE.APP_NAME}> Found Existing <{_filename}> in Temp Storage"))
                logger.error(response.detail)

            else:
                try:
                    with open(temp_file_path, "wb+") as temp_file:
                        shutil.copyfileobj(upload_object.upload_file, temp_file)
                    logger.info(f"Upload File Success : <{SETTINGS.BASE.APP_NAME}> Uploaded File <{_filename}> to Temp Storage")
                    
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Upload Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Upload File <{_filename}> to Temp Storage"))
                    logger.error(response.detail)

        else:
            response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unrecognized Temp Storage Location"))
            logger.error(response.detail)

        # Update Input Object Info
        input_object.__dict__.update(
            storage_type             = storage_type,
            storage_provider         = storage_provider,
            storage_directory        = temp_file_path,
            storage_directory_origin = upload_object.storage_directory_origin,
        )
        
        return input_object, response

    
    def knowledgeinput_ingest(self, request: KnowledgeInputIngestRequest) -> tuple[KnowledgeInputIngestResponse | None, Response]:
        response_knowledgeinput = KnowledgeInputIngestResponse(**request.__dict__)
        start_at = time.time()

        # Check if Empty Ingestion
        if not request.knowledgeinput_creates:
            response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Found Empty <knowledgeinput_creates>"))
            logger.error(response.detail)
            return response_knowledgeinput, response
        
        _knowledgeinput_success_objects = []
        _knowledgeinput_fail_objects    = []
        for i, ingest_object in enumerate(request.knowledgeinput_creates, start=1):
            if ingest_object.storage_type_origin.upper() == "API":
                create_object, response = self.ingest_api(ingest_object=ingest_object)

            elif ingest_object.storage_type_origin.upper() == "LOCAL":
                create_object, response = self.ingest_local(ingest_object=ingest_object)
            
            elif ingest_object.storage_type_origin.upper() == "AZURE":
                create_object, response = self.ingest_azure(ingest_object=ingest_object)

            else:
                response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unrecognized Storage Origin"))
                create_object = ingest_object

            # Register the Object on KnowledgeInput DB
            if response.status_code <= SETTINGS.STAT.SUCC_CODE_END:
                response = self.ingest_registration(request=request, data=ingest_object)

            # Define Status Code
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                _knowledgeinput_code = SETTINGS.KWIN.STATUS_CODE.get("FAIL")
            else:
                _knowledgeinput_code = SETTINGS.KWIN.STATUS_CODE.get("SUCCESS")

            # Parsing Ingestion Result
            result_object = KnowledgeInputIngestObject(
                **create_object.__dict__, 
                knowledgeinput_sequence = i,
                knowledgeinput_code     = _knowledgeinput_code, 
                knowledgeinput_reason   = response.detail
            )

            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                _knowledgeinput_fail_objects.append(result_object)
            else:
                _knowledgeinput_success_objects.append(result_object)


        # Update Response
        response_knowledgeinput.__dict__.update(
            knowledgeinput_success_objects = _knowledgeinput_success_objects,
            knowledgeinput_fail_objects    = _knowledgeinput_fail_objects,
            knowledgeinput_total_no        = len(request.knowledgeinput_creates),
            knowledgeinput_success_no      = len(_knowledgeinput_success_objects),
            knowledgeinput_fail_no         = len(_knowledgeinput_fail_objects),
            knowledgeinput_upload_time     = time.time() - start_at,
            knowledgeinput_response_at     = datetime.now(timezone.utc)
        )

        response = Response(status_code=200, detail=self.response_format.ok(f"KnowledgeInput Ingest Completed : <{SETTINGS.BASE.APP_NAME}> Completed Ingesting and Registering KnowledgeInput to Temp Storage"))

        return response_knowledgeinput, response
    
    def ingest_security_check(self, ingest_object: KnowledgeInputCreate) -> Response:
        if ingest_object.storage_type_origin == 'LOCAL':
            if ".." in ingest_object.storage_directory_origin or ".." in ingest_object.knowledgeinput_filename:
                response = Response(status_code=403, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Declined Relative Path while Ingesting Knowledge from Local"))
                logger.error(response.detail)
                return response
            
        # elif ingest_object.storage_type_origin == 'AZURE':
        # blob_url_prefix = f"https://{SETTINGS.BLOB.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BLOB.CONTAINER_NAME}/"
        # if not ingest_object.storage_directory_origin.startswith(blob_url_prefix):
        #     response = Response(status_code=403, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Declined Invalid Blob URL Format while Ingesting Knowledge from Azure"))
        #     logger.error(response.detail)
        #     return response

        response = Response(status_code=200, detail=self.response_format.ok("KnowledgeInput Ingestion Security Check Passed"))
        return response

    def ingest_api(self, ingest_object: KnowledgeInputCreate) -> tuple[KnowledgeInputCreate, Response]:
        ingest_object.storage_type_origin = 'API'

        """ 1. Parsing KnowledgeInput Object """
        # Check whether Directory of Temp Storage is Given, as API should be ingested via upload
        if not ingest_object.storage_directory:
            response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Found Empty <storage_directory> while Ingesting Knowledge from API"))
            logger.error(response.detail)
            return ingest_object, response

        # Check Origin Directory
        if not ingest_object.storage_directory_origin:
            response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Found Empty <storage_directory_origin> while Ingesting Knowledge from API"))
            logger.error(response.detail)
            return ingest_object, response
        
        # Check Filename
        if not ingest_object.knowledgeinput_filename or not ingest_object.knowledgeinput_fileextension:
            try:
                _file = ingest_object.storage_directory_origin.split(os.path.sep)[-1]
                ingest_object.knowledgeinput_filename, ingest_object.knowledgeinput_fileextension = os.path.splitext(_file)
            except:
                response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Parse File Name while Ingesting Knowledge from API"))
                logger.error(response.detail)
                return ingest_object, response
        
        # Convert docs, ppt to pdf
        if ingest_object.knowledgeinput_fileextension.lower() != '.pdf':
            try:
                ingest_object.storage_directory_origin = convert_to_pdf(ingest_object.knowledgeinput_fileextension, ingest_object.storage_directory_origin)
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Convert File to PDF while Ingesting Knowledge from API"))
                logger.error(response.detail)
                return ingest_object, response
            
        # Check Filesize
        if not ingest_object.knowledgeinput_filesize:
            try:
                ingest_object.knowledgeinput_filesize = os.path.getsize(ingest_object.storage_directory_origin)
            except:
                response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Get File Size while Ingesting Knowledge from API"))
                logger.error(response.detail)
                return ingest_object, response

        # Check KnowledgeInput Name
        if not ingest_object.knowledgeinput_name:
            ingest_object.knowledgeinput_name = ingest_object.knowledgeinput_filename

        """ 2. Knowledge Security Check """
        response = self.ingest_security_check(ingest_object=ingest_object)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return ingest_object, response
        
        response = Response(status_code=200, detail=self.response_format.ok(f"Temp Storage Ingestion Completed : <{SETTINGS.BASE.APP_NAME}> Completed Ingesting KnowledgeInput into Temp Storage via API"))

        return ingest_object, response

    def ingest_local(self, ingest_object: KnowledgeInputCreate) -> tuple[KnowledgeInputCreate, Response]:
        ingest_object.storage_type_origin     = 'LOCAL'
        ingest_object.storage_provider_origin = 'LOCAL'

        """ 1. Parsing KnowledgeInput Object """
        # Check Origin Directory
        if not ingest_object.storage_directory_origin:
            response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Found Empty <storage_directory_origin> while Ingesting Knowledge from Local"))
            logger.error(response.detail)
            return ingest_object, response
        
        # Check Filename
        if not ingest_object.knowledgeinput_filename or not ingest_object.knowledgeinput_fileextension:
            try:
                _file = ingest_object.storage_directory_origin.split(os.path.sep)[-1]
                ingest_object.knowledgeinput_filename, ingest_object.knowledgeinput_fileextension = os.path.splitext(_file)
            except:
                response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Parse File Name while Ingesting Knowledge from Local"))
                logger.error(response.detail)
                return ingest_object, response

        # Check Filesize
        if not ingest_object.knowledgeinput_filesize:
            try:
                ingest_object.knowledgeinput_filesize = os.path.getsize(ingest_object.storage_directory_origin)
            except:
                response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Get File Size while Ingesting Knowledge from Local"))
                logger.error(response.detail)
                return ingest_object, response

        # Check KnowledgeInput Name
        if not ingest_object.knowledgeinput_name:
            ingest_object.knowledgeinput_name = ingest_object.knowledgeinput_filename

        """ 2. Knowledge Security Check """
        response = self.ingest_security_check(ingest_object=ingest_object)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return ingest_object, response

        """ 3. Copy File to Temp Storage """
        if SETTINGS.KWIN.STORAGE_TEMP_LOCA.upper() == 'LOCAL':
            ingest_object.storage_type     = SETTINGS.KWIN.STORAGE_TEMP_LOCA.upper()
            ingest_object.storage_provider = 'LOCAL'
            
            # os.makedirs(os.path.join(SETTINGS.KWIN.STORAGE_TEMP_RDIR, SETTINGS.KWIN.STORAGE_TEMP_SDIR), exist_ok=True)
            temp_file_path = os.path.join(SETTINGS.KWIN.STORAGE_TEMP_RDIR, SETTINGS.KWIN.STORAGE_TEMP_SDIR, ingest_object.knowledgeinput_filename + ingest_object.knowledgeinput_fileextension)

            # Check if File Exists
            if os.path.isfile(temp_file_path):
                response = Response(status_code=500, detail=self.response_format.error(f"KnowledgeInput Ingest Failed : <{SETTINGS.BASE.APP_NAME}> Found Existing <{ingest_object.knowledgeinput_filename + ingest_object.knowledgeinput_fileextension}> in Temp Storage"))
                logger.error(response.detail)
                return ingest_object, response

            try:
                shutil.copyfile(ingest_object.storage_directory_origin, temp_file_path) 
                ingest_object.storage_directory = temp_file_path
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Ingestion Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Ingest File <{ingest_object.knowledgeinput_filename + ingest_object.knowledgeinput_fileextension}> to Temp Storage from Local"))
                logger.error(response.detail)
                return ingest_object, response
            
            if ingest_object.knowledgeinput_fileextension.lower() != '.pdf':
                # Convert docs, ppt to pdf
                try:
                    ingest_object.storage_directory = convert_to_pdf(ingest_object.knowledgeinput_fileextension, ingest_object.storage_directory)
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Convert File to PDF while Ingesting Knowledge from Local"))
                    logger.error(response.detail)
                    return ingest_object, response

        else:
            response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unrecognized Temp Storage Location when Ingesting from Local"))
            logger.error(response.detail)
            return ingest_object, response
        
        response = Response(status_code=200, detail=self.response_format.ok(f"Temp Storage Ingestion Completed : <{SETTINGS.BASE.APP_NAME}> Completed Ingesting KnowledgeInput into Temp Storage via Local"))
        return ingest_object, response
    
    def ingest_azure(self, ingest_object: KnowledgeInputCreate) -> tuple[KnowledgeInputCreate, Response]:
        ingest_object.storage_type_origin     = 'AZURE'
        ingest_object.storage_provider_origin = 'AZURE'

        """ 1. Parsing KnowledgeInput Object """
        # Check Origin Directory
        if not ingest_object.storage_directory_origin:
            response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Found Empty <storage_directory_origin> while Ingesting Knowledge from Azure"))
            logger.error(response.detail)
            return ingest_object, response
        
        # Check Filename
        # if not ingest_object.knowledgeinput_filename or not ingest_object.knowledgeinput_fileextension:
        try:
            pdf_blob_url = urllib.parse.unquote(ingest_object.storage_directory_origin)
            _file = pdf_blob_url.split('/')[-1]
            ingest_object.knowledgeinput_filename, ingest_object.knowledgeinput_fileextension = os.path.splitext(_file)
        except:
            response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Parse File Name while Ingesting Knowledge from Azure"))
            logger.error(response.detail)
            return ingest_object, response
            
        # Check Filesize
        if not ingest_object.knowledgeinput_filesize:
            try:
                ingest_object.knowledgeinput_filesize = get_blob_file_size(ingest_object.storage_directory_origin)
            except:
                response = Response(status_code=404, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Get File Size while Ingesting Knowledge from Azure"))
                logger.error(response.detail)
                return ingest_object, response

        """ 2. Knowledge Security Check """
        response = self.ingest_security_check(ingest_object=ingest_object)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return ingest_object, response

        """ 3. Download File from Azure Blob Storage """
        if SETTINGS.KWIN.STORAGE_TEMP_LOCA.upper() == 'LOCAL':
            ingest_object.storage_type     = SETTINGS.KWIN.STORAGE_TEMP_LOCA.upper()
            ingest_object.storage_provider = 'LOCAL'
            
            temp_file_path = os.path.join(SETTINGS.KWIN.STORAGE_TEMP_RDIR, SETTINGS.KWIN.STORAGE_TEMP_SDIR, ingest_object.knowledgeinput_filename + ingest_object.knowledgeinput_fileextension)

            # Check if File Exists
            if os.path.isfile(temp_file_path):
                response = Response(status_code=500, detail=self.response_format.error(f"KnowledgeInput Ingest Failed : <{SETTINGS.BASE.APP_NAME}> Found Existing <{ingest_object.knowledgeinput_filename + ingest_object.knowledgeinput_fileextension}> in Temp Storage"))
                logger.error(response.detail)
                return ingest_object, response

            # Download File from Azure Blob Storage
            try:
                download_from_blob_by_url(ingest_object.storage_directory_origin, temp_file_path)
                ingest_object.storage_directory = temp_file_path
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Ingestion Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Ingest File <{ingest_object.knowledgeinput_filename + ingest_object.knowledgeinput_fileextension}> to Temp Storage from Azure"))
                logger.error(response.detail)
                return ingest_object, response
            
            if ingest_object.knowledgeinput_fileextension.lower() != '.pdf':
                # Convert docs, ppt to pdf
                try:
                    ingest_object.storage_directory = convert_to_pdf(ingest_object.knowledgeinput_fileextension, ingest_object.storage_directory)
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Convert File to PDF while Ingesting Knowledge from Local"))
                    logger.error(response.detail)
                    return ingest_object, response
                
                # Upload Local Temporary PDF to Original Azure Blob Storage
                try:
                    blob_path = get_blob_path(ingest_object.storage_directory_origin)
                    blob_path = blob_path.replace(ingest_object.knowledgeinput_filename + ingest_object.knowledgeinput_fileextension, ingest_object.knowledgeinput_filename + '.pdf')
                    blob_file_url = upload_to_blob(ingest_object.storage_directory, blob_path, 'application/pdf')
                    ingest_object.knowledgeinput_fileextension = '.pdf'
                    ingest_object.storage_directory_origin = blob_file_url
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"KnowledgeInput Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Update PDF File to Azure while Ingesting Knowledge from Local"))
                    logger.error(response.detail)
                    return ingest_object, response

        else:
            response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unrecognized Temp Storage Location when Ingesting from Azure"))
            logger.error(response.detail)
            return ingest_object, response
        
        response = Response(status_code=200, detail=self.response_format.ok(f"Temp Storage Ingestion Completed : <{SETTINGS.BASE.APP_NAME}> Completed Ingesting KnowledgeInput into Temp Storage via Azure"))
        return ingest_object, response

    def ingest_registration(self, request: KnowledgeInputIngestRequest, data: KnowledgeInputCreate) -> Response:
        create_request = KnowledgeInputCreateRequest(**request.__dict__, data=data)
        response = general_create_knowledgeinput(
            request  = create_request, 
            api_call = self.api_call
        )
        
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            if data.storage_type == 'LOCAL' and data.storage_directory:
                try:
                    shutil.rmtree(data.storage_directory)
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Ingestion Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Register KnowledgeInput and Unable to Delete File <{data.knowledgeinput_name}> in Temp Storage during Local Ingestion"))
                    logger.error(response.detail)
        else:
            response = Response(status_code=200, detail=self.response_format.ok(f"KnowledgeInput Registration Completed : <{SETTINGS.BASE.APP_NAME}> Completed Ingestion and Registration for KnowledgeInput <{data.knowledgeinput_name}>"))
        
        return response