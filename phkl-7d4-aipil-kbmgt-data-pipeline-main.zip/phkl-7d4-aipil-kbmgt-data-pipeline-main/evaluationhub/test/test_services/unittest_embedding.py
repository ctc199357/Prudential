import unittest
from unittest.mock import Mock, patch
from datetime import datetime
import httpx
from src.services.embedding import EmbeddingServiceManager, EmbeddingRequest, EmbeddingResponse, EmbeddingEngine
from src.schemas.format import Response
from src.settings import SETTINGS

class TestEmbeddingServiceManager(unittest.TestCase):
    def setUp(self):
        """Set up the test fixture before each test method."""
        # Define a default engine for consistency across tests
        self.default_engine = EmbeddingEngine(
            embedding_location="server",
            embedding_engine="ollama",
            embedding_host="localhost",
            embedding_port="11434",
            embedding_api="api/embed",
            embedding_base="nomic-embed-text",
            embedding_key="dummy_key",
            embedding_timeout=30
        )
        EmbeddingServiceManager.default_engine = self.default_engine

    def test_text_embedding_default_engine_ollama_success(self):
        """Test successful embedding with default engine (Ollama)."""
        # Mock HTTP response for Ollama server
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "embeddings": [[0.1, 0.2], [0.3, 0.4]],
            "prompt_eval_count": 10
        }

        with patch('httpx.post', return_value=mock_response):
            manager = EmbeddingServiceManager()
            request = EmbeddingRequest(data_input=["Hello", "World"])
            response_data, response = manager.text_embedding(request)

            # Assertions
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response_data.data_output, [[0.1, 0.2], [0.3, 0.4]])
            self.assertEqual(response_data.embedding_tokens, 10)
            self.assertIsInstance(response_data.response_at, datetime)
            self.assertGreater(response_data.embedding_time, 0)

    def test_text_embedding_azure_success(self):
        """Test successful embedding with an Azure engine."""
        azure_engine = EmbeddingEngine(
            embedding_location="azure",
            embedding_host="https://example.openai.azure.com",
            embedding_base="text-embedding-ada-002",
            embedding_key="azure_key",
            embedding_secrets={"api_version": "2023-05-15"}
        )
        EmbeddingServiceManager.default_engine = azure_engine

        # Mock AzureOpenAI response
        mock_resp = Mock()
        mock_resp.data = [Mock(embedding=[0.1, 0.2]), Mock(embedding=[0.3, 0.4])]
        mock_resp.usage.total_tokens = 15

        with patch('openai.AzureOpenAI') as mock_azure:
            mock_client = mock_azure.return_value
            mock_client.embeddings.create.return_value = mock_resp

            manager = EmbeddingServiceManager()
            request = EmbeddingRequest(data_input=["Hello", "World"])
            response_data, response = manager.text_embedding(request)

            # Assertions
            self.assertEqual(response.status_code, 200)
            self.assertEqual(response_data.data_output, [[0.1, 0.2], [0.3, 0.4]])
            self.assertEqual(response_data.embedding_tokens, 15)

    def test_text_embedding_ollama_server_error(self):
        """Test when Ollama server returns an error."""
        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.json.return_value = {"error": "Server error"}

        with patch('httpx.post', return_value=mock_response):
            manager = EmbeddingServiceManager()
            request = EmbeddingRequest(data_input=["Hello"])
            response_data, response = manager.text_embedding(request)

            # Adjusted to match the actual server error message
            self.assertIn("Server error", response.detail)
            self.assertEqual(response.status_code, 500)
            self.assertEqual(response_data.data_output, [])  # No embeddings returned

    def test_text_embedding_azure_timeout(self):
        """Test timeout error with Azure engine."""
        azure_engine = EmbeddingEngine(
            embedding_location="azure",
            embedding_host="https://example.openai.azure.com",
            embedding_base="text-embedding-ada-002",
            embedding_key="azure_key"
        )
        EmbeddingServiceManager.default_engine = azure_engine

        with patch('openai.AzureOpenAI') as mock_azure:
            mock_client = mock_azure.return_value
            mock_client.embeddings.create.side_effect = httpx.TimeoutException("Timeout")

            manager = EmbeddingServiceManager()
            request = EmbeddingRequest(data_input=["Hello"])
            response_data, response = manager.text_embedding(request)

            # Assertions
            self.assertEqual(response.status_code, 502)
            self.assertIn("Timeout Error", response.detail)

    def test_text_embedding_length_mismatch(self):
        """Test when the number of embeddings doesn't match input data."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "embeddings": [[0.1, 0.2]],  # Only one embedding for two inputs
            "prompt_eval_count": 10
        }

        with patch('httpx.post', return_value=mock_response):
            manager = EmbeddingServiceManager()
            request = EmbeddingRequest(data_input=["Hello", "World"])
            response_data, response = manager.text_embedding(request)

            # Assertions
            self.assertEqual(response.status_code, 500)
            self.assertIn("Unequal Number between Raw Data and Processed Data", response.detail)

    def test_text_embedding_unrecognized_location(self):
        """Test with an unrecognized engine location."""
        unrecognized_engine = EmbeddingEngine(embedding_location="unknown")
        EmbeddingServiceManager.default_engine = unrecognized_engine

        manager = EmbeddingServiceManager()
        request = EmbeddingRequest(data_input=["Hello"])
        response_data, response = manager.text_embedding(request)

        # Assertions
        self.assertEqual(response.status_code, 404)
        self.assertIn("Failed to Perform Embedding", response.detail)

    def test_text_embedding_unrecognized_engine(self):
        """Test with 'server' location but unrecognized engine."""
        unrecognized_engine = EmbeddingEngine(embedding_location="server", embedding_engine="unknown")
        EmbeddingServiceManager.default_engine = unrecognized_engine

        manager = EmbeddingServiceManager()
        request = EmbeddingRequest(data_input=["Hello"])
        response_data, response = manager.text_embedding(request)

        # Assertions
        self.assertEqual(response.status_code, 404)
        self.assertIn("Failed to Perform Embedding", response.detail)

    def test_init_engine_default(self):
        """Test initializing with the default engine."""
        manager = EmbeddingServiceManager()
        response = manager.init_engine()

        # Assertions
        self.assertEqual(response.status_code, 200)
        self.assertIn("Init Embedding Completed", response.detail)
        self.assertEqual(manager.engine, EmbeddingServiceManager.default_engine)

    def test_init_engine_provided(self):
        """Test initializing with a provided engine."""
        custom_engine = EmbeddingEngine(embedding_location="azure")
        manager = EmbeddingServiceManager()
        response = manager.init_engine(engine=custom_engine)

        # Assertions
        self.assertEqual(response.status_code, 200)
        self.assertIn("Init Embedding Completed", response.detail)
        self.assertEqual(manager.engine, custom_engine)

    def test_init_engine_unrecognized_location(self):
        """Test initializing with an unrecognized engine location."""
        custom_engine = EmbeddingEngine(embedding_location="unknown")
        manager = EmbeddingServiceManager()
        response = manager.init_engine(engine=custom_engine)

        # Adjusted to match the typo in the actual message
        self.assertIn("Cannot Recognie Embedding Engine Location", response.detail)
        self.assertEqual(response.status_code, 404)

if __name__ == '__main__':
    unittest.main()