import unittest
from unittest.mock import Mock, patch
from src.services.chatflow import (
    ChatFlowServiceManager,
    ChatQueryBody,
    ChatQueryResponse,
    Response,
    CitationObject,
    RespCitation,
    InferenceRequest,
    InferenceInput,
    KnowledgeRetrievalRequest,
    KnowledgeRetrievalResponse,
    SummarizationRequest,
)
from src.schemas.chatflow import(
    CustomField,
    ChatHistoryItem
)
from src.settings import SETTINGS

class TestChatFlowServiceManager(unittest.TestCase):
    def setUp(self):
        """Set up the test fixture before each test method."""
        # Initialize the ChatFlowServiceManager with api_call=False to avoid real API calls
        self.service_manager = ChatFlowServiceManager(api_call=False)
        
        # Mock external service managers
        self.mock_summarization = Mock()
        self.mock_inference = Mock()
        
        # Patch the external services used by ChatFlowServiceManager
        self.patcher_summarization = patch(
            'src.services.chatflow.SummarizationServiceManager',
            return_value=self.mock_summarization
        )
        self.patcher_inference = patch(
            'src.services.chatflow.InferenceServiceManager',
            return_value=self.mock_inference
        )
        
        # Start the patches
        self.patcher_summarization.start()
        self.patcher_inference.start()
    def tearDown(self):
        """Clean up after each test method."""
        # Stop all patches
        self.patcher_summarization.stop()
        self.patcher_inference.stop()

    def test_chat_query_success_with_history(self):
        SETTINGS.BASE.APP_FUNC = False
        SETTINGS.STAT.SUCC_CODE_END = 300

        request = ChatQueryBody(
            query="What is the capital of France?",
            rationale="Testing chat query",
            chat_history=[ChatHistoryItem(session_id="123", role="human", content="Hello", unix_time=1234567890)],
            custom_field=CustomField(agent_id="agent1", pru_force_lang="en")
        )

        # Mock summarization
        mock_summarization_response = Mock()
        mock_summarization_response.standalone_query = "Summarized query: What is the capital of France?"
        self.mock_summarization.history_summarization.return_value = (
            mock_summarization_response,
            Response(status_code=200, detail="Success")
        )

        # Mock knowledge retrieval
        citation = CitationObject(document_name="doc1", hyperlink="http://example.com")
        self.service_manager.knowledge_retrieval = Mock()
        self.service_manager.knowledge_retrieval.return_value = (
            KnowledgeRetrievalResponse(
                retrieval_requestid="123",
                citations=[citation],
                citation_count=1
            ),
            Response(status_code=200, detail="Retrieval success")
        )

        # Mock prompt formation
        self.service_manager.prompt_formation = Mock()
        self.service_manager.prompt_formation.return_value = ("System prompt text.", Response(status_code=200, detail="Success"))

        # Mock inference response
        mock_inference_output = Mock()
        mock_inference_output.inference_output = Mock()
        mock_inference_output.inference_output.text = "The capital of France is Paris."
        self.mock_inference.inference_engine.return_value = (
            mock_inference_output,
            Response(status_code=200, detail="Inference success")
        )

        # Call the method
        response_chatflow, response = self.service_manager.chat_query(request)

        # Assertions
        self.assertIsInstance(response_chatflow, ChatQueryResponse)
        self.assertEqual(response_chatflow.response, "The capital of France is Paris.")
        self.assertEqual(len(response_chatflow.citations), 1)
        self.assertIsInstance(response_chatflow.citations[0], RespCitation)
        self.assertEqual(response_chatflow.citations[0].document_name, "doc1")
        self.assertEqual(response.status_code, 200)

    def test_chat_query_summarization_error(self):
        """Test chat_query when summarization fails."""
        # Mock input
        request = ChatQueryBody(
            query="What is the capital of France?",
            rationale="Testing error",
            chat_history=[ChatHistoryItem(session_id="123", role="human", content="Hello", unix_time=1234567890)],
            custom_field=CustomField(agent_id="agent1", pru_force_lang="en")
        )

        # Mock summarization error
        self.mock_summarization.history_summarization.return_value = (
            None,
            Response(status_code=500, detail="Summarization failed")
        )

        # Call the method
        response_chatflow, response = self.service_manager.chat_query(request)

        # Assertions
        self.assertEqual(response_chatflow.response, SETTINGS.RESP.SUMMARIZATION_ERR)
        self.assertEqual(response.status_code, 500)

    def test_chat_query_no_knowledge_retrieved(self):
        """Test chat_query when no knowledge is retrieved."""
        # Mock input
        request = ChatQueryBody(
            query="What is XYZ?",
            rationale="Testing no knowledge",
            chat_history=[],
            custom_field=CustomField(agent_id="agent1", pru_force_lang="en")
        )

        # Mock knowledge retrieval with no citations
        self.service_manager.knowledge_retrieval = Mock()
        self.service_manager.knowledge_retrieval.return_value = (
            KnowledgeRetrievalResponse(
                retrieval_requestid="123",
                citations=[],
                citation_count=0
            ),
            Response(status_code=200, detail="Retrieval success")
        )

        # Call the method
        response_chatflow, response = self.service_manager.chat_query(request)

        # Assertions
        self.assertEqual(response_chatflow.response, SETTINGS.RESP.NO_KNOWLEDGE)
        self.assertEqual(len(response_chatflow.citations), 0)
        self.assertEqual(response.status_code, 200)

    
    def test_chat_query_inference_error(self):
        """Test chat_query when inference fails."""
        # Mock input
        request = ChatQueryBody(
            query="What is the capital of France?",
            rationale="Testing inference error",
            chat_history=[],
            custom_field=CustomField(agent_id="agent1", pru_force_lang="en")
        )

        # Mock knowledge retrieval response
        citation = CitationObject(document_name="doc1", hyperlink="http://example.com")
        self.service_manager.knowledge_retrieval = Mock()
        self.service_manager.knowledge_retrieval.return_value = (
            KnowledgeRetrievalResponse(
                retrieval_requestid="123",
                citations=[citation],
                citation_count=1
            ),
            Response(status_code=200, detail="Retrieval success")
        )

        # Mock inference error
        self.mock_inference.inference_engine.return_value = (
            None,
            Response(status_code=500, detail="Inference failed")
        )

        # Call the method
        response_chatflow, response = self.service_manager.chat_query(request)

        # Assertions
        self.assertEqual(response_chatflow.response, SETTINGS.RESP.INFERENCING_ERR)
        self.assertEqual(response.status_code, 500)
if __name__ == '__main__':
    unittest.main()