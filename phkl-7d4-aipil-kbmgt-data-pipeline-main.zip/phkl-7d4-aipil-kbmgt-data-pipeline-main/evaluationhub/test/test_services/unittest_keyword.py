import unittest
from unittest.mock import Mock, patch
from datetime import datetime
import time
import httpx

# Assuming these are the correct import paths based on your project structure
from src.services.keyword import KeywordServiceManager
from src.schemas.chatflow import KeywordEngine, KeywordExtractionRequest, KeywordExtractionResponse
from src.schemas.format import Response
from src.settings import SETTINGS

class TestKeywordServiceManager(unittest.TestCase):
    def setUp(self):
        """Set up test fixtures before each test method."""
        self.manager = KeywordServiceManager()
        # Set a default engine for tests where needed
        self.default_engine = KeywordEngine(keyword_location="azure")
        SETTINGS.STAT.SUCC_CODE_END = 300  # Assuming this is the threshold for success codes

    ### Tests for `init_engine`
    def test_init_engine_default(self):
        """Test initializing the engine with the default engine."""
        manager = KeywordServiceManager()
        response = manager.init_engine()
        self.assertEqual(manager.engine, manager.default_engine)
        self.assertEqual(response.status_code, 200)
        self.assertIn("Azure", response.detail)

    def test_init_engine_provided(self):
        """Test initializing with a provided engine."""
        custom_engine = KeywordEngine(keyword_location="server")
        manager = KeywordServiceManager()
        response = manager.init_engine(custom_engine)
        self.assertEqual(manager.engine, custom_engine)
        self.assertEqual(response.status_code, 200)
        self.assertIn("Server", response.detail)

    def test_init_engine_unknown_location(self):
        """Test initializing with an unrecognized engine location."""
        custom_engine = KeywordEngine(keyword_location="unknown")
        manager = KeywordServiceManager()
        response = manager.init_engine(custom_engine)
        self.assertEqual(manager.engine, custom_engine)
        self.assertEqual(response.status_code, 404)
        # Check for the actual message with the typo
        self.assertIn("Cannot Recognie", response.detail)

    ### Tests for `text_keyword`
    @patch.object(KeywordServiceManager, 'azure_server')
    def test_text_keyword_success(self, mock_azure_server):
        """Test successful keyword extraction with Azure engine."""
        manager = KeywordServiceManager()
        manager.init_engine(self.default_engine)
        request = KeywordExtractionRequest(data_input=["Sample text"])
        mock_azure_server.return_value = ([["keyword1", "keyword2"]], 15, Response(status_code=200, detail="Success"))

        response_data, response = manager.text_keyword(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response_data.data_output, [["keyword1", "keyword2"]])
        self.assertEqual(response_data.keyword_tokens, 15)
        self.assertGreater(response_data.keyword_time, 0)
        self.assertIsInstance(response_data.response_at, datetime)

    def test_text_keyword_unknown_location(self):
        """Test keyword extraction with an unrecognized engine location."""
        manager = KeywordServiceManager()
        custom_engine = KeywordEngine(keyword_location="unknown")
        manager.init_engine(custom_engine)
        request = KeywordExtractionRequest(data_input=["Sample text"])

        response_data, response = manager.text_keyword(request)

        # Expect 200 since the method proceeds with default behavior
        self.assertEqual(response.status_code, 200)
        # Optional: Add checks for response_data if specific behavior is expected

    @patch.object(KeywordServiceManager, 'azure_server')
    def test_text_keyword_length_mismatch(self, mock_azure_server):
        """Test keyword extraction when input and output lengths do not match."""
        manager = KeywordServiceManager()
        manager.init_engine(self.default_engine)
        request = KeywordExtractionRequest(data_input=["Text1", "Text2"])
        mock_azure_server.return_value = ([["keyword1"]], 5, Response(status_code=200, detail="Success"))

        response_data, response = manager.text_keyword(request)

        self.assertEqual(response.status_code, 500)
        self.assertIn("Unequal Number", response.detail)
        self.assertEqual(response_data.data_output, [])
        self.assertEqual(response_data.keyword_tokens, -1)
        self.assertEqual(response_data.keyword_time, 0.0)
        self.assertIsNone(response_data.response_at)

    ### Tests for `azure_server`
    @patch('azure.ai.textanalytics.TextAnalyticsClient')
    def test_azure_server_success(self, mock_client):
        """Test successful keyword extraction using Azure server."""
        manager = KeywordServiceManager()
        manager.engine = self.default_engine

        # Mock Azure client response
        mock_response = Mock()
        mock_response.is_error = False
        mock_response.key_phrases = ["hello world", "test"]
        mock_client.return_value.extract_key_phrases.return_value = [mock_response]

        raw_data = ["Sample text"]
        processed_data, tool_tokens, response = manager.azure_server(raw_data)

        self.assertEqual(processed_data, [["hello world", "test"]])
        self.assertEqual(tool_tokens, 15)  # len("hello world") + len("test") = 11 + 4
        self.assertEqual(response.status_code, 200)
        self.assertIn("Azure Keyword Success", response.detail)

    @patch('azure.ai.textanalytics.TextAnalyticsClient')
    def test_azure_server_error(self, mock_client):
        """Test Azure server when an individual document has an error."""
        manager = KeywordServiceManager()
        manager.engine = self.default_engine

        # Mock Azure client response with error
        mock_response = Mock()
        mock_response.is_error = True
        mock_response.error = "Some error"
        mock_client.return_value.extract_key_phrases.return_value = [mock_response]

        raw_data = ["Sample text"]
        processed_data, tool_tokens, response = manager.azure_server(raw_data)

        self.assertEqual(processed_data, [[]])
        self.assertEqual(tool_tokens, 0)
        self.assertEqual(response.status_code, 200)  # Still 200 as processing completes

    @patch('azure.ai.textanalytics.TextAnalyticsClient')
    def test_azure_server_timeout(self, mock_client):
        """Test Azure server handling a timeout exception."""
        manager = KeywordServiceManager()
        manager.engine = self.default_engine

        # Mock timeout exception
        mock_client.return_value.extract_key_phrases.side_effect = httpx.TimeoutException("Timeout")

        raw_data = ["Sample text"]
        processed_data, tool_tokens, response = manager.azure_server(raw_data)

        self.assertEqual(processed_data, [])
        self.assertEqual(tool_tokens, 0)
        self.assertEqual(response.status_code, 502)
        self.assertIn("Timeout", response.detail)

    @patch('azure.ai.textanalytics.TextAnalyticsClient')
    def test_azure_server_batch_processing(self, mock_client):
        """Test Azure server batch processing with more than 10 inputs."""
        manager = KeywordServiceManager()
        manager.engine = self.default_engine

        # Mock responses for two batches
        mock_response1 = Mock()
        mock_response1.is_error = False
        mock_response1.key_phrases = ["keyword1", "keyword2"]
        mock_response2 = Mock()
        mock_response2.is_error = False
        mock_response2.key_phrases = ["keyword3", "keyword4"]
        mock_client.return_value.extract_key_phrases.side_effect = [[mock_response1] * 10, [mock_response2]]

        raw_data = ["Text" + str(i) for i in range(11)]
        processed_data, tool_tokens, response = manager.azure_server(raw_data)

        self.assertEqual(len(processed_data), 11)
        self.assertEqual(processed_data[0], ["keyword1", "keyword2"])
        self.assertEqual(processed_data[10], ["keyword3", "keyword4"])
        self.assertEqual(response.status_code, 200)

    ### Tests for `api_call_static`
    @patch('httpx.post')
    def test_api_call_static_success(self, mock_post):
        """Test successful static API call."""
        manager = KeywordServiceManager()
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"key": "value"}
        mock_post.return_value = mock_response

        data = {"data": "test"}
        response_data, response = manager.api_call_static(
            data=data,
            service="TestService",
            api_url="http://test.com/api",
            method="post",
            timeout=10.0
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response_data.status_code, 200)
        self.assertEqual(response_data.json(), {"key": "value"})

    @patch('httpx.post')
    def test_api_call_static_timeout(self, mock_post):
        """Test static API call handling a timeout."""
        manager = KeywordServiceManager()
        mock_post.side_effect = httpx.TimeoutException("Timeout")

        data = {"data": "test"}
        response_data, response = manager.api_call_static(
            data=data,
            service="TestService",
            api_url="http://test.com/api",
            method="post",
            timeout=10.0
        )

        self.assertEqual(response.status_code, 502)
        self.assertIn("Timeout", response.detail)
        self.assertIsNone(response_data)

    def test_api_call_static_unknown_method(self):
        """Test static API call with an unknown method."""
        manager = KeywordServiceManager()
        data = {"data": "test"}
        response_data, response = manager.api_call_static(
            data=data,
            service="TestService",
            api_url="http://test.com/api",
            method="get",
            timeout=10.0
        )

        self.assertEqual(response.status_code, 500)
        self.assertIn("Unknown API Method", response.detail)
        self.assertIsNone(response_data)

if __name__ == '__main__':
    unittest.main()