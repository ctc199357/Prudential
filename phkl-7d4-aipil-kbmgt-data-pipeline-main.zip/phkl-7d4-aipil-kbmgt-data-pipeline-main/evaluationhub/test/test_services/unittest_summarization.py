import unittest
from unittest.mock import patch, Mock
import time
from src.services.summarization import SummarizationServiceManager
from src.schemas.chatflow import (
    SummarizationRequest,
    SummarizationResponse,
    ChatHistoryItem,
    InferenceInput,
    InferenceRequest,
)
from src.schemas.format import ResponseFormatter, Response, StreamResponse
from unittest.mock import ANY

class TestSummarizationServiceManager(unittest.TestCase):
    def setUp(self):
        """Set up the test fixture before each test method."""
        self.service_manager = SummarizationServiceManager(api_call=False)

    def test_extract_hist_prompt(self):
        """Test the extract_hist_prompt method with various chat history scenarios."""
        current_time = int(time.time())

        # Chat history within cutoff (360 seconds), same session
        chat_history_within = [
            ChatHistoryItem(role="human", content="Msg1", unix_time=current_time - 100, session_id="session1"),
            ChatHistoryItem(role="chatbot", content="Resp1", unix_time=current_time - 50, session_id="session1")
        ]

        # Chat history outside cutoff
        chat_history_outside = [
            ChatHistoryItem(role="human", content="Old Msg", unix_time=current_time - 400, session_id="session1")
        ]

        # Mixed history
        chat_history_mixed = chat_history_outside + chat_history_within

        # Test with mixed history
        request_mixed = SummarizationRequest(query="Query", chat_history=chat_history_mixed, rationale="")
        hist_prompt_mixed = SummarizationServiceManager.extract_hist_prompt(request_mixed)
        expected_mixed = "human: Msg1\nchatbot: Resp1"
        self.assertEqual(hist_prompt_mixed, expected_mixed, "Should include only messages within cutoff from the latest session")

        # Test with no history
        request_no_history = SummarizationRequest(query="Query", chat_history=[], rationale="")
        hist_prompt_no_history = SummarizationServiceManager.extract_hist_prompt(request_no_history)
        self.assertEqual(hist_prompt_no_history, "", "Should return empty string when no chat history")

        # Test with only old history
        request_old_history = SummarizationRequest(query="Query", chat_history=chat_history_outside, rationale="")
        hist_prompt_old_history = SummarizationServiceManager.extract_hist_prompt(request_old_history)
        self.assertEqual(hist_prompt_old_history, "", "Should return empty string when all history is outside cutoff")

        # Test with different sessions
        chat_history_diff_sessions = [
            ChatHistoryItem(role="human", content="Msg Old Session", unix_time=current_time - 200, session_id="session_old"),
            ChatHistoryItem(role="human", content="Msg New Session", unix_time=current_time - 50, session_id="session_new")
        ]
        request_diff_sessions = SummarizationRequest(query="Query", chat_history=chat_history_diff_sessions, rationale="")
        hist_prompt_diff_sessions = SummarizationServiceManager.extract_hist_prompt(request_diff_sessions)
        expected_diff_sessions = "human: Msg New Session"
        self.assertEqual(hist_prompt_diff_sessions, expected_diff_sessions, "Should include only messages from the latest session")

        # Test with future and None unix_time
# Use an invalid negative unix_time to represent missing time
        chat_history_future_invalid = [
            ChatHistoryItem(role="human", content="Future Msg", unix_time=current_time + 100, session_id="session1"),
            ChatHistoryItem(role="human", content="Invalid Time Msg", unix_time=-1, session_id="session1"),  # Negative timestamp
            ChatHistoryItem(role="human", content="Past Msg", unix_time=current_time - 50, session_id="session1")
        ]
        request_future_invalid = SummarizationRequest(query="Query", chat_history=chat_history_future_invalid, rationale="")
        hist_prompt_future_invalid = SummarizationServiceManager.extract_hist_prompt(request_future_invalid)
        expected_future_invalid = "human: Past Msg"
        self.assertEqual(hist_prompt_future_invalid, expected_future_invalid, "Should exclude future and invalid unix_time messages")

    @patch('src.services.summarization.InferenceServiceManager')
    def test_history_summarization_success(self, mock_inference_manager):
        """Test history_summarization with successful inference and relevant chat history."""
        # Set up mock inference manager
        mock_inference_response = Mock()
        mock_inference_response.inference_output = Mock(text="Summarized standalone question")
        mock_inference_manager.return_value.inference_engine.return_value = (
            mock_inference_response,
            Response(status_code=200, detail="Success")
        )

        # Create a sample request with chat history
        current_time = int(time.time())
        chat_history = [
            ChatHistoryItem(role="human", content="Previous message", unix_time=current_time - 100, session_id="session1"),
            ChatHistoryItem(role="chatbot", content="Previous response", unix_time=current_time - 50, session_id="session1")
        ]
        request = SummarizationRequest(
            query="Current query",
            chat_history=chat_history,
            rationale=""
        )

        # Call the method
        response_summarization, response = self.service_manager.history_summarization(request)

        # Assertions
        self.assertEqual(response_summarization.standalone_query, "Summarized standalone question")
        self.assertEqual(response.status_code, 200)

        # Verify that inference_engine was called with the correct parameters
        expected_prompt = SummarizationServiceManager.summarization_input_prompt(
            cur_query="Current query",
            conv_hist="human: Previous message\nchatbot: Previous response"
        )
        expected_inference_request = InferenceRequest(
            system_prompt=SummarizationServiceManager.default_system_prompt,
            input=InferenceInput(text=expected_prompt),
            config=None
        )

        # Use mock.ANY for dynamic fields
        expected_inference_request.inference_requestid = ANY
        expected_inference_request.user_requestid = ANY
        expected_inference_request.request_at = ANY

        # Assert the call
        mock_inference_manager.return_value.inference_engine.assert_called_once_with(
            request=expected_inference_request
        )
    @patch('src.services.summarization.InferenceServiceManager')
    def test_history_summarization_no_history(self, mock_inference_manager):
        """Test history_summarization with no chat history."""
        # Set up mock inference manager
        mock_inference_response = Mock()
        mock_inference_response.inference_output = Mock(text="Current query")
        mock_inference_manager.return_value.inference_engine.return_value = (
            mock_inference_response,
            Response(status_code=200, detail="Success")
        )

        # Create a sample request with no chat history
        request = SummarizationRequest(
            query="Current query",
            chat_history=[],
            rationale=""
        )

        # Call the method
        response_summarization, response = self.service_manager.history_summarization(request)

        # Assertions
        self.assertEqual(response_summarization.standalone_query, "Current query")
        self.assertEqual(response.status_code, 200)

        # Verify that inference_engine was called with the correct parameters
        expected_prompt = SummarizationServiceManager.summarization_input_prompt(
            cur_query="Current query",
            conv_hist=""
        )
        expected_inference_request = InferenceRequest(
            system_prompt=SummarizationServiceManager.default_system_prompt,
            input=InferenceInput(text=expected_prompt),
            config=None
        )

        # Use mock.ANY for dynamic fields
        expected_inference_request.inference_requestid = ANY
        expected_inference_request.user_requestid = ANY
        expected_inference_request.request_at = ANY

        # Assert the call
        mock_inference_manager.return_value.inference_engine.assert_called_once_with(
            request=expected_inference_request
        )

    @patch('src.services.summarization.InferenceServiceManager')
    def test_history_summarization_inference_error(self, mock_inference_manager):
        """Test history_summarization when inference fails."""
        # Set up mock inference manager to return an error
        mock_inference_manager.return_value.inference_engine.return_value = (
            None,
            Response(status_code=500, detail="Inference error")
        )

        # Create a sample request
        request = SummarizationRequest(
            query="Current query",
            chat_history=[],
            rationale=""
        )

        # Call the method
        response_summarization, response = self.service_manager.history_summarization(request)

        # Assertions
        self.assertEqual(response_summarization.standalone_query, "Current query")
        self.assertEqual(response.status_code, 500)

if __name__ == '__main__':
    unittest.main()