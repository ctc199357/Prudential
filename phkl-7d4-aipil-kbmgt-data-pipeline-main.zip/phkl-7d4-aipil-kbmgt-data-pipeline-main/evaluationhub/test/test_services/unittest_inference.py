import unittest
from unittest.mock import Mock, patch, mock_open
from datetime import datetime
import httpx
from openai import AzureOpenAI
from src.services.inference import InferenceServiceManager
from src.schemas.chatflow import (
    InferenceRequest,
    InferenceResponse,
    InferenceModel,
    InferenceInput,
    InferenceOutput,
    InferenceMetrics,
    InferenceResult,
    ChatHistoryItem
)
from src.schemas.format import Response, ResponseFormatter
from src.settings import SETTINGS

class TestInferenceServiceManager(unittest.TestCase):
    def setUp(self):
        """Set up the test fixture before each test method."""
        # Initialize InferenceServiceManager with api_call=False to avoid real API calls
        self.service_manager = InferenceServiceManager(api_call=False)
        
        # Mock SETTINGS for consistent testing
        SETTINGS.BASE.APP_NAME = "TestApp"
        SETTINGS.INFR.STATUS_CODE = {"SUCCESS": "SUCCESS"}
        SETTINGS.INFR.ENGINE_TIMEOUT = 30

        # Mock logger to avoid actual logging during tests
        self.service_manager.logger = Mock()

    def test_inference_engine_azure_success(self):
        """Test inference_engine with Azure model location successfully."""
        # Mock InferenceRequest
        request = InferenceRequest(
            input=InferenceInput(text="What is AI?"),
            model=InferenceModel(model_location="azure", model_base="test-model", model_host="azure.com", model_port="443", model_key="test-key"),
            system_prompt="You are an AI assistant."
        )

        # Mock azure_server response
        inference_result = InferenceResult(
            inference_output=InferenceOutput(text="AI is artificial intelligence."),
            inference_metrics=InferenceMetrics(inference_code="SUCCESS", inference_reason="SUCCEED")
        )
        self.service_manager.azure_server = Mock(return_value=(inference_result, Response(status_code=200, detail="Success")))

        # Call the method
        response_inference, response = self.service_manager.inference_engine(request)

        # Assertions
        self.assertIsInstance(response_inference, InferenceResponse)
        self.assertEqual(response_inference.inference_output.text, "AI is artificial intelligence.")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response_inference.inference_metrics.inference_code, "SUCCESS")

    def test_inference_engine_ollama_success(self):
        """Test inference_engine with Ollama server successfully."""
        # Mock InferenceRequest
        request = InferenceRequest(
            input=InferenceInput(text="What is AI?"),
            model=InferenceModel(model_location="server", model_engine="ollama", model_host="localhost", model_port="11434", model_api="api", model_base="llama"),
        )

        # Mock ollama_server response
        inference_result = InferenceResult(
            inference_output=InferenceOutput(text="AI is artificial intelligence."),
            inference_metrics=InferenceMetrics(inference_code="SUCCESS", inference_reason="SUCCEED")
        )
        self.service_manager.ollama_server = Mock(return_value=(inference_result, Response(status_code=200, detail="Success")))

        # Call the method
        response_inference, response = self.service_manager.inference_engine(request)

        # Assertions
        self.assertIsInstance(response_inference, InferenceResponse)
        self.assertEqual(response_inference.inference_output.text, "AI is artificial intelligence.")
        self.assertEqual(response.status_code, 200)
    def test_inference_engine_unrecognized_model_location(self):
        """Test inference_engine with unrecognized model location."""
        model = InferenceModel(
            model_location="unknown",  # Unrecognized location
            model_host="example.com",
            model_port="80",
            model_key="test-key"
        )
        request = InferenceRequest(
            input=InferenceInput(text="Test input"),
            model=model
        )
        # Expect the AttributeError due to the bug in the code
        with self.assertRaises(AttributeError):
            self.service_manager.inference_engine(request)
    def test_inference_engine_unrecognized_model_engine(self):
        """Test inference_engine with unrecognized model engine."""
        model = InferenceModel(
            model_location="server",
            model_engine="unknown",  # Unrecognized engine
            model_host="example.com",
            model_port="80",
            model_key="test-key"
        )
        request = InferenceRequest(
            input=InferenceInput(text="Test input"),
            model=model
        )
        # Expect the AttributeError due to the bug in the code
        with self.assertRaises(AttributeError):
            self.service_manager.inference_engine(request)

    @patch('httpx.post')
    def test_ollama_server_success(self, mock_post):
        """Test ollama_server with successful response."""
        # Mock InferenceRequest
        request = InferenceRequest(
            input=InferenceInput(text="What is AI?"),
            model=InferenceModel(model_host="localhost", model_port="11434", model_api="api", model_base="llama")
        )

        # Mock HTTP response
        mock_response = Mock()
        mock_response.status_code = httpx.codes.OK
        mock_response.json.return_value = {
            "response": "AI is artificial intelligence.",
            "prompt_eval_count": 10,
            "eval_count": 15,
            "prompt_eval_duration": 1000000000,  # 1 second in nanoseconds
            "eval_duration": 1500000000  # 1.5 seconds in nanoseconds
        }
        mock_post.return_value = mock_response

        # Call the method
        inference_result, response = self.service_manager.ollama_server(request)

        # Assertions
        self.assertEqual(response.status_code, 200)
        self.assertEqual(inference_result.inference_output.text, "AI is artificial intelligence.")
        self.assertEqual(inference_result.inference_metrics.inference_code, "SUCCESS")
        self.assertEqual(inference_result.inference_metrics.input_tokens, 10)
        self.assertEqual(inference_result.inference_metrics.output_tokens, 15)

    @patch('httpx.post')
    def test_ollama_server_timeout(self, mock_post):
        """Test ollama_server with timeout exception."""
        # Mock InferenceRequest
        request = InferenceRequest(
            input=InferenceInput(text="What is AI?"),
            model=InferenceModel(model_host="localhost", model_port="11434", model_api="api", model_base="llama")
        )

        # Mock timeout exception
        mock_post.side_effect = httpx.TimeoutException("Timeout")

        # Call the method
        inference_result, response = self.service_manager.ollama_server(request)

        # Assertions
        self.assertEqual(response.status_code, 502)
        self.assertIn("Timeout Error", response.detail)
        self.assertEqual(inference_result.inference_metrics.inference_reason, "FAIL")  # Default value

    @patch('builtins.open', new_callable=mock_open)
    def test_ollama_server_with_image_success(self, mock_file):
        """Test ollama_server with image input successfully."""
        # Mock InferenceRequest with image
        request = InferenceRequest(
            input=InferenceInput(text="Describe this image", image=["test.jpg"]),
            model=InferenceModel(model_host="localhost", model_port="11434", model_api="api", model_base="llama")
        )

        # Mock file read and base64 encoding
        mock_file.return_value.read.return_value = b"image_data"
        with patch('base64.b64encode', return_value=b"encoded_data"), patch('httpx.post') as mock_post:
            mock_response = Mock()
            mock_response.status_code = httpx.codes.OK
            mock_response.json.return_value = {
                "response": "This is an image.",
                "prompt_eval_count": 5,
                "eval_count": 10,
                "prompt_eval_duration": 500000000,  # 0.5 seconds
                "eval_duration": 1000000000  # 1 second
            }
            mock_post.return_value = mock_response

            # Call the method
            inference_result, response = self.service_manager.ollama_server(request)

            # Assertions
            self.assertEqual(response.status_code, 200)
            self.assertEqual(inference_result.inference_output.text, "This is an image.")
            self.assertIn("encoded_data", mock_post.call_args[1]["json"]["images"])

    @patch('src.services.inference.AzureOpenAI')  # Changed from 'openai.AzureOpenAI'
    def test_azure_server_success(self, mock_azure_client):
        # Mock InferenceRequest with model_secrets
        request = InferenceRequest(
            input=InferenceInput(text="What is AI?"),
            model=InferenceModel(
                model_host="azure.com",
                model_port="443",
                model_base="gpt-3",
                model_key="test-key",
                model_secrets={"api_version": "v1"}
            ),
            system_prompt="You are an AI assistant.",
            chat_history=[ChatHistoryItem(session_id="123", role="human", content="Hi", unix_time=1234567890)]
        )

        # Mock AzureOpenAI client response
        mock_client = Mock()
        mock_response = Mock()
        mock_response.choices = [Mock(message=Mock(content="AI is artificial intelligence."))]
        mock_response.usage = Mock(prompt_tokens=10, completion_tokens=15)
        mock_client.chat.completions.create.return_value = mock_response
        mock_azure_client.return_value = mock_client

        # Call the method
        inference_result, response = self.service_manager.azure_server(request)

        # Assertions
        self.assertEqual(response.status_code, 200)
        self.assertEqual(inference_result.inference_output.text, "AI is artificial intelligence.")
        self.assertEqual(inference_result.inference_metrics.inference_code, "SUCCESS")
        self.assertEqual(inference_result.inference_metrics.input_tokens, 10)
        self.assertEqual(inference_result.inference_metrics.output_tokens, 15)

    @patch('src.services.inference.AzureOpenAI')  # Changed from 'openai.AzureOpenAI'
    def test_azure_server_no_choices(self, mock_azure_client):
        # Mock InferenceRequest with model_secrets
        request = InferenceRequest(
            input=InferenceInput(text="What is AI?"),
            model=InferenceModel(
                model_host="azure.com",
                model_port="443",
                model_base="gpt-3",
                model_key="test-key",
                model_secrets={"api_version": "v1"}
            )
        )

        # Mock AzureOpenAI client with no choices
        mock_client = Mock()
        mock_response = Mock()
        mock_response.choices = []
        mock_client.chat.completions.create.return_value = mock_response
        mock_azure_client.return_value = mock_client

        # Call the method
        inference_result, response = self.service_manager.azure_server(request)

        # Assertions
        self.assertEqual(response.status_code, 500)
        self.assertIn("Azure GenAI Error", response.detail)
        self.assertEqual(inference_result.inference_metrics.inference_reason, response.detail)

if __name__ == '__main__':
    unittest.main()