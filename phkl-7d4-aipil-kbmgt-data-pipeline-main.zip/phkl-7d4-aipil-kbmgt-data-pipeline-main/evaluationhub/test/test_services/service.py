import sys
import os
sys.path.append(os.getcwd())
from src.schemas.evaluation import EvaluationRequest
from src.services.evaluation import EvaluationServiceManager

def main():
    request = EvaluationRequest()
    evaluation, response = EvaluationServiceManager(api_call=False).evaluation_query(request=request)
    # print(evaluation)
    # print(response)

if __name__ == "__main__":
    main()