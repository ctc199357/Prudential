import unittest
from unittest.mock import Mock, patch
from fastapi.testclient import TestClient
from fastapi import FastAPI, status
from src.routers.request import router  # Replace 'your_module' with the actual module name

from src.schemas.chatflow import (
    ChatHistoryItem,
    CustomField,
    RespCitation,
    CitationObject,
    ChatFlowRequest,
    CommonHeaders,
    ChatQueryResponse,
    ChatFlowResponse
)

class TestChatRouter(unittest.TestCase):
    def setUp(self):
        """Set up the test fixture before each test method."""
        # Create a FastAPI app and include the router
        app = FastAPI()
        app.include_router(router)
        
        # Create a TestClient instance with the app
        self.client = TestClient(app)
        
        # Sample request data
        self.chat_flow_request = ChatFlowRequest(
            query="What is the weather like?",
            rationale="Testing the chatflow endpoint",
            chat_history=[
                ChatHistoryItem(
                    session_id="123-123-123",
                    role="human",
                    content="Hello",
                    unix_time=1734408157
                )
            ],
            custom_field=CustomField(
                agent_id="AD11223",
                pru_force_lang="en"
            )
        ).dict()

        # Sample headers
        self.common_headers = CommonHeaders(
            ocp_apim_subscription_key="1"
        ).dict()

        # Mock response data
        self.chat_query_response = ChatQueryResponse(
            id="test-id-123",
            response="The weather is sunny.",
            citations=[RespCitation(
                document_name="weather_doc.pdf",
                hyperlink="http://example.com/weather_doc.pdf",
                page_number="1",
                last_update_date="2023-10-01",
                pil_reference_number="pil-001",
                sources=[],
                translation="ORIGINAL"
            )]
        )

        self.chat_flow_response = ChatFlowResponse(
            id="test-id-456",
            response="The weather is sunny.",
            citations=[CitationObject(
                document_name="weather_doc.pdf",
                hyperlink="http://example.com/weather_doc.pdf",
                page_number="1",
                last_update_date="2023-10-01",
                pil_reference_number="pil-001",
                raw_sources=[],
                translation="ORIGINAL"
            )]
        )



    def test_chat_query_success(self):
        """Test the /chat/query endpoint with a successful response."""
        with patch('src.routers.request.ChatFlowServiceManager.chat_query') as mock_chat_query:
            mock_chat_query.return_value = (self.chat_query_response, Mock(status_code=200))

            # Send a POST request to /chat/query with the correct header name
            response = self.client.post(
                "/chat/query",
                json=self.chat_flow_request,
                headers={"Ocp-Apim-Subscription-Key": "1"}
            )

            # Assertions
            self.assertEqual(response.status_code, status.HTTP_200_OK)
            response_data = response.json()
            self.assertEqual(response_data["id"], "test-id-123")
            self.assertEqual(response_data["response"], "The weather is sunny.")
            self.assertEqual(len(response_data["citations"]), 1)
            self.assertEqual(response_data["citations"][0]["document_name"], "weather_doc.pdf")


    def test_chat_query_missing_header(self):
        """Test the /chat/query endpoint with a missing required header."""
        # Send a POST request without the required Ocp-Apim-Subscription-Key header
        response = self.client.post(
            "/chat/query",
            json=self.chat_flow_request
        )

        # Assertions
        self.assertEqual(response.status_code, status.HTTP_422_UNPROCESSABLE_ENTITY)
        response_data = response.json()
        self.assertIn("detail", response_data)
        self.assertEqual(response_data["detail"][0]["msg"], "field required")


    def test_chat_query_service_failure(self):
        """Test the /chat/query endpoint when the service fails."""
        with patch('src.routers.request.ChatFlowServiceManager.chat_query') as mock_chat_query:
            mock_response = Mock(status_code=500, detail="Service failure")
            mock_chat_query.return_value = (None, mock_response)

            # Send a POST request to /chat/query
            response = self.client.post(
                "/chat/query",
                json=self.chat_flow_request,
                headers={"ocp_apim_subscription_key": "1"}
            )

            # Assertions (assuming router_response_handler raises an HTTPException)
            self.assertNotEqual(response.status_code, status.HTTP_200_OK)

if __name__ == "__main__":
    unittest.main()