import pandas as pd

def merge_csv_files(qa_file, eval_file, output_file):
    # Read the CSV files
    qa_df = pd.read_csv(qa_file, encoding="utf-8-sig")
    eval_df = pd.read_csv(eval_file, encoding="utf-8-sig")
    
    # Merge the dataframes on qna_id, keeping all eval rows (left join)
    merged_df = pd.merge(
        eval_df,
        qa_df[['qna_id', 'qna_response', 'qna_citations', 'qna_query']],
        on='qna_id',
        how='left'
    )
    
    # Save the merged dataframe to a new CSV file
    merged_df.to_csv(output_file, index=False, encoding="utf-8-sig")
    print(f"Merged CSV saved to {output_file}","news")
def merge_csv_files_i(qa_file, eval_file, output_file):
    # Read the CSV files
    qa_df = pd.read_csv(qa_file, encoding="utf-8-sig")
    eval_df = pd.read_csv(eval_file, encoding="utf-8-sig")
    
    # Merge the dataframes on qna_id, keeping all eval rows (left join)
    merged_df = pd.merge(
        eval_df,
        qa_df[['knowledge_id','knowledge_name']],
        on='knowledge_id',
        how='left'
    )
    
    # Save the merged dataframe to a new CSV file
    merged_df.to_csv(output_file, index=False, encoding="utf-8-sig")
    print(f"Merged CSV saved to {output_file}","newssss")
# Example usage
merge_csv_files_i('metadata_2025-04-29-02-31-14.csv', 'merged_output.csv', 'merged.csv')