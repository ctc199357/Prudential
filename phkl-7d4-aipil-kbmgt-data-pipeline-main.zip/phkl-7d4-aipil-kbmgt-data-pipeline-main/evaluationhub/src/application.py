from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from fastapi.exceptions import HTTPException, RequestValidationError

from .settings import SETTINGS
from .routers import router
from .logger.log_handler import get_logger

logger = get_logger(__name__)

from .schemas.exception import http_exception_handler, validation_exception_handler


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup Server
    logger.info(f'Startup {SETTINGS.BASE.APP_NAME} API Server')
    yield

    # Shutdown Server
    logger.info(f'Shutdown {SETTINGS.BASE.APP_NAME} API Server')

application = FastAPI(lifespan=lifespan)

# set fastapi server config
application.include_router(router)
application.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


application.add_exception_handler(HTTPException, http_exception_handler)
application.add_exception_handler(RequestValidationError, validation_exception_handler)