import inspect
import time
import httpx
import re
import json
import requests

from datetime import datetime, timezone

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
)

from ..schemas.qna import (
    SystemQnARequest,
    QnAFilter,
    QnAStringFilter,
    QnANumericFilter,
    KnowledgeQnARequest,
    QnABatchCreateRequest,
    QnACreateRequest
)

from ..schemas.evaluation import (
    SystemEvaluationRequest,
    EvaluationFilter,
    EvaluationStringFilter,
    EvaluationNumericFilter,
    EvaluationRequest,

    ChatflowEvaluationRequest, 
    ChatflowEvaluationResponse,
    EvaluationQnAPair, 
    QnAEvaluationRequest,
    QnAEvaluationResponse,
    KnowledgeEvaluationRequest,
    EvaluationMetrics,
    EvaluationResult,
    EvaluationCreate,
    EvaluationCreateRequest,
    EvaluationBatchCreateRequest,
    EvaluationBatchRequest,
    SystemEvaluationRequest,
    EvaluationRequest,
    EvaluationFilter,
    EvaluationStringFilter,
    KnowledgeEvaluationResult
)

from ..schemas.chatflow import (
    EvaluationQuery,
    EvaluationQueryResponse,
    CustomField
)

from ..schemas.inference import (
    InferenceInput,
    InferenceRequest
)

from ..services.inference import InferenceServiceManager

from ..schemas.utils import (
    KnowledgeVectorRequest,
    KnowledgeVectorReadResponse,
    KnowledgeUpdateRequest,
    KnowledgeUpdate,
    SecretKnowledge,
    KnowledgeStringFilter,
    KnowledgeNumericFilter,
    KnowledgeFilter,
    SystemKnowledgeRequest,
    SystemKnowledgeResponse
)

from .utils import consolidate_page_ranges

from ..routers.registry.general import (
    general_batch_create_qna,
    general_batch_create_evaluation, 
    general_batch_activate_evaluation, 
    general_batch_deactivate_evaluation, 
    general_batch_drop_evaluation,
    general_batch_drop_qna
)

from ..routers.registry.system import system_query_evaluation

from ..routers.request_qna import (
    QnAGenerationRequest,
    request_qna_knowledge_generation,
    request_read_knowledge_qna,
    request_deactivate_knowledge_qna,
    request_drop_knowledge_qna
)

if SETTINGS.BASE.APP_FUNC == True:
    from ..services import system_query_knowledge, general_update_knowledge

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class EvaluationServiceManager:

    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    default_system_prompt = """YOU ARE THE WORLD'S BEST GenAI Audit ASSISTANT FROM Prudential Hong Kong. Your task is to evaluate the response accuracy and quality from GenAI.

        ### INSTRUCTIONS
        **Operating Guidelines**:
        **Operating Guidelines**:
        - Do not request additional information or clarification unless the user explicitly asks.

        ### Guideliens for Resposne Evaluation
        - You need to compare and evaluate the expected answer and actual answer with the following metrics:
        ## Groundedness Score (1 to 5) for each actual answer based on the following criteria:
            1 - The answer is completely unrelated to the question or context, providing off-topic or irrelevant information.
            2 - The answer relates to the general topic but doesn't directly or meaningfully address the specific question. It may include vague or tangential connections.
            3 - The answer attempts to address the question but introduces minor inaccuracies or unsupported details. The primary focus may still be relevant but lacks precision.
            4 - The answer directly addresses the question and is grounded in the context. It uses relevant information from the provided content but might miss minor nuances or rank the most relevant details slightly lower.
            5 - The answer fully and accurately uses the context to address the query. The most relevant details are prioritized, and no unnecessary or external information is introduced.
        
        ## Retrieval Score (1 to 5) for each actual answer based on the following criteria:
            1 - The retrieved context chunks are irrelevant or unrelated to the query, and no useful information is provided.
            2 - Some relevant context chunks are included, but they are mostly overshadowed by irrelevant information. External knowledge or biases may also influence the result.
            3 - The retrieved context chunks include relevant details, but the most pertinent ones are ranked lower, leading to a less effective response.
            4 - The context chunks effectively address the query, with relevant details included in the middle or upper portions of the list. External knowledge is not used, but the ranking could be slightly improved.
            5 - The retrieved context chunks are highly relevant, with the most important information placed at the forefront. The response is solely based on the provided context and avoids introducing unnecessary or external knowledge.

        ## Relevance Score (1 to 5) for each expected answer and actual answer based on the following criteria:
            1 - The answer is completely off-topic or irrelevant, failing to address the query.
            2 - The answer attempts to address the query but contains significant inaccuracies or misleading information.
            3 - The answer partially addresses the question but omits important details, leading to an incomplete or unclear response.
            4 - The answer fully addresses the question with accurate and relevant information but may lack minor insights or elaborations.
            5 - The answer fully addresses the question with complete, accurate information and includes additional useful insights or elaborations that enhance understanding.
        
        ## Ground-truth Similarity Score (1 to 5) for each correct-predicted answer pair based on the following criteria:
            1 - The predicted answer is completely dissimilar, with no overlap in meaning or relevance.
            2 - The predicted answer is mostly dissimilar, with significant omissions or differences in meaning.
            3 - The predicted answer is somewhat similar but lacks key details or includes inaccuracies.
            4 - The predicted answer is largely similar, with only minor differences that do not significantly alter the meaning.
            5 - The predicted answer is almost identical to the expected answer, fully reflecting its meaning, structure, and details.
        ---

        ### What Not To Do ###
        OBEY and never do:
        - NEVER PROVIDE GENERIC OR VAGUE ANSWERS THAT LACK SPECIFIC DETAILS.
        - NEVER USE JARGON WITHOUT EXPLANATION, ENSURE ALL TERMS ARE CLEARLY DEFINED.
        - NEVER IGNORE THE USER'S SPECIFIC NEEDS OR CIRCUMSTANCES.
        - NEVER INCLUDE INCORRECT OR MISLEADING INFORMATION ABOUT INSURANCE PRODUCTS.
        - NEVER FAIL TO MAINTAIN A PROFESSIONAL AND EMPATHETIC TONE.
        - NEVER OMIT IMPORTANT TERMS, CONDITIONS, OR EXCLUSIONS.
        - NEVER ASK THE USER FOR ADDITIONAL INFORMATION OR CLARIFICATION UNLESS THEY HAVE SPECIFICALLY REQUESTED IT.
        - NEVER USE DOCUMENT_IDS THAT ARE NOT PRESENT IN THE PROVIDED CONTEXT OR MODIFY THE DOCUMENT_IDS IN ANY WAY.
        - NEVER IGNORE OR OVERLOOK THE PRODUCT NAME AND TERMINOLOGY IN THE USER QUERY
        
        **Finalizing the Response**:
        - Ensure the response is professional, sincere, and comprehensive, covering all aspects.
        - Check the accuracy and transparency of the answer.
        - The queries should include all the generated queries in a list.
        - The responses should include all the generated responses matched to the generated queries in a list
        - The languages should include the used language of the generated responses. If the generated responses is Traditional Chinese, then the language should be zh. If the language of the generated response is English, the language should be en.
        - The reply format must be in JSON as follows:
            ```
            {{
                "groundedness": <groundedness score from 1-5 in integer>,
                "retrieval": <retrieval score from 1-5 in integer>,
                "relevance": <relevance score from 1-5 in integer>,
                "similarity": <similarity score from 1-5 in integer>
            }}
            ```

        ---
        ### 
        Here is the expected answer and actual answer:
        Expected Answer: 
        {expected_response}

        Actual Answer: 
        {actual_response}

        Actual Citations: 
        {actual_citations}
"""
        # ---
        # Here is the seed context chunks
        # Seed Context Chunks: {seed_chunks}
        
    def __init__(self, api_call: bool):
        self.api_call = api_call

    def response_jsonlize(self, text: str) -> dict:
        match = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
        if match:
            json_str = match.group(1)
        else:
            json_str = text  
        try:
            data = json.loads(json_str)
            if isinstance(data, dict) and "groundedness" in data and "retrieval" in data and "relevance" in data and "similarity" in data:
                if isinstance(data["groundedness"], int) and isinstance(data["retrieval"], int) and isinstance(data["similarity"], int) and isinstance(data["relevance"], int):
                    return data
        except json.JSONDecodeError:
            raise json.JSONDecodeError
        
        return {"groundedness": -1, "retrieval": -1, "relevance": -1, "similarity": -1}

    def evaluate_knowledge(self, request: QnAEvaluationRequest) -> tuple[QnAEvaluationResponse, Response]:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Initiated Evaluation Process")
        start_at = time.time()

        response_data = QnAEvaluationResponse(**request.__dict__)

        """ 1. Retrieving Knowledge Data """
        logger.info("Processing : Retrieving Knowledge Metadata")
        if not request.knowledge_id:
            response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Evaluation Unfound Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid Knoweldge ID for Evaluation"))
            logger.error(response.detail)
            return response_data, response
        
        knowledge_request = SystemKnowledgeRequest(
            data_filter = KnowledgeFilter(
                string_filter=KnowledgeStringFilter(
                    knowledge_id_filter=[request.knowledge_id]
                )
            )
        )
        
        response_knowledge, response = self.query_knowledge(request=knowledge_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response
        else:
            if not response_knowledge.filtered_data:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : <{SETTINGS.BASE.APP_NAME}> Retrieved Empty Knowledge"))
                logger.error(response.detail)
                return response_data, response
            else:
                knowledge_metadata = response_knowledge.filtered_data[0]

        """ 2. Update Knowledge Ingestion Stage """
        update_request = KnowledgeUpdateRequest(
            knowledge_id = request.knowledge_id,
            update_data  = KnowledgeUpdate(knowledge_ingestion_stage="Evaluating"),
            overwrite    = True
        )
        response = self.update_knowledge(request=update_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response
        
        """ 3. Retrieve QnA for Evaluation """
        logger.info("Processing : Retrieving QnA Generation for Evaluation")
        try:
            response_qna = request_read_knowledge_qna(request=KnowledgeQnARequest(knowledge_ids=[request.knowledge_id]), api_call=False)
            qna_data = response_qna.filtered_data
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Retreival Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve QnA for Evaluation", str(e)))
            logger.error(response.detail)
            return response_data, response
        
        """ 4. Check if QnA Exists """
        if not qna_data:
            response = Response(status_code=200, detail=self.response_format.ok(f"Unfound QnA : <{SETTINGS.BASE.APP_NAME}> Cannot Find Relevant QnA for Evaluation"))
            logger.info(response.detail)
            update_request = KnowledgeUpdateRequest(
                knowledge_id = request.knowledge_id,
                update_data  = KnowledgeUpdate(
                        knowledge_ingestion_stage="Initialize Q&A Dataset", 
                        knowledge_ingestion_reason=response.detail
                    ),
                overwrite    = True
            )
            _response = self.update_knowledge(request=update_request)
            return response_data, response
            

        """ 5. Start Evaluation """
        success_objects = []
        fail_objects    = []
        for i, qna in enumerate(qna_data, start=1):
            logger.info(f"Processing : Evaluating QnA Pairs for <{i} / {len(qna_data)}> QnA Pair")

            logger.info("Processing : Sending Request to Chatflow API")
            qna_request = EvaluationQuery(
                query         = qna.qna_query,
                knowledge_ids = [], 
                rationale     = "",
                chat_history  = [],
                custom_field  = CustomField(
                    agent_id = "abc123",
                    pru_force_lang = qna.qna_response_language
                )
            )

            response_qna, response = self.generate_qna_response(request=qna_request)

            _result = EvaluationCreate(
                **request.__dict__,
                knowledge_version     = knowledge_metadata.knowledge_version,
                document_name         = f"{knowledge_metadata.knowledge_name}{knowledge_metadata.knowledge_fileextension}",
                qna_id                = qna.qna_id,
                qna_query             = qna.qna_query,
                qna_response          = qna.qna_response,
                qna_citations         = qna.qna_citations,
                qna_data_ids          = qna.qna_data_ids,
                qna_query_language    = qna.qna_query_language,
                qna_response_language = qna.qna_response_language,
                actual_response       = response_qna.response,
                actual_citations      = [f'{citation.document.document_name} ({consolidate_page_ranges(page_ranges=[{"page_start": _citiation.page_start, "page_end": _citiation.page_end} for _citiation in citation.citations])})' for citation in response_qna.citations],
                actual_data_ids       = [f'{chunk.data_id}' for citation in response_qna.citations for chunk in citation.citations],
                actual_language       = qna.qna_response_language,
                input_tokens          = response_qna.metrics.total_input_tokens,
                output_tokens         = response_qna.metrics.total_output_tokens,
                tool_tokens           = response_qna.metrics.total_tool_tokens,
                response_time         = response_qna.metrics.response_time
            )

            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                fail_objects.append(_result)
                continue

            """ 6. Prompt Formation """
            system_prompt = self.default_system_prompt.format(
                expected_response = qna.qna_response, 
                actual_response   = _result.actual_response,
                actual_citations  = '\n\n'.join([_chunk.content for _citation in response_qna.citations for _chunk in _citation.citations])
            )

            """ 7. GenAI Inference """
            logger.info(f"Processing : Started Evaluation for <{i} / {len(qna_data)}> QnA Pair")
            success_flag = False
            retry_max_no = SETTINGS.INFR.RETRY_LIMIT
            retry_count  = 1
            while retry_count <= retry_max_no:
                inference_start_at = time.time()
                request_inference = InferenceRequest(input=InferenceInput(text=system_prompt))
                response_inference, response = InferenceServiceManager(api_call=self.api_call).inference_engine(request=request_inference)

                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    logger.error(f"Inference Error : Retrying")
                    retry_count += 1
                    continue

                # Attempt to parse the inference output
                try:
                    response_inference_json = self.response_jsonlize(response_inference.inference_output.text)
                    _evaluation_time = time.time() - inference_start_at
                    _groundedness    = response_inference_json["groundedness"]
                    _retrieval       = response_inference_json["retrieval"]
                    _relevance       = response_inference_json["relevance"]
                    _similarity      = response_inference_json["similarity"]
                    _evaluation_code = "Completed Evaluation"
                    success_flag     = True
                    break
                
                except:
                    if retry_count > retry_max_no:
                        _evaluation_time = time.time() - inference_start_at
                        _groundedness    = -1
                        _retrieval       = -1
                        _relevance       = -1
                        _similarity      = -1
                        _evaluation_code = "Failed to Call QAflowAPI"
                        break

                    logger.error(f"LLM Formatting Issue. Retrying")
                    retry_count += 1

            """ 8. Parsing the Inference Response """
            _result.__dict__.update(
                groundedness    = _groundedness,
                retrieval       = _retrieval,
                similarity      = _similarity,
                relevance       = _relevance,
                evaluation_code = _evaluation_code,
                evaluation_time = _evaluation_time
            )
            
            if success_flag == True:
                success_objects.append(_result)
            else:
                fail_objects.append(_result)

        response_data.__dict__.update(
            **{
                "success_objects":          success_objects,
                "fail_objects":             fail_objects,
                "total_evaluation_count":   len(qna_data),
                "success_evaluation_count": len(success_objects),
                "fail_evaluation_count":    len(fail_objects)

            }
        )

        if not success_objects:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Evalaution"))
            return response_data, response

        """ 9. Save to DB """
        if request.save_to_db:

            """ 10. Deactivating Previous Records """
            response = self.deactivate_evaluation(request=KnowledgeEvaluationRequest(knowledge_ids=[request.knowledge_id]))
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response_data, response

            logger.info("Processing : Storing Successful Evaluation into DB")
            success_flag  = False
            batch_size    = SETTINGS.EVAL.EVALUTATION_BATCH_CREATE_LIMIT
            batches       = [success_objects[i:i + batch_size] for i in range(0, len(success_objects), batch_size)]
            processed_ids = []

            for i, batch in enumerate(batches, start=1):
                logger.info(f"Storing <{i} / {len(batches)}> Evaluation Batch")
                batch_request = EvaluationBatchCreateRequest(
                    create_requests=[
                        EvaluationCreateRequest(
                            data=_data
                        )
                        for _data in batch
                    ]
                )
                try:
                    response = general_batch_create_evaluation(
                        request  = batch_request, 
                        api_call = self.api_call
                    )
                    success_flag = True
                    processed_ids += [_data.evaluation_id for _data in batch]
                    
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Failed to Store <{i} / {len(batches)}> Evaluation Batch", str(e)))
                    logger.info(response.detail)
                    continue

            if success_flag == True:
                """ Dropping Previous Records """
                response = self.drop_evaluation(request=KnowledgeEvaluationRequest(knowledge_ids=[request.knowledge_id]))
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return response_data, response

                """ Update Knowledge Ingestion Stage """
                update_request = KnowledgeUpdateRequest(
                    knowledge_id = request.knowledge_id,
                    update_data  = KnowledgeUpdate(
                        knowledge_ingestion_stage = "Evaluated for Review",
                        average_groundedness      = sum([obj.groundedness for obj in success_objects]) / len(success_objects),
                        average_relevance         = sum([obj.relevance for obj in success_objects]) / len(success_objects),
                        average_retrieval         = sum([obj.retrieval for obj in success_objects]) / len(success_objects),
                        average_similarity        = sum([obj.similarity for obj in success_objects]) / len(success_objects)
                    ),
                    overwrite = True
                )
                response = self.update_knowledge(request=update_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return response_data, response

        else:
            logger.info("Save DB is Disabled. Skipped Evaluation Storage")

        """ 11. Finalize the request response """
        response_data.response_at = datetime.now(timezone.utc)

        response = Response(status_code=200, detail=self.response_format.ok(f"Success : Evaluation Completed"))
        logger.info(response.detail)
        return response_data, response

    def auto_evaluate_knowledge(self, request: QnAEvaluationRequest) -> tuple[QnAEvaluationResponse, Response]:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Initiated Auto Evaluation Process")
        start_at = time.time()

        response_data = QnAEvaluationResponse(**request.__dict__)

        """ 1. Retrieving Knowledge Data """
        logger.info("Processing : Retrieving Knowledge Metadata")
        if not request.knowledge_id:
            response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Evaluation Unfound Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid Knoweldge ID for Evaluation"))
            logger.error(response.detail)
            return response_data, response
        
        knowledge_request = SystemKnowledgeRequest(
            data_filter = KnowledgeFilter(
                string_filter=KnowledgeStringFilter(
                    knowledge_id_filter=[request.knowledge_id]
                )
            )
        )
        
        response_knowledge, response = self.query_knowledge(request=knowledge_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response
        else:
            if not response_knowledge.filtered_data:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : <{SETTINGS.BASE.APP_NAME}> Retrieved Empty Knowledge"))
                logger.error(response.detail)
                return response_data, response
            else:
                knowledge_metadata = response_knowledge.filtered_data[0]

        """ 2. Update Knowledge Ingestion Stage """
        update_request = KnowledgeUpdateRequest(
            knowledge_id = request.knowledge_id,
            update_data  = KnowledgeUpdate(knowledge_ingestion_stage="Initialize Q&A Dataset"),
            overwrite    = True
        )
        response = self.update_knowledge(request=update_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response

        """ 3. Generating QnA """
        logger.info("Processing : Generating QnA for Evaluation")
        try:
            qna_request = QnAGenerationRequest(**request.__dict__)
            qna_request.__dict__.update(
                **{
                    "save_to_db": False
                }
            )
            response_qna = request_qna_knowledge_generation(request=qna_request, api_call=self.api_call)
            qna_data = response_qna.success_objects
        except Exception as e:
            response = Response(status_code=404, detail=self.response_format.error(f"QnA Generation Error : <{SETTINGS.BASE.APP_NAME}> Failed to Generate QnA", str(e)))
            logger.error(response.detail)
            return response_data, response

        """ 4. Check if QnA Exists """
        if not qna_data:
            response = Response(status_code=200, detail=self.response_format.ok(f"Unfound QnA : <{SETTINGS.BASE.APP_NAME}> Cannot Find Relevant QnA for Evaluation"))
            logger.info(response.detail)
            update_request = KnowledgeUpdateRequest(
                knowledge_id = request.knowledge_id,
                update_data  = KnowledgeUpdate(
                        knowledge_ingestion_stage="Ingested for Review", 
                        knowledge_ingestion_reason=response.detail
                    ),
                overwrite    = True
            )
            _response = self.update_knowledge(request=update_request)
            return response_data, response
            
        """ 5. Start Evaluation """
        success_objects = []
        fail_objects    = []
        valid_qnas      = []
        invalid_qnas    = []
        for i, qna in enumerate(qna_data, start=1):
            logger.info(f"Processing : Evaluating QnA Pairs for <{i} / {len(qna_data)}> QnA Pair")

            logger.info("Processing : Sending Request to Chatflow API")
            qna_request = EvaluationQuery(
                query         = qna.qna_query,
                knowledge_ids = [], 
                rationale     = "",
                chat_history  = [],
                custom_field  = CustomField(
                    agent_id = "abc123",
                    pru_force_lang = qna.qna_response_language
                )
            )

            response_qna, response = self.generate_qna_response(request=qna_request)

            _result = EvaluationCreate(
                **request.__dict__,
                knowledge_version     = knowledge_metadata.knowledge_version,
                document_name         = f"{knowledge_metadata.knowledge_name}{knowledge_metadata.knowledge_fileextension}",
                qna_id                = qna.qna_id,
                qna_query             = qna.qna_query,
                qna_response          = qna.qna_response,
                qna_citations         = qna.qna_citations,
                qna_data_ids          = qna.qna_data_ids,
                qna_query_language    = qna.qna_query_language,
                qna_response_language = qna.qna_response_language,
                actual_response       = response_qna.response,
                actual_citations      = [f'{citation.document.document_name} ({consolidate_page_ranges(page_ranges=[{"page_start": _citiation.page_start, "page_end": _citiation.page_end} for _citiation in citation.citations])})' for citation in response_qna.citations],
                actual_data_ids       = [f'{chunk.data_id}' for citation in response_qna.citations for chunk in citation.citations],
                actual_language       = qna.qna_response_language,
                input_tokens          = response_qna.metrics.total_input_tokens,
                output_tokens         = response_qna.metrics.total_output_tokens,
                tool_tokens           = response_qna.metrics.total_tool_tokens,
                response_time         = response_qna.metrics.response_time
            )

            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                fail_objects.append(_result)
                continue

            """ 6. Prompt Formation """
            system_prompt = self.default_system_prompt.format(
                expected_response = qna.qna_response, 
                actual_response   = _result.actual_response,
                actual_citations  = '\n\n'.join([_chunk.content for _citation in response_qna.citations for _chunk in _citation.citations])
            )

            """ 7. GenAI Inference """
            logger.info(f"Processing : Started Evaluation for <{i} / {len(qna_data)}> QnA Pair")
            success_flag = False
            retry_max_no = SETTINGS.INFR.RETRY_LIMIT
            retry_count  = 1
            while retry_count <= retry_max_no:
                inference_start_at = time.time()
                request_inference = InferenceRequest(input=InferenceInput(text=system_prompt))
                response_inference, response = InferenceServiceManager(api_call=self.api_call).inference_engine(request=request_inference)

                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    logger.error(f"Inference Error : Retrying")
                    retry_count += 1
                    continue

                # Attempt to parse the inference output
                try:
                    response_inference_json = self.response_jsonlize(response_inference.inference_output.text)
                    _evaluation_time = time.time() - inference_start_at
                    _groundedness    = response_inference_json["groundedness"]
                    _retrieval       = response_inference_json["retrieval"]
                    _relevance       = response_inference_json["relevance"]
                    _similarity      = response_inference_json["similarity"]
                    _evaluation_code = "Completed Evaluation"
                    success_flag     = True
                    break
                
                except:
                    if retry_count > retry_max_no:
                        _evaluation_time = time.time() - inference_start_at
                        _groundedness    = -1
                        _retrieval       = -1
                        _relevance       = -1
                        _similarity      = -1
                        _evaluation_code = "Failed to Call QAflowAPI"
                        break

                    logger.error(f"LLM Formatting Issue. Retrying")
                    retry_count += 1
                    time.sleep(SETTINGS.EVAL.INFERENCE_INTERVAL)

            """ 8. Parsing the Inference Response """
            _result.__dict__.update(
                groundedness    = _groundedness,
                retrieval       = _retrieval,
                similarity      = _similarity,
                relevance       = _relevance,
                evaluation_code = _evaluation_code,
                evaluation_time = _evaluation_time
            )
            
            # Improvement* code here
            if any([_groundedness < 3, _retrieval < 3, _similarity < 3, _relevance < 3]):
                success_flag = False

            if success_flag == True:
                success_objects.append(_result)
                valid_qnas.append(qna)
            else:
                fail_objects.append(_result)
                invalid_qnas.append(qna)

        response_data.__dict__.update(
            **{
                "success_objects":          success_objects,
                "fail_objects":             fail_objects,
                "total_evaluation_count":   len(qna_data),
                "success_evaluation_count": len(success_objects),
                "fail_evaluation_count":    len(fail_objects)

            }
        )

        if not success_objects:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Evalaution"))
            logger.info(response.detail)
            update_request = KnowledgeUpdateRequest(
                knowledge_id = request.knowledge_id,
                update_data  = KnowledgeUpdate(
                        knowledge_ingestion_stage="Ingested for Review", 
                        knowledge_ingestion_reason=response.detail
                    ),
                overwrite = True
            )
            _response = self.update_knowledge(request=update_request)
            return response_data, response

        """ 9. Save to DB """
        if request.save_to_db:

            """ 9.1. Deactivating Previous QnA Records """
            try:
                _response = request_deactivate_knowledge_qna(request=KnowledgeQnARequest(knowledge_ids=[request.knowledge_id]))
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Failed to Deactivate Previous QnA Records", str(e)))
                logger.error(response.detail)
                return response_data, response

            """ 9.2. Deactivating Previous Records """
            response = self.deactivate_evaluation(request=KnowledgeEvaluationRequest(knowledge_ids=[request.knowledge_id]))
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response_data, response

            logger.info("Processing : Storing Successful QnA Pairs into DB")
            success_flag  = False
            batch_size    = SETTINGS.EVAL.QNA_BATCH_CREATE_LIMIT
            batches       = [valid_qnas[i:i + batch_size] for i in range(0, len(valid_qnas), batch_size)]
            processed_ids = []

            for i, batch in enumerate(batches, start=1):
                logger.info(f"Storing <{i} / {len(batches)}> QnA Batch")
                batch_request = QnABatchCreateRequest(
                    create_requests=[
                        QnACreateRequest(
                            data=_data
                        )
                        for _data in batch
                    ]
                )
                try:
                    response = general_batch_create_qna(
                        request  = batch_request, 
                        api_call = self.api_call
                    )
                    success_flag = True
                    processed_ids += [_data.qna_id for _data in batch]
                    
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Failed to Store <{i} / {len(batches)}> QnA Batch", str(e)))
                    logger.info(response.detail)
                    continue

            logger.info("Processing : Storing Successful Evaluation into DB")
            success_flag  = False
            batch_size    = SETTINGS.EVAL.EVALUTATION_BATCH_CREATE_LIMIT
            batches       = [success_objects[i:i + batch_size] for i in range(0, len(success_objects), batch_size)]
            processed_ids = []

            for i, batch in enumerate(batches, start=1):
                logger.info(f"Storing <{i} / {len(batches)}> Evaluation Batch")
                batch_request = EvaluationBatchCreateRequest(
                    create_requests=[
                        EvaluationCreateRequest(
                            data=_data
                        )
                        for _data in batch
                    ]
                )
                try:
                    response = general_batch_create_evaluation(
                        request  = batch_request, 
                        api_call = self.api_call
                    )
                    success_flag = True
                    processed_ids += [_data.evaluation_id for _data in batch]
                    
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Failed to Store <{i} / {len(batches)}> Evaluation Batch", str(e)))
                    logger.info(response.detail)
                    continue

            if success_flag == True:
                """ Deactivating Dropping QnA Records """
                try:
                    _response = request_drop_knowledge_qna(request=KnowledgeQnARequest(knowledge_ids=[request.knowledge_id]))
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Failed to Drop Previous QnA Records", str(e)))
                    logger.error(response.detail)
                    return response_data, response

                """ Dropping Previous Records """
                response = self.drop_evaluation(request=KnowledgeEvaluationRequest(knowledge_ids=[request.knowledge_id]))
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return response_data, response

                """ Update Knowledge Ingestion Stage """
                update_request = KnowledgeUpdateRequest(
                    knowledge_id = request.knowledge_id,
                    update_data  = KnowledgeUpdate(
                        knowledge_ingestion_stage  = "Evaluated for Review",
                        knowledge_ingestion_reason ="Evaluated for Review",
                        average_groundedness      = sum([obj.groundedness for obj in success_objects]) / len(success_objects),
                        average_relevance         = sum([obj.relevance for obj in success_objects]) / len(success_objects),
                        average_retrieval         = sum([obj.retrieval for obj in success_objects]) / len(success_objects),
                        average_similarity        = sum([obj.similarity for obj in success_objects]) / len(success_objects)
                    ),
                    overwrite = True
                )
                response = self.update_knowledge(request=update_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return response_data, response

        else:
            logger.info("Save DB is Disabled. Skipped Evaluation Storage")

        """ 11. Finalize the request response """
        response_data.response_at = datetime.now(timezone.utc)

        response = Response(status_code=200, detail=self.response_format.ok(f"Success : Evaluation Completed"))
        logger.info(response.detail)
        return response_data, response

    def query_knowledge(self, request: SystemKnowledgeRequest) -> tuple[SystemKnowledgeResponse, Response]:
        response_data = SystemKnowledgeResponse(**request.__dict__)

        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.KNOW.HOST}:{SETTINGS.KNOW.PORT}/{SETTINGS.KNOW.REQUEST_KNOW_API}"
                payload = request.json()
                response_data, response = self.api_call_static(data=payload, service="KnowledgeHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                response_data = SystemKnowledgeResponse(**response_data)
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response_data = response_data.json()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Knowledge via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                if SETTINGS.BASE.APP_FUNC == True:
                    try:
                        response_data = system_query_knowledge(request=request, api_call=False)
                        response_data = SystemKnowledgeResponse(**response_data.__dict__)
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Knowledge via Function Call"))
                        logger.info(response.detail)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge via Function Call", str(e)))
                        logger.error(response.detail)
                
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Retrieve Knowledge but <APP_FUNC> is False"))
                    logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Retrieving Knowledge", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Retrieving Knowledge"))
            logger.error(response.detail)
        
        return response_data, response

    def update_knowledge(self, request: KnowledgeUpdateRequest) -> Response:

        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.KNOW.HOST}:{SETTINGS.KNOW.PORT}/{SETTINGS.KNOW.REQUEST_KNOW_API}"
                payload = request.json()
                response = self.api_call_static(data=payload, service="KnowledgeHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Updated Knowledge via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                if SETTINGS.BASE.APP_FUNC == True:
                    try:
                        response = general_update_knowledge(request=request, api_call=False)
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Updated Knowledge via Function Call"))
                        logger.info(response.detail)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Update Knowledge via Function Call", str(e)))
                        logger.error(response.detail)
                
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Update Knowledge but <APP_FUNC> is False"))
                    logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Updating Knowledge", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Updating Knowledge"))
            logger.error(response.detail)
        
        return response



    def deactivate_evaluation(self, request: KnowledgeEvaluationRequest) -> Response:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Started Deactivating Previous Evaluation Results")

        if not request.knowledge_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"Evaluation Result Deactivating Fail : <{SETTINGS.BASE.APP_NAME}> Cannot Find knowledge_ids for Deactivating Results"))
            logger.error(response.detail)
            return response
        
        data_request = SystemEvaluationRequest(
            data_filter=EvaluationFilter(
                string_filter=EvaluationStringFilter(
                    knowledge_id_filter=request.knowledge_ids
                ),
                numeric_filter=EvaluationNumericFilter(
                    evaluation_status_min=1
                )
            )
        )
        try:
            response_evaluation = system_query_evaluation(request=data_request, api_call=self.api_call)
            evaluation_ids = [_evaluation.evaluation_id for _evaluation in response_evaluation.filtered_data]
        
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving Evaluation Results", str(e)))
            logger.error(response.detail)
            return response
        
        if not evaluation_ids:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Previous Evaluations were Detected : <{SETTINGS.BASE.APP_NAME}> No Action is Taken"))
            logger.info(response.detail)
            return response
        
        # Batch Deactivate
        batch_request = EvaluationBatchRequest(
            batch_requests=[
                EvaluationRequest(evaluation_id=evaluation_id) 
                for evaluation_id in evaluation_ids
            ]
        )
        try:
            response = general_batch_deactivate_evaluation(request=batch_request, api_call=self.api_call)
            # response = general_batch_drop_evaluation(request=batch_request, api_call=self.api_call)
            logger.info(f"Completed Deactivating Evaluation : <{SETTINGS.BASE.APP_NAME}> Completed Deactivating Evaluation")
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Result Deactivating Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Deactivating Evaluation Results", str(e)))
            logger.error(response.detail)
            return response

        return response    

    def activate_evaluation(self, request: KnowledgeEvaluationRequest) -> Response:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Started Activating Previous Evaluation Results")

        if not request.knowledge_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"Evaluation Result Activating Fail : <{SETTINGS.BASE.APP_NAME}> Cannot Find knowledge_ids for Activating Results"))
            logger.error(response.detail)
            return response
        
        data_request = SystemEvaluationRequest(
            data_filter=EvaluationFilter(
                string_filter=EvaluationStringFilter(
                    knowledge_id_filter=request.knowledge_ids
                )
            )
        )
        try:
            response_evaluation = system_query_evaluation(request=data_request, api_call=self.api_call)
            evaluation_ids = [_evaluation.evaluation_id for _evaluation in response_evaluation.filtered_data]
        
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving Evaluation Results", str(e)))
            return response

        if not evaluation_ids:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Previous Evaluations were Detected : <{SETTINGS.BASE.APP_NAME}> No Action is Taken"))
            logger.info(response.detail)
            return response
        
        # Batch Activate
        batch_request = EvaluationBatchRequest(
            batch_requests=[
                EvaluationRequest(evaluation_id=evaluation_id) 
                for evaluation_id in evaluation_ids
            ]
        )
        try:
            response = general_batch_activate_evaluation(request=batch_request, api_call=self.api_call)
            logger.info(f"Completed Activating Evaluation : <{SETTINGS.BASE.APP_NAME}> Completed Activating Evaluation")
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Result Activating Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Activating Evaluation Results", str(e)))
            return response

        return response    


    def drop_evaluation(self, request: KnowledgeEvaluationRequest) -> Response:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Started Dropping Evaluation Results")
        start_at = time.time()

        if not request.knowledge_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"Evaluation Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Cannot Find knowledge_ids for Dropping Results"))
            logger.error(response.detail)
            return response
        
        data_request = SystemEvaluationRequest(
            data_filter=EvaluationFilter(
                string_filter=EvaluationStringFilter(
                    knowledge_id_filter=request.knowledge_ids
                ),
                numeric_filter=EvaluationNumericFilter(
                    evaluation_status_max=0
                )
            )
        )
        try:
            response_evaluation = system_query_evaluation(request=data_request, api_call=self.api_call)
            evaluation_ids = [_evaluation.evaluation_id for _evaluation in response_evaluation.filtered_data]
        
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving Evaluation Results", str(e)))
            logger.error(response.detail)
            return response

        if not evaluation_ids:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Previous Evaluations were Detected : <{SETTINGS.BASE.APP_NAME}> No Action is Taken"))
            logger.info(response.detail)
            return response

        # Batch Drop
        batch_request = EvaluationBatchRequest(
            batch_requests=[
                EvaluationRequest(evaluation_id=evaluation_id) 
                for evaluation_id in evaluation_ids
            ]
        )
        try:
            response = general_batch_drop_evaluation(request=batch_request, api_call=self.api_call)
            logger.info(f"Completed Dropping Evaluation : <{SETTINGS.BASE.APP_NAME}> Completed Dropping Evaluation")
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Dropping Evaluation Results", str(e)))
            logger.error(response.detail)
            return response

        return response    

    def generate_qna_response(self, request: EvaluationQuery) -> tuple[EvaluationQueryResponse, Response]:
        response_data = EvaluationQueryResponse(**request.__dict__)

        try:
            # API Call
            api_url = f"{SETTINGS.CHAT.URL}/{SETTINGS.CHAT.EVALUATION_API}"
            payload = request.json()
            response_data, response = self.api_call_static(data=payload, service="QAFlow", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
            response_data = EvaluationQueryResponse(**response_data)
            if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved QA Response via API"))
                logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Retrieving QA Response", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Retrieving QA Response"))
            logger.error(response.detail)
        
        return response_data, response

    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)
                
                resp.raise_for_status()
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp.json()

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response


    # def evaluate_chatflow(self, request: ChatflowEvaluationRequest) -> tuple[ChatflowEvaluationResponse, Response]:
    #     logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Initiated Evaluation Process")
    #     start_at = time.time()
    #     response_data = ChatflowEvaluationResponse(**request.__dict__)

    #     """ 3. Input QA into ChatFlow API Server"""
    #     _evaluation_results = []
    #     for i, qna in enumerate(request.data_input, start=1):
    #         logger.info(f"Processing : Evaluating QnA Pairs for <{i} / {len(request.data_input)}> Seed QnA Pair")

    #         _result = EvaluationResult(
    #             **qna.__dict__
    #         )

    #         payload = {
    #             "rationale": "",
    #             "query": qna.qna_query,
    #             "rationale": "",
    #             "chat_history":[],
    #             "custom_field": {"agent_id": "AD11223", "pru_force_lang": qna.qna_response_langauge}
    #         }

    #         try:
    #             logger.info("Processing : Sending Request to Chatflow API")
    #             resp = requests.post(SETTINGS.CHAT.URL, json=payload, headers={"Ocp-Apim-Subscription-Key": "123-123-123"})
    #             response_chatflow = resp.json()
    #             logger.info("Proccesing : Received Resposne from Chatflow API")
    #         except:
    #             continue
            
    #         _result.__dict__.update(
    #             actual_response = response_chatflow["response"]
    #         )

    #         """ 1. Prompt Formation """
    #         system_prompt = self.default_system_prompt.format(
    #             seed_response=qna.qna_response, 
    #             actual_response=_result.actual_response
    #         )

    #         """ 2. GenAI Inference """
    #         logger.info("Processing : Started Evaluation")
    #         retry_max_no = SETTINGS.INFR.RETRY_LIMIT
    #         retry_count  = 1
    #         while retry_count <= retry_max_no:
    #             inference_start_at = time.time()
    #             request_inference = InferenceRequest(input=InferenceInput(text=system_prompt))
    #             response_inference, response = InferenceServiceManager(api_call=self.api_call).inference_engine(request=request_inference)
    #             if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
    #                 break

    #             """ 3. Translate to Traditional Chinese if Chinese is Involved """
    #             try:
    #                 response_inference_json = self.response_jsonlize(response_inference.inference_output.text)
    #                 _response_time   = time.time() - inference_start_at
    #                 _groundedness     = response_inference_json["groundedness"]
    #                 _retrieval        = response_inference_json["retrieval"]
    #                 _relevance       = response_inference_json["relevance"]
    #                 _similarity      = response_inference_json["similarity"]
    #                 _evaluation_code = "Completed Evaluation"
    #                 break
                
    #             except:
    #                 if retry_count > retry_max_no:
    #                     _response_time = -1
    #                     _groundedness  = -1
    #                     _retrieval     = -1
    #                     _relevance     = -1
    #                     _similarity    = -1
    #                     _evaluation_code = "Failed to Call ChatflowAPI"
    #                     break
    #                 logger.error(f"LLM Formatting Issue. Retry <{retry_count}/{retry_max_no}>")
    #                 retry_count += 1

    #         """ 4. Parsing the Inference Response """
    #         _result.__dict__.update(
    #             evaluation_code    = _evaluation_code,
    #             evaluation_source  = qna,
    #             evaluation_metrics = EvaluationMetrics(
    #                 groundedness    = _groundedness,
    #                 retrieval       = _retrieval,
    #                 similarity      = _similarity,
    #                 relevance       = _relevance,
    #                 input_tokens    = response_inference.inference_metrics.input_tokens,
    #                 output_tokens   = response_inference.inference_metrics.output_tokens,
    #                 response_time   = _response_time
    #             )
    #         )

    #         _evaluation_results.append(_result)

    #     """ 5. Finalizing the Request Response """
    #     response_data.__dict__.update(
    #         evaluation_results = _evaluation_results,
    #         total_no        = len(request.data_input),
    #         evaluation_time = time.time() - start_at,
    #         response_at     = datetime.now()
    #     )

    #     response = Response(status_code=200, detail=self.response_format.ok(f"Success : Evaluation Completed"))
    #     return response_data, response


    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp.json()["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp.json()

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response