import tiktoken

def consolidate_page_ranges(page_ranges: list[dict]) -> str:
    if not page_ranges:
        return ""

    # Sort by page_start and then page_end
    sorted_ranges = sorted(page_ranges, key=lambda x: (x['page_start'], x['page_end']))
    consolidated = []
    
    current_start = sorted_ranges[0]['page_start']
    current_end = sorted_ranges[0]['page_end']

    for page in sorted_ranges[1:]:
        start = page['page_start']
        end = page['page_end']

        if start <= current_end + 1:  # Check for overlap or contiguity
            current_end = max(current_end, end)  # Extend the current range
        else:
            # Append the current range
            consolidated.append((current_start, current_end))
            current_start = start
            current_end = end

    # Append the last range
    consolidated.append((current_start, current_end))

    # Format the output
    formatted_ranges = []
    for start, end in consolidated:
        if start == end:
            formatted_ranges.append(str(start))  # Single page
        else:
            formatted_ranges.append(f"{start}-{end}")  # Range

    return ", ".join(formatted_ranges)


def num_tokens_from_string(string: str, encoding_name: str="cl100k_base") -> int:
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens