import inspect
import time
import json
import re
import httpx
import os
import requests
import pandas as pd
import tiktoken

from datetime import datetime, timezone

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
)

from ..schemas.inference import (
    InferenceRequest,
    InferenceInput
)

from ..schemas.seed_qna import (
    SeedQnAFilter,
    SeedQnAStringFilter,
    SeedQnANumericFilter,
    SystemSeedQnARequest,
    SystemSeedQnAResponse
)

from ..schemas.qna import (
    QnAPair,
    QnACreate,
    QnACreateRequest,
    QnABatchCreateRequest,
    QnAGenerationRequest,
    QnAGenerationResponse,
    KnowledgeQnARequest,
    KnowledgeQnAReadResponse,
    QnABatchRequest,
    SystemQnARequest,
    QnARequest,
    QnAFilter,
    QnAStringFilter,
    QnANumericFilter
)

from ..schemas.chatflow import (
    EvaluationQuery,
    EvaluationQueryResponse
)

from ..schemas.utils import (
    KnowledgeVectorRequest,
    KnowledgeVectorReadResponse,
    KnowledgeUpdate,
    KnowledgeUpdateRequest,
    SecretKnowledge,
    KnowledgeStringFilter,
    KnowledgeNumericFilter,
    KnowledgeFilter,
    SystemKnowledgeRequest,
    SystemKnowledgeResponse
)

from ..schemas.chatflow import (
    EvaluationQuery,
    CustomField
)

from ..services.utils import consolidate_page_ranges

from ..services.inference import InferenceServiceManager

from ..routers.registry.general import general_batch_create_qna, general_batch_activate_qna, general_batch_deactivate_qna, general_batch_drop_qna
from ..routers.registry.system import system_query_qna, system_query_seedqna

if SETTINGS.BASE.APP_FUNC == True:
    from ..services import system_query_knowledge, general_update_knowledge, general_read_knowledge_vector


from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class QnAServiceManager:

    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    
    # default_system_prompt = """
    #     YOU ARE THE WORLD'S BEST INSURANCE AUDIT ASSISTANT FROM Prudential Hong Kong. Your task is to generate variations of question-and-answer pairs related to insurance, taking into account both the given SEED QUESTION AND ANSWER PAIR **and** the relevant CHUNKS FROM THE DOCUMENT.

    #     ### INSTRUCTIONS

    #     1. **Operating Guidelines**:
    #     - Do not request additional information or clarification unless the user explicitly asks.  
    #     - Generate question-and-answer pairs in either English or Traditional Chinese, ensuring a 1:1 ratio (half in English, half in Traditional Chinese).
    #     - Produce `{unit_generation_num}` question-and-answer pairs based on the seed question-and-answer pair.
    #     - Preserve the core meaning of the seed Q&A but create novel and varied phrasing.
    #     - The first generated query must be rephrase version of the seed question.
    #     - Incorporate facts from the document chunks whenever relevant; do not add any incorrect or speculative information.
    #     - Ensure that any referenced document_ids are used correctly and match actual document_ids from the provided context.

    #     2. **Response Principles**:
    #     - Maintain a professional, empathetic, and comprehensive tone.
    #     - Avoid vague or generic statements; be specific and reference detailed information from the chunks if applicable.
    #     - Explain any insurance terminology used.
    #     - Do not distort or omit key terms, conditions, or exclusions.
    #     - Remain accurate and transparent concerning Prudential Hong Kong insurance products.

    #     ---

    #     ### CHAIN OF THOUGHTS

    #     1. **Analyzing the Seed Pair**:
    #     - Understand the essence of the seed question and answer.
    #     - Identify any key terms or conditions.

    #     2. **Selecting Relevant Content**:
    #     - Review the CHUNKS FROM THE DOCUMENT for matching or related information.
    #     - Use relevant chunks to add or rephrase details.

    #     3. **Constructing New Q&A Pairs**:
    #     - Vary language, structure, and style while preserving the essential meaning.
    #     - Change keywords to related terms if it helps rephrase or add diversity.

    #     4. **Tailor the Generated Response**  
    #     - Use selected document chunks to highlight product advantages and features.  
    #     - Clarify terms, conditions, or exclusions.  
    #     - Offer advice based on the user’s specific needs.  
    #     - Suggest related Prudential Hong Kong products if relevant.  
    #     - Provide next steps for completing or advancing the insurance process.

    #     5. **Handle Insufficient Data**  
    #     - If a generated Q&A pair cannot be supported by the document chunks, the final response for that Q&A pair must be "None" and the corresponding language fields must also be "None". The document_ids for such a pair would be an empty list [].

    #     6. **Final Output Formatting**:
    #     - Must return the results in valid JSON structure as shown below.
    #     - Do not mention document_ids in the body of your Q&A text; only include them in the "document_ids" field.

    #     ---
    #     ---

    #     ### WHAT NOT TO DO
    #     OBEY and never do:
    #     - NEVER PROVIDE GENERIC OR VAGUE ANSWERS THAT LACK SPECIFIC DETAILS.
    #     - NEVER USE JARGON WITHOUT EXPLANATION, ENSURE ALL TERMS ARE CLEARLY DEFINED.
    #     - NEVER IGNORE THE USER'S SPECIFIC NEEDS OR CIRCUMSTANCES.
    #     - NEVER INCLUDE INCORRECT OR MISLEADING INFORMATION ABOUT INSURANCE PRODUCTS.
    #     - NEVER FAIL TO MAINTAIN A PROFESSIONAL AND EMPATHETIC TONE.
    #     - NEVER OMIT IMPORTANT TERMS, CONDITIONS, OR EXCLUSIONS.
    #     - NEVER ASK THE USER FOR ADDITIONAL INFORMATION OR CLARIFICATION UNLESS THEY HAVE SPECIFICALLY REQUESTED IT.
    #     - NEVER USE DOCUMENT_IDS THAT ARE NOT PRESENT IN THE PROVIDED CONTEXT OR MODIFY THE DOCUMENT_IDS IN ANY WAY.
    #     - NEVER IGNORE OR OVERLOOK THE PRODUCT NAME AND TERMINOLOGY IN THE USER QUERY
    #     ---

    #     ### CHUNKS FROM THE DOCUMENT
    #     {document_chunks}

    #     ---

    #     ### NOTE
    #     - The final JSON must be in the format below.  
    #     - For each Q&A pair:  
    #     - If sufficient and relevant data exist, produce your question, answer, and the correct document_ids (if any).  
    #     - If data is insufficient, the "response" must be "None", and the corresponding language fields must be "None", with an empty list of document_ids.  

    #     The final JSON must look like this (all strings properly escaped, no extra newlines):
    #     ```json
    #     {{
    #         "queries": [
    #         "generated_query 1 that must be a rephrase version of the seed question",
    #         "generated_query 2",
    #         "generated_query 3 that is insufficient data in the CHUNKS FROM THE DOCUMENT",
    #         ...
    #         ],
    #         "responses": [
    #         "generated_response 1",
    #         "generated_response 2",
    #         "None",
    #         ...
    #         ],
    #         "query_languages": [
    #         "language of query 1 en or zh",
    #         "language of query 2 en or zh",
    #         "None",
    #         ...
    #         ],
    #         "response_languages": [
    #         "language of response 1 en or zh",
    #         "language of response 2 en or zh",
    #         "None",
    #         ...
    #         ],
    #         "document_ids": [
    #         ["id starting with D- of Q&A pair 1", "id starting with D- of Q&A pair 1", ...],
    #         ["id starting with D- of Q&A pair 2", ...],
    #         [],
    #         ...
    #         ]
    #     }}
    #     ```
        

    #     **Important Note**:  
    #     - Do not reveal or discuss the document_ids in your generated text—only in the "document_ids" field.  
    #     - The generated_response should be detailed and comprehensive, without mentioning `document_ids` or document references in the main text.
    #     - Ensure all instructions, constraints, and guidelines are followed meticulously.
    #     - Generated question-and-answer pairs should only be in either English or Traditional Chinese, ensuring a 1:1 ratio (half in English, half in Traditional Chinese).
        
    #     ---
    #     Here is All the seed question and answer pair for your generation.  
    #     SEED QUESTION: {seed_query}  
    #      SEED ANSWER: {seed_response}

    #     """

    # default_system_prompt = """
    #     YOU ARE THE WORLD'S BEST INSURANCE AUDIT ASSISTANT FROM Prudential Hong Kong. Your task is to generate variations of question-and-answer pairs related to insurance, taking into account both the given SEED QUESTION AND ANSWER PAIR **and** the relevant CHUNKS FROM THE DOCUMENT.

    #     ### INSTRUCTIONS

    #     1. **Operating Guidelines**:
    #     - Do not request additional information or clarification unless the user explicitly asks.  
    #     - Generate question-and-answer pairs in either English or Traditional Chinese, ensuring a 1:1 ratio (half in English, half in Traditional Chinese).
    #     - Produce `{unit_generation_num}` question-and-answer pairs based on the seed question-and-answer pair.
    #     - Preserve the core meaning of each seed Q&A but create novel and varied phrasing.
    #     - Incorporate facts from the document chunks whenever relevant; do not add any incorrect or speculative information.
    #     - Ensure that any referenced document_ids are used correctly and match actual document_ids from the provided context.

    #     2. **Response Principles**:
    #     - Maintain a professional, empathetic, and comprehensive tone.
    #     - Avoid vague or generic statements; be specific and reference detailed information from the chunks if applicable.
    #     - Explain any insurance terminology used.
    #     - Do not distort or omit key terms, conditions, or exclusions.
    #     - Remain accurate and transparent concerning Prudential Hong Kong insurance products.

    #     ---

    #     ### CHAIN OF THOUGHTS

    #     1.  **Analyzing Each Seed Pair**:
    #     - Understand the essence of each seed question and answer.
    #     - Identify any key terms or conditions.

    #     2. **Selecting Relevant Content**:
    #     - Review the CHUNKS FROM THE DOCUMENT for matching or related information.
    #     - Use relevant chunks to add or rephrase details.

    #     3. **Constructing New Q&A Pairs**:
    #     - Vary language, structure, and style while preserving the essential meaning.
    #     - Change keywords to related terms if it helps rephrase or add diversity.

    #     4. **Tailor the Generated Response**  
    #     - Use selected document chunks to highlight product advantages and features.  
    #     - Clarify terms, conditions, or exclusions.  
    #     - Offer advice based on the user’s specific needs.  
    #     - Suggest related Prudential Hong Kong products if relevant.  
    #     - Provide next steps for completing or advancing the insurance process.

    #     5. **Handle Insufficient Data**  
    #     - If a generated Q&A pair cannot be supported by the document chunks, the final response for that Q&A pair must be "None" and the corresponding language fields must also be "None". The document_ids for such a pair would be an empty list [].

    #     6. **Final Output Formatting**:
    #     - Must return the results in valid JSON structure as shown below.
    #     - Do not mention document_ids in the body of your Q&A text; only include them in the "document_ids" field.

    #     ---
    #     ---

    #     ### WHAT NOT TO DO
    #     OBEY and never do:
    #     - NEVER PROVIDE GENERIC OR VAGUE ANSWERS THAT LACK SPECIFIC DETAILS.
    #     - NEVER USE JARGON WITHOUT EXPLANATION, ENSURE ALL TERMS ARE CLEARLY DEFINED.
    #     - NEVER IGNORE THE USER'S SPECIFIC NEEDS OR CIRCUMSTANCES.
    #     - NEVER INCLUDE INCORRECT OR MISLEADING INFORMATION ABOUT INSURANCE PRODUCTS.
    #     - NEVER FAIL TO MAINTAIN A PROFESSIONAL AND EMPATHETIC TONE.
    #     - NEVER OMIT IMPORTANT TERMS, CONDITIONS, OR EXCLUSIONS.
    #     - NEVER ASK THE USER FOR ADDITIONAL INFORMATION OR CLARIFICATION UNLESS THEY HAVE SPECIFICALLY REQUESTED IT.
    #     - NEVER USE DOCUMENT_IDS THAT ARE NOT PRESENT IN THE PROVIDED CONTEXT OR MODIFY THE DOCUMENT_IDS IN ANY WAY.
    #     - NEVER IGNORE OR OVERLOOK THE PRODUCT NAME AND TERMINOLOGY IN THE USER QUERY
    #     ---

    #     ### CHUNKS FROM THE DOCUMENT
    #     {document_chunks}

    #     ---

    #     ### NOTE
    #     - The final JSON must be in the format below.  
    #     - For each Q&A pair:  
    #     - If sufficient and relevant data exist, produce your question, answer, and the correct document_ids (if any).  
    #     - If data is insufficient, the "response" must be "None", and the corresponding language fields must be "None", with an empty list of document_ids.  

    #     The final JSON must look like this (all strings properly escaped, no extra newlines):
    #     ```json
    #     {{
    #         "queries": [
    #         "generated_query 1 that must be a rephrase version of the seed question",
    #         "generated_query 2",
    #         "generated_query 3 that is insufficient data in the CHUNKS FROM THE DOCUMENT",
    #         ...
    #         ],
    #         "responses": [
    #         "generated_response 1",
    #         "generated_response 2",
    #         "None",
    #         ...
    #         ],
    #         "query_languages": [
    #         "language of query 1 en or zh",
    #         "language of query 2 en or zh",
    #         "None",
    #         ...
    #         ],
    #         "response_languages": [
    #         "language of response 1 en or zh",
    #         "language of response 2 en or zh",
    #         "None",
    #         ...
    #         ],
    #         "document_ids": [
    #         ["id starting with D- of Q&A pair 1", "id starting with D- of Q&A pair 1", ...],
    #         ["id starting with D- of Q&A pair 2", ...],
    #         [],
    #         ...
    #         ]
    #     }}
    #     ```
        

    #     **Important Note**:  
    #     - Do not reveal or discuss the document_ids in your generated text—only in the "document_ids" field.  
    #     - The generated_response should be detailed and comprehensive, without mentioning `document_ids` or document references in the main text.
    #     - Ensure all instructions, constraints, and guidelines are followed meticulously.
    #     - Generated question-and-answer pairs should only be in either English or Traditional Chinese, ensuring a 1:1 ratio (half in English, half in Traditional Chinese).


    #     ### SEED QUESTION AND ANSWER PAIR
    #     Here is All the seed question and answer pair for your generation:
    #     {seed_qa}
    #     """


    def __init__(self, api_call: bool):
        self.api_call = api_call
    
    # def response_jsonlize(self, text: str) -> dict:
    #     match = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
    #     if match:
    #         json_str = match.group(1)
    #     else:
    #         json_str = text  
    #     try:
    #         data = json.loads(json_str)
    #         if isinstance(data, dict) and "queries" in data and "responses" in data and "query_languages" in data and "response_languages" in data:
    #             if isinstance(data["queries"], list) and isinstance(data["responses"], list) and isinstance(data["query_languages"], list) and isinstance(data["response_languages"], list):
    #                 if all(isinstance(_query, str) for _query in data["queries"]) and all(isinstance(_response, str) for _response in data["responses"]) and all(isinstance(_qlanguage, str) for _qlanguage in data["query_languages"]) and all(isinstance(_rlanguage, str) for _rlanguage in data["response_languages"]):
    #                     return {
    #                         "queries":            data.get("queries", []),
    #                         "responses":          data.get("responses", []),
    #                         "query_languages":    data.get("query_languages", []),
    #                         "response_languages": data.get("response_languages", []),
    #                         "document_ids":       data.get("document_ids", [])
    #                     }
    #     except json.JSONDecodeError:
    #         raise json.JSONDecodeError
        
    #     return {"queries": [], "responses": [], "query_languages": [], "response_languages": [], "document_ids": []}



    def citation_prompt_formation(self, citations: list[str]) -> str:
        
        citation_prompt = "\n\n".join([
            f'{{"citation_id": "C-{i}"," "content": "{_citation}"}}'
            for  i, _citation in enumerate(citations, start=1)
            ]
        )

        return citation_prompt


    def get_seed_qna_by_library(self, library_name: str) -> tuple[list[QnAPair], Response]:
        response_data = []

        """ 1. Retrieving Seed QnA Data """
        logger.info("Processing : Retrieving Seed QnA")
        
        seed_qna_request = SystemSeedQnARequest(
            data_filter = SeedQnAFilter(
                string_filter=SeedQnAStringFilter(
                    library_name_en_filter=[library_name]
                ),
                numeric_filter=SeedQnANumericFilter(
                    seed_qna_status_min=1
                )
            )
        )
        try:
            response_seedqnas = system_query_seedqna(request=seed_qna_request, api_call=self.api_call)
            response_data = [QnAPair(**_qna.__dict__) for _qna in response_seedqnas.filtered_data]
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Got Seed QnA"))

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Seed QnA Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Cannot Retrieve Seed QnA"))
            logger.error(response.detail)
            return response_data, response

        return response_data, response


    def generate_knowledge_qna(self, request: QnAGenerationRequest) -> tuple[QnAGenerationResponse, Response]:

        default_system_prompt = """
        YOU ARE THE WORLD'S BEST INSURANCE AUDIT ASSISTANT FROM Prudential Hong Kong. Your task is to generate variations of question-and-answer pairs solely based on the content provided in the CHUNKS FROM THE DOCUMENT. Use the SEED QUESTION AND ANSWER PAIR only as a style reference; DO NOT incorporate its content into the generated questions.

        ### INSTRUCTIONS

        1. **Operating Guidelines**:
        - Do not ask for additional information or clarification unless explicitly required.
        - Generate `{unit_generation_num}` refernce questions that preserve the core meaning of the seed question but are entirely based on the information in the CHUNKS FROM THE DOCUMENT.
        - The generated questions must be answerable solely using the information provided in the document chunks.
        - If the documents are insurances products, policies, regulations, etc., you must specific the name of the products, policies, regulations to make the question clear for being answerable solely.
        - Avoid including any speculative, incorrect, or out-of-context details. Do not directly use the content of the seed question or answer.

        2. **Response Principles**:
        - Maintain a professional and empathetic tone.
        - Ensure the language is specific, detailed, and references facts from the document chunks when applicable.
        - In the generated queries, include the product / policy names, key terms, conditions, or exclusions as provided in the document chunks.
        - Do not include or alter any chunk_id (C-) found in the context.

        3. **Final Output Formatting**:
        - Return your results in a valid JSON structure as shown below.
        - Populate only the "queries" field with the generated questions. Follow the example JSON structure exactly.
        - Ensure that all string values are properly escaped with no extra newlines.

        4. **Language Requirements**:
        - Generated questions must be written exclusively in either English or Traditional Chinese.
        - Ensure a 1:1 ratio (half in English, half in Traditional Chinese).

        ### CHUNKS FROM THE DOCUMENT
        {document_chunks}

        ### SEED QUESTION AND ANSWER PAIR (Style Reference Only)
        {seed_qna}

        ### TARGET JSON OUTPUT FORMAT
        The JSON must strictly follow this structure (with escaped strings, no extraneous newlines):
        ```json
        {{
            "queries": [
                "generated_query 1",
                "generated_query 2",
                ...
            ],
            "query_languages": [
                "language of query 1 en or zh",
                "language of query 2 en or zh",
                ...
            ]
        }}


        **IMPORTANT NOTES:**
        - Do not include any direct content from the seed question or answer; use them solely to guide the style and tone.
        - Ensure all instructions and constraints are followed meticulously.
        """

        def response_jsonlize(text: str) -> dict:
            match = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
            if match:
                json_str = match.group(1)
            else:
                json_str = text  
            try:
                data = json.loads(json_str)
                if isinstance(data, dict) and "queries" in data and "query_languages" in data:
                    if isinstance(data["queries"], list):
                        if all(isinstance(_query, str) for _query in data["queries"]):
                            return {
                                "queries":            data.get("queries", []),
                                "query_languages":    data.get("query_languages", []),

                            }
            except json.JSONDecodeError:
                raise json.JSONDecodeError
            
            return {"queries": [], "query_languages": []}
            
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Initated Knowledge QnA Generation Process")
        start_at = time.time()
        
        seed_qnas = []
        response_data = QnAGenerationResponse(**request.__dict__)
        total_input_tokens  = 0
        total_output_tokens = 0
        total_tool_tokens   = 0

        """ 1. Retrieving Knowledge Data """
        logger.info("Prcessing : Retrieving Knowledge Metadata")
        if not request.knowledge_id:
            response = Response(status_code=404, detail=self.response_format.error(f"Generation Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Knowledge ID for Generation"))
            logger.error(response.detail)
            return response_data, response
        
        knowledge_request = SystemKnowledgeRequest(
            data_filter = KnowledgeFilter(
                string_filter=KnowledgeStringFilter(
                    knowledge_id_filter=[request.knowledge_id]
                )
            )
        )
        response_knowledge, response = self.query_knowledge(request=knowledge_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response
        else:
            if not response_knowledge.filtered_data:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : <{SETTINGS.BASE.APP_NAME}> Retrieved Empty Knowledge"))
                logger.error(response.detail)
                return response_data, response
            else:
                knowledge_metadata = response_knowledge.filtered_data[0]
        
        """ 2. Input Validation for Seed QnA """
        if not request.data_input:
            response = Response(status_code=200, detail=self.response_format.ok(f"Processing : <{SETTINGS.BASE.APP_NAME}> Cannot Find Seed QnA for Generation. Trying Retrieving Seed QnA from Category"))
            logger.info(response.detail)
            
            seed_qnas, response = self.get_seed_qna_by_library(knowledge_metadata.library_name_en)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response_data, response

            if not seed_qnas:
                response = Response(status_code=200, detail=self.response_format.ok(f"Unfound Seed QnA Library : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid Seed QnA from Library"))
                logger.info(response.detail)

                update_request = KnowledgeUpdateRequest(
                    knowledge_id = request.knowledge_id,
                    update_data  = KnowledgeUpdate(
                            knowledge_ingestion_stage="Initialize Q&A Dataset",
                            knowledge_ingestion_reason=response.detail
                        ),
                    overwrite    = True
                )
                _response = self.update_knowledge(request=update_request)
                if _response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return response_data, _response
                return response_data, response
            
        else:
            seed_qnas = request.data_input

        """ 3. Update Knowledge Ingestion Stage """
        update_request = KnowledgeUpdateRequest(
            knowledge_id = request.knowledge_id,
            update_data  = KnowledgeUpdate(knowledge_ingestion_stage="Initialize Q&A Dataset"),
            overwrite    = True
        )
        response = self.update_knowledge(request=update_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response

        
        """ 4. Retrieve Knowledge Vectors for QnA Generation"""
        logger.info("Processing : Retrieving Knowledge Vectors for QnA Generation")
        vector_request = KnowledgeVectorRequest(knowledge_id=request.knowledge_id)

        response_vector, response = self.query_vector(request=vector_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response
        else:
            if not response_vector.filtered_vectors:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : <{SETTINGS.BASE.APP_NAME}> Retrieved Empty Vectors"))
                logger.error(response.detail)
                return response_data, response
            else:
                knowledge_vectors = response_vector.filtered_vectors

        """ 5. Generate Questions based on Seed QnAs """
        # Prepare document chunks and ID mapping
        success_objects = []
        fail_objects    = []
        raw_texts = [vec.raw_data.strip() for vec in knowledge_vectors if vec.raw_data]

        content_windows = self.truncate_content(raw_texts, SETTINGS.EVAL.TOKEN_LIMIT)

        for raw_text in content_windows:
            citation_prompt = self.citation_prompt_formation(raw_text)

            seed_qna_prompt = "\n\n".join(
                [
                    f"seed_query: {qna.qna_query}\nseed_response: {qna.qna_response}" 
                    for qna in seed_qnas
                ]
            )

            logger.info("Processing : Generating QnA with reference to Seed QnAs")
            system_prompt = default_system_prompt.format(
                unit_generation_num = request.unit_generation_num,
                document_chunks     = citation_prompt,
                seed_qna            = seed_qna_prompt
            )

            # 2) GenAI Inference (Single Attempt or Retry Mechanism)
            retry_max_no = SETTINGS.INFR.RETRY_LIMIT
            retry_count  = 1
            generated_queries         = []
            generated_query_languages = []

            while retry_count <= retry_max_no:
                logger.info(f"Calling Inference Service - Attempt: <{retry_count} / {retry_max_no}>")
                request_inference = InferenceRequest(input=InferenceInput(text=system_prompt))
                response_inference, response = InferenceServiceManager(api_call=self.api_call).inference_engine(request=request_inference)

                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    logger.error(f"Inference Error : Retrying")
                    retry_count += 1
                    continue

                # Update Metrics
                total_input_tokens  += response_inference.inference_metrics.input_tokens
                total_output_tokens += response_inference.inference_metrics.output_tokens

                # Attempt to parse the inference output
                try:
                    response_inference_json   = response_jsonlize(response_inference.inference_output.text)
                    generated_queries         = response_inference_json["queries"]
                    generated_query_languages = response_inference_json["query_languages"]
                    break

                except:
                    if retry_count >= retry_max_no:
                        response = Response(status_code=500, detail=self.response_format.error(f"Inference Max Retry Reached : <{SETTINGS.BASE.APP_NAME}> Failed to Generate QnA due to Inference Error"))
                        logger.error(response.detail)
                        return response_data, response
                    
                    logger.error(f"LLM Formatting Issue. Retrying")
                    retry_count += 1
                    time.sleep(SETTINGS.EVAL.INFERENCE_INTERVAL)

                break

            """ 6. Generated Response based on Generated Questions """
            for i, (query, qlang) in enumerate(zip(generated_queries, generated_query_languages)):
                custom_field = CustomField(
                    agent_id       = 'abc123',
                    pru_force_lang = qlang  # Use the corresponding query language
                )

                qna_request = EvaluationQuery(
                    query         = query,
                    rationale     = '',
                    knowledge_ids = [request.knowledge_id],
                    chat_history  = [],
                    custom_field  = custom_field
                )

                response_qna, response = self.generate_qna_response(request=qna_request)

                generated_qna = QnACreate(
                    **request.__dict__,
                    document_name         = f"{knowledge_metadata.knowledge_name}{knowledge_metadata.knowledge_fileextension}",
                    qna_query             = query,
                    qna_response          = response_qna.response,
                    qna_citations         = [f'{citation.document.document_name} ({consolidate_page_ranges(page_ranges=[{"page_start": _citiation.page_start, "page_end": _citiation.page_end} for _citiation in citation.citations])})' for citation in response_qna.citations],
                    qna_data_ids          = [f'{chunk.data_id}' for citation in response_qna.citations for chunk in citation.citations],
                    qna_query_language    = qlang,
                    qna_response_language = qlang
                )

                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    fail_objects.append(generated_qna)
                    continue
                elif response_qna.response in ["NONE", "UNCLEAR"]:
                    continue
                else:
                    success_objects.append(generated_qna)
                
        """ 7. Save to DB """
        if request.save_to_db:

            """ 8. Deactivating Previous Records """
            response = self.deactivate_knowledge_qna(request=KnowledgeQnARequest(knowledge_ids=[request.knowledge_id]))
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response_data, response
            
            logger.info("Processing : Storing Successful QnA Pairs into DB")
            success_flag  = False
            batch_size    = SETTINGS.EVAL.QNA_BATCH_CREATE_LIMIT
            batches       = [success_objects[i:i + batch_size] for i in range(0, len(success_objects), batch_size)]
            processed_ids = []

            for i, batch in enumerate(batches, start=1):
                logger.info(f"Storing <{i} / {len(batches)}> QnA Batch")
                batch_request = QnABatchCreateRequest(
                    create_requests=[
                        QnACreateRequest(
                            data=_data
                        )
                        for _data in batch
                    ]
                )
                try:
                    response = general_batch_create_qna(
                        request  = batch_request, 
                        api_call = self.api_call
                    )
                    success_flag = True
                    processed_ids += [_data.qna_id for _data in batch]
                    
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Failed to Store <{i} / {len(batches)}> QnA Batch", str(e)))
                    logger.info(response.detail)
                    continue

            if success_flag == True:
                """ Dropping Previous Records """
                response = self.drop_knowledge_qna(request=KnowledgeQnARequest(knowledge_ids=[request.knowledge_id]))
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return response_data, response

                """ Update Knowledge Ingestion Stage """
                update_request = KnowledgeUpdateRequest(
                    knowledge_id = request.knowledge_id,
                    update_data  = KnowledgeUpdate(
                        knowledge_ingestion_stage="Reviewing Q&A Dataset",
                        knowledge_ingestion_reason="Reviewing Q&A Dataset"
                    ),
                    overwrite    = True
                )
                response = self.update_knowledge(request=update_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return response_data, response

        else:
            logger.info("Save DB is Disabled. Skipped QnA Storage")

        """ 9. Finalize the request response """
        response_data.__dict__.update(
            success_objects     = success_objects,
            fail_objects        = fail_objects,
            total_qna_count     = len(generated_queries),
            success_qna_count   = len(success_objects),
            fail_qna_count      = len(fail_objects),
            generation_time     = time.time() - start_at,
            total_input_tokens  = total_input_tokens,
            total_output_tokens = total_output_tokens,
            total_tool_tokens   = total_tool_tokens,
            response_at         = datetime.now(timezone.utc)
        )

        return response_data, response

    def query_knowledge(self, request: SystemKnowledgeRequest) -> tuple[SystemKnowledgeResponse, Response]:
        response_data = SystemKnowledgeResponse(**request.__dict__)

        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.KNOW.HOST}:{SETTINGS.KNOW.PORT}/{SETTINGS.KNOW.REQUEST_KNOW_API}"
                payload = request.json()
                response_data, response = self.api_call_static(data=payload, service="KnowledgeHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                response_data = SystemKnowledgeResponse(**response_data)
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response_data = response_data.json()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Knowledge via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                if SETTINGS.BASE.APP_FUNC == True:
                    try:
                        response_data = system_query_knowledge(request=request, api_call=False)
                        response_data = SystemKnowledgeResponse(**response_data.__dict__)
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Knowledge via Function Call"))
                        logger.info(response.detail)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge via Function Call", str(e)))
                        logger.error(response.detail)
                
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Retrieve Knowledge but <APP_FUNC> is False"))
                    logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Retrieving Knowledge", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Retrieving Knowledge"))
            logger.error(response.detail)
        
        return response_data, response

    def update_knowledge(self, request: KnowledgeUpdateRequest) -> Response:

        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.KNOW.HOST}:{SETTINGS.KNOW.PORT}/{SETTINGS.KNOW.REQUEST_KNOW_API}"
                payload = request.json()
                response = self.api_call_static(data=payload, service="KnowledgeHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Updated Knowledge via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                if SETTINGS.BASE.APP_FUNC == True:
                    try:
                        response = general_update_knowledge(request=request, api_call=False)
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Updated Knowledge via Function Call"))
                        logger.info(response.detail)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Update Knowledge via Function Call", str(e)))
                        logger.error(response.detail)
                
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Update Knowledge but <APP_FUNC> is False"))
                    logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Updating Knowledge", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Updating Knowledge"))
            logger.error(response.detail)
        
        return response

    def query_vector(self, request: KnowledgeVectorRequest) -> tuple[KnowledgeVectorReadResponse, Response]:
        response_data = KnowledgeVectorReadResponse(**request.__dict__)

        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.KNOW.HOST}:{SETTINGS.KNOW.PORT}/{SETTINGS.KNOW.REQUEST_DATA_API}"
                payload = request.json()
                response_data, response = self.api_call_static(data=payload, service="KnowledgeHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                response_data = KnowledgeVectorReadResponse(**response_data)
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response_data = response_data.json()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Knowledge Vector via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                if SETTINGS.BASE.APP_FUNC == True:
                    try:
                        response_data = general_read_knowledge_vector(request=request)
                        response_data = KnowledgeVectorReadResponse(**response_data.__dict__)
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Knowledge Vector via Function Call"))
                        logger.info(response.detail)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge Vector via Function Call", str(e)))
                        logger.error(response.detail)
                
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Retrieve Knowledge Vector but <APP_FUNC> is False"))
                    logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Retrieving Knowledge Vector", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Retrieving Knowledge Vector"))
            logger.error(response.detail)
        
        return response_data, response
    

    def generate_qna_response(self, request: EvaluationQuery) -> tuple[EvaluationQueryResponse, Response]:
        response_data = EvaluationQueryResponse(**request.__dict__)

        try:
            # API Call
            api_url = f"{SETTINGS.CHAT.URL}/{SETTINGS.CHAT.EVALUATION_API}"
            payload = request.json()
            response_data, response = self.api_call_static(data=payload, service="QAFlow", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
            response_data = EvaluationQueryResponse(**response_data)
            if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved QA Response via API"))
                logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Retrieving QA Response", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Retrieving QA Response"))
            logger.error(response.detail)
        
        return response_data, response

    def read_knowledge_qna(self, request: KnowledgeQnARequest) -> tuple[KnowledgeQnAReadResponse, Response]:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Started Reading QnA Results")
        response_data = KnowledgeQnAReadResponse(**request.__dict__)
        
        if not request.knowledge_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"QnA Result Read Fail : <{SETTINGS.BASE.APP_NAME}> Cannot Find knowledge_ids for Reading Results"))
            logger.error(response.detail)
            return response_data, response
        
        data_request = SystemQnARequest(
            data_filter=QnAFilter(
                string_filter=QnAStringFilter(
                    knowledge_id_filter=request.knowledge_ids
                )
            )
        )

        try:
            response_data.response_at = datetime.now(timezone.utc)
            response_qna = system_query_qna(request=data_request, api_call=self.api_call)
            qna_data = response_qna.filtered_data
            response = Response(status_code=200, detail=self.response_format.ok(f"Retrieved QnA Results : <{SETTINGS.BASE.APP_NAME}> Retrieved QnA for Evaluation"))
            logger.info(response.detail)
            
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Result Reading Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving QnA Results", str(e)))
            logger.info(response.detail)
            return response_data, response

        if not qna_data:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Previous QnAs were Detected : <{SETTINGS.BASE.APP_NAME}> No Action is Taken"))
            logger.info(response.detail)
            return response_data, response
        else:
            response_data.filtered_data = qna_data

        return response_data, response

    def deactivate_knowledge_qna(self, request: KnowledgeQnARequest) -> Response:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Started Deactivating Previous QnA Results")

        if not request.knowledge_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"QnA Result Deactivating Fail : <{SETTINGS.BASE.APP_NAME}> Cannot Find knowledge_ids for Deactivating Results"))
            logger.error(response.detail)
            return response
        
        data_request = SystemQnARequest(
            data_filter=QnAFilter(
                string_filter=QnAStringFilter(
                    knowledge_id_filter=request.knowledge_ids
                ),
                numeric_filter=QnANumericFilter(
                    qna_status_min=1
                )
            )
        )
        try:
            response_qna = system_query_qna(request=data_request, api_call=self.api_call)
            qna_ids = [_qna.qna_id for _qna in response_qna.filtered_data]
        
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving QnA Results", str(e)))
            logger.error(response.detail)
            return response

        if not qna_ids:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Previous QnAs were Detected : <{SETTINGS.BASE.APP_NAME}> No Action is Taken"))
            logger.info(response.detail)
            return response
        
        # Batch Deactivate
        batch_request = QnABatchRequest(
            batch_requests=[
                QnARequest(qna_id=qna_id) 
                for qna_id in qna_ids
            ]
        )
        try:
            response = general_batch_deactivate_qna(request=batch_request, api_call=self.api_call)
            logger.info(f"Completed Deactivating QnA : <{SETTINGS.BASE.APP_NAME}> Completed Deactivating QnA")
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Result Deactivating Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Deactivating QnA Results", str(e)))
            logger.error(response.detail)
            return response

        return response

    def activate_knowledge_qna(self, request: KnowledgeQnARequest) -> Response:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Started Activating Previous QnA Results")

        if not request.knowledge_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"QnA Result Activating Fail : <{SETTINGS.BASE.APP_NAME}> Cannot Find knowledge_ids for Activating Results"))
            logger.error(response.detail)
            return response
        
        data_request = SystemQnARequest(
            data_filter=QnAFilter(
                string_filter=QnAStringFilter(
                    knowledge_id_filter=request.knowledge_ids
                ),
                numeric_filter=QnANumericFilter(
                    qna_status_max=0
                )
            )
        )
        try:
            response_qna = system_query_qna(request=data_request, api_call=self.api_call)
            qna_ids = [_qna.qna_id for _qna in response_qna.filtered_data]
        
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving QnA Results", str(e)))
            return response

        if not qna_ids:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Previous QnAs were Detected : <{SETTINGS.BASE.APP_NAME}> No Action is Taken"))
            logger.info(response.detail)
            return response
        
        # Batch Activate
        batch_request = QnABatchRequest(
            batch_requests=[
                QnARequest(qna_id=qna_id) 
                for qna_id in qna_ids
            ]
        )
        try:
            response = general_batch_activate_qna(request=batch_request, api_call=self.api_call)
            logger.info(f"Completed Activating QnA : <{SETTINGS.BASE.APP_NAME}> Completed Activating QnA")
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Result Activating Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Activating QnA Results", str(e)))
            return response

        return response    


    def drop_knowledge_qna(self, request: KnowledgeQnARequest) -> Response:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Started Dropping QnA Results")
        start_at = time.time()

        if not request.knowledge_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"QnA Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Cannot Find knowledge_ids for Dropping Results"))
            logger.error(response.detail)
            return response
        

        data_request = SystemQnARequest(
            data_filter=QnAFilter(
                string_filter=QnAStringFilter(
                    knowledge_id_filter=request.knowledge_ids
                ),
                numeric_filter=QnANumericFilter(
                    qna_status_max=0
                )
            )
        )
        try:
            response_qna = system_query_qna(request=data_request, api_call=self.api_call)
            qna_ids = [_qna.qna_id for _qna in response_qna.filtered_data]
        
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving QnA Results", str(e)))
            return response

        if not qna_ids:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Previous QnAs were Detected : <{SETTINGS.BASE.APP_NAME}> No Action is Taken"))
            logger.info(response.detail)
            return response

        # Batch Drop
        batch_request = QnABatchRequest(
            batch_requests=[
                QnARequest(qna_id=qna_id) 
                for qna_id in qna_ids
            ]
        )
        try:
            response = general_batch_drop_qna(request=batch_request, api_call=self.api_call)
            logger.info(f"Completed Dropping QnA : <{SETTINGS.BASE.APP_NAME}> Completed Dropping QnA")
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Result Dropping Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Dropping QnA Results", str(e)))
            return response

        return response    

    def truncate_content(self, content: list[str], max_token: int=SETTINGS.EVAL.TOKEN_LIMIT) -> list[list[str]]:
        windows = []
        current_window = []
        current_token = 0

        # Token Check
        encoding = tiktoken.encoding_for_model("gpt-4o")

        for text in content:
            text_token =len(encoding.encode(text))

            if current_token + text_token > max_token:
                windows.append(current_window)
                current_window = [text]
                current_token = text_token
            else:
                current_window.append(text)
                current_token += text_token

        if current_window:
            windows.append(current_window)

        return windows

    # def generate_knowledge_qna(self, request: QnAGenerationRequest) -> tuple[QnAGenerationResponse, Response]:
    #     logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Initated Knowledge QnA Generation Process")
    #     start_at = time.time()
    #     response_data = QnAGenerationResponse(**request.__dict__)
    #     total_input_tokens  = 0
    #     total_output_tokens = 0
    #     total_tool_tokens   = 0

    #     # Input Validation
    #     if not request.data_input:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Generation Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Seed QnA for Generation"))
    #         return response_data, response

    #     if not request.knowledge_id:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Generation Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Knowledge ID for Generation"))
    #         return response_data, response

    #     # Knowledge Vector Retrieval
    #     logger.info("Processing : Retrieving Knowledge Vectors for QnA Generation")
    #     vector_request = KnowledgeVectorRequest(knowledge_id=request.knowledge_id)
    #     try:
    #         response_vector = general_read_knowledge_vector(request=vector_request, api_call=self.api_call)
    #         knowledge_vectors = response_vector.filtered_vectors
    #         logger.info(f"Processing : Retrieved <{response_vector.vector_no}> for QnA Generation")
    #     except Exception as e:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Vector Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving Knowledge Vector", str(e)))
    #         logger.error(response.detail)
    #         return response_data, response
    #     except:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Vector Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unknown Error when Retrieving Knowledge Vector"))
    #         logger.error(response.detail)
    #         return response_data, response

    #     if not knowledge_vectors:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Vector Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Knowledge Vector for Generation"))
    #         logger.error(response.detail)
    #         return response_data, response

    #     # Language Convert
    #     converter = OpenCC('s2hk')

    #     # Prepare document chunks and ID mapping
    #     raw_texts = [vec.raw_data.strip() for vec in knowledge_vectors if vec.raw_data]
    #     citation_prompt, _ = self.raw_prompt_formation(raw_texts)
    #     # Create mapping from "D-{i}" to data_id
    #     id_mapping = {f"D-{i}": vec.data_id for i, vec in enumerate(knowledge_vectors, start=1)}   
    #     seed_qa = "\n\n".join(
    #         f"seed_query: {qna.qna_query}\nseed_response: {qna.qna_response}"
    #         for qna in request.data_input
    #     )

    #     _success_objects = []
    #     _failed_objects  = []
    #     logger.info("Processing : Generating QnA in one pass for all seed QnA.")
    #     system_prompt = self.default_system_prompt.format(
    #         unit_generation_num=request.unit_generation_num,
    #         document_chunks=citation_prompt,
    #         seed_qa=seed_qa
    #     )

    #     # 2) GenAI Inference (Single Attempt or Retry Mechanism)
    #     retry_max_no = SETTINGS.INFR.RETRY_LIMIT
    #     retry_count  = 1
    #     generated_queries    = []
    #     generated_responses  = []
    #     generated_citations  = []
    #     generated_qlanguages = []
    #     generated_rlanguages = []

    #     while retry_count <= retry_max_no:
    #         logger.info(f"Attempting Inference <{retry_count} / {retry_max_no}>")
    #         request_inference = InferenceRequest(input=InferenceInput(text=system_prompt))
    #         response_inference, response = InferenceServiceManager(api_call=self.api_call).inference_engine(
    #             request=request_inference
    #         )
    #         if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
    #             retry_count += 1
    #             continue

    #         # Update Metrics
    #         total_input_tokens  += response_inference.inference_metrics.input_tokens
    #         total_output_tokens += response_inference.inference_metrics.output_tokens

    #         # Attempt to parse the inference output
    #         try:
    #             response_inference_json = self.response_jsonlize(response_inference.inference_output.text)
    #             generated_queries    = response_inference_json["queries"]
    #             generated_qlanguages = response_inference_json["query_languages"]

    #             break
    #         except:
    #             if retry_count >= retry_max_no:
    #                 break
    #             logger.error(f"LLM Formatting Issue. Retry <{retry_count}/{retry_max_no}>")
    #             retry_count += 1


    #     processed_pairs = []
    #     failed_pairs =[]
    #     for i, (query, qlang) in enumerate(zip(generated_queries, generated_qlanguages)):
    #         a = CustomField(
    #             agent_id='',
    #             pru_force_lang=qlang  # Use the corresponding query language
    #         )
    #         eval_request = EvaluationQuery(
    #             query=query,
    #             rationale='',
    #             knowledge_ids=[request.knowledge_id],
    #             chat_history=None,
    #             custom_field=a
    #         )

    #         try:
    #             # Evaluate the query
    #             eval_response = evaluate_knowledge_query(request=eval_request, api_call=self.api_call)
    #             # Create a successful QnA pair using the evaluated response
    #             pair = QnAPair(
    #                 knowledge_id=request.knowledge_id,
    #                 qna_id=f"{request.knowledge_id}_{i}_{request.batch_order}",
    #                 qna_query=converter.convert(query),
    #                 qna_response=converter.convert(eval_response.response),
    #                 qna_citations=eval_response.citations,
    #                 qna_query_language=qlang,
    #                 qna_response_language=qlang  ,
    #             )
    #             processed_pairs.append(pair)
    #         except Exception as e:
    #             logger.error(f"Evaluation of query failed for query: {query}. Error: {str(e)}")
    #             # If evaluation fails, create a QnA pair with an error notice or fallback value,
    #             # and add it to the failed objects
    #             pair = QnAPair(
    #                 knowledge_id=request.knowledge_id,
    #                 qna_id=f"{request.knowledge_id}_{i}_{request.batch_order}",
    #                 qna_query=converter.convert(query),
    #                 qna_response="Evaluation Failed",  # or an empty string or some error detail
    #                 qna_citations=[],  # empty list as no citations available
    #                 qna_query_language=qlang,
    #                 qna_response_language=qlang ,
    #             )
    #             failed_pairs.append(pair)


    #         _success_objects = [ProcessedQnAPair(seed_qna=None, generated_qna=[pair]) for pair in processed_pairs]
    #         _failed_objects = [ProcessedQnAPair(seed_qna=None, generated_qna=[failed_pair]) for failed_pair in failed_pairs]

        
    #     if request.save_to_db:
    #         logger.info("Processing : Storing Successful QnA Pairs into DB")
    #         data_requests = []
    #         data_to_db = [_data for _obj in _success_objects for _data in _obj.generated_qna]
    #         for qna_pair in data_to_db:
    #             # Get QnAPair fields as a dictionary, excluding qna_citations
    #             qna_pair_dict = qna_pair.dict(exclude={'qna_citations'})
                
    #             # Extract all data_ids from qna_citations
    #             qna_citations_list = [
    #                 source.data_id 
    #                 for citation in qna_pair.qna_citations 
    #                 for source in citation.sources
    #             ]
                
    #             # Handle qna_document_name with empty citation check
    #             if qna_pair.qna_citations:
    #                 document_name = qna_pair.qna_citations[0].document_name
    #                 page_list = [citation.page_number for citation in qna_pair.qna_citations]
    #                 page_str = ','.join(page_list)
    #                 qna_document_name = f"{document_name}({page_str})"
    #             else:
    #                 qna_document_name = "No citations"
                
    #             # Prepare data for QnACreate
    #             qna_create_data = {
    #                 **qna_pair_dict,
    #                 'batch_order': request.batch_order,
    #                 'qna_citations': qna_citations_list,
    #                 'qna_document_name': qna_document_name,
    #             }
                
    #             # Create QnACreateRequest
    #             data_request = QnACreateRequest(
    #                 data=QnACreate(**qna_create_data)
    #             )
    #             data_requests.append(data_request)

    #         batch_data_request = QnABatchCreateRequest(create_requests=data_requests)
    #         # Initialize response with a default error state
    #         response = Response(status_code=500, detail="Database storage not attempted")
    #         try:
    #             response = general_batch_create_qna(
    #                 request=batch_data_request, api_call=self.api_call
    #             )
    #             if response.status_code >= 400:  # Assuming 400+ indicates failure
    #                 logger.error(f"Failed to store QnA pairs: {response.detail}")
    #                 # Optionally update response_data to reflect failure
    #         except Exception as e:
    #             logger.error(
    #                 f"Storing QnA Error : <{SETTINGS.BASE.APP_NAME}> "
    #                 f"Encountered Error when Storing Generated QnA Pairs into DB: {str(e)}"
    #             )
    #             response = Response(status_code=500, detail=f"Failed to store QnA pairs: {str(e)}")
    #     else:
    #         logger.info("Save DB is Disabled. Skipped QnA Storage")

    #     # 5) Finalize the request response
    #     response_data.__dict__.update(
    #         success_objects     = _success_objects,
    #         failed_objects      = _failed_objects,
    #         total_seed_count    = len(request.data_input), 
    #         success_seed_count  = len(_success_objects),    
    #         fail_seed_count     = len(_failed_objects),    
    #         generation_time     = time.time() - start_at,
    #         total_input_tokens  = total_input_tokens,
    #         total_output_tokens = total_output_tokens,
    #         total_tool_tokens   = total_tool_tokens,
    #         response_at         = datetime.now()
    #     )

    #     return response_data, response


    # def generate_knowledge_qna_by_seed(self, request: QnAGenerationRequest) -> tuple[QnAGenerationResponse, Response]:
    #     logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Initated Knowledge QnA Generation Process")
    #     start_at = time.time()
    #     response_data = QnAGenerationResponse(**request.__dict__)
    #     total_input_tokens  = 0
    #     total_output_tokens = 0
    #     total_tool_tokens   = 0

    #     # Input Validation
    #     if not request.data_input:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Generation Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Seed QnA for Generation"))
    #         return response_data, response

    #     if not request.knowledge_id:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Generation Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Knowledge ID for Generation"))
    #         return response_data, response

    #     # Knowledge Vector Retrieval
    #     logger.info("Processing : Retrieving Knowledge Vectors for QnA Generation")
    #     vector_request = KnowledgeVectorRequest(knowledge_id=request.knowledge_id)
    #     try:
    #         response_vector = general_read_knowledge_vector(request=vector_request, api_call=self.api_call)
    #         knowledge_vectors = response_vector.filtered_vectors
    #         logger.info(f"Processing : Retrieved <{response_vector.vector_no}> for QnA Generation")
    #     except Exception as e:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Vector Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Retrieving Knowledge Vector", str(e)))
    #         logger.error(response.detail)
    #         return response_data, response
    #     except:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Vector Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unknown Error when Retrieving Knowledge Vector"))
    #         logger.error(response.detail)
    #         return response_data, response

    #     if not knowledge_vectors:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Vector Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Knowledge Vector for Generation"))
    #         logger.error(response.detail)
    #         return response_data, response

    #     # Language Convert
    #     converter = OpenCC('s2hk')

    #     # Prepare document chunks and ID mapping
    #     raw_texts = [vec.raw_data.strip() for vec in knowledge_vectors if vec.raw_data]
    #     citation_prompt, _ = self.raw_prompt_formation(raw_texts)
    #     # Create mapping from "D-{i}" to data_id
    #     id_mapping = {f"D-{i}": vec.data_id for i, vec in enumerate(knowledge_vectors, start=1)}   
    #     # seed_qa = "\n\n".join(
    #     #     f"seed_query: {qna.qna_query}\nseed_response: {qna.qna_response}"
    #     #     for qna in request.data_input
    #     # )
    #     # print(seed_qa)

    #     _success_objects = []
    #     _failed_objects  = []
    #     for i, _data in enumerate(request.data_input, start=1):
    #         logger.info(f"Processing : Generating QnA Pairs for <{i} / {len(request.data_input)}> Seed QnA Pair")

    #         """ 1. Prompt Formation """
    #         system_prompt = self.default_system_prompt.format(
    #             unit_generation_num=request.unit_generation_num, 
    #             document_chunks=citation_prompt,
    #             seed_query=_data.qna_query, 
    #             seed_response=_data.qna_response
    #             #seed_qa
    #         )

    #         """ 2. GenAI Inference """
    #         retry_max_no = SETTINGS.INFR.RETRY_LIMIT
    #         retry_count  = 1
    #         generated_queries    = []
    #         generated_responses  = []
    #         generated_citations  = []
    #         generated_qlanguages = []
    #         generated_rlanguages = []

    #         while retry_count <= retry_max_no:
    #             logger.info(f"Attempting for Inference <{retry_count} / {retry_max_no}>")
    #             request_inference = InferenceRequest(input=InferenceInput(text=system_prompt))
    #             response_inference, response = InferenceServiceManager(api_call=self.api_call).inference_engine(request=request_inference)
    #             if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
    #                 retry_count += 1
    #                 continue

    #             # Update Metrics
    #             total_input_tokens  += response_inference.inference_metrics.input_tokens
    #             total_output_tokens += response_inference.inference_metrics.output_tokens

    #             """ 3. Translate to Traditional Chinese if Chinese is Involved """
    #             try:
    #                 response_inference_json = self.response_jsonlize(response_inference.inference_output.text)
    #                 generated_queries    = response_inference_json["queries"]
    #                 generated_responses  = response_inference_json["responses"]
    #                 generated_citations  = response_inference_json["document_ids"]
    #                 generated_qlanguages = response_inference_json["query_languages"]
    #                 generated_rlanguages = response_inference_json["response_languages"]
    #                 break

    #             except:
    #                 if retry_count > retry_max_no: 
    #                     break
    #                 logger.error(f"LLM Formatting Issue. Retry <{retry_count}/{retry_max_no}>")
    #                 retry_count += 1

    #         """ 4. Parsing the Inference Response """
    #         if generated_queries and generated_responses and generated_qlanguages and generated_rlanguages:
    #             generated_qna_pair = ProcessedQnAPair(
    #                 seed_qna      = _data,
    #                 generated_qna = [
    #                         QnAPair(
    #                         seed_qna_id           = _data.seed_qna_id,
    #                         knowledge_id          = request.knowledge_id,
    #                         qna_id                = f"{request.knowledge_id}_{_data.seed_qna_id}_{_i}_{request.batch_order}",
    #                         qna_query             = converter.convert(_query),
    #                         qna_response          = converter.convert(_response),
    #                         qna_citations         = [id_mapping.get(_citation_id, _citation_id) for _citation_id in _citations],
    #                         qna_query_language    = _qlanguage,
    #                         qna_response_language = _rlanguage
    #                     ) for _i, (_query, _response, _citations, _qlanguage, _rlanguage) in enumerate(zip(generated_queries, generated_responses, generated_citations, generated_qlanguages, generated_rlanguages), start=1)
    #                     if _response.upper() != "NONE"
    #                 ]
    #             )
    #             _success_objects.append(generated_qna_pair)
    #         else:
    #             generated_qna_pair = ProcessedQnAPair(
    #                 seed_qna = _data
    #             )
    #             _failed_objects.append(generated_qna_pair)

    #     """ 5. Store into QnA DB """
    #     if request.save_to_db:
    #         logger.info("Processing : Storing Successful QnA Pairs into DB")
    #         data_requests = []
    #         data_to_db    = [_data for _object in _success_objects for _data in _object.generated_qna]
    #         for qna_pair in data_to_db:
    #             data_request = QnACreateRequest(
    #                 data = QnACreate(
    #                     batch_order=request.batch_order,
    #                     **qna_pair.__dict__
    #                 )
    #             )
    #             data_requests.append(data_request)
            
    #         batch_data_request = QnABatchCreateRequest(create_requests=data_requests)
    #         try:
    #             response = general_batch_create_qna(request=batch_data_request, api_call=self.api_call)
    #         except Exception as e:
    #             logger.error(f"Storing QnA Error : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Storing Generated QnA Pairs into DB", str(e))
    #         except:
    #             logger.error(f"Unknown Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unknown Error when Storing Generated QnA Pairs into DB")

    #     else:
    #         logger.info("Save DB is Disabled. Skipped QnA Storage")

    #     """ 6. Finalizing the Request Response """
    #     response_data.__dict__.update(
    #         success_objects     = _success_objects,
    #         failed_objects      = _failed_objects,
    #         total_seed_count    = len(request.data_input),
    #         success_seed_count  = len(_success_objects),
    #         fail_seed_count     = len(_failed_objects),
    #         generation_time     = time.time() - start_at,
    #         total_input_tokens  = total_input_tokens,
    #         total_output_tokens = total_output_tokens,
    #         total_tool_tokens   = total_tool_tokens,
    #         response_at         = datetime.now()
    #     )

    #     return response_data, response
    
    # def generate_qna(self, request: QnAGenerationRequest) -> tuple[QnAGenerationResponse, Response]:
    #     logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Initated QnA Generation Process")
    #     start_at = time.time()
    #     response_data = QnAGenerationResponse(**request.__dict__)

    #     if not request.data_input:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Generation Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Seed QnA for Generation"))
    #         return response_data, response
        
    #     # Language Convert
    #     converter = OpenCC('s2hk')

    #     _success_objects = []
    #     _failed_objects  = []
    #     for i, _data in enumerate(request.data_input, start=1):
    #         logger.info(f"Processing : Generating QnA Pairs for <{i} / {len(request.data_input)}> Seed QnA Pair")

    #         """ 1. Prompt Formation """
    #         system_prompt = self.default_system_prompt.format(
    #             unit_generation_num=request.unit_generation_num, 
    #             seed_query=_data.qna_query, 
    #             seed_response=_data.qna_response
    #         )

    #         """ 2. GenAI Inference """
    #         retry_max_no = SETTINGS.INFR.RETRY_LIMIT
    #         retry_count  = 1
    #         while retry_count <= retry_max_no:
    #             request_inference = InferenceRequest(input=InferenceInput(text=system_prompt))
    #             response_inference, response = InferenceServiceManager(api_call=self.api_call).inference_engine(request=request_inference)
    #             if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
    #                 break

    #             """ 3. Translate to Traditional Chinese if Chinese is Involved """
    #             try:
    #                 response_inference_json = self.response_jsonlize(response_inference.inference_output.text)
    #                 generated_queries    = response_inference_json["queries"]
    #                 generated_responses  = response_inference_json["responses"]
    #                 generated_qlanguages = response_inference_json["query_languages"]
    #                 generated_rlanguages = response_inference_json["response_languages"]
    #                 break

    #             except:
    #                 if retry_count > retry_max_no:
    #                     generated_queries    = []
    #                     generated_responses  = []
    #                     generated_qlanguages = []
    #                     generated_rlanguages = []
    #                     break
    #                 logger.error(f"LLM Formatting Issue. Retry <{retry_count}/{retry_max_no}>")
    #                 retry_count += 1

    #         """ 4. Parsing the Inference Response """
    #         if generated_queries and generated_responses and generated_qlanguages and generated_rlanguages:
    #             generated_qna_pair = ProcessedQnAPair(
    #                 seed_qna      = _data,
    #                 generated_qna = [QnAPair(
    #                     seed_qna_id           = _data.seed_qna_id,
    #                     knowledge_id          = request.knowledge_id,
    #                     qna_id                = f"{request.knowledge_id}_{_data.seed_qna_id}_{_i}_{str(int(time.time()))}",
    #                     qna_query             = converter.convert(_query),
    #                     qna_response          = converter.convert(_response),
    #                     qna_query_language    = _qlanguage,
    #                     qna_response_language = _rlanguage
    #                 ) for _i, (_query, _response, _qlanguage, _rlanguage) in enumerate(zip(generated_queries, generated_responses, generated_qlanguages, generated_rlanguages), start=1)]
    #             )
    #             _success_objects.append(generated_qna_pair)
    #         else:
    #             generated_qna_pair = ProcessedQnAPair(
    #                 seed_qna = _data
    #             )
    #             _failed_objects.append(generated_qna_pair)


    #     """ 5. Finalizing the Request Response """
    #     response_data.__dict__.update(
    #         success_objects    = _success_objects,
    #         failed_objects     = _failed_objects,
    #         total_seed_count   = len(request.data_input),
    #         success_seed_count = len(_success_objects),
    #         fail_seed_no       = len(_failed_objects),
    #         generation_time    = time.time() - start_at,
    #         response_at        = datetime.now()
    #     )

    #     return response_data, response

    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

                resp.raise_for_status()
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                logger.info(response.detail)
                response_data = resp.json()

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)
        
        return response_data, response

