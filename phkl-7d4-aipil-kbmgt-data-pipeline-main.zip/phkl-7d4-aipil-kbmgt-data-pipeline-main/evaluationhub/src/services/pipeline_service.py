"""
    Custom Config
"""
from ..schemas.job import (
    PipelineStatus,
    PipelineResponse
)

JOB_PENDING    = "PENDING"
JOB_PROCESSING = "PROCESSING"
JOB_COMPLETE   = "COMPLETED"
JOB_SUCCESS    = "SUCCESS"
JOB_FAIL       = "FAIL"
JOB_PIPELINE   = 'EVALUATION'

from ..routers.request_onboarding import (
    request_knowledge_onboarding,
    OnboardingPipelineRequest
)

pipeline_mapper = {
    "request_knowledge_onboarding": {
        "pipeline": request_knowledge_onboarding,
        "class":    OnboardingPipelineRequest
    }
}

"""
    End of Custom Config
"""

import inspect
import asyncio
from datetime import datetime, timezone
from typing import Any
import math

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
)

from ..services import system_query_knowledge

from ..schemas.utils import (
    KnowledgeFilter,
    KnowledgeStringFilter,
    KnowledgeNumericFilter,
    SystemKnowledgeRequest
)

from ..job.schemas.job import (
    JobCreate,
    JobCreateRequest,
    JobBatchCreateRequest,
    JobUpdate,
    JobUpdateRequest,
    JobFilter,
    JobStringFilter,
    JobNumericFilter,
    JobBooleanFilter,
    SystemJobRequest,
    SystemJobResponse,
    JobRequest,
    JobBatchRequest
)

from ..routers.job import general_batch_create_job, general_update_job, system_query_job, system_drop_condition_job

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class JobManager:

    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool):
        self.api_call = api_call

    @staticmethod
    def clear_job(job_type: str='ALL', job_stage: str=JOB_SUCCESS):

        logger.info(f"Job Cleansing : <job_type : {job_type}> <job_stage : {job_stage}> Pipeline")
        condition = JobUpdate(job_status = 1)

        if job_type != 'ALL':
            condition.job_type = job_type

        if job_stage != "ALL":
            condition.job_stage = job_stage

        try:
            response = system_drop_condition_job(
                request = condition
            )

            logger.info(f"Drop <job_type : {job_type}> <job_stage : {job_stage}> Jobs")
        
        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Failed to Drop <job_type : {job_type}> <job_stage : {job_stage}> Jobs"))
            raise Exception(response.detail)

    @staticmethod
    async def reset_job(job_type: str='ALL', job_stage: str=JOB_PROCESSING):
        if job_type.upper() in ['A', 'ALL']:
            job_type = 'ALL'
        
        logger.info(f"Evaluation Job Reset : {job_type} Pipeline")
        processing_data_request = SystemJobRequest(
            data_filter = JobFilter(
                numeric_filter = JobNumericFilter(
                    job_status_min = 0
                ),
                sorting={"created_at": "desc"}
            )
        )

        if job_type != 'ALL':
            if not processing_data_request.data_filter.string_filter:
                processing_data_request.data_filter.string_filter = JobStringFilter(job_type_filter=[job_type])
            else:
                processing_data_request.data_filter.string_filter.job_type_filter = [job_type]

        if job_stage != "ALL":
            if not processing_data_request.data_filter.string_filter:
                processing_data_request.data_filter.string_filter = JobStringFilter(job_stage_filter=[job_stage])
            else:
                processing_data_request.data_filter.string_filter.job_stage_filter = [job_stage]

        response_processing_data = system_query_job(request=processing_data_request)
        logger.info(f"Found <{len(response_processing_data.filtered_data)}> <job_type : {job_type}> <job_stage : {job_stage}> Jobs")

        try:
            for data in response_processing_data.filtered_data:
                await JobManager._update_job_status(
                    data.job_id, 
                    PipelineStatus(
                        job_stage = JOB_PENDING,
                        processed_at = None
                    )
                )
            logger.info(f"Reset <{len(response_processing_data.filtered_data)}> <job_type : {job_type}> <job_stage : {job_stage}> Evaluation Jobs")
        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Failed to Reset {job_type} Evaluation Jobs"))
            raise Exception(response.detail)

    @staticmethod
    def create_pipeline_job(request: OnboardingPipelineRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_PIPELINE} Pipeline Request")

        response_data = PipelineResponse()

        if request.process.upper() in ["AUTO", "FULL"]:
            if request.knowledge_ids:
                knowledge_request = SystemKnowledgeRequest(
                    data_filter=KnowledgeFilter(
                        string_filter=KnowledgeStringFilter(
                            knowledge_id_filter=request.knowledge_ids
                        ),
                        numeric_filter=KnowledgeNumericFilter(
                            knowledge_status_min=1
                        )
                    )
                )
            else:
                knowledge_request = SystemKnowledgeRequest(
                    data_filter=KnowledgeFilter(
                        numeric_filter=KnowledgeNumericFilter(
                            knowledge_ingestion_stage_filter=["Ingested for Review"],
                            knowledge_status_min=1
                        ),
                        sorting={"updated_at": "asc"},
                        filter_no=2000
                    )
                )

            try:
                response_knowledge = system_query_knowledge(request=knowledge_request)
                knowledges = response_knowledge.filtered_data
            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Auto Evaluation Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge for Auto Evaluation Pipeline"))
                logger.error(response.detail)
                return response_data, response
            
            if not knowledges:
                response = Response(status_code=200, detail=JobManager.response_format.ok(f"Auto Evaluation Pipeline Completed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Knowledge for Auto Evaluation Pipeline"))
                logger.error(response.detail)
                return response_data, response
            
            if request.process.upper() == "AUTO":
                create_requests = []
                for knowledge in knowledges:
                    if knowledge.knowledge_ingestion_stage not in ["Evaluated for Review", "Onboard"]:
                        create_request = JobCreateRequest(
                            data = JobCreate(
                                knowledge_id = knowledge.knowledge_id,
                                job_type     = "QNA_GENERATION",
                                job_stage    = JOB_PENDING,
                                job_pipeline = "request_knowledge_onboarding",
                                job_config = {
                                    "knowledge_ids": [knowledge.knowledge_id], 
                                    "process": "QNA_GENERATION",
                                    "batch_order": request.batch_order
                                }
                            )
                        )
                        create_requests.append(create_request)
                    
                    elif knowledge.knowledge_ingestion_stage == "Reviewing Q&A Dataset":
                        create_request = JobCreateRequest(
                            data = JobCreate(
                                knowledge_id = knowledge.knowledge_id,
                                job_type     = "EVALUATION",
                                job_stage    = JOB_PENDING,
                                job_pipeline = "request_knowledge_onboarding",
                                job_config = {
                                    "knowledge_ids": [knowledge.knowledge_id], 
                                    "process": "EVALUATION",
                                    "batch_order": request.batch_order
                                }
                            )
                        )
                        create_requests.append(create_request)

                    elif knowledge.knowledge_ingestion_stage == "Evaluated for Review":
                        create_request = JobCreateRequest(
                            data = JobCreate(
                                knowledge_id = knowledge.knowledge_id,
                                job_type     = "ONBOARD",
                                job_stage    = JOB_PENDING,
                                job_pipeline = "request_knowledge_onboarding",
                                job_config = {
                                    "knowledge_ids": [knowledge.knowledge_id], 
                                    "process": "ONBOARD",
                                    "batch_order": request.batch_order
                                }
                            )
                        )
                        create_requests.append(create_request)

            else:
                create_requests = []
                for knowledge in knowledges:
                    create_request = JobCreateRequest(
                        data = JobCreate(
                            knowledge_id = knowledge.knowledge_id,
                            job_type     = "FULL",
                            job_stage    = JOB_PENDING,
                            job_pipeline = "request_knowledge_onboarding",
                            job_config = {
                                "knowledge_ids": [knowledge.knowledge_id], 
                                "process": "FULL",
                                "batch_order": request.batch_order
                            }
                        )
                    )
                    create_requests.append(create_request)    


            total_data_count = len(create_requests)
            batch_count = math.ceil(total_data_count / SETTINGS.EVAL.AUTO_PIPELINE_BATCH_SIZE)
            logger.info(f"Partitioning Data : Detected <{total_data_count}> Data. Divided into <{batch_count}> Batches with <{SETTINGS.EVAL.AUTO_PIPELINE_BATCH_SIZE}> Each for Processing")

            for batch_index, i in enumerate(range(0, total_data_count, SETTINGS.EVAL.AUTO_PIPELINE_BATCH_SIZE), start=1):
                logger.info(f"Submitting Job : <{batch_index} / {batch_count}> Job Batch")
                batch_request = create_requests[i : i + SETTINGS.EVAL.AUTO_PIPELINE_BATCH_SIZE]
                try:
                    response = general_batch_create_job(request = JobBatchCreateRequest(create_requests=batch_request))
                    response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_PIPELINE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(request.knowledge_ids)}> Jobs"))
                    logger.info(response.detail)

                except Exception as e:
                    response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs in <{batch_index} / {batch_count}> Job Batch", str(e)))
                    logger.error(response.detail)
                    continue

            response_data.pipeline_info = [request.data for request in create_requests[:10]]

            return response_data, response   

        else:
            knowledge_ids = request.knowledge_ids
            
            if not knowledge_ids:
                if request.process.upper() == "ONBOARD":
                    knowledge_ingestion_stage_filter = ["Evaluated for Review"]
                elif request.process.upper() == "EVALUAITON":
                    knowledge_ingestion_stage_filter = ["Reviewing Q&A Dataset", "Pending to Evaluate"]
                else:
                    knowledge_ingestion_stage_filter = None

                knowledge_request = SystemKnowledgeRequest(
                    data_filter=KnowledgeFilter(
                        string_filter=KnowledgeStringFilter(
                            knowledge_ingestion_stage_filter=knowledge_ingestion_stage_filter
                        ),
                        numeric_filter=KnowledgeNumericFilter(
                            knowledge_status_min=1
                        )
                    )
                )

                try:
                    response_knowledge = system_query_knowledge(request=knowledge_request)
                    knowledges = response_knowledge.filtered_data
                except Exception as e:
                    response = Response(status_code=500, detail=JobManager.response_format.error(f"Auto Evaluation Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge for Evaluation Pipeline"))
                    logger.error(response.detail)
                    return response_data, response
                
                if not knowledges:
                    response = Response(status_code=200, detail=JobManager.response_format.ok(f"Auto Evaluation Pipeline Completed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Knowledge for Evaluation Pipeline"))
                    logger.ok(response.detail)
                    return response_data, response
                
                else:
                    knowledge_ids = [knowledge.knowledge_id for knowledge in knowledges]
                
            create_requests = JobBatchCreateRequest(
                create_requests = [
                    JobCreateRequest(
                        data = JobCreate(
                            knowledge_id = knowledge_id,
                            job_type     = request.process,
                            job_stage    = JOB_PENDING,
                            job_pipeline = "request_knowledge_onboarding",
                            job_config = {"knowledge_ids": [knowledge_id], "batch_order": request.batch_order} | {key: value for key, value in request.__dict__.items() if key != "knowledge_ids"}
                        )
                    )
                    for knowledge_id in knowledge_ids
                ]
            )
        try:
            response = general_batch_create_job(request = create_requests)
            response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_PIPELINE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(knowledge_ids)}> Jobs"))
            response_data.pipeline_info = [request.data for request in create_requests.create_requests]
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
            logger.error(response.detail)

        return response_data, response

    
    @staticmethod
    async def time_trigger_job(
        job_type: str
    ):
        logger.info(f"Exploring Pending and Processing <{job_type}> Jobs")
        processing_data_request = SystemJobRequest(
            data_filter = JobFilter(
                string_filter = JobStringFilter(
                    job_stage_filter = [JOB_PROCESSING]
                ),
                numeric_filter = JobNumericFilter(
                    job_status_min = 1
                ),
                boolean_filter = JobBooleanFilter(
                    job_complete_filter = False
                ),
                sorting={"created_at": "desc"}
            )
        )
        
        pending_data_request = SystemJobRequest(
            data_filter = JobFilter(
                string_filter = JobStringFilter(
                    job_stage_filter = [JOB_PENDING]
                ),
                numeric_filter = JobNumericFilter(
                    job_status_min = 1
                ),
                boolean_filter = JobBooleanFilter(
                    job_complete_filter = False
                ),
                sorting={"created_at": "desc"}
            )
        )

        if not job_type.upper() == 'ALL':
            processing_data_request.data_filter.string_filter.job_type_filter = [job_type]
            pending_data_request.data_filter.string_filter.job_type_filter = [job_type]
            
        try:
            response_processing_data = system_query_job(request=processing_data_request)
            response_pending_data    = system_query_job(request=pending_data_request)
            logger.info(f"Found <{len(response_processing_data.filtered_data)}> Processing Jobs and <{len(response_pending_data.filtered_data)}> Pending Jobs")

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Query Jobs", str(e)))
            logger.error(response.detail)

        job_capacity = SETTINGS.JOB.PIPELINE_JOB_LIMIT - response_processing_data.data_count
        if response_pending_data.data_count > 0 and job_capacity <= 0:
            logger.info(f"Reached Maximum Pipeline Job Capacity : <{response_pending_data.data_count}> Pending Jobs on Hold")

        else:
            if response_pending_data.filtered_data:
                try:
                    pending_data = response_pending_data.filtered_data[:job_capacity]
                    
                    tasks = []
                    for job in pending_data:
                        await JobManager._update_job_status(
                            job.job_id, 
                            PipelineStatus(
                                job_stage = JOB_PROCESSING,
                                processed_at = datetime.now(timezone.utc)
                            )
                        )

                        pipeline_setup = pipeline_mapper.get(job.job_pipeline, None)
                        if not pipeline_setup:
                            response = Response(status_code=404, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Map Pipeline Setup"))
                            logger.error(response.detail)
                            await JobManager._update_job_status(
                                job.job_id, 
                                PipelineStatus(
                                    job_complete = True,
                                    job_success  = False,
                                    job_stage    = JOB_FAIL,
                                    job_reason   = response.detail,
                                    completed_at = datetime.now(timezone.utc)
                                )
                            )
                        
                        else:
                            task = JobManager._run_job(
                                    job.job_id, 
                                    pipeline_setup.get("pipeline"),
                                    pipeline_setup.get("class")(**job.job_config)
                                )
                        tasks.append(task)
                    
                    if tasks:
                        logger.info(f"Triggered <{len(pending_data)}> {job_type} Jobs")
                        await asyncio.gather(*tasks)
                    # await asyncio.sleep(SETTINGS.JOB.EVALUATION_SCAN_JOB_SEC)
            
                except Exception as e:
                    response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
                    logger.error(response.detail)

    @staticmethod
    async def event_trigger_job(
        job: JobCreate
    ):
        logger.info(f"Exploring Processing {job.job_type} Jobs")
        processing_data_request = SystemJobRequest(
            data_filter = JobFilter(
                string_filter = JobStringFilter(
                    job_stage_filter = [JOB_PROCESSING],
                    job_type_filter  = [job.job_type]
                ),
                numeric_filter = JobNumericFilter(
                    job_status_min = 1
                ),
                boolean_filter = JobBooleanFilter(
                    job_complete_filter = False
                ),
                sorting={"created_at": "desc"}
            )
        )

        try:
            response_processing_data = system_query_job(request=processing_data_request)
            logger.info(f"Found <{len(response_processing_data.filtered_data)}> Processing Jobs")

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Query Jobs", str(e)))
            logger.error(response.detail)
            raise Exception(response.detail)

        job_capacity = SETTINGS.JOB.PIPELINE_JOB_LIMIT - response_processing_data.data_count
        if job_capacity <= 0:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Failed to Create Job : Reached Maximum <{job.job_type}> Pipeline Job Capacity"))
            logger.error(response.detail)
            raise Exception(response.detail)

        else:
            try:
                await JobManager._update_job_status(
                    job.job_id, 
                    PipelineStatus(
                        job_stage = JOB_PROCESSING,
                        processed_at = datetime.now(timezone.utc)
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Update Job Stage", str(e)))
                logger.error(response.detail)
                raise Exception(response.detail)

            try:
                pipeline_setup = pipeline_mapper.get(job.job_pipeline, None)
                if not pipeline_setup:
                    response = Response(status_code=404, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Map Pipeline Setup"))
                    logger.error(response.detail)
                    await JobManager._update_job_status(
                        job.job_id, 
                        PipelineStatus(
                            job_complete = True,
                            job_success  = False,
                            job_stage    = JOB_FAIL,
                            job_reason   = response.detail,
                            completed_at = datetime.now(timezone.utc)
                        )
                    )

                else:
                    # start async job processing
                    asyncio.get_running_loop().create_task(
                        JobManager._run_job(
                            job.job_id, 
                            pipeline_setup.get("pipeline"),
                            pipeline_setup.get("class")(**job.job_config)
                        )
                    )                    

                    logger.info(f"Event-Triggered <{job.job_type}> Job <job_id: {job.job_id}>")

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
                logger.error(response.detail)
                raise Exception(response.detail)

    @staticmethod
    async def _run_job(
            job_id:   str, 
            pipeline: Any,
            request:  Any
        ):

        try:
            response_pipeline = await asyncio.get_running_loop().run_in_executor(
                None, pipeline, request
            )

            job_info = PipelineStatus(
                job_complete = True,
                job_success  = True,
                job_stage    = JOB_SUCCESS,
                job_reason   = f"Completed with Success",
                completed_at = datetime.now(timezone.utc)
            )

            await JobManager._update_job_status(job_id, job_info)
            logger.info(f"Completed : Job <{job_id}>")
        
        except Exception as e:
            job_info = PipelineStatus(
                job_complete = True,
                job_success  = False,
                job_stage    = JOB_FAIL,
                job_reason   = str(e),
                completed_at = datetime.now(timezone.utc)
            )
            await JobManager._update_job_status(job_id, job_info)
            logger.error(f"Failed : Job <{job_id}> - {str(e)}")
        
    @staticmethod
    async def _update_job_status(job_id: str, job_info: PipelineStatus):

        """Update job status in MongoDB"""
        try:
            response = general_update_job(
                request = JobUpdateRequest(
                    job_id = job_id,
                    update_data = JobUpdate(
                        **job_info.__dict__
                    ),
                    overwrite=True
                )
            )   
            logger.info(f"Updated Job Status <job_id: {job_id}>")
        
        except Exception as e:
            logger.error(f"Failed to Update Job Status <job_id: {job_id}> due to {str(e)}")
            raise e