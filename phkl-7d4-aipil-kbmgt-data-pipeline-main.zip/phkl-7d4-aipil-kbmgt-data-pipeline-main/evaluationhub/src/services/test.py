import sys
import os
sys.path.append(os.getcwd())
from src.schemas.evaluation import QAPair

def main():
    with open("pru_demo_evaluation.csv", "r", encoding="utf-8") as f:
        lines = f.readlines()
        cells = []
        cell = ""
        for index, line in enumerate(lines):
            line = line.strip()
            if index != 0 and "Question:" in line:
                cells.append(cell)
                cell = ""
                cell += line
            else:
                cell += line
        cells.append(cell)
        
        QA_pairs = []
        for c in cells:
            c = c.replace('\"', "")
            if "Answer:" in c:
                question = c.split("Answer: ")[0].replace("Question: ", "")
                answer = c.split("Answer: ")[1].split("參考資料:")[0]
                # reference = c.split("Answer: ")[1].split("參考資料:")[1]
                # QA_pairs.append(QAPair(question=question, answer=answer, reference=reference))
                QA_pairs.append(QAPair(question=question, answer=answer))
            else:
                question = c.split("Response: ")[0].replace("Question: ", "")
                answer = c.split("Response: ")[1].split("參考資料:")[0]
                # reference = c.split("Response: ")[1].split("參考資料:")[1]
                QA_pairs.append(QAPair(question=question, answer=answer))
                # QA_pairs.append(QAPair(question=question, answer=answer, reference=reference))

        for QA in QA_pairs:
            print(QA)

if __name__ == "__main__":
    main()

        