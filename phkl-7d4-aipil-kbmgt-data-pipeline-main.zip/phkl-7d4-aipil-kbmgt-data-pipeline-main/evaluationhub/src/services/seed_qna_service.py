import inspect
import time
import json
import re
import httpx
import os
import requests
import pandas as pd

from datetime import datetime, timezone

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
)

from ..schemas.seed_qna import (
    SeedQnASyncRequest,
    SeedQnASyncResponse,
)

from ..schemas.seed_qna import (
    SeedQnACreate,
    SeedQnACreateRequest,
    SeedQnABatchCreateRequest,
    SeedQnABatchRequest,
    SeedQnANumericFilter,
    SeedQnAFilter,
    SeedQnARequest,
    SystemSeedQnARequest
)

from ..routers.registry.db import db_table_rename, db_table_drop, DBTableRenameRequest

from ..routers.registry.general import (
    general_batch_create_seedqna, 
    general_batch_drop_seedqna,
    general_batch_deactivate_seedqna,
    general_batch_activate_seedqna
)

from ..routers.registry.system import (
    system_query_seedqna
)

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class SeedQnAServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    
    def __init__(self, api_call: bool):
        self.api_call = api_call

    def sync_qna_from_file(self, request: SeedQnASyncRequest) -> tuple[SeedQnASyncResponse, Response]:
        logger.info(f"Processing : Start Sync QnA From File")
        response_data = SeedQnASyncResponse(**request.__dict__)
        batch_order   = request.batch_order

        """ 1. Download Sync File From Path """
        logger.info(f"Processing : Reading Seed QnA File")
        if request.qna_sync_origin.upper() == "LOCAL":
            temp_file_path = request.qna_sync_path

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid Sync File Origin"))
            logger.error(response.detail)
            response_data.reason = response.detail
            return response_data, response

        """ 2. Read the Content """
        logger.info(f"Processing : Parsing Seed QnA File Content")
        create_requests = []
        file_name, file_extension = os.path.splitext(os.path.basename(temp_file_path))  

        if file_extension.lower() == '.xlsx':
            for bu_name in SETTINGS.EVAL.SEED_QNA_BU_LIST:
                sheet_name = f"{SETTINGS.EVAL.SEED_QNA_TABLE_PREFIX}{bu_name}"
                try:
                    df = pd.read_excel(temp_file_path, sheet_name=sheet_name)
                    df = df[['Library', 'Question(s)', 'Answer(s)']]
                    df = df.dropna(subset=['Question(s)', 'Answer(s)'])
                    if not df.empty:
                        logger.info(f"Processing : Found Table <{sheet_name}>")
                        for index, row in df.iterrows():
                            create_requests.append(
                                SeedQnACreateRequest(
                                    data = SeedQnACreate(
                                        batch_order     = batch_order,
                                        qna_query       = row["Question(s)"].strip(),
                                        qna_response    = row["Answer(s)"].strip(),
                                        library_name_en = row["Library"].strip()
                                    )
                                )
                            )
                    
                except ValueError as e:
                    logger.info(f"Skipped : Sheet <{sheet_name}> Not Found")

            if not create_requests:
                response = Response(status_code=200, detail=self.response_format.ok(f"No Data to be Updated : <{SETTINGS.BASE.APP_NAME}> Skipped Sync Seed QnA"))
                logger.info(response.detail)
                response_data.succeess_flag = True
                response_data.reason = response.detail
                return response_data, response

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid Sync File Type"))
            logger.error(response.detail)
            response_data.reason = response.detail
            return response_data, response

        """ 3. Deactivating Previous Records """
        try:
            response_prev_data = system_query_seedqna(
                request=SystemSeedQnARequest(
                    data_filter=SeedQnAFilter(
                        numeric_filter=SeedQnANumericFilter(
                            seed_qna_status_min=1
                        )
                    )
                ),
                api_call=self.api_call
            )
            previous_data_ids = [_data.seed_qna_id for _data in response_prev_data.filtered_data]

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Seed QnA Deactivation Error : <{SETTINGS.BASE.APP_NAME}> Cannot Deactivate Previous Record"))
            logger.error(response.detail)
            response_data.reason = response.detail
            return response_data, response
        
        """ 4. Create New Seed QnA Table """
        logger.info("Processing : Creating New Seed QnA Table")
        create_request = SeedQnABatchCreateRequest(create_requests = create_requests)
        try:
            response = general_batch_create_seedqna(request=create_request, api_call=self.api_call)
            logger.info("Sync Processing : Registered New Records for SeedQnA")

            if previous_data_ids:
                response = general_batch_deactivate_seedqna(
                    request = SeedQnABatchRequest(
                        batch_requests = [
                            SeedQnARequest(seed_qna_id=data_id)
                            for data_id in previous_data_ids
                        ]
                    ),
                    api_call=self.api_call
                )

                response = general_batch_drop_seedqna(
                    request = SeedQnABatchRequest(
                        batch_requests = [
                            SeedQnARequest(seed_qna_id=seed_qna_id)
                            for seed_qna_id in previous_data_ids
                        ]
                    ),
                    api_call=self.api_call
                )
                logger.info("Dropped Previous Records")

        except:
            logger.error("Processing : Failed to Create New Seed QnA Records. Revert Original Seed QnAs")
            
            if previous_data_ids:
                response = general_batch_activate_seedqna(
                    request = SeedQnABatchRequest(
                        batch_requests = [
                            SeedQnARequest(seed_qna_id=data_id)
                            for data_id in previous_data_ids
                        ]
                    ),
                    api_call=self.api_call
                )
                
            response = Response(status_code=500, detail=self.response_format.error(f"Seed QnA Creation Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Creating New Table"))
            logger.error(response.detail)
            response_data.reason = response.detail
            return response_data, response
        
        """ 6. Return Response """
        response_data.succeess_flag = True
        response_data.reason = 'SUCCESS'
        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Syncing Seed QnA"))
        logger.info(response.detail)

        return response_data, response