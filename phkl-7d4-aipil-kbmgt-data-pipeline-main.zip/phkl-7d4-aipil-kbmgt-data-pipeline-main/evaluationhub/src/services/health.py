from sqlalchemy.orm import Session
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime
import inspect

from ..schemas.format import Health, ResponseFormatter, Response

from ..settings import SETTINGS

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class HealthService:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool):
        self.api_call = api_call

    def health_check(self) -> Health:
   
        response_health = Health(app_name=SETTINGS.BASE.APP_NAME)
        if SETTINGS.BASE.APP_API == False:
            response_health.api_call = 'INACTIVE'
        if SETTINGS.BASE.APP_FUNC == False:
            response_health.function_call = 'INACTIVE'

        return response_health