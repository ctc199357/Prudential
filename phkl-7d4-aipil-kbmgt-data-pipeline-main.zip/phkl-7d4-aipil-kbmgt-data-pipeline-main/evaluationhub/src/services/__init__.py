import os
import shutil

from ..settings import SETTINGS

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

if SETTINGS.BASE.APP_FUNC == False and SETTINGS.BASE.APP_API == False:
    err_msg = f"Failed to Inititate <{SETTINGS.BASE.APP_NAME}> : APP_FUNC and APP_API cannot be ALL False"
    logger.error(err_msg)
    raise Exception(err_msg)


# Import Functions if APP_FUNC == True
if SETTINGS.BASE.APP_FUNC == True:
    # Import KnowledgeHub Function
    try:
        know_module = __import__(SETTINGS.KNOW.REQUEST_KNOW_MODULE, fromlist=[SETTINGS.KNOW.REQUEST_KNOW_FUNC])
        system_query_knowledge = getattr(know_module, SETTINGS.KNOW.REQUEST_KNOW_FUNC)

        know_update_module = __import__(SETTINGS.KNOW.REQUEST_KNOW_UPDATE_MODULE, fromlist=[SETTINGS.KNOW.REQUEST_KNOW_UPDATE_FUNC])
        general_update_knowledge = getattr(know_update_module, SETTINGS.KNOW.REQUEST_KNOW_UPDATE_FUNC)

        data_module = __import__(SETTINGS.KNOW.REQUEST_DATA_MODULE, fromlist=[SETTINGS.KNOW.REQUEST_DATA_FUNC])
        general_read_knowledge_vector = getattr(data_module, SETTINGS.KNOW.REQUEST_DATA_FUNC)

    except:
        err_msg = f"Import Error : <{SETTINGS.BASE.APP_NAME}> Failed to Import <KnowledgeHub> Module"
        logger.error(err_msg)
        raise Exception(err_msg)