import inspect
import time
import httpx
import re
import json
import requests

from datetime import datetime, timezone

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
)

from ..schemas.onboarding import (
    OnboardingPipelineRequest,
    PipelineResult,
    OnboardingPipelineResponse
)

from ..routers.request_qna import (
    request_qna_knowledge_generation,
    QnAGenerationRequest,
    request_deactivate_knowledge_qna,
    request_drop_knowledge_qna,
    KnowledgeQnARequest
)

from ..routers.request_evaluation import (
    request_knowledge_evaluation,
    request_auto_knowledge_evaluation,
    QnAEvaluationRequest,
    request_deactivate_knowledge_evaluation,
    request_drop_knowledge_evaluation,
    KnowledgeEvaluationRequest
)

from ..schemas.utils import KnowledgeUpdateRequest, KnowledgeUpdate

if SETTINGS.BASE.APP_FUNC == True:
    from ..services import general_update_knowledge
else:
    general_update_knowledge = None

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class OnboardingServiceManager:

    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
        
    def __init__(self, api_call: bool):
        self.api_call = api_call

    def execute_pipeline(self, request: OnboardingPipelineRequest) -> OnboardingPipelineResponse:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Started Executing Pipeline for <{request.process}>")
        response_data = OnboardingPipelineResponse(**request.__dict__)
        
        pipeline_results = []
        success_objects  = []
        fail_objects     = []
        if request.process.upper() in ["QNA_GENERATION", "UPDATE_QNA"]:

            if request.process.upper() == "UPDATE_QNA":
                try:
                    _response = request_deactivate_knowledge_evaluation(
                        request=KnowledgeEvaluationRequest(
                            knowledge_ids = request.knowledge_ids
                        ), 
                        api_call = False
                    )

                    _response = request_drop_knowledge_evaluation(
                        request=KnowledgeEvaluationRequest(
                            knowledge_ids = request.knowledge_ids
                        ), 
                        api_call = False
                    )
                    logger.info("Dropped Previous Evaluation Records")
                
                except Exception as e:
                    fail_objects = [
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "FAIL",
                            pipeline_reason = str(e)
                        )
                        for knowledge_id in request.knowledge_ids
                    ]
                    response = Response(status_code=500, detail=self.response_format.error(f"Previous Evaluation Drop Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error in <{request.process}> Pipeline"))
                    logger.error(response.detail)

            for knowledge_id in request.knowledge_ids:                
                try:
                    _response_data = request_qna_knowledge_generation(
                        request = QnAGenerationRequest(
                                knowledge_id = knowledge_id,
                                batch_order  = request.batch_order,
                                save_to_db   = True
                            ),
                            api_call = False
                        )
                    success_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "SUCCESS",
                            pipeline_reason = "SUCCESS"
                        )
                    )
                    response = Response(status_code=200, detail=self.response_format.ok(f"Pipeline Success : <{SETTINGS.BASE.APP_NAME}> Completed <{request.process}> Pipeline"))
                    logger.info(response.detail)

                except Exception as e:
                    fail_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "FAIL",
                            pipeline_reason = str(e)
                        )
                    )
                    response = Response(status_code=500, detail=self.response_format.error(f"Pipeline Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error in <{request.process}> Pipeline"))
                    logger.error(response.detail)

        elif request.process.upper() == "EVALUATION":
            for knowledge_id in request.knowledge_ids:                
                try:
                    _response_data = request_knowledge_evaluation(
                        request = QnAEvaluationRequest(
                                knowledge_id = knowledge_id,
                                batch_order  = request.batch_order,
                                save_to_db   = True
                            ),
                            api_call = False
                        )
                    success_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "SUCCESS",
                            pipeline_reason = "SUCCESS"
                        )
                    )
                    response = Response(status_code=200, detail=self.response_format.ok(f"Pipeline Success : <{SETTINGS.BASE.APP_NAME}> Completed <{request.process}> Pipeline"))

                except Exception as e:
                    fail_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "FAIL",
                            pipeline_reason = str(e)
                        )
                    )
                    response = Response(status_code=500, detail=self.response_format.error(f"Pipeline Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error in <{request.process}> Pipeline"))
                    logger.error(response.detail)        

        elif request.process.upper() == "FULL":
            for knowledge_id in request.knowledge_ids:                
                try:
                    _response_data = request_auto_knowledge_evaluation(
                        request = QnAEvaluationRequest(
                                knowledge_id = knowledge_id,
                                batch_order  = request.batch_order,
                                save_to_db   = True
                            ),
                            api_call = False
                        )
                    success_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "SUCCESS",
                            pipeline_reason = "SUCCESS"
                        )
                    )
                    response = Response(status_code=200, detail=self.response_format.ok(f"Pipeline Success : <{SETTINGS.BASE.APP_NAME}> Completed <{request.process}> Pipeline"))

                except Exception as e:
                    fail_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "FAIL",
                            pipeline_reason = str(e)
                        )
                    )
                    response = Response(status_code=500, detail=self.response_format.error(f"Pipeline Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error in <{request.process}> Pipeline"))
                    logger.error(response.detail)       

        elif request.process.upper() == "ONBOARD":
            
            ### TODO: Sync to AI Search Document Type

            try:
                for knowledge_id in request.knowledge_ids:
                    _response = general_update_knowledge(
                        request=KnowledgeUpdateRequest(
                            knowledge_id=knowledge_id,
                            update_data=KnowledgeUpdate(
                                knowledge_status=1,
                                knowledge_ingestion_stage="ONBAORD",
                                knowledge_ingestion_reason="ONBOARD COMPLETED"
                            )
                        ),
                        api_call = False
                    )
                    success_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "SUCCESS",
                            pipeline_reason = "SUCCESS"
                        )
                    )
                    response = Response(status_code=200, detail=self.response_format.ok(f"Pipeline Success : <{SETTINGS.BASE.APP_NAME}> Completed <{request.process}> Pipeline"))
                    logger.info(response.detail)

            except Exception as e:
                fail_objects.append(
                    PipelineResult(
                        knowledge_id    = knowledge_id,
                        pipeline        = request.process,
                        pipeline_code   = "FAIL",
                        pipeline_reason = str(e)
                    )
                )
                response = Response(status_code=500, detail=self.response_format.error(f"Pipeline Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error in <{request.process}> Pipeline"))
                logger.error(response.detail)


        elif request.process.upper() == "UPDATE_DOCUMENT":

            try:
                _response = request_deactivate_knowledge_qna(
                    request=KnowledgeQnARequest(
                        knowledge_ids = request.knowledge_ids
                    ), 
                    api_call = False
                )
                
                _response = request_drop_knowledge_qna(
                    request=KnowledgeQnARequest(
                        knowledge_ids = request.knowledge_ids
                    ), 
                    api_call = False
                )

                _response = request_deactivate_knowledge_evaluation(
                    request=KnowledgeEvaluationRequest(
                        knowledge_ids = request.knowledge_ids
                    ), 
                    api_call = False
                )

                _response = request_drop_knowledge_evaluation(
                    request=KnowledgeEvaluationRequest(
                        knowledge_ids = request.knowledge_ids
                    ), 
                    api_call = False
                )

            except Exception as e:
                fail_objects = [
                    PipelineResult(
                        knowledge_id    = knowledge_id,
                        pipeline        = request.process,
                        pipeline_code   = "FAIL",
                        pipeline_reason = str(e)
                    )
                    for knowledge_id in request.knowledge_ids
                ]
                response = Response(status_code=500, detail=self.response_format.error(f"Previous Evaluation Drop Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error in <{request.process}> Pipeline"))
                logger.error(response.detail)

            for knowledge_id in request.knowledge_ids:                
                try:
                    _response = general_update_knowledge(
                        request=KnowledgeUpdateRequest(
                            knowledge_id=knowledge_id,
                            update_data=KnowledgeUpdate(
                                knowledge_status=1,
                                knowledge_ingestion_stage="Ingested for Review",
                                knowledge_ingestion_reason="UPDATE DOCUMENT"
                            )
                        ),
                        api_call = False
                    )
                    success_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "SUCCESS",
                            pipeline_reason = "SUCCESS"
                        )
                    )
                    response = Response(status_code=200, detail=self.response_format.ok(f"Pipeline Success : <{SETTINGS.BASE.APP_NAME}> Completed <{request.process}> Pipeline"))
                    logger.info(response.detail)

                except Exception as e:
                    fail_objects.append(
                        PipelineResult(
                            knowledge_id    = knowledge_id,
                            pipeline        = request.process,
                            pipeline_code   = "FAIL",
                            pipeline_reason = str(e)
                        )
                    )
                    response = Response(status_code=500, detail=self.response_format.error(f"Pipeline Fail : <{SETTINGS.BASE.APP_NAME}> Encountered Error in <{request.process}> Pipeline"))
                    logger.error(response.detail)

        else:
            response = Response(status_code=500, detail=self.response_format.error("Invalid Process Input"))
            logger.error(response.detail)
        
        response_data.pipeline_results = success_objects + fail_objects

        return response_data, response