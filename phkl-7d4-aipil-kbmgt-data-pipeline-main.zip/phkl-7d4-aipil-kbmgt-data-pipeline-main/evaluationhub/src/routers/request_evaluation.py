from fastapi import APIRouter, status, Header, Body, Depends, HTTPException
from typing import Annotated
from ..settings import SETTINGS
from ..utils import router_response_handler,router_response_exception_handler

from ..schemas.format import Response, ComplexEncoder

from ..schemas.exception import ExceptionFormat
from ..schemas.evaluation import (
    QnAEvaluationRequest,
    QnAEvaluationResponse,
    KnowledgeEvaluationRequest
)

from ..services.evaluation_service import EvaluationServiceManager

router = APIRouter(tags=["Request-Evaluation"])

# API Configuration
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

@router.post("/request/knowledge_evaluation", status_code=status.HTTP_200_OK, response_model=QnAEvaluationResponse, responses={422: {"model": ExceptionFormat}})
def request_knowledge_evaluation(request: QnAEvaluationRequest, api_call: bool = default_api_call) -> QnAEvaluationResponse:
    request = QnAEvaluationRequest(**request.__dict__)
    response_data, response = EvaluationServiceManager(api_call=api_call).evaluate_knowledge(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.post("/request/auto_knowledge_evaluation", status_code=status.HTTP_200_OK, response_model=QnAEvaluationResponse, responses={422: {"model": ExceptionFormat}})
def request_auto_knowledge_evaluation(request: QnAEvaluationRequest, api_call: bool = default_api_call) -> QnAEvaluationResponse:
    request = QnAEvaluationRequest(**request.__dict__)
    response_data, response = EvaluationServiceManager(api_call=api_call).auto_evaluate_knowledge(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.post("/request/deactivate_knowledge_evaluation", status_code=status.HTTP_200_OK, responses={422: {"model": ExceptionFormat}})
def request_deactivate_knowledge_evaluation(request: KnowledgeEvaluationRequest, api_call: bool = default_api_call) -> Response:
    request = KnowledgeEvaluationRequest(**request.__dict__)
    response = EvaluationServiceManager(api_call=api_call).deactivate_evaluation(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/request/drop_knowledge_evaluation", status_code=status.HTTP_200_OK, responses={422: {"model": ExceptionFormat}})
def request_drop_knowledge_evaluation(request: KnowledgeEvaluationRequest, api_call: bool = default_api_call) -> Response:
    request = KnowledgeEvaluationRequest(**request.__dict__)
    response = EvaluationServiceManager(api_call=api_call).drop_evaluation(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response