from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.seed_qna_data import (
        DataManager as SeedQnADataManager,
        CreateRequest as SeedQnACreateRequest, 
        BatchCreateRequest as SeedQnABatchCreateRequest,
        UpdateRequest as SeedQnAUpdateRequest, 
        CommonRequest as SeedQnARequest,
        BatchCommonRequest as SeedQnABatchRequest,
    )

from ...database.registry.services.qna_data import (
        DataManager as QnADataManager,
        CreateRequest as QnACreateRequest, 
        BatchCreateRequest as QnABatchCreateRequest,
        UpdateRequest as QnAUpdateRequest, 
        CommonRequest as QnARequest,
        BatchCommonRequest as QnABatchRequest,
    )

from ...database.registry.services.evaluation_data import (
        DataManager as EvaluationDataManager,
        CreateRequest as EvaluationCreateRequest, 
        BatchCreateRequest as EvaluationBatchCreateRequest,
        UpdateRequest as EvaluationUpdateRequest, 
        CommonRequest as EvaluationRequest,
        BatchCommonRequest as EvaluationBatchRequest,
    )

router = APIRouter(tags=["Registry-General"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


"""
    Seed QnA Data Management
"""
@router.post("/general/seedqna/single/create", status_code=status.HTTP_201_CREATED)
def general_create_seedqna(request: SeedQnACreateRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnACreateRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/seedqna/single/update", status_code=status.HTTP_200_OK)
def general_update_seedqna(request: SeedQnAUpdateRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnAUpdateRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/seedqna/single/delete", status_code=status.HTTP_200_OK)
# def general_delete_seedqna(request: SeedQnARequest, api_call: bool=default_api_call) -> Response:
#     request  = SeedQnARequest(**request.__dict__)
#     response = SeedQnADataManager(api_call=api_call).delete(request=request)
#     router_response_handler(response=response, api_call=api_call)
#     return response

@router.delete("/general/seedqna/single/drop", status_code=status.HTTP_200_OK)
def general_drop_seedqna(request: SeedQnARequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnARequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/seedqna/single/activate", status_code=status.HTTP_200_OK)
def general_activate_seedqna(request: SeedQnARequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnARequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/seedqna/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_seedqna(request: SeedQnARequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnARequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/seedqna/batch/create", status_code=status.HTTP_201_CREATED)
def general_batch_create_seedqna(request: SeedQnABatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnABatchCreateRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/seedqna/batch/delete", status_code=status.HTTP_200_OK)
def general_batch_delete_seedqna(request: SeedQnABatchRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnABatchRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/seedqna/batch/drop", status_code=status.HTTP_200_OK)
def general_batch_drop_seedqna(request: SeedQnABatchRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnABatchRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/seedqna/batch/activate", status_code=status.HTTP_200_OK)
def general_batch_activate_seedqna(request: SeedQnABatchRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnABatchRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/seedqna/batch/deactivate", status_code=status.HTTP_200_OK)
def general_batch_deactivate_seedqna(request: SeedQnABatchRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnABatchRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    QnA Data Management
"""
@router.post("/general/qna/single/create", status_code=status.HTTP_201_CREATED)
def general_create_qna(request: QnACreateRequest, api_call: bool=default_api_call) -> Response:
    request  = QnACreateRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/qna/single/update", status_code=status.HTTP_200_OK)
def general_update_qna(request: QnAUpdateRequest, api_call: bool=default_api_call) -> Response:
    request  = QnAUpdateRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/qna/single/delete", status_code=status.HTTP_200_OK)
# def general_delete_qna(request: QnARequest, api_call: bool=default_api_call) -> Response:
#     request  = QnARequest(**request.__dict__)
#     response = QnADataManager(api_call=api_call).delete(request=request)
#     router_response_handler(response=response, api_call=api_call)
#     return response

@router.delete("/general/qna/single/drop", status_code=status.HTTP_200_OK)
def general_drop_qna(request: QnARequest, api_call: bool=default_api_call) -> Response:
    request  = QnARequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/qna/single/activate", status_code=status.HTTP_200_OK)
def general_activate_qna(request: QnARequest, api_call: bool=default_api_call) -> Response:
    request  = QnARequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/qna/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_qna(request: QnARequest, api_call: bool=default_api_call) -> Response:
    request  = QnARequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/qna/batch/create", status_code=status.HTTP_201_CREATED)
def general_batch_create_qna(request: QnABatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = QnABatchCreateRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/qna/batch/delete", status_code=status.HTTP_200_OK)
def general_batch_delete_qna(request: QnABatchRequest, api_call: bool=default_api_call) -> Response:
    request  = QnABatchRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/qna/batch/drop", status_code=status.HTTP_200_OK)
def general_batch_drop_qna(request: QnABatchRequest, api_call: bool=default_api_call) -> Response:
    request  = QnABatchRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/qna/batch/activate", status_code=status.HTTP_200_OK)
def general_batch_activate_qna(request: QnABatchRequest, api_call: bool=default_api_call) -> Response:
    request  = QnABatchRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/qna/batch/deactivate", status_code=status.HTTP_200_OK)
def general_batch_deactivate_qna(request: QnABatchRequest, api_call: bool=default_api_call) -> Response:
    request  = QnABatchRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    Evaluation Data Management
"""
# @router.post("/general/evaluation/single/create", status_code=status.HTTP_201_CREATED)
def general_create_evaluation(request: EvaluationCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationCreateRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.patch("/general/evaluation/single/update", status_code=status.HTTP_200_OK)
def general_update_evaluation(request: EvaluationUpdateRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationUpdateRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/evaluation/single/delete", status_code=status.HTTP_200_OK)
def general_delete_evaluation(request: EvaluationRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/evaluation/single/drop", status_code=status.HTTP_200_OK)
def general_drop_evaluation(request: EvaluationRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/evaluation/single/activate", status_code=status.HTTP_200_OK)
def general_activate_evaluation(request: EvaluationRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/evaluation/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_evaluation(request: EvaluationRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/evaluation/batch/create", status_code=status.HTTP_201_CREATED)
def general_batch_create_evaluation(request: EvaluationBatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationBatchCreateRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/evaluation/batch/delete", status_code=status.HTTP_200_OK)
def general_batch_delete_evaluation(request: EvaluationBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationBatchRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.delete("/general/evaluation/batch/drop", status_code=status.HTTP_200_OK)
def general_batch_drop_evaluation(request: EvaluationBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationBatchRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/evaluation/batch/activate", status_code=status.HTTP_200_OK)
def general_batch_activate_evaluation(request: EvaluationBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationBatchRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

# @router.post("/general/evaluation/batch/deactivate", status_code=status.HTTP_200_OK)
def general_batch_deactivate_evaluation(request: EvaluationBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationBatchRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response