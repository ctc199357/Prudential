from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.seed_qna_data import (
        DataManager as SeedQnADataManager,
        DataBackupRequest as SeedQnABackupRequest, 
        DataBackupListRequest as SeedQnABackupListRequest,
        DataBackupListResponse as SeedQnABackupListResponse,
        DBRestoreRequest as SeedQnARestoreRequest,
        DataImportRequest as SeedQnAImportRequest,
        DataExportRequest as SeedQnAExportRequest,
    )

from ...database.registry.services.qna_data import (
        DataManager as QnADataManager,
        DataBackupRequest as QnABackupRequest, 
        DataBackupListRequest as QnABackupListRequest,
        DataBackupListResponse as QnABackupListResponse,
        DBRestoreRequest as QnARestoreRequest,
        DataImportRequest as QnAImportRequest,
        DataExportRequest as QnAExportRequest,
    )

from ...database.registry.services.evaluation_data import (
        DataManager as EvaluationDataManager,
        DataBackupRequest as EvaluationBackupRequest, 
        DataBackupListRequest as EvaluationBackupListRequest,
        DataBackupListResponse as EvaluationBackupListResponse,
        DBRestoreRequest as EvaluationRestoreRequest,
        DataImportRequest as EvaluationImportRequest,
        DataExportRequest as EvaluationExportRequest,
    )

router = APIRouter(tags=["Registry-IO"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


"""
    SeedQnA
"""
@router.post("/io/seedqna/export", status_code=status.HTTP_200_OK)
def system_export_seedqna(request: SeedQnAExportRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnAExportRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/seedqna/import", status_code=status.HTTP_200_OK)
def system_import_seedqna(request: SeedQnAImportRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnAImportRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/seedqna/backup", status_code=status.HTTP_200_OK)
def system_backup_seedqna(request: SeedQnABackupRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnABackupRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/seedqna/backup/list", status_code=status.HTTP_200_OK, response_model=SeedQnABackupListResponse)
def system_backup_list_seedqna(request: SeedQnABackupListRequest, api_call: bool=default_api_call) -> SeedQnABackupListResponse:
    request = SeedQnABackupListRequest(**request.__dict__)
    response_table, response = SeedQnADataManager(api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/io/seedqna/restore/backup", status_code=status.HTTP_200_OK)
def system_restore_backup_seedqna(request: SeedQnARestoreRequest, api_call: bool=default_api_call) -> Response:
    request  = SeedQnARestoreRequest(**request.__dict__)
    response = SeedQnADataManager(api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    QnA
"""
@router.post("/io/qna/export", status_code=status.HTTP_200_OK)
def system_export_qna(request: QnAExportRequest, api_call: bool=default_api_call) -> Response:
    request  = QnAExportRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/qna/import", status_code=status.HTTP_200_OK)
def system_import_qna(request: QnAImportRequest, api_call: bool=default_api_call) -> Response:
    request  = QnAImportRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/qna/backup", status_code=status.HTTP_200_OK)
def system_backup_qna(request: QnABackupRequest, api_call: bool=default_api_call) -> Response:
    request  = QnABackupRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/qna/backup/list", status_code=status.HTTP_200_OK, response_model=QnABackupListResponse)
def system_backup_list_qna(request: QnABackupListRequest, api_call: bool=default_api_call) -> QnABackupListResponse:
    request = QnABackupListRequest(**request.__dict__)
    response_table, response = QnADataManager(api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/io/qna/restore/backup", status_code=status.HTTP_200_OK)
def system_restore_backup_qna(request: QnARestoreRequest, api_call: bool=default_api_call) -> Response:
    request  = QnARestoreRequest(**request.__dict__)
    response = QnADataManager(api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    Evaluation
"""
@router.post("/io/evaluation/export", status_code=status.HTTP_200_OK)
def system_export_evaluation(request: EvaluationExportRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationExportRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/evaluation/import", status_code=status.HTTP_200_OK)
def system_import_evaluation(request: EvaluationImportRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationImportRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/evaluation/backup", status_code=status.HTTP_200_OK)
def system_backup_evaluation(request: EvaluationBackupRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationBackupRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/evaluation/backup/list", status_code=status.HTTP_200_OK, response_model=EvaluationBackupListResponse)
def system_backup_list_evaluation(request: EvaluationBackupListRequest, api_call: bool=default_api_call) -> EvaluationBackupListResponse:
    request = EvaluationBackupListRequest(**request.__dict__)
    response_table, response = EvaluationDataManager(api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/io/evaluation/restore/backup", status_code=status.HTTP_200_OK)
def system_restore_backup_evaluation(request: EvaluationRestoreRequest, api_call: bool=default_api_call) -> Response:
    request  = EvaluationRestoreRequest(**request.__dict__)
    response = EvaluationDataManager(api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response
