from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.db_service import (
        DBManager,
        DBTableInfoResponse,
        DBTableRenameRequest
    )

router = APIRouter(tags=["Registry-DB"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

""" DB """
@router.patch("/db/evaluation/collection/rename", status_code=status.HTTP_200_OK, response_model=Response)
def db_table_rename(request: DBTableRenameRequest) -> Response:
    response = DBManager().rename_table(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.delete("/db/evaluation/collection/drop/{table_name}", status_code=status.HTTP_200_OK, response_model=Response)
def db_table_drop(table_name: str) -> Response:
    response = DBManager().drop_table(table_name=table_name)
    router_response_handler(response=response, api_call=default_api_call)
    return response