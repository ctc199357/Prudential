from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.seed_qna_data import (
        DataManager as SeedQnADataManager,
        UserDataRequest as UserSeedQnARequest, 
        UserDataResponse as UserSeedQnAResponse,
    )

from ...database.registry.services.qna_data import (
        DataManager as QnADataManager,
        UserDataRequest as UserQnARequest, 
        UserDataResponse as UserQnAResponse,
    )

from ...database.registry.services.evaluation_data import (
        DataManager as EvaluationDataManager,
        UserDataRequest as UserEvaluationRequest, 
        UserDataResponse as UserEvaluationResponse,
    )

router = APIRouter(tags=["Registry-User"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

"""
    SeedQnA
"""
@router.post("/user/seedqna/query", status_code=status.HTTP_200_OK, response_model=UserSeedQnAResponse)
def user_query_seedqna(request: UserSeedQnARequest, api_call: bool=default_api_call) -> UserSeedQnAResponse:
    request = UserSeedQnARequest(**request.__dict__)
    response_data, response = SeedQnADataManager(api_call=api_call).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

"""
    QnA
"""
@router.post("/user/qna/query", status_code=status.HTTP_200_OK, response_model=UserQnAResponse)
def user_query_qna(request: UserQnARequest, api_call: bool=default_api_call) -> UserQnAResponse:
    request = UserQnARequest(**request.__dict__)
    response_data, response = QnADataManager(api_call=api_call).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

"""
    Evaluation
"""
@router.post("/user/evaluation/query", status_code=status.HTTP_200_OK, response_model=UserEvaluationResponse)
def user_query_evaluation(request: UserEvaluationRequest, api_call: bool=default_api_call) -> UserEvaluationResponse:
    request = UserEvaluationRequest(**request.__dict__)
    response_data, response = EvaluationDataManager(api_call=api_call).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data
