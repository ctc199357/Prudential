from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.seed_qna_data import (
        DataManager as SeedQnADataManager,
        SystemDataRequest as SystemSeedQnARequest, 
        SystemDataResponse as SystemSeedQnAResponse,
    )

from ...database.registry.services.qna_data import (
        DataManager as QnADataManager,
        SystemDataRequest as SystemQnARequest, 
        SystemDataResponse as SystemQnAResponse,
    )

from ...database.registry.services.evaluation_data import (
        DataManager as EvaluationDataManager,
        SystemDataRequest as SystemEvaluationRequest, 
        SystemDataResponse as SystemEvaluationResponse,
    )

router = APIRouter(tags=["Registry-Admin"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


"""
    Seed QnA
"""
@router.post("/system/seedqna/query", status_code=status.HTTP_200_OK, response_model=SystemSeedQnAResponse)
def system_query_seedqna(request: SystemSeedQnARequest, api_call: bool=default_api_call) -> SystemSeedQnAResponse:
    request = SystemSeedQnARequest(**request.__dict__)
    response_data, response = SeedQnADataManager(api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/seedqna/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_seedqna(api_call: bool=default_api_call) -> Response:
    response = SeedQnADataManager(api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response

"""
    QnA
"""
@router.post("/system/qna/query", status_code=status.HTTP_200_OK, response_model=SystemQnAResponse)
def system_query_qna(request: SystemQnARequest, api_call: bool=default_api_call) -> SystemQnAResponse:
    request = SystemQnARequest(**request.__dict__)
    response_data, response = QnADataManager(api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/qna/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_qna(api_call: bool=default_api_call) -> Response:
    response = QnADataManager(api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    Evaluation
"""
@router.post("/system/evaluation/query", status_code=status.HTTP_200_OK, response_model=SystemEvaluationResponse)
def system_query_evaluation(request: SystemEvaluationRequest, api_call: bool=default_api_call) -> SystemEvaluationResponse:
    request = SystemEvaluationRequest(**request.__dict__)
    response_data, response = EvaluationDataManager(api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/evaluation/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_evaluation(api_call: bool=default_api_call) -> Response:
    response = EvaluationDataManager(api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response


