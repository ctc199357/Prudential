from fastapi import APIRouter

from ..settings import SETTINGS

from .health  import router as health_router

from .request_pipeline import router as request_pipeline_router

from .request_qna import router as request_qna_router
from .request_evaluation import router as request_evaluation_router

from .registry.general import router as general_router
from .registry.user    import router as user_router
from .registry.system  import router as system_router
from .registry.io      import router as io_router

# from .testing import router as test_router

router = APIRouter()

api_routers = [
    # health_router,
    request_pipeline_router,
    request_qna_router,
    request_evaluation_router,
    general_router,
    # user_router,
    # system_router
    # io_router,
]

for api_router in api_routers:
    router.include_router(api_router, prefix=SETTINGS.BASE.ENDPOINT_PREFIX)