from fastapi import APIRouter, Depends, status
from typing import Any

from ..settings import SETTINGS
from ..schemas.format import Response
from ..utils import router_response_handler

from ..job.services.job_data import (
        DataManager as JobDataManager,
        CreateRequest as JobCreateRequest, 
        BatchCreateRequest as JobBatchCreateRequest,
        DataUpdate as JobUpdate,
        UpdateRequest as JobUpdateRequest, 
        CommonRequest as JobRequest,
        BatchCommonRequest as JobBatchRequest,
        SystemDataRequest as SystemJobRequest, 
        SystemDataResponse as SystemJobResponse,
    )


router = APIRouter(tags=["EvaluationHub-Job"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


"""
    Job Data Management
"""
@router.post("/job/query", status_code=status.HTTP_200_OK, response_model=SystemJobResponse)
def system_query_job(request: SystemJobRequest, api_call: bool=default_api_call) -> SystemJobResponse:
    request = SystemJobRequest(**request.__dict__)
    response_data, response = JobDataManager(api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.post("/job/single/create", status_code=status.HTTP_201_CREATED)
def general_create_job(request: JobCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = JobCreateRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/job/single/update", status_code=status.HTTP_200_OK)
def general_update_job(request: JobUpdateRequest, api_call: bool=default_api_call) -> Response:
    request  = JobUpdateRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/job/single/delete", status_code=status.HTTP_200_OK)
def general_delete_job(request: JobRequest, api_call: bool=default_api_call) -> Response:
    request  = JobRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/job/single/drop", status_code=status.HTTP_200_OK)
def general_drop_job(request: JobRequest, api_call: bool=default_api_call) -> Response:
    request  = JobRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/job/single/activate", status_code=status.HTTP_200_OK)
def general_activate_job(request: JobRequest, api_call: bool=default_api_call) -> Response:
    request  = JobRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/job/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_job(request: JobRequest, api_call: bool=default_api_call) -> Response:
    request  = JobRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/job/batch/create", status_code=status.HTTP_201_CREATED)
def general_batch_create_job(request: JobBatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = JobBatchCreateRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/job/batch/delete", status_code=status.HTTP_200_OK)
def general_batch_delete_job(request: JobBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = JobBatchRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/job/batch/drop", status_code=status.HTTP_200_OK)
def general_batch_drop_job(request: JobBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = JobBatchRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/job/batch/activate", status_code=status.HTTP_200_OK)
def general_batch_activate_job(request: JobBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = JobBatchRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/job/batch/deactivate", status_code=status.HTTP_200_OK)
def general_batch_deactivate_job(request: JobBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = JobBatchRequest(**request.__dict__)
    response = JobDataManager(api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/job/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_job(api_call: bool=default_api_call) -> Response:
    response = JobDataManager(api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/job/drop/condition", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def system_drop_condition_job(request: JobUpdate) -> Response:
    request = JobUpdate(**request.__dict__)
    response = JobDataManager(api_call=default_api_call).condition_drop(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response