from fastapi import APIRouter, status, Header, Body, Depends, HTTPException, BackgroundTasks
from typing import Annotated
import asyncio
import time
from ..settings import SETTINGS
from ..utils import router_response_handler,router_response_exception_handler

from ..schemas.format import Response, ComplexEncoder

from ..schemas.exception import ExceptionFormat

from ..services.pipeline_service import (
    JobManager,
    OnboardingPipelineRequest,
    PipelineResponse,
    JOB_PROCESSING,
    JOB_SUCCESS,
    JOB_PIPELINE
)

router = APIRouter(tags=["Request-Pipeline"])

# API Configuration
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

@router.get("pipeline/job/time_trigger/{job_type}", status_code=status.HTTP_200_OK)
def time_trigger_pipeline_job(job_type: str='ALL'):
    asyncio.run(JobManager(api_call=False).time_trigger_job(job_type=job_type))

@router.get("pipeline/job/reset/{job_type}/{job_stage}", status_code=status.HTTP_200_OK)
async def reset_pipeline_job(job_type: str='ALL', job_stage: str=JOB_PROCESSING):
    await JobManager(api_call=False).reset_job(job_type=job_type, job_stage=job_stage)

@router.get("pipeline/job/clear/{job_type}/{job_stage}", status_code=status.HTTP_200_OK)
def clear_pipeline_job(job_type: str='ALL', job_stage: str=JOB_SUCCESS):
    JobManager(api_call=False).clear_job(job_type=job_type, job_stage=job_stage)

@router.post("/pipeline/job/evaluation", status_code=status.HTTP_200_OK, response_model=PipelineResponse, responses={422: {"model": ExceptionFormat}})
def request_execute_evaluation_pipeline(request: OnboardingPipelineRequest, api_call: bool = default_api_call) -> PipelineResponse:
    request = OnboardingPipelineRequest(**request.__dict__)
    response_data, response = JobManager(api_call=api_call).create_pipeline_job(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data





# @router.post("/request/evaluation/pipeline", status_code=status.HTTP_200_OK, response_model=EvaluationPipelineResponse, responses={422: {"model": ExceptionFormat}})
# def request_execute_evaluation_pipeline(request: EvaluationPipelineRequest, api_call: bool = default_api_call) -> EvaluationPipelineResponse:
#     request = EvaluationPipelineRequest(**request.__dict__)
#     response_data, response = PipelineServiceManager(api_call=api_call).execute_pipeline(request=request)
#     router_response_handler(response=response, api_call=api_call)
#     return response_data
