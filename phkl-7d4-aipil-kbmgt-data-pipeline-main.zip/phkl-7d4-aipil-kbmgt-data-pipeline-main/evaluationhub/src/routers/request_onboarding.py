from fastapi import APIRouter, status, Header, Body, Depends, HTTPException
from typing import Annotated
from ..settings import SETTINGS
from ..utils import router_response_handler,router_response_exception_handler

from ..schemas.format import Response, ComplexEncoder

from ..schemas.exception import ExceptionFormat

from ..services.onboarding_service import (
    OnboardingServiceManager,
    OnboardingPipelineRequest,
    OnboardingPipelineResponse
)

router = APIRouter(tags=["Request-Onboarding"])

# API Configuration
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

@router.post("/request/onboarding/pipeline", status_code=status.HTTP_200_OK, response_model=OnboardingPipelineResponse, responses={422: {"model": ExceptionFormat}})
def request_knowledge_onboarding(request: OnboardingPipelineRequest) -> OnboardingPipelineResponse:
    request = OnboardingPipelineRequest(**request.__dict__)
    response_data, response = OnboardingServiceManager(api_call=default_api_call).execute_pipeline(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data
