from fastapi import APIRouter
from ..schemas.format import Health

router = APIRouter(tags=["Health"])

@router.get("/", status_code=200)
def index():
    """
    For health check

    :return:
    """
    return {"domain": ""}


from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..settings import SETTINGS

from ..schemas.format import Health
from ..services.health import HealthService

router = APIRouter(tags=["Health"])

# API Configuration
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


@router.get("/health", status_code=status.HTTP_200_OK, response_model=Health)
def health_check() -> Health:
    response_health = HealthService(api_call=default_api_call).health_check()
    if response_health.status_code >= SETTINGS.STAT.SUCC_CODE_END:
        _detail = [f"{key} : {value}" for key, value in response_health.__dict__.items() if '_reason' in key]
        detail  = '; '.join(_detail)

        if default_api_call == True:
            raise HTTPException(status_code=response_health.status_code, detail=detail)
        else:
            raise Exception(detail)
        
    return response_health