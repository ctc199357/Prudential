from fastapi import APIRouter, status, Header, Body, Depends, HTTPException
from typing import Annotated
from ..settings import SETTINGS
from ..utils import router_response_handler,router_response_exception_handler

from ..schemas.format import Response, ComplexEncoder

from ..schemas.qna import (
    KnowledgeQnARequest,
    KnowledgeQnAReadResponse,
    QnAGenerationRequest,
    QnAGenerationResponse
)

from ..schemas.seed_qna import (
    SeedQnASyncRequest,
    SeedQnASyncResponse
)

from ..schemas.exception import ExceptionFormat
from ..services.qna_service import QnAServiceManager
from ..services.seed_qna_service import SeedQnAServiceManager

router = APIRouter(tags=["Request-QnA"])

# API Configuration
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

@router.post("/request/sync_seed_qna", status_code=status.HTTP_200_OK, response_model=SeedQnASyncResponse, responses={422: {"model": ExceptionFormat}})
def request_seed_qna_sync(request: SeedQnASyncRequest, api_call: bool = default_api_call) -> SeedQnASyncResponse:
    request = SeedQnASyncRequest(**request.__dict__)
    response_data, response = SeedQnAServiceManager(api_call=api_call).sync_qna_from_file(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data


@router.post("/request/qna_knowledge_generation", status_code=status.HTTP_200_OK, response_model=QnAGenerationResponse, responses={422: {"model": ExceptionFormat}})
def request_qna_knowledge_generation(request: QnAGenerationRequest, api_call: bool = default_api_call) -> QnAGenerationResponse:
    request = QnAGenerationRequest(**request.__dict__)
    response_data, response = QnAServiceManager(api_call=api_call).generate_knowledge_qna(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data


@router.post("/request/qna/read", status_code=status.HTTP_200_OK, response_model=KnowledgeQnAReadResponse, responses={422: {"model": ExceptionFormat}})
def request_read_knowledge_qna(request: KnowledgeQnARequest, api_call: bool = default_api_call) -> KnowledgeQnAReadResponse:
    request = KnowledgeQnARequest(**request.__dict__)
    response_data, response = QnAServiceManager(api_call=api_call).read_knowledge_qna(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data



@router.post("/request/deactivate_knowledge_qna", status_code=status.HTTP_200_OK)
def request_deactivate_knowledge_qna(request: KnowledgeQnARequest, api_call: bool = default_api_call) -> Response:
    request = KnowledgeQnARequest(**request.__dict__)
    response = QnAServiceManager(api_call=api_call).deactivate_knowledge_qna(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/request/drop_knowledge_qna", status_code=status.HTTP_200_OK)
def request_drop_knowledge_qna(request: KnowledgeQnARequest, api_call: bool = default_api_call) -> Response:
    request = KnowledgeQnARequest(**request.__dict__)
    response = QnAServiceManager(api_call=api_call).drop_knowledge_qna(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response
