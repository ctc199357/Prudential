import uuid
from datetime import datetime, timezone

from ...settings import SETTINGS

if SETTINGS.JOB.FORM.upper() in ["MODB"]:
    from mongoengine import *
     
    class JobDB(Document):

        # Trace Information
        job_id       = StringField(default=lambda: str(uuid.uuid4()), unique=True)
        job_status   = IntField(default=1)
        job_version  = IntField(default=1)
        knowledge_id = StringField(default='')

        # Specification
        job_type     = StringField(default='')
        job_pipeline = StringField(default='')
        job_config   = DictField(default=dict())
        job_success  = BooleanField(default=False)
        job_complete = BooleanField(default=False)
        job_stage    = StringField(default='')
        job_reason   = StringField(default='')

        # Time Information        
        created_at   = DateTimeField(default=datetime.now(timezone.utc))
        updated_at   = DateTimeField(default=datetime.now(timezone.utc))
        processed_at = DateTimeField(default=None)
        completed_at = DateTimeField(default=None)

        meta = {
            'collection': SETTINGS.JOB.TABLE, 
            'indexes': [
                'job_id',
                'job_status',
                'job_version',
                'knowledge_id',
                'job_type',
                'job_pipeline',
                'job_success',
                'job_complete',
                'job_stage',
                'job_reason',
                'created_at',
                'updated_at',
                'processed_at',
                'completed_at'
            ]
        }

        def to_dict(self):
            return {**self.to_mongo().to_dict()}
        

else:
    err_msg = f"Unknown DB Schema Error : <{SETTINGS.JOB.NAME}> Database"
    raise Exception(err_msg)