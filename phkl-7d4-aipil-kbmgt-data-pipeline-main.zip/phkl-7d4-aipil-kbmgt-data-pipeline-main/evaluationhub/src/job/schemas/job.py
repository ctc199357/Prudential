from pydantic import BaseModel, Field, validator
from typing import List, Optional, Union
import uuid
from datetime import datetime, timezone

from ...settings import SETTINGS

""""
    Job General Operation
"""
class JobCreate(BaseModel):
    # Trace Information
    job_id:       str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Job ID")
    job_status:   int=Field(default=1, description="[Optional] Job Status")
    job_version:  int=Field(default=1, description="[Optional] Job Version")
    knowledge_id: str=Field(default='', description="[Optional] Knowledge ID")

    # Specification
    job_type:     str=Field(default='', description="[Optional] Job Type")
    job_pipeline: str=Field(default='', description="Job Pipeline Function name")
    job_config:   dict=Field(default=dict(), description="[Optional] Job Config")
    job_success:  bool=Field(default=False, description="Job Success Flag")
    job_complete: bool=Field(default=False, description="Job Complete Flag")
    job_stage:    str=Field(default='', description="Job Stage")
    job_reason:   str=Field(default='', description="Job Fail Reason")

    # Time Information
    created_at:   datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Created DateTime") # Created DateTime
    updated_at:   datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Updated DateTime") # Updated DateTime
    processed_at: Optional[datetime]=Field(default=None)
    completed_at: Optional[datetime]=Field(default=None)

class JobCreateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Job")
    user_name:      str=Field(default="", description="[Optional] User Name for the Job")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Job")
    data:           JobCreate=Field(..., description="[Required] Job Data", example=JobCreate())

class JobBatchCreateRequest(BaseModel):
    create_requests: list[JobCreateRequest]

# Job CRUD
class JobUpdate(BaseModel):
    # Trace Information
    job_id:       str | None = None
    job_status:   int | None = None
    job_version:  int | None = None
    knowledge_id: str | None = None

    # Specification
    job_type:     str | None = None
    job_pipeline: str | None = None
    job_config:   dict | None = None
    job_success:  bool | None = None
    job_complete: bool | None = None
    job_stage:    str | None = None
    job_reason:   str | None = None

    # Time Information
    created_at:   datetime | None = None
    updated_at:   datetime | None = None
    processed_at: datetime | None = None
    completed_at: datetime | None = None

class JobUpdateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Job")
    user_name:      str=Field(default="", description="[Optional] User Name for the Job")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Job")
    job_id:         str=Field(..., description="[Required] Job ID for the Update")
    update_data:    JobUpdate=Field(..., description="[Required] Job Data for the Update")
    overwrite:      bool=Field(default=True, description="[Optional] Overwrite Flag for the Update") # Overwrite Flag for the Update
    
class JobRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Job")
    user_name:      str=Field(default="", description="[Optional] User Name for the Job")
    job_id:         str=Field(..., description="[Required] Job ID for the Request")

class JobBatchRequest(BaseModel):
    batch_requests: list[JobRequest]

# System-level Access
class SecretJob(BaseModel):
    # Trace Information
    job_id:       str | None = None
    job_status:   int | None = None
    job_version:  int | None = None
    knowledge_id: str | None = None

    # Specification
    job_type:     str | None = None
    job_pipeline: str | None = None
    job_config:   dict | None = None
    job_success:  bool | None = None
    job_complete: bool | None = None
    job_stage:    str | None = None
    job_reason:   str | None = None

    # Time Information
    created_at:   datetime | None = None
    updated_at:   datetime | None = None
    processed_at: datetime | None = None
    completed_at: datetime | None = None

# User-level Access
class Job(BaseModel):
    # Trace Information
    job_id:       str | None = None
    job_status:   int | None = None
    job_version:  int | None = None
    knowledge_id: str | None = None

    # Specification
    job_type:     str | None = None
    job_pipeline: str | None = None
    job_config:   dict | None = None
    job_success:  bool | None = None
    job_complete: bool | None = None
    job_stage:    str | None = None
    job_reason:   str | None = None

    # Time Information
    created_at:   datetime | None = None
    updated_at:   datetime | None = None
    processed_at: datetime | None = None
    completed_at: datetime | None = None

"""
    Job Filter
"""   
class JobStringFilter(BaseModel):
    job_id_filter:       list[str] | None = None
    knowledge_id_filter: list[str] | None = None
    
    job_type_filter:     list[str] | None = None
    job_pipeline_filter: list[str] | None = None
    job_stage_filter:    list[str] | None = None
    job_reason_filter:   list[str] | None = None


class JobNumericFilter(BaseModel):
    job_status_min:  int | None = None
    job_status_max:  int | None = None 
    job_version_min: int | None = None
    job_version_max: int | None = None

class JobListFilter(BaseModel):
    not_used_filter_or:  list[str] | None = None
    not_used_filter_and: list[str] | None = None

class JobDictionaryFilter(BaseModel):
    job_config_filter_or:  list[str] | None = None
    job_config_filter_and: list[str] | None = None

class JobBooleanFilter(BaseModel):
    job_success_filter:  bool | None = None
    job_complete_filter: bool | None = None

class JobDatetimeFilter(BaseModel):
    created_at_start:   datetime  | None = None
    created_at_end:     datetime  | None = None
    updated_at_start:   datetime  | None = None
    updated_at_end:     datetime  | None = None
    processed_at_start: datetime  | None = None
    processed_at_end:   datetime  | None = None
    completed_at_start: datetime  | None = None
    completed_at_end:   datetime  | None = None

class JobByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class JobFilter(BaseModel):
    string_filter:     JobStringFilter     | None = None
    numeric_filter:    JobNumericFilter    | None = None
    list_filter:       JobListFilter       | None = None
    dictionary_filter: JobDictionaryFilter | None = None
    boolean_filter:    JobBooleanFilter    | None = None
    datetime_filter:   JobDatetimeFilter   | None = None
    byte_filter:       JobByteFilter       | None = None
    sorting:           dict={"job_id": "asc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access Jobs
"""
class SystemJobRequest(BaseModel):
    job_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:   JobFilter=Field(..., description="[Required] Job Filter")  

    class Config:
        schema_extra = {
            "example": {
                "job_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "numeric_filter": {
                        "job_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemJobResponse(BaseModel):
    job_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data: list[SecretJob]=Field(default=[], description="Filtered Job Data")
    data_count:    int=Field(default=0, description="Count of Filtered Job Data", example=1)

"""
    Request and Response for User Access Permitted Jobs
""" 
class UserJobRequest(BaseModel):
    job_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:   JobFilter

class UserJobResponse(BaseModel):
    job_requestid: str
    filtered_data: list[Job]=[]

"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class JobBackupRequest(BaseModel):
    job_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:   JobFilter | None = None
    backup_config: BackupConfig | None = None

class JobBackupListRequest(BaseModel):
    job_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config: BackupConfig | None = None

class JobBackupListResponse(BaseModel):
    job_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:    list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class JobRestoreRequest(BaseModel):
    job_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config: RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class JobImportRequest(BaseModel):
    job_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:     IOConfig | None = None
    backup:        bool=True

class JobExportRequest(BaseModel):
    job_requestid:    str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:      JobFilter | None = None
    io_config:        IOConfig | None = None
    include_datetime: bool = True

    class Config:
        schema_extra = {
            "example": {
                "job_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "numeric_filter": {
                        "job_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "evaluation_job"
                },
                "include_datetime": True
            }
        }