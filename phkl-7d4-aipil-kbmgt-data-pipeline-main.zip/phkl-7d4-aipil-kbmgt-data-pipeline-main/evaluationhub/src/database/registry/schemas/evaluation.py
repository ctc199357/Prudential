from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from .utils import RawRetrievalObject

from ....settings import SETTINGS

""""
    Evaluation General Operation
"""
class EvaluationCreate(BaseModel):
    # Trace Information
    evaluation_id:            str=Field(default_factory=lambda: str(uuid.uuid4()))
    evaluation_traceid:       str=Field(default_factory=lambda: str(uuid.uuid4()))
    evaluation_version:       int=1
    batch_order:              str=Field(default_factory=lambda: datetime.now().strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp
    knowledge_id:             str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_version:        int=1
    document_name:            str=''

    # Control Information
    evaluation_status:        int=1
    evaluation_permission:    int=1  # evaluation access level
    evaluation_management:    int=10 # evaluation management level
    
    # Evaluation Information
    qna_id:                   str=''
    qna_query:                str=''
    qna_response:             str=''
    qna_citations:            list[str]=[]
    qna_data_ids:             list[str]=[]
    qna_query_language:       str=''
    qna_response_language:    str=''

    actual_response:          str=''
    actual_citations:         list[str]=[]
    actual_data_ids:          list[str]=[]
    actual_language:          str=''

    # Evaluation Matrix
    similarity:               int=-1
    relevance:                int=-1
    groundedness:             int=-1
    retrieval:                int=-1
    input_tokens:             int=-1   # Inference Input Tokens
    output_tokens:            int=-1   # Inference Output Tokens
    tool_tokens:              int=-1   # Inference Tool Tokens
    response_time:            float=-1 # Inference Response Time

    # Statistics
    evaluation_code:          str='SUCCESS'
    evaluation_time:          float=0.0

    # Tags
    evaluation_tags:          list[str]=[]
    
    # Time Information
    created_at:               datetime=Field(default_factory=datetime.now)
    updated_at:               datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "evaluation_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "evaluation_traceid": "a7bcf831-a33e-4f4b-939d-5ad26c128542",
                "evaluation_version": 1,
                "batch_order": "20230430120000",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "knowledge_version": 1,
                "document_name": "Sample Document",
                "evaluation_status": 1,
                "evaluation_permission": 1,
                "evaluation_management": 10,
                "qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "qna_query": "What is the capital of France?",
                "qna_response": "The capital of France is Paris.",
                "qna_citations": [
                    {
                        "document": {
                            "knowledge_id": "doc123",
                            "knowledge_languages": ["en"],
                            "document_name": "Sample Document",
                            "hyperlink": "https://example.com/sample-document",
                            "last_update_date": "2023-04-30",
                            "pil_reference_number": "PIL12345",
                            "translation": "ORIGINAL"
                        },
                        "citations": [
                            {
                                "data_id": "cite456",
                                "knowledge_id": "doc123",
                                "content": "This is a sample citation content.",
                                "source_type": "text",
                                "image_table_link": "https://example.com/citation-image.jpg",
                                "page_start": 1,
                                "page_end": 1,
                                "langauage": "en",
                                "score": 0.85
                            }
                        ]
                    }
                ],
                "qna_query_language": "en",
                "qna_response_language": "en",
                "actual_response": "The capital of France is Paris.",
                "actual_citations": [],
                "actual_language": "en",
                "similarity": 5,
                "relevance": 4,
                "groundedness": 3,
                "retrieval": 2,
                "input_tokens": 10,
                "output_tokens": 15,
                "tool_tokens": 5,
                "response_time": 0.123,
                "evaluation_code": "SUCCESS",
                "evaluation_time": 1.5,
                "evaluation_tags": [],
                "created_at": "2023-04-30T12:00:00Z",
                "updated_at": "2023-04-30T12:00:00Z"
            }
        }

class EvaluationCreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           EvaluationCreate

class EvaluationBatchCreateRequest(BaseModel):
    create_requests: list[EvaluationCreateRequest]


# Evaluation CRUD
class EvaluationUpdate(BaseModel):
    # Trace Information
    evaluation_id:            str | None = None
    evaluation_traceid:       str | None = None
    evaluation_version:       int | None = None
    batch_order:              str | None = None
    knowledge_id:             str | None = None
    knowledge_version:        int | None = None
    document_name:            str | None = None

    # Control Information
    evaluation_status:        int | None = None
    evaluation_permission:    int | None = None  # evaluation access level
    evaluation_management:    int | None = None
    
    # Evaluation Information
    qna_id:                   str | None = None
    qna_query:                str | None = None
    qna_response:             str | None = None
    qna_citations:            list[str] | None = None
    qna_data_ids:             list[str] | None = None
    qna_query_language:       str | None = None
    qna_response_language:    str | None = None

    actual_response:          str | None = None
    actual_citations:         list[str] | None = None
    actual_data_ids:          list[str] | None = None
    actual_language:          str | None = None

    # Evaluation Matrix
    similarity:               int | None = None
    relevance:                int | None = None
    groundedness:             int | None = None
    retrieval:                int | None = None
    input_tokens:             int | None = None   # Inference Input Tokens
    output_tokens:            int | None = None   # Inference Output Tokens
    tool_tokens:              int | None = None   # Inference Tool Tokens
    response_time:            float | None = None # Inference Response Time

    # Statistics
    evaluation_code:          str | None = None
    evaluation_time:          float | None = None

    # Tags
    evaluation_tags:          list[str] | None = None
    
    # Time Information
    created_at:               datetime | None = None
    updated_at:               datetime | None = None


class EvaluationUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    evaluation_id:  str | None = None
    update_data:    EvaluationUpdate=EvaluationUpdate()
    overwrite:      bool = True

class EvaluationRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Evaluation")
    user_name:      str=Field(default="", description="[Optional] User Name for the Evaluation")
    evaluation_id:  str=Field(..., description="[Required] Evaluation ID for the Request")

    class Config:
        schema_extra = {
            "example": {
                "evaluation_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541"
            }
        }

class EvaluationBatchRequest(BaseModel):
    batch_requests: list[EvaluationRequest]


# System-level Access
class SecretEvaluation(BaseModel):
    # Trace Information
    evaluation_id:            str | None = None
    evaluation_traceid:       str | None = None
    evaluation_version:       int | None = None
    batch_order:              str | None = None
    knowledge_id:             str | None = None
    knowledge_version:        int | None = None
    document_name:            str | None = None

    # Control Information
    evaluation_status:        int | None = None
    evaluation_permission:    int | None = None  # evaluation access level
    evaluation_management:    int | None = None
    
    # Evaluation Information
    qna_id:                   str | None = None
    qna_query:                str | None = None
    qna_response:             str | None = None
    qna_citations:            list[str] | None = None
    qna_data_ids:             list[str] | None = None
    qna_query_language:       str | None = None
    qna_response_language:    str | None = None

    actual_response:          str | None = None
    actual_citations:         list[str] | None = None
    actual_data_ids:          list[str] | None = None
    actual_language:          str | None = None

    # Evaluation Matrix
    similarity:               int | None = None
    relevance:                int | None = None
    groundedness:             int | None = None
    retrieval:                int | None = None
    input_tokens:             int | None = None   # Inference Input Tokens
    output_tokens:            int | None = None   # Inference Output Tokens
    tool_tokens:              int | None = None   # Inference Tool Tokens
    response_time:            float | None = None # Inference Response Time

    # Statistics
    evaluation_code:          str | None = None
    evaluation_time:          float | None = None

    # Tags
    evaluation_tags:          list[str] | None = None
    
    # Time Information
    created_at:               datetime | None = None
    updated_at:               datetime | None = None

"""
    Evaluation Filter
"""   
class EvaluationStringFilter(BaseModel):
    evaluation_id_filter:         list[str] | None = None
    evaluation_traceid_filter:    list[str] | None = None    
    batch_order_filter:           list[str] | None = None
    knowledge_id_filter:          list[str] | None = None
    document_name_filter:         list[str] | None = None

    qna_query_filter:             list[str] | None = None
    qna_response_filter:          list[str] | None = None
    qna_query_language_filter:    list[str] | None = None
    qna_response_language_filter: list[str] | None = None

    actual_response_filter:       list[str] | None = None
    actual_language_filter:       list[str] | None = None

    evaluation_code_filter:       list[str] | None = None
    
class EvaluationNumericFilter(BaseModel):
    evaluation_version_min:    int | None = None
    evaluation_version_max:    int | None = None
    knowledge_version_min:     int | None = None
    knowledge_version_max:     int | None = None

    evaluation_status_min:     int | None = None
    evaluation_status_max:     int | None = None 
    evaluation_permission_min: int | None = None
    evaluation_permission_max: int | None = None
    evaluation_management_min: int | None = None
    evaluation_management_max: int | None = None

    similarity_min:            int | None = None
    similarity_max:            int | None = None 
    relevance_min:             int | None = None
    relevance_max:             int | None = None
    groundedness_min:          int | None = None
    groundedness_max:          int | None = None

    retrieval_min:             int | None = None
    retrieval_max:             int | None = None 
    input_tokens_min:          int | None = None
    input_tokens_max:          int | None = None
    output_tokens_min:         int | None = None
    output_tokens_max:         int | None = None

    tool_tokens_min:           int | None = None
    tool_tokens_max:           int | None = None
    response_time_min:         int | None = None
    response_time_max:         int | None = None

    evaluation_time_min:       int | None = None
    evaluation_time_max:       int | None = None

class EvaluationListFilter(BaseModel):
    evaluation_tags_or:  list[str] | None = None
    evaluation_tags_and: list[str] | None = None    

class EvaluationDictionaryFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None

class EvaluationBooleanFilter(BaseModel):
    not_used_filter: bool | None = None

class EvaluationDatetimeFilter(BaseModel):
    created_at_start:                  datetime  | None = None
    created_at_end:                    datetime  | None = None
    updated_at_start:                  datetime  | None = None
    updated_at_end:                    datetime  | None = None

class EvaluationByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class EvaluationFilter(BaseModel):
    string_filter:     EvaluationStringFilter     | None = None
    numeric_filter:    EvaluationNumericFilter    | None = None
    list_filter:       EvaluationListFilter       | None = None
    dictionary_filter: EvaluationDictionaryFilter | None = None
    boolean_filter:    EvaluationBooleanFilter    | None = None
    datetime_filter:   EvaluationDatetimeFilter   | None = None
    byte_filter:       EvaluationByteFilter       | None = None
    sorting:           dict={"evaluation_id": "asc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access Evaluations
"""
class SystemEvaluationRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:   EvaluationFilter=Field(..., description="[Required] Evaluation Filter", example=EvaluationFilter(
                                    string_filter=EvaluationStringFilter(
                                        evaluation_id_filter=["evaluation_id_1"]
                                    ),
                                    numeric_filter=EvaluationNumericFilter(
                                        evaluation_status_min=1
                                    )
                                ))  

    class Config:
        schema_extra = {
            "example": {
                "evaluation_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "numeric_filter": {
                        "evaluation_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemEvaluationResponse(BaseModel):
    evaluation_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data: list[SecretEvaluation]=Field(default=[], description="Filtered Evaluation Data")
    data_count:    int=Field(default=0, description="Count of Filtered Evaluation Data", example=1)


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class EvaluationBackupRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:          EvaluationFilter | None = None
    backup_config:        BackupConfig | None = None

class EvaluationBackupListRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:        BackupConfig | None = None

class EvaluationBackupListResponse(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:           list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class EvaluationRestoreRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:       RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class EvaluationImportRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:            IOConfig | None = None
    backup:               bool=True

class EvaluationExportRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:          EvaluationFilter | None = None
    io_config:            IOConfig | None = None
    include_datetime:     bool = True

    class Config:
        schema_extra = {
            "example": {
                "evaluation_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "numeric_filter": {
                        "evaluation_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "evaluation"
                },
                "include_datetime": True
            }
        }

"""" EvaluationServiceManager """
"""
    Request and Response for User Access Permitted Evaluations
"""
# User-level Access
class Evaluation(BaseModel):
    # Trace Information
    evaluation_id:            str | None = None
    evaluation_traceid:       str | None = None
    evaluation_version:       int | None = None
    batch_order:              str | None = None
    knowledge_id:             str | None = None
    knowledge_version:        int | None = None

    # Control Information
    evaluation_status:        int | None = None
    evaluation_permission:    int | None = None  # evaluation access level
    evaluation_management:    int | None = None
    
    # Evaluation Information
    qna_id:                   str | None = None
    qna_query:                str | None = None
    qna_response:             str | None = None
    qna_citations:            list[str] | None = None
    qna_data_ids:             list[str] | None = None
    qna_query_language:       str | None = None
    qna_response_language:    str | None = None

    actual_response:          str | None = None
    actual_citations:         list[str] | None = None
    actual_data_ids:          list[str] | None = None
    actual_language:          str | None = None

    # Evaluation Matrix
    similarity:               int | None = None
    relevance:                int | None = None
    groundedness:             int | None = None
    retrieval:                int | None = None
    input_tokens:             int | None = None   # Inference Input Tokens
    output_tokens:            int | None = None   # Inference Output Tokens
    tool_tokens:              int | None = None   # Inference Tool Tokens
    response_time:            float | None = None # Inference Response Time

    # Statistics
    evaluation_code:          str | None = None
    evaluation_time:          float | None = None

    # Tags
    evaluation_tags:          list[str] | None = None
    
    # Time Information
    created_at:               datetime | None = None
    updated_at:               datetime | None = None

    
class UserEvaluationRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:          EvaluationFilter

class UserEvaluationResponse(BaseModel):
    evaluation_requestid: str
    filtered_data:        list[Evaluation]=[]