from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from .utils import RawRetrievalObject

from ....settings import SETTINGS

""""
    SeedQnA General Operation
"""
class SeedQnACreate(BaseModel):
    # Trace Information
    seed_qna_id:                str=Field(default_factory=lambda: str(uuid.uuid4()))
    seed_qna_traceid:           str=Field(default_factory=lambda: str(uuid.uuid4()))
    seed_qna_version:           int=1
    batch_order:                str=Field(default_factory=lambda: datetime.now().strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp
    knowledge_id:               str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_version:          int=1
    library_name_en:            str=''

    # Creator Information
    creator_id:                 str=''
    creator_name:               str=''
    approver_id:                str='system'
    approver_name:              str='system'

    # Control Information
    seed_qna_status:            int=1
    seed_qna_permission:        int=1  # qna access level
    seed_qna_management:        int=10 # qna management level

    # SeedQnA Information
    qna_query:                  str=''
    qna_response:               str=''
    qna_citations:              list[str]=[]
    qna_query_language:         str=''
    qna_response_language:      str=''

    # Tags
    seed_qna_tags:              list[str]=[]
    
    # Time Information
    created_at:                 datetime=Field(default_factory=datetime.now)
    updated_at:                 datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "seed_qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "seed_qna_traceid": "a7bcf831-a33e-4f4b-939d-5ad26c128542",
                "seed_qna_version": 1,
                "batch_order": "20230430120000",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "knowledge_version": 1,
                "library_name_en": "MPF",
                "creator_id": "creator_001",
                "creator_name": "John Doe",
                "approver_id": "system",
                "approver_name": "system",
                "seed_qna_status": 1,
                "seed_qna_permission": 1,
                "seed_qna_management": 10,
                "qna_query": "What is the capital of France?",
                "qna_response": "The capital of France is Paris.",
                "qna_citations": [
                    {
                        "document": {
                            "knowledge_id": "doc123",
                            "knowledge_languages": ["en"],
                            "document_name": "Sample Document",
                            "hyperlink": "https://example.com/sample-document",
                            "last_update_date": "2023-04-30",
                            "pil_reference_number": "PIL12345",
                            "translation": "ORIGINAL"
                        },
                        "citations": [
                            {
                                "data_id": "cite456",
                                "knowledge_id": "doc123",
                                "content": "This is a sample citation content.",
                                "source_type": "text",
                                "image_table_link": "https://example.com/citation-image.jpg",
                                "page_start": 1,
                                "page_end": 1,
                                "langauage": "en",
                                "score": 0.85
                            }
                        ]
                    }
                ],
                "qna_query_language": "en",
                "qna_response_language": "en",
                "seed_qna_tags": []
            }
        }

class SeedQnACreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           SeedQnACreate

class SeedQnABatchCreateRequest(BaseModel):
    create_requests: list[SeedQnACreateRequest]

# SeedQnA CRUD
class SeedQnAUpdate(BaseModel):
    # Trace Information
    seed_qna_id:                str | None = None
    seed_qna_traceid:           str | None = None
    seed_qna_version:           int | None = None
    batch_order:                str | None = None
    knowledge_id:               str | None = None
    knowledge_version:          int | None = None
    library_name_en:            str | None = None

    # Creator Information
    creator_id:                 str | None = None
    creator_name:               str | None = None
    approver_id:                str | None = None
    approver_name:              str | None = None

    # Control Information
    seed_qna_status:            int | None = None
    seed_qna_permission:        int | None = None  # qna access level
    seed_qna_management:        int | None = None # qna management level

    # SeedQnA Information
    qna_query:                  str | None = None
    qna_response:               str | None = None
    qna_citations:              list[str] | None = None
    qna_query_language:         str | None = None
    qna_response_language:      str | None = None

    # Tags
    seed_qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:                 datetime | None = None
    updated_at:                 datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "batch_order": "single",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "qna_query": "What is the capital of UK?",
                "qna_response": "The capital of UK is London.",
                "qna_citations": []
            }
        }


class SeedQnAUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    seed_qna_id:    str | None = None
    update_data:    SeedQnAUpdate=SeedQnAUpdate()
    overwrite:      bool = True

    class Config:
        schema_extra = {
            "example": {
                "seed_qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "update_data": {
                    "batch_order": "single",
                    "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                    "qna_query": "What is the capital of UK?",
                    "qna_response": "The capital of UK is London.",
                    "qna_citations": []
                }
            }
        }
    
class SeedQnARequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the SeedQnA")
    user_name:      str=Field(default="", description="[Optional] User Name for the SeedQnA")
    seed_qna_id:    str=Field(..., description="[Required] SeedQnA ID for the Request")

    class Config:
        schema_extra = {
            "example": {
                "seed_qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541"
            }
        }

class SeedQnABatchRequest(BaseModel):
    batch_requests: list[SeedQnARequest]


# System-level Access
class SecretSeedQnA(BaseModel):
    # Trace Information
    seed_qna_id:                str | None = None
    seed_qna_traceid:           str | None = None
    seed_qna_version:           int | None = None
    batch_order:                str | None = None
    knowledge_id:               str | None = None
    knowledge_version:          int | None = None
    library_name_en:            str | None = None

    # Creator Information
    creator_id:                 str | None = None
    creator_name:               str | None = None
    approver_id:                str | None = None
    approver_name:              str | None = None

    # Control Information
    seed_qna_status:            int | None = None
    seed_qna_permission:        int | None = None  # qna access level
    seed_qna_management:        int | None = None # qna management level

    # SeedQnA Information
    qna_query:                  str | None = None
    qna_response:               str | None = None
    qna_citations:              list[str] | None = None
    qna_query_language:         str | None = None
    qna_response_language:      str | None = None

    # Tags
    seed_qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:                 datetime | None = None
    updated_at:                 datetime | None = None


"""
    SeedQnA Filter
"""   
class SeedQnAStringFilter(BaseModel):
    seed_qna_id_filter:                list[str] | None = None
    seed_qna_traceid_filter:           list[str] | None = None    
    batch_order_filter:                list[str] | None = None
    knowledge_id_filter:               list[str] | None = None
    library_name_en_filter:            list[str] | None = None

    creator_id_filter:                 list[str] | None = None
    creator_name_filter:               list[str] | None = None
    approver_id_filter:                list[str] | None = None
    approver_name_filter:              list[str] | None = None

    qna_query_filter:                  list[str] | None = None
    qna_response_filter:               list[str] | None = None
    qna_query_language_filter:         list[str] | None = None
    qna_response_language_filter:      list[str] | None = None

class SeedQnANumericFilter(BaseModel):
    seed_qna_version_min:    int | None = None
    seed_qna_version_max:    int | None = None
    knowledge_version_min:   int | None = None
    knowledge_version_max:   int | None = None  

    seed_qna_status_min:     int | None = None
    seed_qna_status_max:     int | None = None 
    seed_qna_permission_min: int | None = None
    seed_qna_permission_max: int | None = None
    seed_qna_management_min: int | None = None
    seed_qna_management_max: int | None = None

class SeedQnAListFilter(BaseModel):
    seed_qna_tags_or:  list[str] | None = None
    seed_qna_tags_and: list[str] | None = None    

class SeedQnADictionaryFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None

class SeedQnABooleanFilter(BaseModel):
    not_used_filter: bool | None = None

class SeedQnADatetimeFilter(BaseModel):
    created_at_start:                  datetime  | None = None
    created_at_end:                    datetime  | None = None
    updated_at_start:                  datetime  | None = None
    updated_at_end:                    datetime  | None = None

class SeedQnAByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class SeedQnAFilter(BaseModel):
    string_filter:     SeedQnAStringFilter     | None = None
    numeric_filter:    SeedQnANumericFilter    | None = None
    list_filter:       SeedQnAListFilter       | None = None
    dictionary_filter: SeedQnADictionaryFilter | None = None
    boolean_filter:    SeedQnABooleanFilter    | None = None
    datetime_filter:   SeedQnADatetimeFilter   | None = None
    byte_filter:       SeedQnAByteFilter       | None = None
    sorting:           dict={"seed_qna_id": "asc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access SeedQnAs
"""
class SystemSeedQnARequest(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:        SeedQnAFilter=Field(..., description="[Required] SeedQnA Filter", example=SeedQnAFilter(
                                    string_filter=SeedQnAStringFilter(
                                        qna_id_filter=["seed_qna_id_1"]
                                    ),
                                    numeric_filter=SeedQnANumericFilter(
                                        qna_status_min=1
                                    )
                                ))  

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "seed_qna_id_filter": ["seed_qna_id_1"],
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemSeedQnAResponse(BaseModel):
    seed_qna_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data:      list[SecretSeedQnA]=Field(default=[], description="Filtered SeedQnA Data")
    data_count:         int=Field(default=0, description="Count of Filtered SeedQnA Data", example=1)


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class SeedQnABackupRequest(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        SeedQnAFilter | None = None
    backup_config:      BackupConfig | None = None

class SeedQnABackupListRequest(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:      BackupConfig | None = None

class SeedQnABackupListResponse(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:         list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class SeedQnARestoreRequest(BaseModel):
    seed_qna_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:      RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class SeedQnAImportRequest(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:          IOConfig | None = None
    backup:             bool=True

class SeedQnAExportRequest(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        SeedQnAFilter | None = None
    io_config:          IOConfig | None = None
    include_datetime:   bool = True

    class Config:
        schema_extra = {
            "example": {
                "seed_qna_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "qna"
                },
                "include_datetime": True
            }
        }

"""" SeedQnAServiceManager """
"""
    Request and Response for User Access Permitted SeedQnAs
"""
# User-level Access
class SeedQnA(BaseModel):
    # Trace Information
    seed_qna_id:                str | None = None
    seed_qna_traceid:           str | None = None
    seed_qna_version:           int | None = None
    batch_order:                str | None = None
    knowledge_id:               str | None = None
    knowledge_version:          int | None = None
    library_name_en:            str | None = None

    # Creator Information
    creator_id:                 str | None = None
    creator_name:               str | None = None
    approver_id:                str | None = None
    approver_name:              str | None = None

    # Control Information
    seed_qna_status:            int | None = None
    seed_qna_permission:        int | None = None  # qna access level
    seed_qna_management:        int | None = None # qna management level

    # SeedQnA Information
    qna_query:                  str | None = None
    qna_response:               str | None = None
    qna_citations:              list[str] | None = None
    qna_query_language:         str | None = None
    qna_response_language:      str | None = None

    # Tags
    seed_qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:                 datetime | None = None
    updated_at:                 datetime | None = None
    
class UserSeedQnARequest(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:   SeedQnAFilter

class UserSeedQnAResponse(BaseModel):
    seed_qna_requestid: str
    filtered_data: list[SeedQnA]=[]