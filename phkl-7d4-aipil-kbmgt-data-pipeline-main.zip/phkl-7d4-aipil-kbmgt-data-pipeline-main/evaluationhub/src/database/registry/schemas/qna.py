from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from .utils import RawRetrievalObject

from ....settings import SETTINGS

""""
    QnA General Operation
"""
class QnACreate(BaseModel):
    # Trace Information
    qna_id:                str=Field(default_factory=lambda: str(uuid.uuid4()))
    qna_traceid:           str=Field(default_factory=lambda: str(uuid.uuid4()))
    qna_version:           int=1
    seed_qna_id:           str=''
    seed_qna_version:      int=1
    batch_order:           str=Field(default_factory=lambda: datetime.now().strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp
    knowledge_id:          str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_version:     int=1
    document_name:         str=''

    # Creator Information
    creator_id:            str=''
    creator_name:          str=''
    approver_id:           str='system'
    approver_name:         str='system'

    # Control Information
    qna_status:            int=1
    qna_permission:        int=1  # qna access level
    qna_management:        int=10 # qna management level

    # QnA Information
    qna_query:             str=''
    qna_response:          str=''
    qna_citations:         list[str]=[]
    qna_data_ids:          list[str]=[]
    qna_query_language:    str=''
    qna_response_language: str=''

    # Tags
    qna_tags:              list[str]=[]
    
    # Time Information
    created_at:            datetime=Field(default_factory=datetime.now)
    updated_at:            datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "qna_traceid": "a7bcf831-a33e-4f4b-939d-5ad26c128542",
                "qna_version": 1,
                "seed_qna_id": "",
                "seed_qna_version": 1,
                "batch_order": "20230430120000",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "knowledge_version": 1,
                "document_name": "Sample Document",
                "creator_id": "creator_001",
                "creator_name": "John Doe",
                "approver_id": "system",
                "approver_name": "system",
                "qna_status": 1,
                "qna_permission": 1,
                "qna_management": 10,
                "qna_query": "What is the capital of France?",
                "qna_response": "The capital of France is Paris.",
                "qna_citations": [],
                "qna_query_language": "en",
                "qna_response_language": "en",
                "qna_tags": []
            }
        }

class QnACreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           QnACreate

class QnABatchCreateRequest(BaseModel):
    create_requests: list[QnACreateRequest]

# QnA CRUD
class QnAUpdate(BaseModel):
    # Trace Information
    qna_id:                str | None = None
    qna_traceid:           str | None = None
    qna_version:           int | None = None
    seed_qna_id:           str | None = None
    seed_qna_version:      int | None = None
    batch_order:           str | None = None
    knowledge_id:          str | None = None
    knowledge_version:     int | None = None
    document_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None
    approver_id:           str | None = None
    approver_name:         str | None = None

    # Control Information
    qna_status:            int | None = None
    qna_permission:        int | None = None  # qna access level
    qna_management:        int | None = None # qna management level

    # QnA Information
    qna_query:             str | None = None
    qna_response:          str | None = None
    qna_citations:         list[str] | None = None
    qna_data_ids:          list[str] | None = None
    qna_query_language:    str | None = None
    qna_response_language: str | None = None

    # Tags
    qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "batch_order": "single",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "qna_query": "What is the capital of UK?",
                "qna_response": "The capital of UK is London.",
                "qna_citations": []
            }
        }


class QnAUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    qna_id:         str | None = None
    update_data:    QnAUpdate=QnAUpdate()
    overwrite:      bool = True

    class Config:
        schema_extra = {
            "example": {
                "qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "update_data": {
                    "batch_order": "single",
                    "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                    "qna_query": "What is the capital of UK?",
                    "qna_response": "The capital of UK is London.",
                    "qna_citations": []
                }
            }
        }
    
class QnARequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the QnA")
    user_name:      str=Field(default="", description="[Optional] User Name for the QnA")
    qna_id:         str=Field(..., description="[Required] QnA ID for the Request")

    class Config:
        schema_extra = {
            "example": {
                "qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541"
            }
        }

class QnABatchRequest(BaseModel):
    batch_requests: list[QnARequest]


# System-level Access
class SecretQnA(BaseModel):
    # Trace Information
    qna_id:                str | None = None
    qna_traceid:           str | None = None
    qna_version:           int | None = None
    seed_qna_id:           str | None = None
    seed_qna_version:      int | None = None
    batch_order:           str | None = None
    knowledge_id:          str | None = None
    knowledge_version:     int | None = None
    document_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None
    approver_id:           str | None = None
    approver_name:         str | None = None

    # Control Information
    qna_status:            int | None = None
    qna_permission:        int | None = None  # qna access level
    qna_management:        int | None = None  # qna management level

    # QnA Information
    qna_query:             str | None = None
    qna_response:          str | None = None
    qna_citations:         list[str] | None = None
    qna_data_ids:          list[str] | None = None
    qna_query_language:    str | None = None
    qna_response_language: str | None = None

    # Tags
    qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None


"""
    QnA Filter
"""   
class QnAStringFilter(BaseModel):
    qna_id_filter:                list[str] | None = None
    qna_traceid_filter:           list[str] | None = None    
    seed_qna_id_filter:           list[str] | None = None
    batch_order_filter:           list[str] | None = None
    knowledge_id_filter:          list[str] | None = None
    document_name_filter:         list[str] | None = None

    creator_id_filter:            list[str] | None = None
    creator_name_filter:          list[str] | None = None
    approver_id_filter:           list[str] | None = None
    approver_name_filter:         list[str] | None = None

    qna_query_filter:             list[str] | None = None
    qna_response_filter:          list[str] | None = None
    qna_query_language_filter:    list[str] | None = None
    qna_response_language_filter: list[str] | None = None

class QnANumericFilter(BaseModel):
    qna_version_min:       int | None = None
    qna_version_max:       int | None = None
    seed_qna_version_min:  int | None = None
    seed_qna_version_max:  int | None = None
    knowledge_version_min: int | None = None
    knowledge_version_max: int | None = None

    qna_status_min:        int | None = None
    qna_status_max:        int | None = None 
    qna_permission_min:    int | None = None
    qna_permission_max:    int | None = None
    qna_management_min:    int | None = None
    qna_management_max:    int | None = None

class QnAListFilter(BaseModel):
    qna_tags_or:  list[str] | None = None
    qna_tags_and: list[str] | None = None    

class QnADictionaryFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None

class QnABooleanFilter(BaseModel):
    not_used_filter: bool | None = None

class QnADatetimeFilter(BaseModel):
    created_at_start:                  datetime  | None = None
    created_at_end:                    datetime  | None = None
    updated_at_start:                  datetime  | None = None
    updated_at_end:                    datetime  | None = None

class QnAByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class QnAFilter(BaseModel):
    string_filter:     QnAStringFilter     | None = None
    numeric_filter:    QnANumericFilter    | None = None
    list_filter:       QnAListFilter       | None = None
    dictionary_filter: QnADictionaryFilter | None = None
    boolean_filter:    QnABooleanFilter    | None = None
    datetime_filter:   QnADatetimeFilter   | None = None
    byte_filter:       QnAByteFilter       | None = None
    sorting:           dict={"qna_id": "asc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access QnAs
"""
class SystemQnARequest(BaseModel):
    qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:   QnAFilter=Field(..., description="[Required] QnA Filter", example=QnAFilter(
                                    string_filter=QnAStringFilter(
                                        qna_id_filter=["qna_id_1"]
                                    ),
                                    numeric_filter=QnANumericFilter(
                                        qna_status_min=1
                                    )
                                ))  

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemQnAResponse(BaseModel):
    qna_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data: list[SecretQnA]=Field(default=[], description="Filtered QnA Data")
    data_count:    int=Field(default=0, description="Count of Filtered QnA Data", example=1)


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class QnABackupRequest(BaseModel):
    qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:   QnAFilter | None = None
    backup_config: BackupConfig | None = None

class QnABackupListRequest(BaseModel):
    qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config: BackupConfig | None = None

class QnABackupListResponse(BaseModel):
    qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:    list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class QnARestoreRequest(BaseModel):
    qna_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config: RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class QnAImportRequest(BaseModel):
    qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:     IOConfig | None = None
    backup:        bool=True

class QnAExportRequest(BaseModel):
    qna_requestid:    str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:      QnAFilter | None = None
    io_config:        IOConfig | None = None
    include_datetime: bool = True

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "qna"
                },
                "include_datetime": True
            }
        }

"""" QnAServiceManager """
"""
    Request and Response for User Access Permitted QnAs
"""
# User-level Access
class QnA(BaseModel):
    # Trace Information
    qna_id:                str | None = None
    qna_traceid:           str | None = None
    qna_version:           int | None = None
    seed_qna_id:           str | None = None
    seed_qna_version:      int | None = None
    batch_order:           str | None = None
    knowledge_id:          str | None = None
    knowledge_version:     int | None = None
    document_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None
    approver_id:           str | None = None
    approver_name:         str | None = None

    # Control Information
    qna_status:            int | None = None
    qna_permission:        int | None = None  # qna access level
    qna_management:        int | None = None  # qna management level

    # QnA Information
    qna_query:             str | None = None
    qna_response:          str | None = None
    qna_citations:         list[str] | None = None
    qna_data_ids:          list[str] | None = None
    qna_query_language:    str | None = None
    qna_response_language: str | None = None

    # Tags
    qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None
    
class UserQnARequest(BaseModel):
    qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:   QnAFilter

class UserQnAResponse(BaseModel):
    qna_requestid: str
    filtered_data: list[QnA]=[]