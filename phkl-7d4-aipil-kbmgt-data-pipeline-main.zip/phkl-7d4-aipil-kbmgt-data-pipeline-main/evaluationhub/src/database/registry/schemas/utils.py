from pydantic import BaseModel, Field
from datetime import datetime, timezone

""""
    QnA General Operation
"""
class RawDocumentObject(BaseModel):
    knowledge_id:         str=Field(default="UNKNOWN", description="knowledge_id of the document")
    knowledge_languages:  list[str]=Field(default=[], description="Languages of the document")
    document_name:        str=Field(default="UNKNOWN", description="Name of the document")
    hyperlink:            str=Field(default="UNKNOWN", description="Hyperlink of the document")
    last_update_date:     str=Field(default="UNKNOWN", description="Last update date of the document")
    pil_reference_number: str=Field(default="UNKNOWN", description="PIL reference number of the document")
    translation:          str=Field(default='ORIGINAL', description="Translation notes of the citation")
    
class RawCitationObject(BaseModel):
    data_id:              str=Field(default="", description="data_id of the citation")
    knowledge_id:         str=Field(default="", description="knowledge_id of the document")
    content:              str=Field(default="", description="Content of the citation")
    source_type:          str=Field(default="UNKNOWN", description="Source type of the citation, e.g., text, image, table")
    image_table_link:     str=Field(default="", description="Image or table URL of the citation")
    page_start:           int=Field(default="UNKNOWN", description="Page start of the citation")
    page_end:             int=Field(default="UNKNOWN", description="Page end of the citation")
    langauage:            str=Field(default="en", description="Langauge of the citation")
    score:                float=Field(default=0.0, description="Retrieval Scoring")

class RawRetrievalObject(BaseModel):
    document:  RawDocumentObject=Field(default=RawDocumentObject(), description="List of DocumentObjects")
    citations: list[RawCitationObject]=Field(default=[], description="List of CitationObjects")
