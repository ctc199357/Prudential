import os
import urllib.parse
from contextlib import contextmanager

from ....settings import SETTINGS

from ....logger.log_handler import get_logger

logger = get_logger(__name__)

if SETTINGS.IMPT.FORM.upper() == "MODB":
    from mongoengine import connect, disconnect
    from pymongo.errors import ServerSelectionTimeoutError
    from ..models.io_models import IMKnowledgeDB
    
    im_model_mapper = {
        SETTINGS.IMPT.REGISTRY_TABLE: IMKnowledgeDB
    }

    if SETTINGS.IMPT.LOCA.lower() == "azure":
        # Access Database Settings
        DB_URL = '{user}:{pswd}@{host}:{port}/?{other}'.format(
            host=urllib.parse.quote_plus(SETTINGS.IMPT.HOST),  # DB host
            port=urllib.parse.quote_plus(SETTINGS.IMPT.PORT),  # DB port
            other=SETTINGS.IMPT.CONFIG.get("OTHER", ""),  # DB name
            user=urllib.parse.quote_plus(SETTINGS.IMPT.USER),  # DB user
            pswd=urllib.parse.quote_plus(SETTINGS.IMPT.PSWD)   # DB pswd
        )

    elif SETTINGS.IMPT.LOCA.lower() == "server":
        
        # Access Database Settings
        if SETTINGS.IMPT.USER and SETTINGS.IMPT.PSWD:
            DB_URL = '{user}:{pswd}@{host}:{port}/{name}'.format(
                host=urllib.parse.quote_plus(SETTINGS.IMPT.HOST),  # DB host
                port=urllib.parse.quote_plus(SETTINGS.IMPT.PORT),  # DB port
                name=urllib.parse.quote_plus(SETTINGS.IMPT.NAME),  # DB name
                user=urllib.parse.quote_plus(SETTINGS.IMPT.USER),  # DB user
                pswd=urllib.parse.quote_plus(SETTINGS.IMPT.PSWD)   # DB pswd
            )
        
        else:
            DB_URL = '{host}:{port}/{name}'.format(
                host=urllib.parse.quote_plus(SETTINGS.IMPT.HOST),  # DB host
                port=urllib.parse.quote_plus(SETTINGS.IMPT.PORT),  # DB port
                name=urllib.parse.quote_plus(SETTINGS.IMPT.NAME)   # DB name
            )
    
    DATABASE_URL = f"mongodb://{DB_URL}"

    # Test DB Connection
    try:
        connect(SETTINGS.IMPT.NAME, alias=f'import_{SETTINGS.IMPT.USER}', host=DATABASE_URL)
        logger.info(f"Connected : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.IMPT.NAME}> Database")

    except ServerSelectionTimeoutError:
        err_msg = f"DB Connection Timeout Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.IMPT.NAME}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)
    
    # Handle any other exceptions that might occur
    except:
        err_msg = f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.IMPT.NAME}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)

    # DB via Function Call
    @contextmanager
    def get_im_db_func(collection_name: str):
        ModelDB = im_model_mapper.get(collection_name, None)
        if not ModelDB:
            raise Exception("MongoDB Error : Invalid Collection Name")
        
        try:
            session = ModelDB._get_db().client.start_session()
            session.start_transaction()
            yield session
            session.commit_transaction()

        except Exception as e:
            session.abort_transaction()  # Abort the transaction on error
            raise e
        
        finally:
            session.end_session()

    # DB via API Call
    @contextmanager
    def get_im_db_api(collection_name: str):
        ModelDB = im_model_mapper.get(collection_name, None)
        if not ModelDB:
            raise Exception("MongoDB Error : Invalid Collection Name")
        
        try:
            session = ModelDB._get_db().client.start_session()
            session.start_transaction()
            yield session
            session.commit_transaction()

        except Exception as e:
            session.abort_transaction()  # Abort the transaction on error
            raise e
        
        finally:
            session.end_session()

else:
    err_msg = f"Unknown DB Error : <{SETTINGS.IMPT.NAME}> Database"
    logger.error(err_msg)
    raise Exception(err_msg)


if SETTINGS.EXPT.FORM.upper() == "MODB":
    from mongoengine import connect, disconnect
    from pymongo.errors import ServerSelectionTimeoutError
    from ..models.io_models import EXKnowledgeDB
    
    ex_model_mapper = {
        SETTINGS.EXPT.REGISTRY_TABLE: EXKnowledgeDB
    }

    if SETTINGS.EXPT.LOCA.lower() == "azure":
        # Access Database Settings
        DB_URL = '{user}:{pswd}@{host}:{port}/?{other}'.format(
            host=urllib.parse.quote_plus(SETTINGS.EXPT.HOST),  # DB host
            port=urllib.parse.quote_plus(SETTINGS.EXPT.PORT),  # DB port
            other=SETTINGS.EXPT.CONFIG.get("OTHER", ""),  # DB name
            user=urllib.parse.quote_plus(SETTINGS.EXPT.USER),  # DB user
            pswd=urllib.parse.quote_plus(SETTINGS.EXPT.PSWD)   # DB pswd
        )

    elif SETTINGS.EXPT.LOCA.lower() == "server":
        
        # Access Database Settings
        if SETTINGS.EXPT.USER and SETTINGS.EXPT.PSWD:
            DB_URL = '{user}:{pswd}@{host}:{port}/{name}'.format(
                host=urllib.parse.quote_plus(SETTINGS.EXPT.HOST),  # DB host
                port=urllib.parse.quote_plus(SETTINGS.EXPT.PORT),  # DB port
                name=urllib.parse.quote_plus(SETTINGS.EXPT.NAME),  # DB name
                user=urllib.parse.quote_plus(SETTINGS.EXPT.USER),  # DB user
                pswd=urllib.parse.quote_plus(SETTINGS.EXPT.PSWD)   # DB pswd
            )
        
        else:
            DB_URL = '{host}:{port}/{name}'.format(
                host=urllib.parse.quote_plus(SETTINGS.EXPT.HOST),  # DB host
                port=urllib.parse.quote_plus(SETTINGS.EXPT.PORT),  # DB port
                name=urllib.parse.quote_plus(SETTINGS.EXPT.NAME)   # DB name
            )
    
    DATABASE_URL = f"mongodb://{DB_URL}"

    # Test DB Connection
    try:
        connect(SETTINGS.EXPT.NAME, alias=f'export_{SETTINGS.EXPT.USER}', host=DATABASE_URL)
        logger.info(f"Connected : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.EXPT.NAME}> Database")

    except ServerSelectionTimeoutError:
        err_msg = f"DB Connection Timeout Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.EXPT.NAME}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)
    
    # Handle any other exceptions that might occur
    except:
        err_msg = f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.EXPT.NAME}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)

    # DB via Function Call
    @contextmanager
    def get_ex_db_func(collection_name: str):
        ModelDB = ex_model_mapper.get(collection_name, None)
        if not ModelDB:
            raise Exception("MongoDB Error : Invalid Collection Name")
        
        try:
            session = ModelDB._get_db().client.start_session()
            session.start_transaction()
            yield session
            session.commit_transaction()

        except Exception as e:
            session.abort_transaction()  # Abort the transaction on error
            raise e
        
        finally:
            session.end_session()

    # DB via API Call
    @contextmanager
    def get_ex_db_api(collection_name: str):
        ModelDB = ex_model_mapper.get(collection_name, None)
        if not ModelDB:
            raise Exception("MongoDB Error : Invalid Collection Name")
        
        try:
            session = ModelDB._get_db().client.start_session()
            session.start_transaction()
            yield session
            session.commit_transaction()

        except Exception as e:
            session.abort_transaction()  # Abort the transaction on error
            raise e
        
        finally:
            session.end_session()

else:
    err_msg = f"Unknown DB Error : <{SETTINGS.EXPT.NAME}> Database"
    logger.error(err_msg)
    raise Exception(err_msg)