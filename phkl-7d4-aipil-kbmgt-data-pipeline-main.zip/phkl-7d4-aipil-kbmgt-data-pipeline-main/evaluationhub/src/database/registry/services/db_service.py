"""
    DB Service Manager
"""

from ....settings import SETTINGS

from mongoengine import connect, disconnect
from pymongo.errors import ServerSelectionTimeoutError

from datetime import datetime, timezone
import inspect

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)
from ..schemas.database import (
    TableInfo,
    DBTableInfoResponse,
    DBTableRenameRequest,
    BackupDatabaseConfiguration,
    IODatabaseConfiguration
)

from ..connections.registry_connection import DATABASE_URL

from ....logger.log_handler import get_logger

logger = get_logger(__name__)

class DBManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            db_name: str=SETTINGS.DATB.NAME,
            db_host: str=DATABASE_URL
        ):
        self.db_name = db_name
        self.db_host = db_host

    def rename_table(self, request: DBTableRenameRequest) -> Response:
        org_name = request.org_name
        new_name = request.new_name
        
        try:
            client    = connect(self.db_name, host=self.db_host)
            db_client = client.get_database(self.db_name)

        except ServerSelectionTimeoutError:
            response = Response(status_code=500, detail=self.response_format.error(f"DB Connection Timeout Error : <{self.db_name}> Database"))
            logger.error(response.detail)
            return response
        
        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"DB Unexpected Error : <{self.db_name}> Database"))
            logger.error(response.detail)
            return response
            
        if org_name in db_client.list_collection_names():
            try:
                result = db_client[org_name].rename(new_name)
                response = Response(status_code=200, detail=self.response_format.ok(f"Collection Rename Success : <{SETTINGS.BASE.APP_NAME}> Completed Renaming Collection <collection_name : {org_name}> to <collection_name : {new_name}>"))
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Collection Rename Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Renaming Collection <collection_name : <collection_name : {org_name}> to <collection_name : {new_name}>"))
        else:
            response = Response(status_code=200, detail=self.response_format.ok(f"Collection Rename Completed : <{SETTINGS.BASE.APP_NAME}> Found Collection Does Not Exist. No Actions have been Taken"))
       
        return response

    def drop_table(self, table_name: str) -> Response:
        
        try:
            client    = connect(self.db_name, host=self.db_host)
            db_client = client.get_database(self.db_name)

        except ServerSelectionTimeoutError:
            response = Response(status_code=500, detail=self.response_format.error(f"DB Connection Timeout Error : <{self.db_name}> Database"))
            logger.error(response.detail)
            return response
        
        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"DB Unexpected Error : <{self.db_name}> Database"))
            logger.error(response.detail)
            return response
            
        if table_name in db_client.list_collection_names():
            try:
                result = db_client[table_name].drop()
                response = Response(status_code=200, detail=self.response_format.ok(f"Collection Drop Success : <{SETTINGS.BASE.APP_NAME}> Completed Dropping Collection <collection_name : {table_name}>"))
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Collection Drop Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Dropping Collection <collection_name : {table_name}>"))
        else:
            response = Response(status_code=200, detail=self.response_format.ok(f"Collection Drop Completed : <{SETTINGS.BASE.APP_NAME}> Found Collection Does Not Exist. No Actions have been Taken"))
       
        return response