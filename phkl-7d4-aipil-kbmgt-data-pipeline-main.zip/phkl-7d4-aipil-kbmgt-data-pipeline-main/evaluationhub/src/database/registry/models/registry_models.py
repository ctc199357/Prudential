import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS

if SETTINGS.DATB.FORM.upper() in ["MODB"]:
    from mongoengine import *

    # class RawDocumentObject(EmbeddedDocument):
    #     knowledge_id         = StringField(default="")
    #     knowledge_languages  = ListField(default=[])
    #     document_name        = StringField(default="")
    #     hyperlink            = StringField(default="")
    #     last_update_date     = StringField(default="")
    #     pil_reference_number = StringField(default="")
    #     translation          = StringField(default="")

    # class RawCitationObject(EmbeddedDocument):
    #     data_id          = StringField(default="") # Chunk ID
    #     knowledge_id     = StringField(default="")

    #     content          = StringField(default="") # TEXT, IMAGE, TABLE, DOCUMENT, etc.
    #     source_type      = StringField(default="") # default, image-to-text, OCR
    #     image_table_link = StringField(default="")
    #     page_start       = IntField(default=-1)
    #     page_end         = IntField(default=-1)

    #     langauage        = ListField(default=[])
    #     score            = FloatField(default=-1.0)

    # class RawRetrievalObject(EmbeddedDocument):
    #     document  = EmbeddedDocumentField(RawDocumentObject, default=RawDocumentObject())
    #     citations = EmbeddedDocumentListField(RawCitationObject, default=[])

    class SeedQnADB(Document):
        # Trace Information
        seed_qna_id                = StringField(default=lambda: str(uuid.uuid4()), unique=True)
        seed_qna_traceid           = StringField(default=lambda: str(uuid.uuid4()))
        seed_qna_version           = IntField(default=1)   # 1=original   
        batch_order                = StringField(default='')
        knowledge_id               = StringField(default='')
        knowledge_version          = IntField(default=1)   # 1=original    
        library_name_en            = StringField(default='')

        # Creator Information
        creator_id                 = StringField(default='')
        creator_name               = StringField(default='')
        approver_id                = StringField(default='system')
        approver_name              = StringField(default='system')

        # Control Information
        seed_qna_status            = IntField(default=1)
        seed_qna_permission        = IntField(default=1)   # 0=default, related to user permission
        seed_qna_management        = IntField(default=10)  # relate to management permission

        # QnA Information
        qna_query                  = StringField(default='')
        qna_response               = StringField(default='')
        # qna_citations              = EmbeddedDocumentListField(RawRetrievalObject, default=[])
        qna_citations              = ListField(default=[])
        qna_query_language         = StringField(default='')
        qna_response_language      = StringField(default='')

        # Tags
        seed_qna_tags              = ListField(default=[])

        # Time Information
        created_at                 = DateTimeField(default=datetime.now(timezone.utc))
        updated_at                 = DateTimeField(default=datetime.now(timezone.utc))

        meta = {
            'collection': SETTINGS.DATB.SEED_QNA_TABLE, 
            'indexes': [
                'seed_qna_id',
                'seed_qna_version',
                'batch_order',
                'knowledge_id',
                'knowledge_version',
                'library_name_en',
                'seed_qna_status',
                'qna_query_language',
                'qna_response_language',
                'created_at',
                'updated_at'
            ]
        }

        def to_dict(self):
            return {**self.to_mongo().to_dict()}
        
    class QnADB(Document):
        # Trace Information
        qna_id                = StringField(default=lambda: str(uuid.uuid4()), unique=True)
        qna_traceid           = StringField(default=lambda: str(uuid.uuid4()))
        qna_version           = IntField(default=1)   # 1=original   
        seed_qna_id           = StringField(default='')
        seed_qna_version      = IntField(default=1)
        batch_order           = StringField(default='')
        knowledge_id          = StringField(default='')
        knowledge_version     = IntField(default=1)   # 1=original 
        document_name         = StringField(default='')   

        # Creator Information
        creator_id            = StringField(default='')
        creator_name          = StringField(default='')
        approver_id           = StringField(default='system')
        approver_name         = StringField(default='system')

        # Control Information
        qna_status            = IntField(default=1)
        qna_permission        = IntField(default=1)   # 0=default, related to user permission
        qna_management        = IntField(default=10)  # relate to management permission

        # QnA Information
        qna_query             = StringField(default='')
        qna_response          = StringField(default='')
        # qna_citations         = EmbeddedDocumentListField(RawRetrievalObject, default=[])
        qna_citations         = ListField(default=[])
        qna_data_ids          = ListField(default=[])
        qna_query_language    = StringField(default='')
        qna_response_language = StringField(default='')

        # Tags
        qna_tags              = ListField(default=[])

        # Time Information
        created_at            = DateTimeField(default=datetime.now(timezone.utc))
        updated_at            = DateTimeField(default=datetime.now(timezone.utc))

        meta = {
            'collection': SETTINGS.DATB.QNA_TABLE, 
            'indexes': [
                'qna_id',
                'qna_version',
                'seed_qna_id',
                'seed_qna_version',
                'batch_order',
                'knowledge_id',
                'knowledge_version',
                'document_name',
                'qna_status',
                'qna_query_language',
                'qna_response_language',
                'created_at',
                'updated_at'
            ]
        }

        def to_dict(self):
            return {**self.to_mongo().to_dict()}
        
    class EvaluationDB(Document):

        # Trace Information
        evaluation_id         = StringField(default=lambda: str(uuid.uuid4()), unique=True)
        evaluation_traceid    = StringField(default=lambda: str(uuid.uuid4()))
        evaluation_version    = IntField(default=1)     # 1=original
        batch_order           = StringField(default='') # single if not batch, otherwise timestamp
        knowledge_id          = StringField(default='')
        knowledge_version     = IntField(default=1)   # 1=original  
        document_name         = StringField(default='')  
        
        # Control Information
        evaluation_status     = IntField(default=1)
        evaluation_permission = IntField(default=1)
        evaluation_management = IntField(default=1)

        # Evaluation Information
        qna_id                = StringField(default='')
        qna_query             = StringField(default='')
        qna_response          = StringField(default='')
        # qna_citations         = EmbeddedDocumentListField(RawRetrievalObject, default=[])
        qna_citations         = ListField(default=[])
        qna_data_ids          = ListField(default=[])
        qna_query_language    = StringField(default='')
        qna_response_language = StringField(default='')

        actual_response       = StringField(default='')
        # actual_citations      = EmbeddedDocumentListField(RawRetrievalObject, default=[])
        actual_citations      = ListField(default=[])
        actual_data_ids       = ListField(default=[])
        actual_language       = StringField(default='')

        # Evaluation Matrix
        similarity            = IntField(default=-1)
        relevance             = IntField(default=-1)
        groundedness          = IntField(default=-1)
        retrieval             = IntField(default=-1)
        input_tokens          = IntField(default=-1)
        output_tokens         = IntField(default=-1)
        tool_tokens           = IntField(default=-1)
        response_time         = FloatField(default=-1.0)
        
        # Statistics
        evaluation_code       = StringField(default='')
        evaluation_time       = FloatField(default=-1.0)

        # Tags
        evaluation_tags       = ListField(default=[])

        # Time Information
        created_at            = DateTimeField(default=datetime.now(timezone.utc))
        updated_at            = DateTimeField(default=datetime.now(timezone.utc))

        meta = {
            'collection': SETTINGS.DATB.EVALUATION_TABLE, 
            'indexes': [
                'evaluation_id',
                'evaluation_version',
                'batch_order',
                'knowledge_id',
                'knowledge_version',
                'document_name',
                'evaluation_status',
                'qna_id',
                'qna_query_language',
                'qna_response_language',
                'actual_language',
                'similarity',
                'relevance',
                'groundedness',
                'retrieval',
                'input_tokens',
                'output_tokens',
                'tool_tokens',
                'response_time',
                'evaluation_code',
                'evaluation_time',
                'created_at',
                'updated_at'
            ]
        }

        def to_dict(self):
            return {**self.to_mongo().to_dict()}

else:
    err_msg = f"Unknown DB Schema Error : <{SETTINGS.DATB.NAME}> Database"
    raise Exception(err_msg)