import uvicorn

from .application import application as app
from .settings import SETTINGS

def main():
    uvicorn.run(app, host=SETTINGS.BASE.APP_HOST, port=SETTINGS.BASE.APP_PORT)

if __name__ == "__main__":    
    main()