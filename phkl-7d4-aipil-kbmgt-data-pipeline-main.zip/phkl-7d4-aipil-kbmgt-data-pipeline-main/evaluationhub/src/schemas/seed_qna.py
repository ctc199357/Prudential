from pydantic import BaseModel, Field
import uuid
from typing import Literal
from datetime import datetime, timezone

from ..database.registry.schemas.seed_qna import *

from ..settings import SETTINGS

""" 
    Seed QnA Generation Request and Response
"""
class SeedQnASyncRequest(BaseModel):
    qna_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()), description="Unique ID for the QnA request")
    qna_sync_origin: str=Field(default=SETTINGS.EVAL.SEED_QNA_SYNC_FILE_ORIGIN, description="Origin of the QnA sync, LOCAL, BLOB")
    qna_sync_path:   str=Field(default=SETTINGS.EVAL.SEED_QNA_SYNC_FILE_PATH, description="Path for QnA sync")
    batch_order:     str=Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d-%H-%M-%S")) # single if not batch, otherwise timestamp
    request_at:      datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="Request time in UTC format")

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "bcbf6b6c-1d4b-4c8f-bd7b-2c7d8c8a2a7f",
                "qna_sync_path": "/path/to/qna/sync/Full List of FAQ for AI-PIL_ by Library.xlsx",
                "request_at": "2023-10-01T12:00:00Z"
            }
        }

class SeedQnASyncResponse(BaseModel):
    qna_requestid: str=Field(..., description="Unique ID for the QnA request")
    succeess_flag: bool=Field(default=False, description="Success flag for the QnA sync")
    reason:        str=Field(default='UNKNOWN', description="Reason for the success or failure of the QnA sync")
    response_at:   datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="Response time in UTC format")

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "bcbf6b6c-1d4b-4c8f-bd7b-2c7d8c8a2a7f",
                "succeess_flag": True,
                "reason": "SUCCESS",
                "response_at": "2023-10-01T12:00:00Z"
            }
        }
