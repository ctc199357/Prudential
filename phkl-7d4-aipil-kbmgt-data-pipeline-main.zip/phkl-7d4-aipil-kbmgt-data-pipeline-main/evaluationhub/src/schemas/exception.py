#%%
from fastapi import Request, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Annotated, Optional, Mapping
from fastapi.responses import JSONResponse
from starlette.status import HTTP_422_UNPROCESSABLE_ENTITY
from fastapi.exceptions import RequestValidationError
import json

class ExceptionFormat(BaseModel):

    error: str | None = None
    code:  str | None = None
    param: str | None = None
    type:  str | None = None
    

#%%
async def http_exception_handler(request: Request, exec: HTTPException):
    
    body = await request.json()

    res = ExceptionFormat(
        code = str(exec.status_code),
        error = str(exec.detail),
        type = json.dumps(body),
        param = json.dumps(dict(request.headers))
    )

    return JSONResponse(
        status_code = exec.status_code,
        content = res.__dict__
    )

async def validation_exception_handler(request: Request, exec: RequestValidationError):
    # Read the request body
    body = await request.json()
    
    res = ExceptionFormat(
        code = '422',
        error = str(exec.errors()),
        type = json.dumps(body),
        param = json.dumps(dict(request.headers))
    )
    return JSONResponse(
        status_code = HTTP_422_UNPROCESSABLE_ENTITY,
        content = res.__dict__
    )
#%%