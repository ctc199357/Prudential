from pydantic import BaseModel
from uuid import UUID
from datetime import datetime
import json

class Health(BaseModel):
    app_name:       str
    status_code:    int=200
    api_call:       str='ACTIVE'
    function_call:  str='ACTIVE'
    

"""
    General System Response
"""
class Response(BaseModel):
    status_code: int
    detail:      str

class ResponseFormatter(BaseModel):
    prefix:  str=''
    suffix:  str=''

    def ok(self, content: str) -> str:
        response = content
        if self.prefix:
            response += f" | {self.prefix}"
        return response

    def error(self, content: str, error: str='') -> str:
        response = content
        if self.prefix:
            response += f" | {self.prefix}"

        if self.suffix:
            response += f" | {self.suffix}"

        if error:
            response += f" | {error}"

        return response


""" 
    Stream Response
"""
class StreamResponse(BaseModel):
    stream_type: str
    status_code: int
    process:     str
    content:     str | dict


""" 
    JSON Response Encoder 
"""
class ComplexEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        elif isinstance(obj, UUID):
            return obj.hex
        return json.JSONEncoder.default(self, obj)