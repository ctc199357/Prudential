from pydantic import BaseModel, Field 
import uuid
from datetime import datetime, timezone
from fastapi import UploadFile
from typing import List, Any, Dict, Optional

from ..job.schemas.job import *

class PipelineStatus(BaseModel):
    job_success:  bool=Field(default=False, description="Job Success Flag")
    job_complete: bool=Field(default=False, description="Job Complete Flag")
    job_stage:    str=Field(default='', description="Job Stage")
    job_reason:   str=Field(default='', description="Job Fail Reason")
    
    processed_at: Optional[datetime]=Field(default=None)
    completed_at: Optional[datetime]=Field(default=None)

class PipelineResponse(BaseModel):
    pipeline_info: list[JobCreate]=Field(default=[], description="List of PipelineStatus Indicating SUCCESS or FAIL")
