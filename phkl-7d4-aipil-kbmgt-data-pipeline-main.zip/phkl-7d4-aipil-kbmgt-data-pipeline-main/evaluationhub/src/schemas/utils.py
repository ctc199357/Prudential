from pydantic import BaseModel, Field
import uuid
from typing import Literal
from datetime import datetime, timezone

""" 
    KnowledgeHub Query
"""
# System-level Access
class SecretVector(BaseModel):
    # Trace Information
    data_id:        str | None = None
    data_traceid:   str | None = None
    data_version:   int | None = None

    # Category Information
    data_type:      str | None = None
    content_type:   str | None = None
    data_url:       str | None = None

    # Control Information
    data_status:    int | None = None

    # Specification
    raw_data:       str | None = None
    processed_data: list[float] | None = None
    data_dimension: int | None = None
    data_length:    int | None = None

    coord_x1:       float | None = None
    coord_x2:       float | None = None
    coord_y1:       float | None = None
    coord_y2:       float | None = None

    page_start:     int | None = None
    page_end:       int | None = None
    line_start:     int | None = None
    line_end:       int | None = None
    seq_no:         int | None = None

    # Dependent
    knowledge_id:   str | None = None
    node_id:        str | None = None
    node_type:      str | None = None

    # Tags
    data_languages: list[str] | None = None
    data_keywords:  list[str] | None = None
    data_tags:      list[str] | None = None

    # Time Information
    created_at:     datetime | None = None
    updated_at:     datetime | None = None

class KnowledgeVectorRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str | None = None
    user_name:      str | None = None
    knowledge_id:   str
    wiping:         bool=False

class KnowledgeVectorReadResponse(BaseModel):
    knowledge_id:     str
    filtered_vectors: list[SecretVector]=[]
    vector_no:        int=0



# Knowledge CRUD
class KnowledgeUpdate(BaseModel):
    # Trace Information
    knowledge_id:                str | None = None
    knowledge_traceid:           str | None = None
    knowledge_name:              str | None = None
    knowledge_version:           int | None = None
    knowledge_ingestion_stage:   str | None = None
    knowledge_ingestion_reason:  str | None = None
    knowledge_processing_stage:  str | None = None
    knowledge_processing_reason: str | None = None
    batch_order:                 str | None = None

    # Creator Information
    creator_id:                  str | None = None
    creator_name:                str | None = None
    approver_id:                 str | None = None
    approver_name:               str | None = None

    # PIL Information
    library_name_en:             str | None = None
    library_name_tc:             str | None = None
    category_name_en:            str | None = None
    category_name_tc:            str | None = None
    title_name_en:               str | None = None  
    title_name_tc:               str | None = None
    item_type:                   str | None = None
    item_url:                    str | None = None
    item_status:                 str | None = None
    document_id:                 str | None = None
    file_name:                   str | None = None
    file_description:            str | None = None
    file_created_datetime:       datetime | None = None
    file_last_modified_datetime: datetime | None = None
    group_id:                    list[str] | None = None
    file_sync_up_url:            str | None = None
    library_id:                  str | None = None
    category_id:                 str | None = None
    reference_start_date:        datetime | None = None
    reference_end_date:          datetime | None = None

    updated_by:                  str | None = None
    retention_at:                datetime | None = None
    pil_active_status:           str | None = None

    # Category Information
    knowledge_group:             str | None = None
    knowledge_type:              str | None = None
    knowledge_location:          str | None = None
    storage_type:                str | None = None
    storage_type_origin:         str | None = None
    storage_provider:            str | None = None
    storage_provider_origin:     str | None = None
    storage_directory:           str | None = None
    storage_directory_origin:    str | None = None
    storage_secrets:             dict | None = None
    storage_secrets_origin:      dict | None = None

    # Control Information
    knowledge_status:            int | None = None
    knowledge_permission:        int | None = None
    knowledge_management:        int | None = None

    # Configuration
    knowledge_vectorstorage:     str  | None = None
    knowledge_vectorlocation:    str  | None = None
    knowledge_vectorinfo:        dict | None = None
    knowledge_graphstorage:      str  | None = None
    knowledge_graphlocation:     str  | None = None
    knowledge_graphinfo:         dict | None = None
    knowledge_searchstorage:     dict | None = None
    knowledge_searchinfo:        dict | None = None
    knowledge_secrets:           dict | None = None
    knowledge_record:            bool | None = None
    knowledge_key:               str  | None = None

    # Specification
    knowledge_confidence:        float | None = None
    knowledge_filename:          str   | None = None
    knowledge_fileextension:     str   | None = None
    knowledge_filesize:          float | None = None
    knowledge_description:       str   | None = None

    # Statistics
    processing_time:             float | None = None
    total_input_tokens:          int   | None = None
    total_output_tokens:         int   | None = None
    total_tool_tokens:           int   | None = None

    # Dependices
    knowledgeinput_id:           str  | None = None
    prepknow_id:                 str  | None = None

    # Tags
    knowledge_keywords:          list[str] | None = None
    knowledge_searchstorages:    list[str] | None = None
    knowledge_sources:           list[str] | None = None
    knowledge_sourcetypes:       list[str] | None = None
    knowledge_contenttypes:      list[str] | None = None
    knowledge_cats:              list[str] | None = None
    knowledge_languages:         list[str] | None = None
    knowledge_tags:              list[str] | None = None
    user_groups:                 list[str] | None = None
    agent_groups:                list[str] | None = None

    # Evaluation Results
    average_groundedness:        float | None = None
    average_relevance:           float | None = None
    average_retrieval:           float | None = None
    average_similarity:          float | None = None

    # Time Information
    knowledge_issue_date:        datetime | None = None
    knowledge_effective_from:    datetime | None = None
    knowledge_effective_to:      datetime | None = None

    created_at:                  datetime | None = None
    updated_at:                  datetime | None = None


class KnowledgeUpdateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Knowledge")
    user_name:      str=Field(default="", description="[Optional] User Name for the Knowledge")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Knowledge")
    knowledge_id:   str=Field(..., description="[Required] Knowledge ID for the Update")
    update_data:    KnowledgeUpdate=Field(..., description="[Required] Knowledge Data for the Update", example=KnowledgeUpdate(
                                        knowledge_ingestion_stage="Ingested",
                                        knowledge_processing_stage="Ingest Done",
                                        library_name_en="Test Library",
                                        category_name_en="Test Category",
                                        title_name_en="Test Title",
                                        item_type="Test Type",
                                        item_url="https://example.com/test.pdf",
                                        item_status="Active",
                                        file_name="test.pdf",
                                        file_description="Test File Description",
                                        file_created_datetime=datetime.now(timezone.utc),
                                        file_last_modified_datetime=datetime.now(timezone.utc),
                                    ))
    overwrite:      bool=Field(default=False, description="[Optional] Overwrite Flag for the Update") # Overwrite Flag for the Update
    


# System-level Access
class SecretKnowledge(BaseModel):
    # Trace Information
    knowledge_id:                str | None = None
    knowledge_traceid:           str | None = None
    knowledge_name:              str | None = None
    knowledge_version:           int | None = None
    knowledge_ingestion_stage:   str | None = None
    knowledge_ingestion_reason:  str | None = None
    knowledge_processing_stage:  str | None = None
    knowledge_processing_reason: str | None = None
    batch_order:                 str | None = None

    # Creator Information
    creator_id:                  str | None = None
    creator_name:                str | None = None
    approver_id:                 str | None = None
    approver_name:               str | None = None

    # PIL Information
    library_name_en:             str | None = None
    library_name_tc:             str | None = None
    category_name_en:            str | None = None
    category_name_tc:            str | None = None
    title_name_en:               str | None = None  
    title_name_tc:               str | None = None
    item_type:                   str | None = None
    item_url:                    str | None = None
    item_status:                 str | None = None
    document_id:                 str | None = None
    file_name:                   str | None = None
    file_description:            str | None = None
    file_created_datetime:       datetime | None = None
    file_last_modified_datetime: datetime | None = None
    group_id:                    list[str] | None = None
    file_sync_up_url:            str | None = None
    library_id:                  str | None = None
    category_id:                 str | None = None
    reference_start_date:        datetime | None = None
    reference_end_date:          datetime | None = None

    updated_by:                  str | None = None
    retention_at:                datetime | None = None
    pil_active_status:           str | None = None

    # Category Information
    knowledge_group:             str | None = None
    knowledge_type:              str | None = None
    knowledge_location:          str | None = None
    storage_type:                str | None = None
    storage_type_origin:         str | None = None
    storage_provider:            str | None = None
    storage_provider_origin:     str | None = None
    storage_directory:           str | None = None
    storage_directory_origin:    str | None = None
    storage_secrets:             dict | None = None
    storage_secrets_origin:      dict | None = None

    # Control Information
    knowledge_status:            int | None = None
    knowledge_permission:        int | None = None
    knowledge_management:        int | None = None

    # Configuration
    knowledge_vectorstorage:     str  | None = None
    knowledge_vectorlocation:    str  | None = None
    knowledge_vectorinfo:        dict | None = None
    knowledge_graphstorage:      str  | None = None
    knowledge_graphlocation:     str  | None = None
    knowledge_graphinfo:         dict | None = None
    knowledge_searchstorage:     dict | None = None
    knowledge_searchinfo:        dict | None = None
    knowledge_secrets:           dict | None = None
    knowledge_record:            bool | None = None
    knowledge_key:               str  | None = None

    # Specification
    knowledge_confidence:        float | None = None
    knowledge_filename:          str   | None = None
    knowledge_fileextension:     str   | None = None
    knowledge_filesize:          float | None = None
    knowledge_description:       str   | None = None

    # Statistics
    processing_time:             float | None = None
    total_input_tokens:          int   | None = None
    total_output_tokens:         int   | None = None
    total_tool_tokens:           int   | None = None

    # Dependices
    knowledgeinput_id:           str  | None = None
    prepknow_id:                 str  | None = None

    # Tags
    knowledge_keywords:          list[str] | None = None
    knowledge_searchstorages:    list[str] | None = None
    knowledge_sources:           list[str] | None = None
    knowledge_sourcetypes:       list[str] | None = None
    knowledge_contenttypes:      list[str] | None = None
    knowledge_cats:              list[str] | None = None
    knowledge_languages:         list[str] | None = None
    knowledge_tags:              list[str] | None = None
    user_groups:                 list[str] | None = None
    agent_groups:                list[str] | None = None

    # Evaluation Results
    average_groundedness:        float | None = None
    average_relevance:           float | None = None
    average_retrieval:           float | None = None
    average_similarity:          float | None = None

    # Time Information
    knowledge_issue_date:        datetime | None = None
    knowledge_effective_from:    datetime | None = None
    knowledge_effective_to:      datetime | None = None

    created_at:                  datetime | None = None
    updated_at:                  datetime | None = None

class KnowledgeStringFilter(BaseModel):
    knowledge_id_filter:              list[str] | None = None
    knowledge_traceid_filter:         list[str] | None = None
    knowledge_name_filter:            list[str] | None = None
    knowledge_ingestion_stage_filter: list[str] | None = None
    knowledge_ingestion_reason_filter:  list[str] | None = None
    knowledge_processing_stage_filter: list[str] | None = None
    knowledge_processing_reason_filter: list[str] | None = None
    batch_order_filter:               list[str] | None = None

    library_name_en_filter:           list[str] | None = None
    library_name_tc_filter:           list[str] | None = None
    category_name_en_filter:          list[str] | None = None
    category_name_tc_filter:          list[str] | None = None
    title_name_en_filter:             list[str] | None = None
    title_name_tc_filter:             list[str] | None = None
    item_type_filter:                 list[str] | None = None
    item_url_filter:                  list[str] | None = None
    item_status_filter:               list[str] | None = None
    document_id_filter:               list[str] | None = None
    file_name_filter:                 list[str] | None = None
    file_sync_up_url_filter:          list[str] | None = None
    library_id_filter:                list[str] | None = None
    category_id_filter:               list[str] | None = None

    updated_by_filter:                list[str] | None = None
    pil_active_status_filter:         list[str] | None = None

    creator_id_filter:                list[str] | None = None
    creator_name_filter:              list[str] | None = None
    approver_id_filter:               list[str] | None = None
    approver_name_filter:             list[str] | None = None

    knowledge_group_filter:           list[str] | None = None
    knowledge_type_filter:            list[str] | None = None
    knowledge_location_filter:        list[str] | None = None
    storage_type_filter:              list[str] | None = None
    storage_type_origin_filter:       list[str] | None = None
    storage_provider_filter:          list[str] | None = None
    storage_provider_origin_filter:   list[str] | None = None
    storage_directory_filter:         list[str] | None = None
    storage_directory_origin_filter:  list[str] | None = None

    knowledge_vectorstorage_filter:   list[str] | None = None
    knowledge_vectorlocation_filter:  list[str] | None = None
    knowledge_graphstorage_filter:    list[str] | None = None
    knowledge_graphlocation_filter:   list[str] | None = None
    knowledge_key_filter:             list[str] | None = None

    knowledge_filename_filter:        list[str] | None = None
    knowledge_fileextension_filter:   list[str] | None = None

    knowledgeinput_id_filter:         list[str] | None = None
    prepknow_id_filter:               list[str] | None = None

class KnowledgeNumericFilter(BaseModel):
    knowledge_version_min:    int | None = None
    knowledge_version_max:    int | None = None

    knowledge_status_min:     int | None = None
    knowledge_status_max:     int | None = None 
    knowledge_permission_min: int | None = None
    knowledge_permission_max: int | None = None
    knowledge_management_min: int | None = None
    knowledge_management_max: int | None = None

    knowledge_confidence_min: float | None = None
    knowledge_confidence_max: float | None = None
    knowledge_filesize_min:   float | None = None
    knowledge_filesize_max:   float | None = None

    processing_time_min:      float | None = None
    processing_time_max:      float | None = None
    total_input_tokens_min:   int   | None = None
    total_input_tokens_max:   int   | None = None
    total_output_tokens_min:  int   | None = None
    total_output_tokens_max:  int   | None = None
    total_tool_tokens_min:    int   | None = None
    total_tool_tokens_max:    int   | None = None

    average_groundedness_min: float | None = None
    average_groundedness_max: float | None = None
    average_relevance_min:    float | None = None
    average_relevance_max:    float | None = None
    average_retrieval_min:    float | None = None
    average_retrieval_max:    float | None = None
    average_similarity_min:   float | None = None
    average_similarity_max:   float | None = None

class KnowledgeListFilter(BaseModel):
    group_id_filter_or:           list[str] | None = None
    group_id_filter_and:          list[str] | None = None
    knowledge_keywords_or:        list[str] | None = None
    knowledge_keywords_and:       list[str] | None = None    
    knowledge_searchstorages_or:  list[str] | None = None
    knowledge_searchstorages_and: list[str] | None = None
    knowledge_sources_or:         list[str] | None = None
    knowledge_sources_and:        list[str] | None = None
    knowledge_sourcetypes_or:     list[str] | None = None
    knowledge_sourcetypes_and:    list[str] | None = None
    knowledge_contenttypes_or:    list[str] | None = None
    knowledge_contenttypes_and:   list[str] | None = None
    knowledge_cats_or:            list[str] | None = None
    knowledge_cats_and:           list[str] | None = None
    knowledge_langauges_or:       list[str] | None = None
    knowledge_langauges_and:      list[str] | None = None
    knowledge_tags_or:            list[str] | None = None
    knowledge_tags_and:           list[str] | None = None
    user_groups_or:               list[str] | None = None
    user_groups_and:              list[str] | None = None
    agent_groups_or:              list[str] | None = None
    agent_groups_and:             list[str] | None = None


class KnowledgeDictionaryFilter(BaseModel):
    storage_secrets_or:          list[str] | None = None
    storage_secrets_and:         list[str] | None = None
    storage_secrets_origin_or:   list[str] | None = None
    storage_secrets_origin_and:  list[str] | None = None

    knowledge_vectorinfo_or:     list[str] | None = None
    knowledge_vectorinfo_and:    list[str] | None = None
    knowledge_graphinfo_or:      list[str] | None = None
    knowledge_graphinfo_and:     list[str] | None = None
    knowledge_searchstorage_or:  list[str] | None = None
    knowledge_searchstorage_and: list[str] | None = None
    knowledge_searchinfo_or:     list[str] | None = None
    knowledge_searchinfo_and:    list[str] | None = None
    knowledge_secrets_or:        list[str] | None = None
    knowledge_secrets_and:       list[str] | None = None

class KnowledgeBooleanFilter(BaseModel):
    knowledge_record_filter: bool | None = None

class KnowledgeDatetimeFilter(BaseModel):
    file_created_datetime_start:       datetime | None = None
    file_created_datetime_end:         datetime | None = None
    file_last_modified_datetime_start: datetime | None = None
    file_last_modified_datetime_end:   datetime | None = None
    reference_start_date_start:        datetime | None = None
    reference_start_date_end:          datetime | None = None
    reference_end_date_start:          datetime | None = None
    reference_end_date_end:            datetime | None = None

    retention_at:                      datetime | None = None

    knowledge_issue_date_start:        datetime  | None = None
    knowledge_issue_date_end:          datetime  | None = None
    knowledge_effective_from_start:    datetime  | None = None
    knowledge_effective_from_end:      datetime  | None = None
    knowledge_effective_to_start:      datetime  | None = None
    knowledge_effective_to_end:        datetime  | None = None

    created_at_start:                  datetime  | None = None
    created_at_end:                    datetime  | None = None
    updated_at_start:                  datetime  | None = None
    updated_at_end:                    datetime  | None = None

class KnowledgeByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class KnowledgeFilter(BaseModel):
    string_filter:     KnowledgeStringFilter     | None = None
    numeric_filter:    KnowledgeNumericFilter    | None = None
    list_filter:       KnowledgeListFilter       | None = None
    dictionary_filter: KnowledgeDictionaryFilter | None = None
    boolean_filter:    KnowledgeBooleanFilter    | None = None
    datetime_filter:   KnowledgeDatetimeFilter   | None = None
    byte_filter:       KnowledgeByteFilter       | None = None
    sorting:           dict={"knowledge_id": "asc"}
    filter_no:         int=-1

class SystemKnowledgeRequest(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:         KnowledgeFilter=Field(..., description="[Required] Knowledge Filter", example=KnowledgeFilter(
                                        string_filter=KnowledgeStringFilter(
                                            knowledge_id_filter=["knowledge_id_1", "knowledge_id_2"]
                                        ),
                                        numeric_filter=KnowledgeNumericFilter(
                                            knowledge_status_min=1
                                        )
                                    ))  


class SystemKnowledgeResponse(BaseModel):
    knowledge_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data:       list[SecretKnowledge]=Field(default=[], description="Filtered Knowledge Data")
    data_count:          int=Field(default=0, description="Count of Filtered Knowledge Data", example=1)