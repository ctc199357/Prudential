from fastapi import Header
from pydantic import BaseModel, Field
from typing import Literal
import uuid
from datetime import datetime, timezone

from ..job.schemas.job import JobCreate

"""
    Onboarding Pipeline Request
"""
class OnboardingPipelineRequest(BaseModel):
    knowledge_ids: list[str]=Field(..., description="List of Knowledge IDs for Onboarding")
    process:       Literal["QNA_GENERATION", 
                        "EVALUATION", 
                        "ONBOARD", 
                        "UPDATE_QNA",
                        "UPDATE_DOCUMENT",
                        "AUTO", 
                        "FULL"]=Field(..., description="Next process of Onboarding (QNA_GENERATION for Generating QNA, EVALUTATION for Eexcuting Onboarding)")
    batch_order:   str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp

    class Config:
        schema_extra = {
            "example": {
                "knowledge_ids": ["knowledge_id_1", "knowledge_id_2", "knowledge_id_3"],
                "process": "QNA_GENERATION"
            }
        }

class PipelineResult(BaseModel):
    knowledge_id:    str=Field(default='', description="Knowledge ID for Onboarding")
    pipeline:        Literal["QNA_GENERATION", 
                        "EVALUATION", 
                        "ONBOARD", 
                        "UPDATE_QNA",
                        "UPDATE_DOCUMENT",
                        "AUTO", 
                        "FULL"]=Field(..., description="Next pipepline of Onboarding (QNA_GENERATION for Generating QNA, EVALUTATION for Eexcuting Onboarding)")
    pipeline_code:   str=Field(default="SUCCESS", description="Pipeline Code indicating SUCCESS or FAIL")
    pipeline_reason: str=Field(default="SUCCESS", description="Reason of Fail")

class OnboardingPipelineResponse(BaseModel):
    pipeline_results: list[PipelineResult]=Field(default=[], description="List of PipelineResult Indicating SUCCESS or FAIL")
    class Config:
        schema_extra = {
            "example": {
                "pipeline_results": [
                    {
                        "knowledge_id": "abc-123-244",
                        "pipeline": "QNA_GENERATION",
                        "pipeline_code": "SUCCESS",
                        "pipeline_reason": "SUCCESS"
                    }
                ]
            }
        }