from fastapi import Header
from pydantic import BaseModel, Field
from typing import Literal
import uuid
from datetime import datetime

""" 
    ChatFlow Request 
"""
class ChatHistoryItem(BaseModel):
    session_id: str = Field(description="Session ID of the chat history.", example = "123-123-123")
    role:       Literal['human', 'chatbot'] = Field(description="Role of the chat conversation. Either human or chatbot", example="human")
    content:    str = Field(description="Content of the chat history.", example="Hi, this is from hu0man.")
    unix_time:  int = Field(description="Unix timestamp of the chat history.", example = 1734408157)

class CustomField(BaseModel):
    agent_id:       str = Field(..., description = "Agent ID to verify the access right", example = 'AD11223')
    pru_force_lang: Literal["en", "zh"] = Field(..., description = "Language variable supporting Traditional Chinese (zh) and English (en)", example = 'en')

class EvaluationQuery(BaseModel):
    query:         str = Field(description="A standalone query in plaintext to generate completion.")
    rationale:     str = Field(str='', description="Raltional of passing the query request to AI-PIL")
    knowledge_ids: list[str] = Field(default=[], description="Filter for evaluation")
    chat_history:  list[ChatHistoryItem] | None = Field(default=[], description="List of chat histories to generate completion")
    custom_field:  CustomField = Field(description="custom_field to pass to AI-PIL")


class RawDocumentObject(BaseModel):
    knowledge_id:         str=Field(default="UNKNOWN", description="knowledge_id of the document")
    knowledge_languages:  list[str]=Field(default=[], description="Languages of the document")
    document_name:        str=Field(default="UNKNOWN", description="Name of the document")
    hyperlink:            str=Field(default="UNKNOWN", description="Hyperlink of the document")
    last_update_date:     str=Field(default="UNKNOWN", description="Last update date of the document")
    pil_reference_number: str=Field(default="UNKNOWN", description="PIL reference number of the document")
    translation:          str=Field(default='ORIGINAL', description="Translation notes of the citation")
    
class RawCitationObject(BaseModel):
    data_id:              str=Field(default="", description="data_id of the citation")
    knowledge_id:         str=Field(default="", description="knowledge_id of the document")
    content:              str=Field(default="", description="Content of the citation")
    source_type:          str=Field(default="UNKNOWN", description="Source type of the citation, e.g., text, image, table")
    image_table_link:     str=Field(default="", description="Image or table URL of the citation")
    page_start:           int=Field(default="UNKNOWN", description="Page start of the citation")
    page_end:             int=Field(default="UNKNOWN", description="Page end of the citation")
    langauage:            str=Field(default="en", description="Langauge of the citation")
    score:                float=Field(default=0.0, description="Retrieval Scoring")

class RawRetrievalObject(BaseModel):
    document:  RawDocumentObject=Field(default=RawDocumentObject(), description="List of RawDocumentObjects")
    citations: list[RawCitationObject]=Field(default=[], description="List of RawCitationObjects")


class EvaluationMetrics(BaseModel):
    total_input_tokens:  int=0
    total_output_tokens: int=0
    total_tool_tokens:   int=0
    response_time:       float=0.0


class EvaluationQueryResponse(BaseModel):
    id:         str = Field(
                            default_factory=lambda: str(uuid.uuid4()), 
                            description="A unique identifier for the completion",
                            example="9e7cb831-a33e-4f4b-939d-5ad26c128541"
                        )
    response:   str = Field(
                            default='Response', 
                            description="The response generated for the input query, i.e., Answer",
                            example = "hello, this is mock Q&A API."
                        )
    citations: list[RawRetrievalObject] = Field(default=[])
    metrics:   EvaluationMetrics = Field(default=EvaluationMetrics())