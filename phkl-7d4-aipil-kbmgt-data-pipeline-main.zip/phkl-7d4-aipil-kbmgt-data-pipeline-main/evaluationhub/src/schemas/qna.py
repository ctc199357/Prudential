from pydantic import BaseModel, Field
import uuid
from typing import Literal
from datetime import datetime, timezone

from ..database.registry.schemas.qna import *

from ..settings import SETTINGS

""" 
    QnA Generation Request and Response
"""
class QnAPair(BaseModel):
    qna_id:                str=Field(default_factory=lambda: str(uuid.uuid4()))
    seed_qna_id:           str=''
    knowledge_id:          str=''
    qna_query:             str=''
    qna_response:          str=''
    qna_citations:         list[RawRetrievalObject]=[]
    qna_query_language:    str=''
    qna_response_language: str=''

class QnAGenerationRequest(BaseModel):
    generation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    batch_order:          str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) # single if not batch, otherwise timestamp
    
    knowledge_id:         str=''
    category_name_en:     str=''
    
    data_input:           list[QnAPair]=[]
    unit_generation_num:  int=SETTINGS.EVAL.QNA_UNIT_GENERATION_NO
    
    save_to_db:           bool=False
    request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class QnAGenerationResponse(BaseModel):
    generation_requestid: str
    batch_order:          str
    knowledge_id:         str

    success_objects:      list[QnACreate]=[]
    fail_objects:         list[QnACreate]=[]
    
    total_qna_count:      int=0
    success_qna_count:    int=0
    fail_qna_count:       int=0

    generation_time:      float=0.0
    total_input_tokens:   int=-1
    total_output_tokens:  int=-1
    total_tool_tokens:    int=-1
    
    response_at:          datetime=Field(default_factory=lambda: datetime.now(timezone.utc))


class KnowledgeQnARequest(BaseModel):
    qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_ids: list[str]=[]
    request_at:    datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class KnowledgeQnAReadResponse(BaseModel):
    qna_requestid: str
    filtered_data: list[SecretQnA]=[]
    response_at:   datetime=Field(default_factory=lambda: datetime.now(timezone.utc))


# class QnAGenerationRequest(BaseModel):
#     generation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
#     batch_order:          str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) # single if not batch, otherwise timestamp
    
#     knowledge_id:         str=''
#     category_name_en:     str=''
#     category_name_tc:     str=''
#     document_id:          str=''
    
#     data_input:           list[QnAPair]=[]
#     unit_generation_num:  int=SETTINGS.EVAL.QNA_UNIT_GENERATION_NO
    
#     save_to_db:           bool=False
#     request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

# class QnAGenerationResponse(BaseModel):
#     generation_requestid: str
#     batch_order:          str
#     knowledge_id:         str

#     success_objects:      list[ProcessedQnAPair]=[]
#     failed_objects:       list[ProcessedQnAPair]=[]
    
#     total_seed_count:     int=0
#     success_seed_count:   int=0
#     fail_seed_count:      int=0

#     generation_time:      float=0.0
#     total_input_tokens:   int=-1
#     total_output_tokens:  int=-1
#     total_tool_tokens:    int=-1
    
#     response_at:          datetime=Field(default_factory=lambda: datetime.now(timezone.utc))