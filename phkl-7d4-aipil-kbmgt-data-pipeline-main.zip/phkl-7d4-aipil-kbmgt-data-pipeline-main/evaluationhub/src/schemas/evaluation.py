from pydantic import BaseModel, Field
import uuid
from typing import Literal
from datetime import datetime, timezone

from ..database.registry.schemas.evaluation import *
from ..database.registry.schemas.qna import QnACreate

""" 
    Evaluation Request and Response
"""
class QnAEvaluationRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    batch_order:          str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp
    knowledge_id:         str
    save_to_db:           bool=False
    request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class QnAEvaluationResponse(BaseModel):
    evaluation_requestid:     str
    batch_order:              str
    knowledge_id:             str

    success_objects:          list[EvaluationCreate]=[]
    fail_objects:             list[EvaluationCreate]=[]
    
    total_evaluation_count:   int=0
    success_evaluation_count: int=0
    fail_evaluation_count:    int=0
    
    response_at:              datetime=Field(default_factory=lambda: datetime.now(timezone.utc))


class KnowledgeEvaluationRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_ids:        list[str]=[]
    request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))


class QnAPair(BaseModel):
    qna_id:                str=Field(default_factory=lambda: str(uuid.uuid4()))
    seed_qna_id:           str=''
    knowledge_id:          str=''
    qna_query:             str=''
    qna_response:          str=''
    qna_citations:         list[RawRetrievalObject]=[]
    qna_query_language:    Literal['en', 'zh']='en'
    qna_response_language: Literal['en', 'zh']='en'

class QnAGenerationRequest(BaseModel):
    generation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    batch_order:          str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) # single if not batch, otherwise timestamp
    
    knowledge_id:         str=''
    category_name_en:     str=''
    
    data_input:           list[QnAPair]=[]
    unit_generation_num:  int=SETTINGS.EVAL.QNA_UNIT_GENERATION_NO
    
    save_to_db:           bool=False
    request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class QnAGenerationResponse(BaseModel):
    generation_requestid: str
    batch_order:          str
    knowledge_id:         str

    success_objects:      list[QnACreate]=[]
    failed_objects:       list[QnACreate]=[]
    
    total_qna_count:      int=0
    success_qna_count:    int=0
    fail_qna_count:       int=0

    generation_time:      float=0.0
    total_input_tokens:   int=-1
    total_output_tokens:  int=-1
    total_tool_tokens:    int=-1
    
    response_at:          datetime=Field(default_factory=lambda: datetime.now(timezone.utc))



class EvaluationMetrics(BaseModel):
    groundedness:    int | None = -1
    retrieval:       int | None = -1
    similarity:      int | None = -1
    relevance:       int | None = -1
    input_tokens:    int | None = -1
    output_tokens:   int | None = -1
    tool_tokens:     int | None = -1
    response_time:   float | None = -1
    evaluation_time: float | None = -1

class EvaluationQnAPair(BaseModel):
    seed_qna_id:           str=Field(default_factory=lambda: str(uuid.uuid4()))
    qna_id:                str=''
    knowledge_id:          str=''
    qna_query:             str=''
    qna_response:          str=''
    qna_citations:         list[str]=[]
    
    qna_query_language:    Literal['en', 'zh']='en'
    qna_response_language: Literal['en', 'zh']='en'

class EvaluationResult(BaseModel):
    evaluation_id:         str=Field(default_factory=lambda: str(uuid.uuid4()))
    evaluation_code:       str | None = 'Failed to Call ChatflowAPI'

    actual_response:       str=''
    actual_citations:      list[str]=[]
    actual_document_name:  list[str]=[]

    actual_language:       str=''
    evaluation_source:     EvaluationQnAPair=EvaluationQnAPair()
    evaluation_metrics:    EvaluationMetrics=EvaluationMetrics()

class KnowledgeEvaluationResult(BaseModel):
    knowledge_id:       str=''
    evaluation_results: list[EvaluationResult]=[]
    evaluation_count:   int=0
    evalution_time:     float=0.0

class ChatflowEvaluationRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    batch_order:          str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp
    knowledge_id:         str=''
    data_input:           list[EvaluationQnAPair]=[]
    request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class ChatflowEvaluationResponse(BaseModel):
    evaluation_requestid:  str
    batch_order:           str
    knowledge_id:          str

    evaluation_results:    list[EvaluationResult] = []
    total_no:              int=0
    total_evaluation_time: float=0.0
    response_at:           datetime = datetime.now(timezone.utc)

