from fastapi import Header, Body, Depends, HTTPException,Request

from .settings import SETTINGS

from .schemas.format import Response
# from .schemas.chatflow import CommonHeaders

from .schemas.exception import ExceptionFormat, http_exception_handler

from azure.storage.blob import BlobClient, BlobServiceClient, ContentSettings

from .logger.log_handler import get_logger

logger = get_logger(__name__)

# Router Response Handler
def router_response_handler(response: Response, api_call: bool):
    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
        if api_call == True:
            raise HTTPException(status_code=response.status_code, detail=response.detail)
        else:
            raise Exception(response.detail)
        
async def router_response_exception_handler(request: Request, exec: HTTPException, api_call: bool):
    if exec.status_code >= SETTINGS.STAT.SUCC_CODE_END:
        if api_call:
            return await http_exception_handler(request, exec)
        else:
            raise Exception(exec.detail)
    return None  # Or handle other cases as needed


# async def get_common_headers(
#     content_type: str = Header(None, alias="Content-Type"),
#     ocp_apim_subscription_key: str = Header(..., alias="Ocp-Apim-Subscription-Key"),
#     user_agent: str = Header(None, alias="User-Agent"),
#     accept: str = Header(None, alias="Accept"),
#     accept_encoding: str = Header(None, alias="Accept-Encoding"),
#     connection: str = Header(None, alias="Connection"),
# ) -> CommonHeaders:
#     return CommonHeaders(
#         content_type=content_type,
#         ocp_apim_subscription_key=ocp_apim_subscription_key,
#         user_agent=user_agent,
#         accept=accept,
#         accept_encoding=accept_encoding,
#         connection=connection,
#     )
