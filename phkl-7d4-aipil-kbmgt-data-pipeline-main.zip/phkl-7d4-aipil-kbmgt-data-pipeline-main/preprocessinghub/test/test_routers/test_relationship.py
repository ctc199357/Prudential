import sys
import os
import json
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
# sys.path.append(os.getcwd())
from preprocessinghub.src.routers.request import request_direct_exec_relationship
from preprocessinghub.src.schemas.preptool import (
    KnowDataObject,
)
from preprocessinghub.src.schemas.graph import (
    RelationshipExtractRequest,
)

with open("response_sample.json", "r", encoding="utf-8") as sample:
    data = json.load(sample)
success_data = []
index = 0
for obj in data["layout_success_objects"]["text"]:
    index+=1
    if index < 6:
        obj["knowledge_id"]="cccccccccccc"
        success_data.append(KnowDataObject(**obj))

request = RelationshipExtractRequest(data_input=success_data)

def main():
    response = request_direct_exec_relationship(request=request, api_call=False)
    print("success: ", response)


if __name__ == '__main__':
    main()
