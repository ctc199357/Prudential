from pydantic import BaseModel, Field
from typing import Any
from datetime import datetime, timezone
import uuid

from ..schemas.prepmedia import KnowDataObject, SecretPrepTool

class OCRRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    preptool:           SecretPrepTool=SecretPrepTool()
    data_input:         list[KnowDataObject] = []
    request_at:         datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class OCRResponse(BaseModel):
    preptool_requestid:     str=''

    preptool_time:          float=0.0
    preptool_input_tokens:  int=0  # For Azure Vision, this could represent number of images
    preptool_output_tokens: int=0  # For Azure Vision, this could represent number of text lines
    preptool_tool_tokens:   int=0
    preptool_config:        dict=dict()

    success_objects:        list[KnowDataObject]=[]
    fail_objects:           list[KnowDataObject]=[]

    total_no:               int=0
    success_no:             int=0
    fail_no:                int=0

    response_at:            datetime | None = None