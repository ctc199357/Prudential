from pydantic import BaseModel, Field
from typing import Any
from datetime import datetime, timezone
import uuid

from .utils import PrepKnowInput

from ..schemas.prepmedia import KnowDataObject, KnowGraphObject
from ..schemas.preptool  import SecretPrepTool

class GenAIRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    preptool:           SecretPrepTool=SecretPrepTool()
    data_input:         list[KnowDataObject] = []
    request_at:         datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class GenAIResponse(BaseModel):
    preptool_requestid:     str=''

    preptool_time:          float=0.0
    preptool_input_tokens:  int=0
    preptool_output_tokens: int=0
    preptool_tool_tokens:   int=0
    preptool_config:        dict=dict()

    success_objects:        list[KnowDataObject]=[]
    fail_objects:           list[KnowDataObject]=[]

    total_no:               int=0
    success_no:             int=0
    fail_no:                int=0

    response_at:            datetime | None = None

class GenAIRelationshipResponse(BaseModel):
    preptool_requestid:     str=''

    preptool_time:          float=0.0
    preptool_input_tokens:  int=0
    preptool_output_tokens: int=0
    preptool_tool_tokens:   int=0
    preptool_config:        dict=dict()

    success_objects:        list[KnowGraphObject]=[]
    fail_objects:           list[KnowGraphObject]=[]

    total_no:               int=0
    success_no:             int=0
    fail_no:                int=0

    response_at:            datetime | None = None