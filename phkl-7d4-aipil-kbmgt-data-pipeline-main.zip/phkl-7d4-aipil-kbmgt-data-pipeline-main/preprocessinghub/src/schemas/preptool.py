from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from ..database.registry.schemas.preptool import *

"""
    I/O Object for Preprocessing
"""
class KnowDataObject(BaseModel):
    # Trace Information
    data_id:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_version:   int=1

    # Category Information
    data_type:      str='' # TEXT, TITLE, IMAGE, TABLE, DOCUMENT, etc.
    content_type:   str='default' # default, image-to-text, OCR
    data_url:       str='' # Image URL, Table URL

    # Control Information
    data_status:    int=1

    # Specification
    raw_data:       str='' # Raw Text, Image Description, Text on Image, etc.
    processed_data: list[float]=[] # vector
    data_dimension: int=-1
    data_length:    int=0

    coord_x1:       float=-1.0
    coord_x2:       float=-1.0
    coord_y1:       float=-1.0
    coord_y2:       float=-1.0

    page_start:     int=-1
    page_end:       int=-1
    line_start:     int=-1
    line_end:       int=-1
    seq_no:         int=-1

    # Dependent
    knowledge_id:   str='' # Map to Original Knowledge
    node_id:        str=''
    node_type:      str=''

    # Tags
    data_languages: list[str]=[]
    data_keywords:  list[str]=[]
    data_tags:      list[str]=[]

    # Time Information
    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class EdgeCreate(BaseModel):
    edge_id:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    edge_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    edge_version:   int=1
    edge_status:    int=1

    updated_by:     str='system'

    source_node_id: str
    target_node_id: str
    edge_type:      str
    edge_cluster:   str='default'
    edge_category:  str='default'
    edge_name:      str=''
    edge_strength:  float=-1.0

    knowledge_id:   str=''
    
    edge_tags:      list[str]=[]

    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class NodeCreate(BaseModel):
    # Trace Information
    node_id:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    node_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    node_version:   int=1
    node_status:    int=1
    
    # Control Information
    updated_by:     str='system'

    # Specification
    node_sequence:  int=-1
    node_type:      str='chunk'
    node_cluster:   str='default'
    node_category:  str='default'
    node_name:      str=''

    # Statistics
    node_indegree:  int=0
    node_outdegree: int=0

    # Chunkg Trace Information
    data_id:        str=''
    data_traceid:   str=''
    data_version:   int=1

    # Chunk Category Information
    data_type:      str='' # TEXT, IMAGE, TABLE, DOCUMENT, etc.
    content_type:   str=''

    # Chunk Tags
    data_languages: list[str]=[]
    data_keywords:  list[str]=[]

    # Dependent
    knowledge_id:   str='' # Map to Original Knowledge

    # Tags
    node_tags:      list[str]=[]

    # Time Information
    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class KnowGraphObject(BaseModel):
    nodes: list[NodeCreate]=[]
    edges: list[EdgeCreate]=[]


class KnowRelationshipObject(BaseModel):
    # Trace Information
    data_id:       str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_version:   int=1

    # Category Information
    data_type:      str='' # TEXT, IMAGE, TABLE, DOCUMENT, etc.

    # Control Information
    data_status:    int=1

    # Dependent
    knowledge_id:   str='' # Map to Original Knowledge
    node_id:        str=''
    node_type:      str=''
    node_name:      str=''

    # Relation
    relationship:    list[dict]=[] # [{target: str, relationship: str}]

    # Time Information
    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

"""
    Request and Response for PrepTool
"""
class PrepToolMetric(BaseModel):
    preptool_id:               str='custom'
    preptool_requestid:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    preptool_pipeline_id:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    preptool_pipeline_traceid: str=Field(default_factory=lambda: str(uuid.uuid4()))

    preptool_code:             str=''
    preptool_reason:           str='DEFAULT'

    # PrepTool Metrics
    preptool_time:             float=0.0
    preptool_input_tokens:     int=0
    preptool_output_tokens:    int=0
    preptool_tool_tokens:      int=0
    preptool_config:           dict=dict()

    preptool_request_at:       datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    preptool_response_at:      datetime | None = None

class PrepToolPipelineRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_requestid:     str | None = None
    user_id:            str | None = None

    data_input:         list[KnowDataObject]=[]
    preptool:           SecretPrepTool | None = None 

    request_at:         datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PrepToolPipelineResponse(BaseModel):
    preptool_requestid:       str
    
    preptool_pipeline_code:   str=''
    preptool_pipeline_reason: str='DEFAULT'

    preptool_output:          list[KnowDataObject]=[]
    preptool_relationship:    KnowGraphObject=KnowGraphObject()
    preptool_metric:          PrepToolMetric=PrepToolMetric()
    
    request_at:               datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    response_at:              datetime | None = None
