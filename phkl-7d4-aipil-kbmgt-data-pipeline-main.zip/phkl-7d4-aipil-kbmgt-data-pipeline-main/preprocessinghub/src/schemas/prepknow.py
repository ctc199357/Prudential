from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from ..settings import SETTINGS

from ..database.registry.schemas.prepknow import *

from ..schemas.prepmedia import SecretPrepMedia, PrepMediaMetric, PrepKnowMedia, SecretPrepTool, KnowDataObject

"""
    Request and Response for KnowledgePreprocessing
"""
class PrepKnowCustomConfiguration(BaseModel):
    # Override Stored Configuration
    prepknow:             SecretPrepKnow  | None = None
    prepmedia:            SecretPrepMedia | None = None
    preptool:             SecretPrepTool  | None = None
    encrypt_knowledge:    str  | None = None

class PrepKnowInitRequest(BaseModel):
    prepknow_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_requestid:     str | None = None
    user_id:            str | None = None
    prepknow_id:        str=''
    custom_config:      PrepKnowCustomConfiguration | None = None

class PrepKnowInitResponse(BaseModel):
    prepknow_requestid: str
    custom_config:      PrepKnowCustomConfiguration | None = None
    prepknow:           SecretPrepKnow | None = None
    prepknow_medias:    list[PrepKnowMedia] = []

    prepknow_init_time: float=0.0

### TODO: Add Resume
class PrepKnowPipelineResume(BaseModel):
    prepknow_pipeline_id:      str
    prepknow_pipeline_traceid: str
    prepknow_pipeline_turn:    int
    prepknow_pipeline_retry:   int

class PrepKnowTermination(BaseModel):
    max_prepknow_turn:       int   | None = None
    max_prepknow_retry:      int   | None = None
    max_prepknow_turn_retry: int   | None = None
    timeout:                 float | None = None
    code:                    str   | None = None

class SystemTermination(BaseModel):
    max_prepknow_turn:       int   | None = None
    max_prepknow_retry:      int   | None = None
    max_prepknow_turn_retry: int   | None = None
    timeout:                 float | None = None
    code:                    str   | None = None

class PrepKnowInput(BaseModel):
    # Trace Information
    knowledge_id:             str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_name:           str=''

    # Creator Information
    creator_id:               str=''
    creator_name:             str=''

    # Category Information
    storage_type:             str='' # Storage Type of Knowledge
    storage_provider:         str='' # Storage Provider of Knowledge
    storage_directory:        str='' # Local File Path
    storage_directory_origin: str='' # Url
    storage_secrets:          dict=dict() # Access Secrets

    # Configuration
    knowledge_vectorstorage:  str=''
    knowledge_vectorlocation: str=''
    knowledge_vectorinfo:     dict=dict()
    knowledge_searchstorage:  dict=dict()
    knowledge_searchinfo:     dict=dict()
    knowledge_secrets:        dict=dict()

    # Specification
    knowledge_description:    str=''

class PrepKnowOutput(BaseModel):
    know_data: list[KnowDataObject]=[]

class PrepKnowMetric(BaseModel):
    prepknow_requestid:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_traceid:          str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_id:               str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_pipeline_id:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_pipeline_traceid: str=Field(default_factory=lambda: str(uuid.uuid4()))

    prepknow_code:             str=''
    prepknow_reason:           str='FAIL'

    # PrepKnow Metrics
    prepknow_request_at:       datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    prepknow_response_at:      datetime | None = None
    prepknow_turn_no:          int=1
    prepknow_retry_no:         int=0
    prepknow_time:             float=0.0
    
    prepknow_input_tokens:     int=0
    prepknow_output_tokens:    int=0
    prepknow_tool_tokens:      int=0

    # PrepMedia Metrics
    prepmedia_metrics:         list[PrepMediaMetric]=[]

class PrepKnowPipelineRecord(BaseModel):
    prepknow_pipeline_termination: bool=True
    prepknow_pipeline_code:        str=''
    prepknow_pipeline_completion:  bool=False
    prepknow_pipeline_reason:      str='DEFAULT'

    prepknow_output:               PrepKnowOutput=PrepKnowOutput()
    prepknow_metric:               PrepKnowMetric=PrepKnowMetric()
    
    request_at:                    datetime | None = None
    response_at:                   datetime | None = None

class PrepKnowPipeline(BaseModel):
    # User Request Info
    user_requestid:                str | None = None
    user_id:                       str | None = None

    # PrepKnow Request Info
    prepknow_requestid:            str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_id:                   str=Field(default_factory=lambda: str(uuid.uuid4()))
    
    # Pipeline Info
    prepknow_pipeline_id:          str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_pipeline_traceid:     str=Field(default_factory=lambda: str(uuid.uuid4()))

    # Individual Pipeline Statistics
    prepmedias_turn_no:            int=0
    prepmedias_retry_no:           int=0
    prepknow_turn_no:              int=1  
    prepknow_retry_no:             int=0
    prepknow_init_time:            float=0.0
    prepknow_time:                 float=0.0

    # Overall Pipeline Statistics
    prepmedias_total_turn_no:      int=0
    prepmedias_total_retry_no:     int=0
    prepknow_total_input_tokens:   int=0
    prepknow_total_output_tokens:  int=0
    prepknow_total_tool_tokens:    int=0
    prepknow_total_turn_no:        int=1  
    prepknow_total_retry_no:       int=0
    prepknow_total_time:           float=0.0

    # Pipeline Status
    prepknow_pipeline_termination: bool=True
    prepknow_pipeline_code:        str=''
    prepknow_pipeline_completion:  bool=False
    prepknow_pipeline_reason:      str='DEFAULT'
    prepknow_pipeline_output:      PrepKnowPipelineRecord=PrepKnowPipelineRecord()

    # Pipeline Termination Criteria
    prepknow_criteria:             PrepKnowTermination=PrepKnowTermination()
    system_criteria:               SystemTermination=SystemTermination()

    # PrepKnow Instances
    prepknow:                      SecretPrepKnow
    prepknow_medias:               list[PrepKnowMedia]=[]
    
    # PrepKnow I/O
    prepknow_input:                PrepKnowInput=PrepKnowInput()
    prepknow_output:               PrepKnowOutput=PrepKnowOutput()
    prepknow_metric:               PrepKnowMetric=PrepKnowMetric()

    # PrepKnow Chain
    prepknow_chain:                list[PrepKnowPipelineRecord]=[]
    
    # Time Information
    input_at:                      datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    output_at:                     datetime | None = None

"""
    Request and Response of PrepKnowPipeline
"""
class PrepKnowPipelineRequest(BaseModel):
    prepknow_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_requestid:       str | None = None
    user_id:              str | None = None

    prepknow_pipeline_id: str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_id:          str=''
    prepknow_input:       PrepKnowInput
    custom_config:        PrepKnowCustomConfiguration | None = None
    resume_pipeline:      bool=False

    prepknow:             SecretPrepKnow | None = None # If prepknow is None, will init prepknow from prepknow_id
    
    encrypt_knowledge:    str='default'
    get_full_chain:       bool=False

    request_at:           datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    
class PrepKnowPipelineResponse(BaseModel):
    prepknow_requestid:           str
    user_requestid:               str | None = None
    user_id:                      str | None = None

    prepknow_pipeline_id:         str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_id:                  str=Field(default_factory=lambda: str(uuid.uuid4()))

    prepknow_pipeline_code:       str=''
    prepknow_pipeline_reason:     str='DEFAULT'
    
    prepknow_pipeline_output:     PrepKnowPipelineRecord=PrepKnowPipelineRecord()

    prepknow_chain:               list[PrepKnowPipelineRecord]=[]  

    # Overall Pipeline Statistics
    prepmedias_total_turn_no:     int=0
    prepmedias_total_retry_no:    int=0
    prepknow_total_input_tokens:  int=0
    prepknow_total_output_tokens: int=0
    prepknow_total_tool_tokens:   int=0
    prepknow_total_turn_no:       int=1  
    prepknow_total_retry_no:      int=0
    prepknow_total_time:          float=0.0

    request_at:                   datetime
    response_at:                  datetime | None = None


""""
    Layout Analysis Operation
"""
class LayoutAnalysisMetrics(BaseModel):
    layout_code:          str=SETTINGS.PRKW.STATUS_CODE.get("FAIL", "500")
    layout_reason:        str='DEFAULT'
    layout_total_no:      int=0
    layout_success_no:    int=0
    layout_fail_no:       int=0
    layout_total_page_no: int=0
    layout_input_tokens:  int=0
    layout_output_tokens: int=0
    layout_analysis_time: float=0.0

class ExtractedLayoutObject(BaseModel):
    text:  list[KnowDataObject]=[]
    image: list[KnowDataObject]=[]
    table: list[KnowDataObject]=[]

class ExtractedLayoutType(BaseModel):
    text:  int | None = None
    image: int | None = None
    table: int | None = None

class LayoutAnalysisRequest(BaseModel):
    prepknow_requestid:    str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_requestid:        str | None = None
    user_id:               str | None = None

    knowledge_id:          str=Field(default_factory=lambda: str(uuid.uuid4()))
    file_path:             str=''
    blob_url:              str=''
    
    prepknow_layout_func:  dict | None = None
    prepknow_parameters:   dict | None = None
    prepknow_secrets:      dict | None = None

    request_at:            datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class LayoutAnalysisResponse(BaseModel):
    prepknow_requestid:      str
    
    # Results
    layout_success_objects:  ExtractedLayoutObject=ExtractedLayoutObject()
    layout_fail_objects:     list[KnowDataObject]=[]
    layout_extracted_types:  ExtractedLayoutType=ExtractedLayoutType()

    # Statistics
    layout_analysis_metrics: LayoutAnalysisMetrics=LayoutAnalysisMetrics()
    
    response_at:             datetime | None = None