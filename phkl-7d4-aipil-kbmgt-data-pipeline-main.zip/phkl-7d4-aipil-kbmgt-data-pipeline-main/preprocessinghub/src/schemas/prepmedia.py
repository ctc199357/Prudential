from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from ..database.registry.schemas.prepmedia import *
from ..schemas.preptool import SecretPrepTool, PrepToolMetric, KnowDataObject, KnowRelationshipObject, KnowGraphObject

"""
    Request and Response for Processing Media
"""
class PrepMediaMetric(BaseModel):
    prepmedia_id:               str='custom'
    prepmedia_requestid:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepmedia_pipeline_id:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepmedia_pipeline_traceid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    
    prepmedia_code:             str=''
    prepmedia_reason:           str='FAIL'

    # PrepMedia Metrics
    prepmedia_request_at:       datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    prepmedia_response_at:      datetime | None = None
    prepmedia_turn_no:          int=1
    prepmedia_retry_no:         int=0
    prepmedia_time:             float=0.0

    total_input_tokens:         int=0
    total_output_tokens:        int=0
    total_tool_tokens:          int=0

    # PrepMdia Metrics
    preptool_metrics:           list[PrepToolMetric]=[]


class PrepMediaTermination(BaseModel):
    max_prepmedia_turn:       int        | None = None
    max_prepmedia_retry:      int        | None = None
    max_prepmedia_turn_retry: int        | None = None
    timeout:                  float      | None = None
    code:                     str        | None = None

class SystemTermination(BaseModel):
    max_prepmedia_turn:       int        | None = None
    max_prepmedia_retry:      int        | None = None
    max_prepmedia_turn_retry: int        | None = None
    timeout:                  float      | None = None
    code:                     str        | None = None

class PrepKnowMedia(BaseModel):
    prepmedia: SecretPrepMedia
    preptools: list[SecretPrepTool]=[]

class PrepMediaPipeline(BaseModel):
    # User Request Info
    user_requestid:                 str | None = None
    user_id:                        str | None = None

    # PrepMedia Request Info
    prepmedia_requestid:            str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepmedia_id:                   str=Field(default_factory=lambda: str(uuid.uuid4()))
    
    # PrepKnow Pipeline Request Info
    prepmedia_pipeline_id:          str=''
    prepknow_pipeline_traceid:      str=''

    # Pipeline Statistics
    prepmedia_turn_no:              int=1
    prepmedia_turn_retry_no:        int=0
    prepmedia_retry_no:             int=0
    prepmedia_time:                 float=0.0

    prepmedia_total_time:           float=0.0
    prepmedia_total_input_tokens:   int=0
    prepmedia_total_output_tokens:  int=0
    prepmedia_total_tool_tokens:    int=0

    # Pipelien Status
    prepmedia_pipeline_termination: bool=True
    prepmedia_pipeline_code:        str=''
    prepmedia_pipeline_completion:  bool=False
    prepmedia_pipeline_reason:      str='DEFAULT'
    prepmedia_pipeline_output:      list[KnowDataObject]=[]

    # Pipeline Termination Criteria
    prepmedia_criteria:             PrepMediaTermination=PrepMediaTermination()
    system_criteria:                SystemTermination=SystemTermination()

    # PrepMedia Instancesw
    prepknow_media:                 PrepKnowMedia

    # PrepMedia I/O
    prepmedia_input:                list[KnowDataObject]=[]
    prepmedia_output:               list[KnowDataObject]=[]
    prepmedia_relationship:         KnowGraphObject=KnowGraphObject()
    prepmedia_metric:               PrepMediaMetric=PrepMediaMetric()

    # PrepMedia Chain
    prepmedia_metrics:              list[PrepMediaMetric]=[]

    # Time Information
    input_at:                       datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    output_at:                      datetime | None = None


"""
    Request and Respones of PrepMediaPipeline
"""
class PrepMediaCustomConfiguration(BaseModel):
    pass

class PrepMediaInitRequest(BaseModel):
    prepmedia_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_requestid:      str | None = None
    user_id:             str | None = None
    prepmedia_id:        str=''
    custom_config:       PrepMediaCustomConfiguration | None = None

class PrepMediaInitResponse(BaseModel):
    prepmedia_requestid: str
    custom_config:       PrepMediaCustomConfiguration | None = None
    prepmedia:           SecretPrepMedia | None = None
    prepknow_media:      PrepKnowMedia | None = None
    prepmedia_init_time: float=0.0


class PrepMediaPipelineRequest(BaseModel):
    prepmedia_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_requestid:       str | None = None
    user_id:              str | None = None

    prepmedia_id:         str=''
    prepmedia_input:      list[KnowDataObject]=[]
    custom_config:        PrepMediaCustomConfiguration | None = None
    resume_pipeline:      bool=False

    prepknow_media:       PrepKnowMedia | None = None
    encrypt_knowledge:    str='default'
    
    request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class PrepMediaPipelineResponse(BaseModel):
    prepmedia_requestid:           str

    prepknow_termination:          bool=False
    prepmedia_pipeline_code:       str=''
    prepmedia_pipeline_reason:     str='DEFAULT'
    prepmedia_output:              list[KnowDataObject]=[]
    prepmedia_relationship:        KnowGraphObject=KnowGraphObject()

    prepmedia_turn_no:             int=1
    prepmedia_retry_no:            int=0
    prepmedia_total_time:          float=0.0
    prepmedia_total_input_tokens:  int=0
    prepmedia_total_output_tokens: int=0
    prepmedia_total_tool_tokens:   int=0

    prepmedia_metrics:             list[PrepMediaMetric]=[]
    
    request_at:                    datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    response_at:                   datetime | None = None