from pydantic import BaseModel, Field
from typing import Any
from datetime import datetime, timezone
import uuid

from ..schemas.preptool import SecretPrepTool
from ..schemas.prepmedia import KnowDataObject

class SummarizationEngine(BaseModel):
    preptool_id: str = ''
    
    preptool_group: str = ''
    preptool_type: str = ''
    preptool_location: str = ''
    
    preptool_host: str = ''
    preptool_port: str = ''
    preptool_api: str = ''
    preptool_engine: str = ''
    preptool_base: str = ''
    preptool_model: str = ''
    preptool_parameters: dict = dict()
    preptool_secrets: dict = dict()
    preptool_inputs: dict = dict()
    preptool_outputs: dict = dict()
    preptool_environment: str = ''
    preptool_retry: dict = dict()
    preptool_termination: dict = dict()
    preptool_key: str = ''
    preptool_timeout: int = 300
    input_format: str = ''
    output_format: str = ''

    input_types: dict = dict()
    output_types: dict = dict()

class SummarizationTextRequest(BaseModel):
    preptool_requestid: str = Field(default_factory=lambda: str(uuid.uuid4()))
    preptool: SecretPrepTool = SecretPrepTool()
    data_input: list[KnowDataObject] = []
    request_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SummarizationTextResponse(BaseModel):
    preptool_requestid: str = ''
    
    preptool_time: float = 0.0
    preptool_input_tokens: int = 0
    preptool_output_tokens: int = 0
    preptool_tool_tokens: int = 0
    preptool_config: dict = {}
    
    success_objects: list[KnowDataObject] = []
    fail_objects: list[KnowDataObject] = []

    total_no: int = 0
    success_no: int = 0
    fail_no: int = 0

    response_at: datetime | None = None