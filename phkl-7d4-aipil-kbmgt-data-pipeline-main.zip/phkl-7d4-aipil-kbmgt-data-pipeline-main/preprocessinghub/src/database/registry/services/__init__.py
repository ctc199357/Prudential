import os

from ..connections.registry_connection import get_db_func
from ..models.registry_models import PrepToolDB, PrepMediaDB, PrepKnowDB
from ..schemas.preptool import PrepToolCreate, PrepToolCreateRequest, PrepToolBatchCreateRequest
from ..services.preptool_data import DataManager as PrepToolDataManager
from ..schemas.prepmedia import PrepMediaCreate, PrepMediaCreateRequest, PrepMediaBatchCreateRequest
from ..services.prepmedia_data import DataManager as PrepMediaDataManager
from ..schemas.prepknow import PrepKnowCreate, PrepKnowCreateRequest, PrepKnowBatchCreateRequest
from ..services.prepknow_data import DataManager as PrepKnowDataManager

from ....settings import SETTINGS, INIT_DB_FILE

from ....logger.log_handler import get_logger

logger = get_logger(__name__)


# Init Database
init_file = INIT_DB_FILE
if SETTINGS.BASE.APP_INIT_CHECK:
    if os.path.isfile(init_file):
        # Init SKill
        try:
            db_func = get_db_func
            with db_func() as db:
                row_count = db.query(PrepToolDB).count()

            if row_count == 0:
                try:
                    from ....config.init_config import default_preptools
                    db_profiles = [PrepToolCreate(**profile) for profile in default_preptools]
                    request = PrepToolBatchCreateRequest(create_requests=[PrepToolCreateRequest(user_id='default', user_name='default', is_admin=True, data=PrepToolCreate(**profile)) for profile in default_preptools])
                    response = PrepToolDataManager(db_api=None, db_func=get_db_func, api_call=False).batch_create(request=request)
                except:
                    logger.error(f"Database Initialization Error : <{SETTINGS.BASE.APP_NAME}> Failed to Load Default PrepTool for DB Initialization")
            
            else:
                logger.info("Identified Existing Data in PrepTool DB. No Initialization is Needed.")
        
        except:
            logger.error(f"Database Connection Error : <{SETTINGS.BASE.APP_NAME}> Failed to Connect to PrepTool DB")


        # Init PrepMedia
        try:
            with db_func() as db:
                row_count = db.query(PrepMediaDB).count()

            if row_count == 0:
                try:
                    from ....config.init_config import default_prepmedias
                    db_profiles = [PrepMediaCreate(**profile) for profile in default_prepmedias]
                    request = PrepMediaBatchCreateRequest(create_requests=[PrepMediaCreateRequest(user_id='default', user_name='default', is_admin=True, data=PrepMediaCreate(**profile)) for profile in default_prepmedias])
                    response = PrepMediaDataManager(db_api=None, db_func=get_db_func, api_call=False).batch_create(request=request)
                except:
                    logger.error(f"Database Initialization Error : <{SETTINGS.BASE.APP_NAME}> Failed to Load Default PrepMedia for DB Initialization")
            
            else:
                logger.info("Identified Existing Data in PrepMedia DB. No Initialization is Needed.")

        except:
            logger.error(f"Database Connection Error : <{SETTINGS.BASE.APP_NAME}> Failed to Connect to PrepMedia DB")


        # Init PrepKnow
        try:
            with db_func() as db:
                row_count = db.query(PrepKnowDB).count()

            if row_count == 0:
                try:
                    from ....config.init_config import default_prepknows
                    db_profiles = [PrepKnowCreate(**profile) for profile in default_prepknows]
                    request = PrepKnowBatchCreateRequest(create_requests=[PrepKnowCreateRequest(user_id='default', user_name='default', is_admin=True, data=PrepKnowCreate(**profile)) for profile in default_prepknows])
                    response = PrepKnowDataManager(db_api=None, db_func=get_db_func, api_call=False).batch_create(request=request)
                except:
                    logger.error(f"Database Initialization Error : <{SETTINGS.BASE.APP_NAME}> Failed to Load Default PrepKnow for DB Initialization")
            
            else:
                logger.info("Identified Existing Data in PrepKnow DB. No Initialization is Needed.")

        except:
            logger.error(f"Database Connection Error : <{SETTINGS.BASE.APP_NAME}> Failed to Connect to PrepKnow DB")
    
    else:
        logger.info("No Default Setting Files for Initiating DB")
