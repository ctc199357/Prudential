from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS

""""
    KnowledgeInput General Operation
"""
class KnowledgeInputCreate(BaseModel):
    # Trace Information
    knowledgeinput_id:            str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledgeinput_traceid:       str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledgeinput_name:          str | None = None
    knowledgeinput_version:       int | None = 1

    # Creator Information
    creator_id:                   str=''
    creator_name:                 str=''
    approver_id:                  str='system'
    approver_name:                str='system'

    # Category Information
    knowledgeinput_group:         str='default' # default, user, group
    knowledgeinput_type:          str='default'
    knowledgeinput_location:      str='default'
    storage_type:                 str='LOCAL'
    storage_type_origin:          str='LOCAL'
    storage_provider:             str='LOCAL'
    storage_provider_origin:      str='LOCAL'
    storage_directory:            str='' # file path / url
    storage_directory_origin:     str=''
    storage_secrets:              dict=dict()
    storage_secrets_origin:       dict=dict()

    # Control Information
    knowledgeinput_status:        int=1
    knowledgeinput_permission:    int=1  # knowledgeinput access level
    knowledgeinput_management:    int=10 # knowledgeinput management level

    # Configuration
    knowledgeinput_secrets:       dict=dict()
    knowledgeinput_record:        bool=False # To keep original copy or not
    knowledgeinput_key:           str=''

    # Specification
    knowledgeinput_filename:      str=''
    knowledgeinput_fileextension: str=''
    knowledgeinput_filesize:      float=0.0

    # Tags
    knowledgeinput_tags:          list[str]=[]

    # Time Information
    created_at:                   datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:                   datetime | None = None

class KnowledgeInputCreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           KnowledgeInputCreate

class KnowledgeInputBatchCreateRequest(BaseModel):
    create_requests: list[KnowledgeInputCreateRequest]

# KnowledgeInput CRUD
class KnowledgeInputUpdate(BaseModel):
    # Trace Information
    knowledgeinput_id:            str | None = None
    knowledgeinput_traceid:       str | None = None
    knowledgeinput_name:          str | None = None
    knowledgeinput_version:       int | None = None

    # Creator Information
    creator_id:                   str | None = None
    creator_name:                 str | None = None
    approver_id:                  str | None = None
    approver_name:                str | None = None

    # Category Information
    knowledgeinput_group:         str | None = None
    knowledgeinput_type:          str | None = None
    knowledgeinput_location:      str | None = None
    storage_type:                 str | None = None
    storage_type_origin:          str | None = None
    storage_provider:             str | None = None
    storage_provider_origin:      str | None = None
    storage_directory:            str | None = None
    storage_directory_origin:     str | None = None
    storage_secrets:              dict | None = None
    storage_secrets_origin:       dict | None = None

    # Control Information
    knowledgeinput_status:        int | None = None
    knowledgeinput_permission:    int | None = None
    knowledgeinput_management:    int | None = None

    # Configuration
    knowledgeinput_secrets:       dict | None = None
    knowledgeinput_record:        bool | None = None
    knowledgeinput_key:           str  | None = None

    # Specification
    knowledgeinput_filename:      str   | None = None
    knowledgeinput_fileextension: str   | None = None
    knowledgeinput_filesize:      float | None = None

    # Tags
    knowledgeinput_tags:          list[str] | None = None

class KnowledgeInputUpdateRequest(BaseModel):
    user_requestid:    str | None = None
    user_id:           str=''
    user_name:         str=''
    is_admin:          bool=False
    knowledgeinput_id: str | None = None
    update_data:       KnowledgeInputUpdate=KnowledgeInputUpdate()
    overwrite:         bool = False
    
class KnowledgeInputRequest(BaseModel):
    user_requestid:    str | None = None
    user_id:           str | None = None
    user_name:         str | None = None
    knowledgeinput_id: str | None = None

class KnowledgeInputBatchRequest(BaseModel):
    batch_requests: list[KnowledgeInputRequest]

# System-level Access
class SecretKnowledgeInput(BaseModel):
    # Trace Information
    knowledgeinput_id:            str | None = None
    knowledgeinput_traceid:       str | None = None
    knowledgeinput_name:          str | None = None
    knowledgeinput_version:       int | None = None

    # Creator Information
    creator_id:                   str | None = None
    creator_name:                 str | None = None
    approver_id:                  str | None = None
    approver_name:                str | None = None

    # Category Information
    knowledgeinput_group:         str | None = None
    knowledgeinput_type:          str | None = None
    knowledgeinput_location:      str | None = None
    storage_type:                 str | None = None
    storage_type_origin:          str | None = None
    storage_provider:             str | None = None
    storage_provider_origin:      str | None = None
    storage_directory:            str | None = None
    storage_directory_origin:     str | None = None
    storage_secrets:              dict | None = None
    storage_secrets_origin:       dict | None = None

    # Control Information
    knowledgeinput_status:        int | None = None
    knowledgeinput_permission:    int | None = None
    knowledgeinput_management:    int | None = None

    # Configuration
    knowledgeinput_secrets:       dict | None = None
    knowledgeinput_record:        bool | None = None
    knowledgeinput_key:           str  | None = None

    # Specification
    knowledgeinput_filename:      str   | None = None
    knowledgeinput_fileextension: str   | None = None
    knowledgeinput_filesize:      float | None = 0.0

    # Tags
    knowledgeinput_tags:          list[str] | None = None

    # Time Information
    created_at:                   datetime | None = None
    updated_at:                   datetime | None = None


"""
    KnowledgeInput Filter
"""   
class KnowledgeInputStringFilter(BaseModel):
    knowledgeinput_id_filter:            list[str] | None = None
    knowledgeinput_traceid_filter:       list[str] | None = None
    knowledgeinput_name_filter:          list[str] | None = None

    creator_id_filter:                   list[str] | None = None
    creator_name_filter:                 list[str] | None = None
    approver_id_filter:                  list[str] | None = None
    approver_name_filter:                list[str] | None = None

    knowledgeinput_group_filter:         list[str] | None = None
    knowledgeinput_type_filter:          list[str] | None = None
    knowledgeinput_location_filter:      list[str] | None = None

    storage_type_filter:                 list[str] | None = None
    storage_type_origin_filter:          list[str] | None = None
    storage_provider_filter:             list[str] | None = None
    storage_provider_origin_filter:      list[str] | None = None
    storage_directory_filter:            list[str] | None = None
    storage_directory_origin_filter:     list[str] | None = None
    
    knowledgeinput_key_filter:           list[str] | None = None

    knowledgeinput_filename_filter:      list[str] | None = None
    knowledgeinput_fileextension_filter: list[str] | None = None

class KnowledgeInputNumericFilter(BaseModel):
    knowledgeinput_version_min:    int | None = None
    knowledgeinput_version_max:    int | None = None

    knowledgeinput_status_min:     int | None = None
    knowledgeinput_status_max:     int | None = None 
    knowledgeinput_permission_min: int | None = None
    knowledgeinput_permission_max: int | None = None
    knowledgeinput_management_min: int | None = None
    knowledgeinput_management_max: int | None = None

    knowledgeinput_filesize_min:   float | None = None
    knowledgeinput_filesize_max:   float | None = None

class KnowledgeInputListFilter(BaseModel):
    knowledgeinput_tags_or:  list[str] | None = None
    knowledgeinput_tags_and: list[str] | None = None

class KnowledgeInputDictionaryFilter(BaseModel):
    knowledgeinput_secrets_or:  list[str] | None = None
    knowledgeinput_secrets_and: list[str] | None = None
    storage_secrets_or:         list[str] | None = None
    storage_secrets_and:        list[str] | None = None
    storage_secrets_origin_or:  list[str] | None = None
    storage_secrets_origin_and: list[str] | None = None

class KnowledgeInputBooleanFilter(BaseModel):
    knowledgeinput_record_filter: bool | None = None

class KnowledgeInputDatetimeFilter(BaseModel):
    created_at_start: datetime  | None = None
    created_at_end:   datetime  | None = None
    updated_at_start: datetime  | None = None
    updated_at_end:   datetime  | None = None

class KnowledgeInputByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class KnowledgeInputFilter(BaseModel):
    string_filter:     KnowledgeInputStringFilter     | None = None
    numeric_filter:    KnowledgeInputNumericFilter    | None = None
    list_filter:       KnowledgeInputListFilter       | None = None
    dictionary_filter: KnowledgeInputDictionaryFilter | None = None
    boolean_filter:    KnowledgeInputBooleanFilter    | None = None
    datetime_filter:   KnowledgeInputDatetimeFilter   | None = None
    byte_filter:       KnowledgeInputByteFilter       | None = None
    sorting:           dict={"knowledgeinput_id": "asc", "updated_at": "desc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access KnowledgeInputs
"""
class SystemKnowledgeInputRequest(BaseModel):
    knowledgeinput_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:    KnowledgeInputFilter | None = None

class SystemKnowledgeInputResponse(BaseModel):
    knowledgeinput_requestid: str
    filtered_data: list[SecretKnowledgeInput]=[]
    data_count:        int=0


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class KnowledgeInputBackupRequest(BaseModel):
    knowledgeinput_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:    KnowledgeInputFilter | None = None
    backup_config:            BackupConfig | None = None

class KnowledgeInputBackupListRequest(BaseModel):
    knowledgeinput_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:            BackupConfig | None = None

class KnowledgeInputBackupListResponse(BaseModel):
    knowledgeinput_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:               list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class KnowledgeInputRestoreRequest(BaseModel):
    knowledgeinput_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:           RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class KnowledgeInputImportRequest(BaseModel):
    knowledgeinput_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:                IOConfig | None = None
    backup:                   bool=True

class KnowledgeInputExportRequest(BaseModel):
    knowledgeinput_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:    KnowledgeInputFilter | None = None
    io_config:                IOConfig | None = None
    include_datetime:         bool = True


"""
    Request and Response for User Access Permitted KnowledgeInputs
"""
# User-level Access
class KnowledgeInput(BaseModel):
    # Trace Information
    knowledgeinput_id:            str | None = None
    knowledgeinput_traceid:       str | None = None
    knowledgeinput_name:          str | None = None
    knowledgeinput_version:       int | None = None

    # Creator Information
    creator_id:                   str | None = None
    creator_name:                 str | None = None
    approver_id:                  str | None = None
    approver_name:                str | None = None

    # Category Information
    knowledgeinput_group:         str | None = None
    knowledgeinput_type:          str | None = None
    knowledgeinput_location:      str | None = None
    storage_type:                 str | None = None
    storage_type_origin:          str | None = None
    storage_provider:             str | None = None
    storage_provider_origin:      str | None = None
    storage_directory:            str | None = None
    storage_directory_origin:     str | None = None
    storage_secrets:              dict | None = None
    storage_secrets_origin:       dict | None = None

    # Control Information
    knowledgeinput_status:        int | None = None
    knowledgeinput_permission:    int | None = None
    knowledgeinput_management:    int | None = None

    # Configuration
    knowledgeinput_secrets:       dict | None = None
    knowledgeinput_record:        bool | None = None
    knowledgeinput_key:           str  | None = None

    # Specification
    knowledgeinput_filename:      str   | None = None
    knowledgeinput_fileextension: str   | None = None
    knowledgeinput_filesize:      float | None = None

    # Tags
    knowledgeinput_tags:          list[str] | None = None

    # Time Information
    created_at:                   datetime | None = None
    updated_at:                   datetime | None = None
    
class UserKnowledgeInputRequest(BaseModel):
    knowledgeinput_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:    KnowledgeInputFilter

class UserKnowledgeInputResponse(BaseModel):
    knowledgeinput_requestid: str
    filtered_data: list[KnowledgeInput]=[]