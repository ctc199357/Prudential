from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone


"""" PrepToolDataManager """
""""
    PrepTool General Operation
"""
class PrepToolCreate(BaseModel):
    # Trace Information
    preptool_id:           str=Field(default_factory=lambda: str(uuid.uuid4()))
    preptool_traceid:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    preptool_version:      int=1
    preptool_name:         str

    # Creator Information
    creator_id:            str=''
    creator_name:          str=''

    # Category Information
    preptool_group:        str='default' # default, user, group
    preptool_type:         str='general'
    preptool_location:     str='default'

    # Control Information
    preptool_permission:   int=1  # preptool access level
    preptool_management:   int=10 # preptool management level
    preptool_status:       int=1

    # Configuration
    preptool_host:         str=''
    preptool_port:         str=''
    preptool_api:          str=''
    preptool_engine:       str=''
    preptool_base:         str=''
    preptool_model:        str=''
    preptool_parameters:   dict=dict()
    preptool_secrets:      dict=dict()
    preptool_inputs:       dict=dict()
    preptool_outputs:      dict=dict()
    preptool_environment:  str=''
    preptool_retry:        dict=dict()
    preptool_termination:  dict={'max_retry': 3}
    preptool_key:          str=''
    preptool_timeout:      int=300
    input_format:          str=''
    output_format:         str=''

    # Specification
    preptool_complexity:   int=1
    preptool_use_gpu:      bool=False
    preptool_instance_num: int=1
    preptool_info:         dict=dict()
    preptool_description:  str=''

    # Tags
    input_types:           dict = {'text': 1} # text, image, audio, video, tool
    output_types:          dict = {'text': 1} # text, image, audio, video, tool
    preptool_languages:    list[str]=['ENG']
    preptool_tags:         list[str]=[]
    user_groups:           list[str]=[]
    agent_groups:          list[str]=[]

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None

class PrepToolCreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           PrepToolCreate

class PrepToolBatchCreateRequest(BaseModel):
    create_requests: list[PrepToolCreateRequest]

# PrepTool CRUD
class PrepToolUpdate(BaseModel):
    # Trace Information
    preptool_id:           str | None = None
    preptool_traceid:      str | None = None
    preptool_version:      int | None = None
    preptool_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None

    # Category Information
    preptool_group:        str | None = None
    preptool_type:         str | None = None
    preptool_location:     str | None = None

    # Control Information
    preptool_permission:   int | None = None
    preptool_management:   int | None = None
    preptool_status:       int | None = None

    # Configuration
    preptool_host:         str  | None = None
    preptool_port:         str  | None = None
    preptool_api:          str  | None = None
    preptool_engine:       str  | None = None
    preptool_base:         str  | None = None
    preptool_model:        str  | None = None
    preptool_parameters:   dict | None = None
    preptool_secrets:      dict | None = None
    preptool_inputs:       dict | None = None
    preptool_outputs:      dict | None = None
    preptool_environment:  str  | None = None
    preptool_retry:        dict | None = None
    preptool_termination:  dict | None = None
    preptool_key:          str  | None = None
    preptool_timeout:      int  | None = None
    input_format:          str  | None = None
    output_format:         str  | None = None

    # Specification
    preptool_complexity:   int  | None = None
    preptool_use_gpu:      bool | None = None
    preptool_instance_num: int  | None = None
    preptool_info:         dict | None = None
    preptool_description:  str  | None = None

    # Tags
    input_types:           dict | None = None
    output_types:          dict | None = None
    preptool_languages:    list[str] | None = None
    preptool_tags:         list[str] | None = None
    user_groups:           list[str] | None = None
    agent_groups:          list[str] | None = None

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None
    
class PrepToolUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    preptool_id:       str | None = None
    update_data:    PrepToolUpdate=PrepToolUpdate()
    overwrite:      bool = True

class PrepToolRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str | None = None
    user_name:      str | None = None
    preptool_id:       str | None = None

class PrepToolBatchRequest(BaseModel):
    batch_requests: list[PrepToolRequest]

# System-level Access
class SecretPrepTool(BaseModel):
    # Trace Information
    preptool_id:           str | None = None
    preptool_traceid:      str | None = None
    preptool_version:      int | None = None
    preptool_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None

    # Category Information
    preptool_group:        str | None = None
    preptool_type:         str | None = None
    preptool_location:     str | None = None

    # Control Information
    preptool_permission:   int | None = None
    preptool_management:   int | None = None
    preptool_status:       int | None = None

    # Configuration
    preptool_host:         str  | None = None
    preptool_port:         str  | None = None
    preptool_api:          str  | None = None
    preptool_engine:       str  | None = None
    preptool_base:         str  | None = None
    preptool_model:        str  | None = None
    preptool_parameters:   dict | None = None
    preptool_secrets:      dict | None = None
    preptool_inputs:       dict | None = None
    preptool_outputs:      dict | None = None
    preptool_environment:  str  | None = None
    preptool_retry:        dict | None = None
    preptool_termination:  dict | None = None
    preptool_key:          str  | None = None
    preptool_timeout:      int  | None = None
    input_format:          str  | None = None
    output_format:         str  | None = None

    # Specification
    preptool_complexity:   int  | None = None
    preptool_use_gpu:      bool | None = None
    preptool_instance_num: int  | None = None
    preptool_info:         dict | None = None
    preptool_description:  str  | None = None

    # Tags
    input_types:           dict | None = None
    output_types:          dict | None = None
    preptool_languages:    list[str] | None = None
    preptool_tags:         list[str] | None = None
    user_groups:           list[str] | None = None
    agent_groups:          list[str] | None = None

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None


"""
    PrepTool Filter
"""
class PrepToolStringFilter(BaseModel):
    preptool_id_filter:          list[str] | None = None
    preptool_traceid_filter:     list[str] | None = None
    preptool_name_filter:        list[str] | None = None

    creator_id_filter:           list[str] | None = None
    creator_name_filter:         list[str] | None = None

    preptool_group_filter:       list[str] | None = None
    preptool_type_filter:        list[str] | None = None
    preptool_location_filter:    list[str] | None = None

    preptool_host_filter:        list[str] | None = None
    preptool_port_filter:        list[str] | None = None
    preptool_api_filter:         list[str] | None = None
    preptool_engine_filter:      list[str] | None = None
    preptool_base_filter:        list[str] | None = None
    preptool_model_filter:       list[str] | None = None
    preptool_environment_filter: list[str] | None = None
    preptool_key_filter:         list[str] | None = None

    input_format_filter:         list[str] | None = None
    output_format_filter:        list[str] | None = None

class PrepToolNumericFilter(BaseModel):
    preptool_version_min:        int | None = None
    preptool_version_max:        int | None = None

    preptool_status_min:         int | None = None
    preptool_status_max:         int | None = None 
    preptool_permission_min:     int | None = None
    preptool_permission_max:     int | None = None
    preptool_management_min:     int | None = None
    preptool_management_max:     int | None = None

    preptool_timeout_min:        int | None = None
    preptool_timeout_max:        int | None = None

    preptool_complexity_min:     int | None = None
    preptool_complexity_max:     int | None = None
    preptool_instance_num_min:   int | None = None
    preptool_instance_num_max:   int | None = None

class PrepToolListFilter(BaseModel):
    preptool_languages_or:       list[str] | None = None
    preptool_languages_and:      list[str] | None = None
    preptool_tags_or:            list[str] | None = None
    preptool_tags_and:           list[str] | None = None
    user_groups_or:              list[str] | None = None
    user_groups_and:             list[str] | None = None
    agent_groups_or:             list[str] | None = None
    agent_groups_and:            list[str] | None = None

class PrepToolDictionaryFilter(BaseModel):
    preptool_parameters_or:      list[str] | None = None
    preptool_parameters_and:     list[str] | None = None
    preptool_secrets_or:         list[str] | None = None
    preptool_secrets_and:        list[str] | None = None
    preptool_inputs_or:          list[str] | None = None
    preptool_inputs_and:         list[str] | None = None
    preptool_outputs_or:         list[str] | None = None
    preptool_outputs_and:        list[str] | None = None
    preptool_retry_or:           list[str] | None = None
    preptool_retry_and:          list[str] | None = None
    preptool_termination_or:     list[str] | None = None
    preptool_termination_and:    list[str] | None = None
    preptool_info_or:            list[str] | None = None
    preptool_info_and:           list[str] | None = None

    input_types_or:              list[str] | None = None
    input_types_and:             list[str] | None = None
    output_types_or:             list[str] | None = None
    output_types_and:            list[str] | None = None

class PrepToolBooleanFilter(BaseModel):
    preptool_use_gpu_filter:     bool | None = None

class PrepToolDatetimeFilter(BaseModel):
    created_at_start:            datetime  | None = None
    created_at_end:              datetime  | None = None
    updated_at_start:            datetime  | None = None
    updated_at_end:              datetime  | None = None

class PrepToolByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class PrepToolFilter(BaseModel):
    string_filter:     PrepToolStringFilter     | None = None
    numeric_filter:    PrepToolNumericFilter    | None = None
    list_filter:       PrepToolListFilter       | None = None
    dictionary_filter: PrepToolDictionaryFilter | None = None
    boolean_filter:    PrepToolBooleanFilter    | None = None
    datetime_filter:   PrepToolDatetimeFilter   | None = None
    byte_filter:       PrepToolByteFilter       | None = None
    sorting:           dict={"preptool_name": "asc", "updated_at": "desc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access PrepTools
"""
class SystemPrepToolRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        PrepToolFilter | None = None

class SystemPrepToolResponse(BaseModel):
    preptool_requestid: str
    filtered_data:      list[SecretPrepTool]=[]
    data_count:         int=0


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class PrepToolBackupRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        PrepToolFilter | None = None
    backup_config:      BackupConfig | None = None

class PrepToolBackupListRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:      BackupConfig | None = None

class PrepToolBackupListResponse(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:         list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class PrepToolRestoreRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:     RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class PrepToolImportRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:          IOConfig | None = None
    backup:             bool=True

class PrepToolExportRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        PrepToolFilter | None = None
    io_config:          IOConfig | None = None
    include_datetime:   bool = True



"""" PrepToolServiceManager """
"""
    Request and Response for User Access Permitted PrepTools
"""
# User-level Access
class PrepTool(BaseModel):
    # Trace Information
    preptool_id:           str | None = None
    preptool_traceid:      str | None = None
    preptool_version:      int | None = None
    preptool_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None

    # Category Information
    preptool_group:        str | None = None
    preptool_type:         str | None = None
    preptool_location:     str | None = None

    # Control Information
    preptool_permission:   int | None = None
    preptool_management:   int | None = None
    preptool_status:       int | None = None

    # Configuration
    preptool_host:         str  | None = None
    preptool_port:         str  | None = None
    preptool_api:          str  | None = None
    preptool_engine:       str  | None = None
    preptool_base:         str  | None = None
    preptool_model:        str  | None = None
    preptool_parameters:   dict | None = None
    preptool_secrets:      dict | None = None
    preptool_inputs:       dict | None = None
    preptool_outputs:      dict | None = None
    preptool_environment:  str  | None = None
    preptool_retry:        dict | None = None
    preptool_termination:  dict | None = None
    preptool_key:          str  | None = None
    preptool_timeout:      int  | None = None
    input_format:          str  | None = None
    output_format:         str  | None = None

    # Specification
    preptool_complexity:   int  | None = None
    preptool_use_gpu:      bool | None = None
    preptool_instance_num: int  | None = None
    preptool_info:         dict | None = None
    preptool_description:  str  | None = None

    # Tags
    input_types:           dict | None = None
    output_types:          dict | None = None
    preptool_languages:    list[str] | None = None
    preptool_tags:         list[str] | None = None
    user_groups:           list[str] | None = None
    agent_groups:          list[str] | None = None

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None

class UserPrepToolRequest(BaseModel):
    preptool_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        PrepToolFilter

class UserPrepToolResponse(BaseModel):
    preptool_requestid: str
    filtered_data:      list[PrepTool]=[]