from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS

"""" PrepMediaDataManager """

""""
    PrepMedia General Operation
"""
class PrepMediaCreate(BaseModel):
    # Trace Information
    prepmedia_id:           str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepmedia_traceid:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepmedia_version:      int=1
    prepmedia_name:         str

    # Creator Information
    creator_id:             str=''
    creator_name:           str=''

    # Category Information
    prepmedia_group:        str='default' # default, user, group
    prepmedia_type:         str='general'
    prepmedia_location:     str='default'

    # Control Information
    prepmedia_status:       int=1
    prepmedia_permission:   int=1  # prepmedia access level
    prepmedia_management:   int=10 # prepmedia management level

    # Configuration
    prepmedia_parameters:   dict=dict()
    prepmedia_secrets:      dict=dict()
    prepmedia_inputs:       dict=dict()
    prepmedia_outputs:      dict=dict()
    prepmedia_retry:        dict=dict()
    prepmedia_termination:  dict={'max_retry': 3}
    prepmedia_key:          str=''
    prepmedia_timeout:      int=300
    input_format:           str=''
    output_format:          str=''

    # Dependent
    preptool_selection:     str='default'
    preptool_ids:           dict=dict() # Tool Infos

    # Specification
    prepmedia_complexity:   int=1
    prepmedia_use_gpu:      bool=False
    prepmedia_instance_num: int=1
    prepmedia_info:         dict=dict()
    prepmedia_description:  str=''

    # Tags
    input_types:            dict = {'text': 1} # text, image, audio, video, tool
    output_types:           dict = {'text': 1} # text, image, audio, video, tool
    prepmedia_languages:    list[str]=['ENG']
    prepmedia_tags:         list[str]=[]
    user_groups:            list[str]=[]
    agent_groups:           list[str]=[]

    # Time Information
    created_at:             datetime | None = None
    updated_at:             datetime | None = None

class PrepMediaCreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           PrepMediaCreate

class PrepMediaBatchCreateRequest(BaseModel):
    create_requests: list[PrepMediaCreateRequest]

# PrepMedia CRUD
class PrepMediaUpdate(BaseModel):
    # Trace Information
    prepmedia_id:           str | None = None
    prepmedia_traceid:      str | None = None
    prepmedia_version:      int | None = None
    prepmedia_name:         str | None = None

    # Creator Information
    creator_id:             str | None = None
    creator_name:           str | None = None

    # Category Information
    prepmedia_group:        str | None = None
    prepmedia_type:         str | None = None
    prepmedia_location:     str | None = None

    # Control Information
    prepmedia_status:       int | None = None
    prepmedia_permission:   int | None = None
    prepmedia_management:   int | None = None

    # Configuration
    prepmedia_parameters:   dict | None = None
    prepmedia_secrets:      dict | None = None
    prepmedia_inputs:       dict | None = None
    prepmedia_outputs:      dict | None = None
    prepmedia_retry:        dict | None = None
    prepmedia_termination:  dict | None = None
    prepmedia_key:          str  | None = None
    prepmedia_timeout:      int  | None = None
    input_format:           str  | None = None
    output_format:          str  | None = None

    # Dependent
    preptool_selection:     str  | None = None
    preptool_ids:           dict | None = None

    # Specification
    prepmedia_complexity:   int  | None = None
    prepmedia_use_gpu:      bool | None = None
    prepmedia_instance_num: int  | None = None
    prepmedia_info:         dict | None = None
    prepmedia_description:  str  | None = None

    # Tags
    input_types:            dict | None = None
    output_types:           dict | None = None
    prepmedia_languages:    list[str] | None = None
    prepmedia_tags:         list[str] | None = None
    user_groups:            list[str] | None = None
    agent_groups:           list[str] | None = None

    # Time Information
    created_at:             datetime | None = None
    updated_at:             datetime | None = None

    
class PrepMediaUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    prepmedia_id:   str  | None = None
    update_data:    PrepMediaUpdate=PrepMediaUpdate()
    overwrite:      bool = True

class PrepMediaRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str | None = None
    user_name:      str | None = None
    prepmedia_id:   str | None = None

class PrepMediaBatchRequest(BaseModel):
    batch_requests: list[PrepMediaRequest]

# System-level Access
class SecretPrepMedia(BaseModel):
    # Trace Information
    prepmedia_id:           str | None = None
    prepmedia_traceid:      str | None = None
    prepmedia_version:      int | None = None
    prepmedia_name:         str | None = None

    # Creator Information
    creator_id:             str | None = None
    creator_name:           str | None = None

    # Category Information
    prepmedia_group:        str | None = None
    prepmedia_type:         str | None = None
    prepmedia_location:     str | None = None

    # Control Information
    prepmedia_status:       int | None = None
    prepmedia_permission:   int | None = None
    prepmedia_management:   int | None = None

    # Configuration
    prepmedia_parameters:   dict | None = None
    prepmedia_secrets:      dict | None = None
    prepmedia_inputs:       dict | None = None
    prepmedia_outputs:      dict | None = None
    prepmedia_retry:        dict | None = None
    prepmedia_termination:  dict | None = None
    prepmedia_key:          str  | None = None
    prepmedia_timeout:      int  | None = None
    input_format:           str  | None = None
    output_format:          str  | None = None

    # Dependent
    preptool_selection:     str  | None = None
    preptool_ids:           dict | None = None

    # Specification
    prepmedia_complexity:   int  | None = None
    prepmedia_use_gpu:      bool | None = None
    prepmedia_instance_num: int  | None = None
    prepmedia_info:         dict | None = None
    prepmedia_description:  str  | None = None

    # Tags
    input_types:            dict | None = None
    output_types:           dict | None = None
    prepmedia_languages:    list[str] | None = None
    prepmedia_tags:         list[str] | None = None
    user_groups:            list[str] | None = None
    agent_groups:           list[str] | None = None

    # Time Information
    created_at:             datetime | None = None
    updated_at:             datetime | None = None


"""
    PrepMedia Filter
"""
class PrepMediaStringFilter(BaseModel):
    prepmedia_id_filter:       list[str] | None = None
    prepmedia_traceid_filter:  list[str] | None = None
    prepmedia_name_filter:     list[str] | None = None

    prepmedia_group_filter:    list[str] | None = None
    prepmedia_type_filter:     list[str] | None = None
    prepmedia_location_filter: list[str] | None = None

    creator_id_filter:         list[str] | None = None
    creator_name_filter:       list[str] | None = None

    prepmedia_key_filter:      list[str] | None = None

    input_format_filter:       list[str] | None = None
    output_format_filter:      list[str] | None = None

    preptool_selection_filter: list[str] | None = None

class PrepMediaNumericFilter(BaseModel):
    prepmedia_version_min:      int | None = None
    prepmedia_version_max:      int | None = None

    prepmedia_status_min:       int | None = None
    prepmedia_status_max:       int | None = None 
    prepmedia_permission_min:   int | None = None
    prepmedia_permission_max:   int | None = None
    prepmedia_management_min:   int | None = None
    prepmedia_management_max:   int | None = None

    prepmedia_timeout_min:      int | None = None
    prepmedia_timeout_max:      int | None = None

    prepmedia_complexity_min:   int | None = None
    prepmedia_complexity_max:   int | None = None
    prepmedia_instance_num_min: int | None = None
    prepmedia_instance_num_max: int | None = None

class PrepMediaListFilter(BaseModel):
    prepmedia_languages_or:  list[str] | None = None
    prepmedia_languages_and: list[str] | None = None
    prepmedia_tags_or:       list[str] | None = None
    prepmedia_tags_and:      list[str] | None = None
    user_groups_or:          list[str] | None = None
    user_groups_and:         list[str] | None = None
    agent_groups_or:         list[str] | None = None
    agent_groups_and:        list[str] | None = None

class PrepMediaDictionaryFilter(BaseModel):
    prepmedia_parameters_or:   list[str] | None = None
    prepmedia_parameters_and:  list[str] | None = None
    prepmedia_secrets_or:      list[str] | None = None
    prepmedia_secrets_and:     list[str] | None = None
    prepmedia_inputs_or:       list[str] | None = None
    prepmedia_inputs_and:      list[str] | None = None
    prepmedia_outputs_or:      list[str] | None = None
    prepmedia_outputs_and:     list[str] | None = None
    prepmedia_retry_or:        list[str] | None = None
    prepmedia_retry_and:       list[str] | None = None
    prepmedia_termination_or:  list[str] | None = None
    prepmedia_termination_and: list[str] | None = None

    preptool_ids_or:           list[str] | None = None
    preptool_ids_and:          list[str] | None = None
    prepmedia_info_or:         list[str] | None = None
    prepmedia_info_and:        list[str] | None = None

    input_types_or:            list[str] | None = None
    input_types_and:           list[str] | None = None
    output_types_or:           list[str] | None = None
    output_types_and:          list[str] | None = None

class PrepMediaBooleanFilter(BaseModel):
    prepmedia_use_gpu_filter: bool | None = None

class PrepMediaDatetimeFilter(BaseModel):
    created_at_start:         datetime  | None = None
    created_at_end:           datetime  | None = None
    updated_at_start:         datetime  | None = None
    updated_at_end:           datetime  | None = None

class PrepMediaByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class PrepMediaFilter(BaseModel):
    string_filter:     PrepMediaStringFilter     | None = None
    numeric_filter:    PrepMediaNumericFilter    | None = None
    list_filter:       PrepMediaListFilter       | None = None
    dictionary_filter: PrepMediaDictionaryFilter | None = None
    boolean_filter:    PrepMediaBooleanFilter    | None = None
    datetime_filter:   PrepMediaDatetimeFilter   | None = None
    byte_filter:       PrepMediaByteFilter       | None = None
    sorting:           dict={"prepmdia_id": "asc", "updated_at": "desc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access PrepMedias
"""
class SystemPrepMediaRequest(BaseModel):
    prepmedia_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:         PrepMediaFilter | None = None

class SystemPrepMediaResponse(BaseModel):
    prepmedia_requestid: str
    filtered_data:       list[SecretPrepMedia]=[]
    data_count:          int=0


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class PrepMediaBackupRequest(BaseModel):
    prepmedia_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:         PrepMediaFilter | None = None
    backup_config:       BackupConfig | None = None

class PrepMediaBackupListRequest(BaseModel):
    prepmedia_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:       BackupConfig | None = None

class PrepMediaBackupListResponse(BaseModel):
    prepmedia_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:          list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class PrepMediaRestoreRequest(BaseModel):
    prepmedia_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:      RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class PrepMediaImportRequest(BaseModel):
    prepmedia_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:           IOConfig | None = None
    backup:              bool=True

class PrepMediaExportRequest(BaseModel):
    prepmedia_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:          PrepMediaFilter | None = None
    io_config:            IOConfig | None = None
    include_datetime:     bool = True


"""" PrepMediaServiceManager """
"""
    Request and Response for User Access Permitted PrepMedias
"""
# User-level Access
class PrepMedia(BaseModel):
    # Trace Information
    prepmedia_id:           str | None = None
    prepmedia_traceid:      str | None = None
    prepmedia_version:      int | None = None
    prepmedia_name:         str | None = None

    # Creator Information
    creator_id:             str | None = None
    creator_name:           str | None = None

    # Category Information
    prepmedia_group:        str | None = None
    prepmedia_type:         str | None = None
    prepmedia_location:     str | None = None

    # Control Information
    prepmedia_status:       int | None = None
    prepmedia_permission:   int | None = None
    prepmedia_management:   int | None = None

    # Configuration
    prepmedia_parameters:   dict | None = None
    prepmedia_secrets:      dict | None = None
    prepmedia_inputs:       dict | None = None
    prepmedia_outputs:      dict | None = None
    prepmedia_retry:        dict | None = None
    prepmedia_termination:  dict | None = None
    prepmedia_key:          str  | None = None
    prepmedia_timeout:      int  | None = None
    input_format:           str  | None = None
    output_format:          str  | None = None

    # Dependent
    preptool_selection:     str  | None = None
    preptool_ids:           dict | None = None

    # Specification
    prepmedia_complexity:   int  | None = None
    prepmedia_use_gpu:      bool | None = None
    prepmedia_instance_num: int  | None = None
    prepmedia_info:         dict | None = None
    prepmedia_description:  str  | None = None

    # Tags
    input_types:            dict | None = None
    output_types:           dict | None = None
    prepmedia_languages:    list[str] | None = None
    prepmedia_tags:         list[str] | None = None
    user_groups:            list[str] | None = None
    agent_groups:           list[str] | None = None

    # Time Information
    created_at:             datetime | None = None
    updated_at:             datetime | None = None
    
class UserPrepMediaRequest(BaseModel):
    prepmedia_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:         PrepMediaFilter

class UserPrepMediaResponse(BaseModel):
    prepmedia_requestid: str
    filtered_data:       list[PrepMedia]=[]