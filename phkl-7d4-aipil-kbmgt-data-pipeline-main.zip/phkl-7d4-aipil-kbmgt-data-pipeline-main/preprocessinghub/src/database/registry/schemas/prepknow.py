from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS

""""
    PrepKnow General Operation
"""
class PrepKnowCreate(BaseModel):
    # Trace Information
    prepknow_id:           str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_traceid:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_version:      int=1
    prepknow_name:         str

    # Creator Information
    creator_id:            str=''
    creator_name:          str=''

    # Category Information
    prepknow_group:        str='default' # default, user, group
    prepknow_type:         str='general'
    prepknow_location:     str='default'

    # Control Information
    prepknow_status:       int=1
    prepknow_permission:   int=1  # prepknow access level
    prepknow_management:   int=10 # prepknow management level

    # Configuration
    prepknow_layout_func:  dict=dict()
    prepknow_parameters:   dict=dict()
    prepknow_secrets:      dict=dict()
    prepknow_inputs:       dict=dict()
    prepknow_outputs:      dict=dict()
    prepknow_retry:        dict=dict()
    prepknow_termination:  dict=dict()
    prepknow_key:          str=''
    prepknow_timeout:      int  | None = None    
    input_format:          str=''
    output_format:         str=''

    # Dependent
    prepmedia_selection:   str='default'
    prepmedia_ids:         dict=dict() # Media Infos

    # Specification
    prepknow_complexity:   int=1
    prepknow_use_gpu:      bool=False
    prepknow_instance_num: int=1
    prepknow_description:  str=''

    # Tags
    input_types:           dict = {'text': 1} # text, image, audio, video, tool
    output_types:          dict = {'text': 1} # text, image, audio, video, tool
    prepknow_languages:    list[str] | None = None
    prepknow_tags:         list[str]=[]
    user_groups:           list[str]=[]
    agent_groups:          list[str]=[]

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None

class PrepKnowCreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           PrepKnowCreate

class PrepKnowBatchCreateRequest(BaseModel):
    create_requests: list[PrepKnowCreateRequest]

# PrepKnow CRUD
class PrepKnowUpdate(BaseModel):
    # Trace Information
    prepknow_id:           str | None = None
    prepknow_traceid:      str | None = None
    prepknow_version:      int | None = None
    prepknow_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None

    # Category Information
    prepknow_group:        str | None = None
    prepknow_type:         str | None = None
    prepknow_location:     str | None = None

    # Control Information
    prepknow_status:       int | None = None
    prepknow_permission:   int | None = None
    prepknow_management:   int | None = None

    # Configuration
    prepknow_layout_func:  dict | None = None
    prepknow_parameters:   dict | None = None
    prepknow_secrets:      dict | None = None
    prepknow_inputs:       dict | None = None
    prepknow_outputs:      dict | None = None
    prepknow_retry:        dict | None = None
    prepknow_termination:  dict | None = None
    prepknow_key:          str  | None = None
    prepknow_timeout:      int  | None = None    
    input_format:          str  | None = None
    output_format:         str  | None = None

    # Dependent
    prepmedia_selection:   str  | None = None
    prepmedia_ids:        dict | None = None

    # Specification
    prepknow_complexity:   int  | None = None
    prepknow_use_gpu:      bool | None = None
    prepknow_instance_num: int  | None = None
    prepknow_description:  str  | None = None

    # Tags
    input_types:           dict | None = None
    output_types:          dict | None = None
    prepknow_languages:    list[str] | None = None
    prepknow_tags:         list[str] | None = None
    user_groups:           list[str] | None = None
    agent_groups:          list[str] | None = None

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None
    
class PrepKnowUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    prepknow_id:    str  | None = None
    update_data:    PrepKnowUpdate=PrepKnowUpdate()
    overwrite:      bool = True

class PrepKnowRequest(BaseModel):
    user_requestid:   str | None = None
    user_id:          str | None = None
    user_name:        str | None = None
    prepknow_id:      str | None = None

class PrepKnowBatchRequest(BaseModel):
    batch_requests: list[PrepKnowRequest]

# System-level Access
class SecretPrepKnow(BaseModel):
    # Trace Information
    prepknow_id:           str | None = None
    prepknow_traceid:      str | None = None
    prepknow_version:      int | None = None
    prepknow_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None

    # Category Information
    prepknow_group:        str | None = None
    prepknow_type:         str | None = None
    prepknow_location:     str | None = None

    # Control Information
    prepknow_status:       int | None = None
    prepknow_permission:   int | None = None
    prepknow_management:   int | None = None

    # Configuration
    prepknow_layout_func:  dict | None = None
    prepknow_parameters:   dict | None = None
    prepknow_secrets:      dict | None = None
    prepknow_inputs:       dict | None = None
    prepknow_outputs:      dict | None = None
    prepknow_retry:        dict | None = None
    prepknow_termination:  dict | None = None
    prepknow_key:          str  | None = None
    prepknow_timeout:      int  | None = None    
    input_format:          str  | None = None
    output_format:         str  | None = None

    # Dependent
    prepmedia_selection:   str  | None = None
    prepmedia_ids:         dict | None = None

    # Specification
    prepknow_complexity:   int  | None = None
    prepknow_use_gpu:      bool | None = None
    prepknow_instance_num: int  | None = None
    prepknow_description:  str  | None = None

    # Tags
    input_types:           dict | None = None
    output_types:          dict | None = None
    prepknow_languages:    list[str] | None = None
    prepknow_tags:         list[str] | None = None
    user_groups:           list[str] | None = None
    agent_groups:          list[str] | None = None

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None


"""
    PrepKnow Filter
"""
class PrepKnowStringFilter(BaseModel):
    prepknow_id_filter:          list[str] | None = None
    prepknow_traceid_filter:     list[str] | None = None
    prepknow_name_filter:        list[str] | None = None

    prepknow_group_filter:       list[str] | None = None
    prepknow_type_filter:        list[str] | None = None
    prepknow_location_filter:    list[str] | None = None

    creator_id_filter:           list[str] | None = None
    creator_name_filter:         list[str] | None = None

    prepknow_key_filter:         list[str] | None = None
    input_format_filter:         list[str] | None = None
    output_format_filter:        list[str] | None = None

    prepmedia_selection_filter:  list[str] | None = None

class PrepKnowNumericFilter(BaseModel):
    prepknow_version_min:      int | None = None
    prepknow_version_max:      int | None = None

    prepknow_status_min:       int | None = None
    prepknow_status_max:       int | None = None 
    prepknow_permission_min:   int | None = None
    prepknow_permission_max:   int | None = None
    prepknow_management_min:   int | None = None
    prepknow_management_max:   int | None = None

    prepknow_timeout_min:      int | None = None
    prepknow_timeout_max:      int | None = None

    prepknow_complexity_min:   int | None = None
    prepknow_complexity_max:   int | None = None
    prepknow_instance_num_min: int | None = None
    prepknow_instance_num_max: int | None = None

class PrepKnowListFilter(BaseModel):
    prepknow_languages_or:     list[str] | None = None
    prepknow_languages_and:    list[str] | None = None
    prepknow_tags_or:          list[str] | None = None
    prepknow_tags_and:         list[str] | None = None
    user_groups_or:            list[str] | None = None
    user_groups_and:           list[str] | None = None
    agent_groups_or:           list[str] | None = None
    agent_groups_and:          list[str] | None = None

class PrepKnowDictionaryFilter(BaseModel):
    prepknow_layout_func_or:   list[str] | None = None
    prepknow_layout_func_and:  list[str] | None = None
    prepknow_parameters_or:    list[str] | None = None
    prepknow_parameters_and:   list[str] | None = None
    prepknow_secrets_or:       list[str] | None = None
    prepknow_secrets_and:      list[str] | None = None
    prepknow_inputs_or:        list[str] | None = None
    prepknow_inputs_and:       list[str] | None = None
    prepknow_outputs_or:       list[str] | None = None
    prepknow_outputs_and:      list[str] | None = None

    prepknow_retry_or:         list[str] | None = None
    prepknow_retry_and:        list[str] | None = None
    prepknow_termination_or:   list[str] | None = None
    prepknow_termination_and:  list[str] | None = None

    prepmedia_ids_or:          list[str] | None = None
    prepmedia_ids_and:         list[str] | None = None
    
    input_types_or:            list[str] | None = None
    input_types_and:           list[str] | None = None
    output_types_or:           list[str] | None = None
    output_types_and:          list[str] | None = None

class PrepKnowBooleanFilter(BaseModel):
    prepknow_use_gpu_filter:   bool | None = None

class PrepKnowDatetimeFilter(BaseModel):
    created_at_start:          datetime  | None = None
    created_at_end:            datetime  | None = None
    updated_at_start:          datetime  | None = None
    updated_at_end:            datetime  | None = None

class PrepKnowByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class PrepKnowFilter(BaseModel):
    string_filter:     PrepKnowStringFilter     | None = None
    numeric_filter:    PrepKnowNumericFilter    | None = None
    list_filter:       PrepKnowListFilter       | None = None
    dictionary_filter: PrepKnowDictionaryFilter | None = None
    boolean_filter:    PrepKnowBooleanFilter    | None = None
    datetime_filter:   PrepKnowDatetimeFilter   | None = None
    byte_filter:       PrepKnowByteFilter       | None = None
    sorting:           dict={"prepknow_name": "asc", "updated_at": "desc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access PrepKnows
"""
class SystemPrepKnowRequest(BaseModel):
    prepknow_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        PrepKnowFilter | None = None

class SystemPrepKnowResponse(BaseModel):
    prepknow_requestid: str
    filtered_data:      list[SecretPrepKnow]=[]
    data_count:         int=0


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class PrepKnowBackupRequest(BaseModel):
    prepknow_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        PrepKnowFilter | None = None
    backup_config:      BackupConfig | None = None

class PrepKnowBackupListRequest(BaseModel):
    prepknow_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:      BackupConfig | None = None

class PrepKnowBackupListResponse(BaseModel):
    prepknow_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:         list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class PrepKnowRestoreRequest(BaseModel):
    prepknow_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:     RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class PrepKnowImportRequest(BaseModel):
    prepknow_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:          IOConfig | None = None
    backup:             bool=True

class PrepKnowExportRequest(BaseModel):
    prepknow_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:         PrepKnowFilter | None = None
    io_config:           IOConfig | None = None
    include_datetime:    bool = True


"""" PrepKnowServiceManager """
"""
    Request and Response for User Access Permitted PrepKnows
"""
# User-level Access
class PrepKnow(BaseModel):
    # Trace Information
    prepknow_id:           str | None = None
    prepknow_traceid:      str | None = None
    prepknow_version:      int | None = None
    prepknow_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None

    # Category Information
    prepknow_group:        str | None = None
    prepknow_type:         str | None = None
    prepknow_location:     str | None = None

    # Control Information
    prepknow_status:       int | None = None
    prepknow_permission:   int | None = None
    prepknow_management:   int | None = None

    # Configuration
    prepknow_layout_func:  dict | None = None
    prepknow_parameters:   dict | None = None
    prepknow_secrets:      dict | None = None
    prepknow_inputs:       dict | None = None
    prepknow_outputs:      dict | None = None
    prepknow_retry:        dict | None = None
    prepknow_termination:  dict | None = None
    prepknow_key:          str  | None = None
    prepknow_timeout:      int  | None = None    
    input_format:          str  | None = None
    output_format:         str  | None = None

    # Dependent
    prepmedia_selection:   str  | None = None
    prepmedia_ids:         dict | None = None

    # Specification
    prepknow_complexity:   int  | None = None
    prepknow_use_gpu:      bool | None = None
    prepknow_instance_num: int  | None = None
    prepknow_description:  str  | None = None

    # Tags
    input_types:           dict | None = None
    output_types:          dict | None = None
    prepknow_languages:    list[str] | None = None
    prepknow_tags:         list[str] | None = None
    user_groups:           list[str] | None = None
    agent_groups:          list[str] | None = None

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None

class UserPrepKnowRequest(BaseModel):
    prepknow_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        PrepKnowFilter

class UserPrepKnowResponse(BaseModel):
    prepknow_requestid: str
    filtered_data:      list[PrepKnow]=[]