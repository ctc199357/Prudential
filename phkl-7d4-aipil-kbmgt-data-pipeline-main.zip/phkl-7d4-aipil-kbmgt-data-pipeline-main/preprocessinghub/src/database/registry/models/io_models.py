from sqlalchemy import Column, String, Integer, DateTime, JSON, Boolean, UniqueConstraint
from sqlalchemy import Table, MetaData
from sqlalchemy.engine import Engine

from sqlalchemy.orm import declarative_base
from sqlalchemy.sql import func

import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS


def set_io_db_preptool_table(table_name: str, engine: Engine):
    Base = declarative_base()

    class IOPrepToolDB(Base):
        __tablename__ = table_name

        # Trace Information
        preptool_id           = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True, unique=True)
        preptool_traceid      = Column(String,  default=lambda: str(uuid.uuid4())) # trace the changes of preptool
        preptool_version      = Column(Integer, default=1)   # 1=original    
        preptool_name         = Column(String,  default='')

        # Category Information
        preptool_group        = Column(String,  default='default') # default, user, group, preptool
        preptool_type         = Column(String,  default='general') # general, retrieval
        preptool_location     = Column(String,  default='default')

        # Control Information
        preptool_status       = Column(Integer, default=1)   # 0=inactvie, 1=active
        preptool_permission   = Column(Integer, default=1)   # 0=default, related to user permission
        preptool_management   = Column(Integer, default=10)  # relate to management permission

        # Configuration
        preptool_host         = Column(String,  default='')
        preptool_port         = Column(String,  default='')
        preptool_api          = Column(String,  default='')
        preptool_engine       = Column(String,  default='')
        preptool_base         = Column(String,  default='')
        preptool_model        = Column(String,  default='')
        preptool_parameters   = Column(JSON,    default=dict()) # preptool parameter: interpreter, language
        preptool_secrets      = Column(JSON,    default=dict()) # preptool secret variables / executable variables  
        preptool_inputs       = Column(JSON,    default=dict())
        preptool_outputs      = Column(JSON,    default=dict())
        preptool_environment  = Column(String,  default='') # Local, Docker, Jupyter
        preptool_retry        = Column(JSON,    default=dict())
        preptool_termination  = Column(JSON,    default=dict())
        preptool_key          = Column(String,  default='')
        preptool_timeout      = Column(Integer, default=300) # in second
        input_format          = Column(String,  default='')
        output_format         = Column(String,  default='')

        # Specification
        preptool_complexity   = Column(Integer, default=1)
        preptool_use_gpu      = Column(Boolean, default=False)
        preptool_instance_num = Column(Integer, default=1)
        preptool_info         = Column(JSON,    default=dict())
        preptool_description  = Column(String,  default='')

        # Tags
        input_types           = Column(JSON, default={'text': 1})
        output_types          = Column(JSON, default={'text': 1})
        _preptool_languages   = Column("preptool_languages", String,  default='ENG') # preptool languages
        _preptool_tags        = Column("preptool_tags",   String, default='')
        _user_groups          = Column("user_groups",  String, default='')
        _agent_groups         = Column("agent_groups", String, default='')
        
        # Creator Information
        creator_id            = Column(String,  default='') # user or group ID
        creator_name          = Column(String,  default='') # user or group name
        
        # Time Information
        created_at            = Column(DateTime(timezone=True), server_default=func.now(), default=datetime.now(timezone.utc))
        updated_at            = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), default=datetime.now(timezone.utc))

        @property
        def preptool_languages(self):
            """Convert value from str to list."""
            if self._preptool_languages:
                return [value.strip() for value in self._preptool_languages.split(SETTINGS.DATB.SEP)]
            return []

        @preptool_languages.setter
        def preptool_languages(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._preptool_languages = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._preptool_languages = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def preptool_tags(self):
            """Convert value from str to list."""
            if self._preptool_tags:
                return [value.strip() for value in self._preptool_tags.split(SETTINGS.DATB.SEP)]
            return []

        @preptool_tags.setter
        def preptool_tags(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._preptool_tags = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._preptool_tags = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def user_groups(self):
            """Convert value from str to list."""
            if self._user_groups:
                return [value.strip() for value in self._user_groups.split(SETTINGS.DATB.SEP)]
            return []

        @user_groups.setter
        def user_groups(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._user_groups = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._user_groups = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def agent_groups(self):
            """Convert value from str to list."""
            if self._agent_groups:
                return [value.strip() for value in self._agent_groups.split(SETTINGS.DATB.SEP)]
            return []

        @agent_groups.setter
        def agent_groups(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._agent_groups = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._agent_groups = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        def to_dict(self):
            return {**self.__dict__,
                "preptool_languages": self.preptool_languages,
                "preptool_tags":      self.preptool_tags,
                "user_groups":        self.user_groups,
                "agent_groups":       self.agent_groups
            }
    
    Base.metadata.create_all(engine)
    return IOPrepToolDB


def set_io_db_prepmedia_table(table_name: str, engine: Engine):
    Base = declarative_base()

    class IOPrepMdiaDB(Base):
        __tablename__ = table_name

        # Trace Information
        prepmedia_id           = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True, unique=True)
        prepmedia_traceid      = Column(String,  default=lambda: str(uuid.uuid4())) # trace the changes of prepmedia
        prepmedia_version      = Column(Integer, default=1)   # 1=original    
        prepmedia_name         = Column(String,  default='')

        # Category Information
        prepmedia_group        = Column(String,  default='default') # default, user, group, prepmedia
        prepmedia_type         = Column(String,  default='general') # general, chain-of-thought
        prepmedia_location     = Column(String,  default='default')

        # Control Information
        prepmedia_status       = Column(Integer, default=1)   # 0=inactvie, 1=active
        prepmedia_permission   = Column(Integer, default=1)   # 0=default, related to user permission
        prepmedia_management   = Column(Integer, default=10)  # relate to management permission

        # Configuration
        prepmedia_parameters   = Column(JSON,    default=dict()) # prepmedia parameter: interpreter, language
        prepmedia_secrets      = Column(JSON,    default=dict()) # prepmedia secret variables / executable variables  
        prepmedia_inputs       = Column(JSON,    default=dict())
        prepmedia_outputs      = Column(JSON,    default=dict())
        prepmedia_retry        = Column(JSON,    default=dict()) # Retry Hint
        prepmedia_termination  = Column(JSON,    default=dict()) # Termination Hint
        prepmedia_key          = Column(String,  default='')
        prepmedia_timeout      = Column(Integer, default=300) # in seconds
        input_format           = Column(String,  default='')
        output_format          = Column(String,  default='')

        # Dependent Configuration
        preptool_selection     = Column(String,  default='default')
        preptool_ids           = Column(JSON,    default=dict())

        # Specification
        prepmedia_complexity   = Column(Integer, default=1)
        prepmedia_use_gpu      = Column(Boolean, default=False)
        prepmedia_instance_num = Column(Integer, default=1)
        prepmedia_info         = Column(JSON,    default=dict())
        prepmedia_description  = Column(String,  default='')

        # Tags
        input_types            = Column(JSON, default={'text': 1})
        output_types           = Column(JSON, default={'text': 1})
        _prepmedia_languages   = Column("prepmedia_languages", String,  default='ENG') # prepmedia languages
        _prepmedia_tags        = Column("prepmedia_tags",   String, default='')
        _user_groups           = Column("user_groups",  String, default='')
        _agent_groups          = Column("agent_groups", String, default='')
        
        # Creator Information
        creator_id             = Column(String,  default='') # user or group ID
        creator_name           = Column(String,  default='') # user or group name
        
        # Time Information
        created_at             = Column(DateTime(timezone=True), server_default=func.now(), default=datetime.now(timezone.utc))
        updated_at             = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), default=datetime.now(timezone.utc))

        @property
        def prepmedia_languages(self):
            """Convert value from str to list."""
            if self._prepmedia_languages:
                return [value.strip() for value in self._prepmedia_languages.split(SETTINGS.DATB.SEP)]
            return []

        @prepmedia_languages.setter
        def prepmedia_languages(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._prepmedia_languages = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._prepmedia_languages = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def prepmedia_tags(self):
            """Convert value from str to list."""
            if self._prepmedia_tags:
                return [value.strip() for value in self._prepmedia_tags.split(SETTINGS.DATB.SEP)]
            return []

        @prepmedia_tags.setter
        def prepmedia_tags(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._prepmedia_tags = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._prepmedia_tags = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def user_groups(self):
            """Convert value from str to list."""
            if self._user_groups:
                return [value.strip() for value in self._user_groups.split(SETTINGS.DATB.SEP)]
            return []

        @user_groups.setter
        def user_groups(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._user_groups = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._user_groups = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def agent_groups(self):
            """Convert value from str to list."""
            if self._agent_groups:
                return [value.strip() for value in self._agent_groups.split(SETTINGS.DATB.SEP)]
            return []

        @agent_groups.setter
        def agent_groups(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._agent_groups = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._agent_groups = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        def to_dict(self):
            return {**self.__dict__,
                "prepmedia_languages": self.prepmedia_languages,
                "prepmedia_tags":      self.prepmedia_tags,
                "user_groups":         self.user_groups,
                "agent_groups":        self.agent_groups
            }
    
    Base.metadata.create_all(engine)
    return IOPrepMdiaDB


def set_io_db_prepknow_table(table_name: str, engine: Engine):
    Base = declarative_base()

    class IOPrepKnowDB(Base):
        __tablename__ = table_name

        # Trace Information
        prepknow_id           = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True, unique=True)
        prepknow_traceid      = Column(String,  default=lambda: str(uuid.uuid4())) # trace the changes of prepknow
        prepknow_version      = Column(Integer, default=1)   # 1=original    
        prepknow_name         = Column(String,  default='')

        # Category Information
        prepknow_group        = Column(String,  default='default') # default, user, group, prepknow
        prepknow_type         = Column(String,  default='general') # general, chain-of-thought
        prepknow_location     = Column(String,  default='default')

        # Control Information
        prepknow_status       = Column(Integer, default=1)   # 0=inactvie, 1=active
        prepknow_permission   = Column(Integer, default=1)   # 0=default, related to user permission
        prepknow_management   = Column(Integer, default=10)  # relate to management permission

        # Configuration
        prepknow_layout_func  = Column(JSON,    default=dict())
        prepknow_parameters   = Column(JSON,    default=dict()) # prepknow parameter: interpreter, language
        prepknow_secrets      = Column(JSON,    default=dict()) # prepknow secret variables / executable variables  
        prepknow_inputs       = Column(JSON,    default=dict())
        prepknow_outputs      = Column(JSON,    default=dict())
        prepknow_retry        = Column(JSON) # Retry Hint
        prepknow_termination  = Column(JSON) # Termination Hint
        prepknow_key          = Column(String,  default='')
        prepknow_timeout      = Column(Integer, default=300) # in seconds
        input_format          = Column(String,  default='')
        output_format         = Column(String,  default='')

        # Dependent
        prepmedia_selection   = Column(String,  default='')
        prepmedia_ids         = Column(JSON,    default=dict()) # Termination Hint

        # Specification
        prepknow_complexity   = Column(Integer, default=1)
        prepknow_use_gpu      = Column(Boolean, default=False)
        prepknow_instance_num = Column(Integer, default=1)
        prepknow_description  = Column(String,  default='')

        # Tags
        input_types           = Column(JSON, default={'text': 1})
        output_types          = Column(JSON, default={'text': 1})
        _prepknow_languages   = Column("prepknow_languages", String,  default='ENG') # prepknow languages
        _prepknow_tags        = Column("prepknow_tags",   String, default='')
        _user_groups          = Column("user_groups",  String, default='')
        _agent_groups         = Column("agent_groups", String, default='')
        
        # Creator Information
        creator_id            = Column(String,  default='') # user or group ID
        creator_name          = Column(String,  default='') # user or group name
        
        # Time Information
        created_at            = Column(DateTime(timezone=True), server_default=func.now(), default=datetime.now(timezone.utc))
        updated_at            = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), default=datetime.now(timezone.utc))

        @property
        def prepknow_languages(self):
            """Convert value from str to list."""
            if self._prepknow_languages:
                return [value.strip() for value in self._prepknow_languages.split(SETTINGS.DATB.SEP)]
            return []

        @prepknow_languages.setter
        def prepknow_languages(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._prepknow_languages = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._prepknow_languages = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def prepknow_tags(self):
            """Convert value from str to list."""
            if self._prepknow_tags:
                return [value.strip() for value in self._prepknow_tags.split(SETTINGS.DATB.SEP)]
            return []

        @prepknow_tags.setter
        def prepknow_tags(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._prepknow_tags = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._prepknow_tags = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def user_groups(self):
            """Convert value from str to list."""
            if self._user_groups:
                return [value.strip() for value in self._user_groups.split(SETTINGS.DATB.SEP)]
            return []

        @user_groups.setter
        def user_groups(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._user_groups = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._user_groups = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        @property
        def agent_groups(self):
            """Convert value from str to list."""
            if self._agent_groups:
                return [value.strip() for value in self._agent_groups.split(SETTINGS.DATB.SEP)]
            return []

        @agent_groups.setter
        def agent_groups(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._agent_groups = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._agent_groups = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        def to_dict(self):
            return {**self.__dict__,
                "prepknow_languages": self.prepknow_languages,
                "prepknow_tags":      self.prepknow_tags,
                "user_groups":        self.user_groups,
                "agent_groups":       self.agent_groups
            }
        
    Base.metadata.create_all(engine)
    return IOPrepKnowDB



def get_io_db_table(table_name: str, engine: Engine) -> Table:
    metadata = MetaData()
    table = Table(table_name, metadata, autoload_with=engine)
    return table