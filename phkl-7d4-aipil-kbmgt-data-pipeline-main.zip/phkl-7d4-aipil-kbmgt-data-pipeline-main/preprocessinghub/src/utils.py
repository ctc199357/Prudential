import os
import re
import tiktoken
from .settings import SETTINGS
from .schemas.format import Response
from fastapi import HTTPException
from azure.storage.blob import BlobClient, BlobServiceClient, ContentSettings
from .logger.log_handler import get_logger

logger = get_logger(__name__)

def normalize_path(long_path: str) -> str:
    if os.name == 'nt':
        long_path = os.path.abspath(long_path)
        if not long_path.startswith('\\\\?\\'):
            long_path = '\\\\?\\' + long_path
    return long_path

# Router Response Handler
def router_response_handler(response: Response, api_call: bool):
    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
        if api_call == True:
            raise HTTPException(status_code=response.status_code, detail=response.detail)
        else:
            raise Exception(response.detail)

def get_local_file_path(blob_url: str) -> str:
    local_dir = os.path.join(SETTINGS.PREP.STORAGE_TEMP_RDIR, SETTINGS.PREP.STORAGE_TEMP_SDIR)    
    blob_path = get_blob_path(blob_url=blob_url)

    # Get curent local file path
    file_path = normalize_path(os.path.join(local_dir, blob_path))
    logger.info(f"Converted to local file path: {file_path}")

    file_dir = os.path.dirname(file_path)
    if not os.path.exists(file_path):
        os.makedirs(file_dir, exist_ok=True)
        # Download from blob to local file path if no such file exists
        download_from_blob_by_url(blob_file_url=blob_url, local_path=file_path)

    return file_path

def num_tokens_from_string(string: str, encoding_name: str="cl100k_base") -> int:
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens

def get_blob_path(blob_url: str) -> str:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = BlobClient.from_blob_url(
            blob_url,
            credential=blob_service_client.credential
        )
        
        return blob_client.blob_name
    except Exception as e:
        logger.error(f"Failed to get blob path for {blob_url}: {str(e)}")
        raise

def upload_to_blob(local_path: str, blob_path: str, content_type: str="application/pdf") -> str:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob_path)
        content_settings = ContentSettings(content_type=content_type)

        with open(local_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True, content_settings=content_settings)

        logger.info(f"Uploaded {local_path} to blob storage as {blob_client.url}")

        return blob_client.url
    except Exception as e:
        logger.error(f"Failed to upload {local_path} to blob storage: {str(e)}")
        raise

def download_from_blob_by_url(blob_file_url: str, local_path: str):
    try:
        # Initialize blob service client
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        
        blob_client = BlobClient.from_blob_url(
            blob_file_url,
            credential=blob_service_client.credential
        )
        # Download the blob
        with open(local_path, "wb") as file:
            file.write(blob_client.download_blob().readall())

        logger.info(f"Downloaded blob from {blob_file_url} to {local_path}")
    except Exception as e:
        logger.error(f"Failed to download {blob_file_url} from blob storage: {str(e)}")
        raise

def download_from_blob(blob_path: str, local_path: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob_path)
        with open(local_path, "wb") as download_file:
            download_file.write(blob_client.download_blob().readall())

        logger.info(f"Downloaded blob from {blob_path} to {local_path}")

        return blob_client.url
    except Exception as e:
        logger.error(f"Failed to download {blob_path} from blob storage: {str(e)}")
        raise

def delete_blob_file(blob: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob)
        blob_client.delete_blob()
        logger.info(f"Deleted {blob} on blob storage")
    except Exception as e:
        logger.error(f"Failed to delete {blob} on blob storage: {str(e)}")
        raise

def download_blob_files(blob_path_prefix: str, local_dir: str, skip_folders: list[str]=[]):
    try:
        # Set up blob service client
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(SETTINGS.BLOB.CONTAINER_NAME)
        # List all blobs in the directory
        blobs_list = container_client.list_blobs(name_starts_with=blob_path_prefix)

        # Download each blob file
        for blob in blobs_list:
            # Skip if the blob is a directory or matches any skip folder pattern
            is_directory = blob.name.endswith('/')
            is_skip_folder = any(blob.name.endswith(folder) for folder in skip_folders)
            if is_directory or is_skip_folder:
                continue

            file_name = os.path.basename(blob.name)
            local_file_path = os.path.join(local_dir, file_name)

            if os.path.exists(local_file_path):
                logger.info(f"File exists: {local_file_path}")
                continue
            
            # Create directory structure if it doesn't exist
            os.makedirs(os.path.dirname(local_file_path), exist_ok=True)

            # Download the blob
            blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob.name)
            logger.info(f"Downloading {blob.name} to {local_file_path}")
            with open(local_file_path, "wb") as download_file:
                download_file.write(blob_client.download_blob().readall())

        logger.info(f"Downloaded files to {local_dir}")
    except Exception as e:
        logger.error(f"Failed to download files to {local_dir}: {str(e)}")
        raise


def rename_blob_file(local_path: str, new_blob_path: str, prev_blob_path: str, content_type: str):
    try:
        # Upload new file to blob
        new_blob_url = upload_to_blob(local_path=local_path, blob_path=new_blob_path, content_type=content_type)
        # Delete old blob
        delete_blob_file(prev_blob_path)

        logger.info(f"Blob '{prev_blob_path}' has been renamed to '{new_blob_path}'")

        return new_blob_url
    except Exception as e:
        logger.error(f"Failed to rename {prev_blob_path} on blob storage: {str(e)}")
        raise