from datetime import datetime, timezone
import time
import uuid
import inspect
import httpx
import tiktoken
import math
import re
import json

# For encode image into image_url
import base64
from mimetypes import guess_type
from openai import AzureOpenAI
import time

from ..settings import SETTINGS
from ..utils import (
    normalize_path,
    get_local_file_path, 
    num_tokens_from_string
)
from ..schemas.format import (
    ResponseFormatter,
    Response
)
from ..schemas.preptool import (
    SecretPrepTool,
    KnowDataObject,
    NodeCreate,
    EdgeCreate,
    KnowGraphObject
)

from ..schemas.genai import (
    GenAIRequest, 
    GenAIResponse,
    GenAIRelationshipResponse,
)

from ..schemas.prepmedia import KnowRelationshipObject

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class GenAIServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    """
        Request Operation
    """
    def relationship_extraction(self, request: GenAIRequest) -> tuple[GenAIRelationshipResponse, Response]:
        
        # Use Default if DB PrepTool has no preptool_parameters["user_prompt"]
        default_user_prompt = """YOUR TASK IS TO ANALYZE THE CHUNKS IN A DOCUMENT AND IDENTIFY THE RELATIONSHIP BETWEEN CHUNKS.
          
          ### INSTRUCTIONS
          
          1. Do not request additional information or clarification.
          
          2. All chunks are from the same document. Make every effort to extract the relationship between the chunks based on given context.
          
          3. Respond in English.

          4. Analyze the important relationship between the context of the given chunks. The chunks will be given with the following format:
            Summary Chunk:
            {{"chunk_id": "<C-1>", "content": "<content>"}}
            
            Reference Chunks:
            [
                {{"chunk_id": "<id starting with C->", "content": "<content>"}},
                ...
            ]

          5. Classify the relationships between the Summary Chunk and other Reference Chunks into various relationship types. You can take the refernece from the Reference Relationship Types and create the relationship types for the classification.  
          
          6. If there is no relationship between the Summary chunk and the Reference Chunk, just skip it in your response.

          7. The relationship is directional. You must consider the relationship direction between the source chunk to the targe chunk.

          8. In the classification, you consider the relationship from the Summary Chunk (source) to the Reference Chunks (target) and the relationship from the Reference Chunks (source) to the Summary Chunk (target).

          9. The reply format must be in JSON as follows:
            - If there are relationship between the chunks:
            ```
            [
                {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
            ]
            ```
          
          ### Example Input:
          [
              {{"chunk_id": "<id starting with C->", "content": "<content>"}},
              ...
          ]
          
          ### Example Expected Output (JSON):
          ```
          [
              {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
              {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
          ]
          ```

          ### Reference Relationship Types:
          {relationship}

          ### Chunk Context for Your Analysis:
          {context}
          """
        
        # Use Default if DB PrepTool has no preptool_parameters["relationship"]
        default_relationship_dict = {
            "PREMIUM":     "Indicates that the premium in the summary chunk is referened from the reference chunk.",
            "DURATION":    "Indicates that the duration in the summary chunk is referened from the reference chunk.",
            "DESCRIPTION": "Indicates that the description in the summary chunk is referened from the reference chunk."
        }

        def format_relationship_prompt(data: dict) -> str:
            prompt = "\n".join([f"{key} : {value}" for key, value in data.items()])
            return prompt

        def format_context_prompt(current_data: KnowDataObject, process_data: list[KnowDataObject]) -> str:

            # Create the reference chunk
            reference_chunk = {
                "chunk_id": "C-1",
                "content_type": current_data.content_type
            }

            # Create comparison chunks
            comparison_chunks = [
                {
                    "chunk_id":  f"C-{i}",
                    "content_type": _data.content_type
                }
                for i, _data in enumerate(process_data, start=2)
            ]

            # Construct the prompt
            prompt = f'Reference Chunk:\n{json.dumps(reference_chunk, indent=2)}\nComparison Chunks:\n'

            # Append each comparison chunk
            prompt += '\n'.join(json.dumps(chunk, indent=2) for chunk in comparison_chunks)

            return prompt

        def jsonlize_relationship(text: str) -> list:
            match = re.search(r'```json\n(.*?)\n```', text, re.DOTALL)
            if match:
                json_str = match.group(1)
            else:
                json_str = text  

            try:
                data = json.loads(json_str)

                # Verify Data
                if isinstance(data, list) and all([isinstance(_data, dict) for _data in data]):
                    if all([isinstance(_data["source"], str) and isinstance(_data["target"], str) and isinstance(_data["relationship"], str) for _data in data]):
                        return data

            except json.JSONDecodeError:
                raise json.JSONDecodeError

            except KeyError:
                raise KeyError        

            return []

        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Starts Relationship Extraction")
        response_data  = GenAIRelationshipResponse(**request.__dict__)
        start_at       = time.time()
        know_graph_obj = []

        ### TODO: Add Token Limit Check
        """ 1. Select Engine """
        success_data    = []
        fail_data       = []
        input_tokens    = 0
        output_tokens   = 0
        preptool_engine = None

        if request.preptool.preptool_location.lower() == "azure":
            preptool_engine = self.azure_server
        elif request.preptool.preptool_location.lower() == "server":
            if request.preptool.preptool_engine.lower() == "ollama":
                preptool_engine = self.ollama_server
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))

        if preptool_engine:
            success_nodes = []
            fail_nodes    = []
            edges = []

            """ 2. Assign Node IDs and Node Types """
            for _data in request.data_input:
                _data.__dict__.update(
                    **{
                        "node_id":   _data.data_id,
                        "node_type": "chunk"
                    }
                )

            summary_chunk = request.data_input.pop(0)

            """ 3. Format Relationship Prompt """
            relationship_dict = request.preptool.preptool_parameters.get("relationship", default_relationship_dict)

            relationship_prompt = format_relationship_prompt(data=relationship_dict)

            """ 4. Iterate Over All Chunks to Classify the Relationship """
            node_sequence = 1
            content_windows = self.truncate_content(request.data_input, SETTINGS.PRTL.MODLE_INPUT_TOKEN_LIMIT)
            
            retry_max_no = int(request.preptool.preptool_retry.get("inference_error", 3))
            batch_count  = int(len(content_windows))

            for current_index, process_data in enumerate(content_windows, start=1):
                success_flag = True
                logger.info(f"Processing <{current_index} / {batch_count}> Chunk for Relationship Extraction ...")
                node_edges = []
                
                current_data = summary_chunk
                process_data = process_data
                
                # Prompt Formatting
                context_prompt = format_context_prompt(current_data=current_data, process_data=process_data)
                user_prompt = request.preptool.preptool_parameters.get("user_prompt", default_user_prompt)
                input_prompt = user_prompt.format(relationship=relationship_prompt, context=context_prompt)

                """ 5. Start Inference """
                classified_relationships = []
                retry_count = 1
                while retry_count <= retry_max_no:
                    logger.info(f"Infernece Attempt <{retry_count} / {retry_max_no}> for Extracting Relationship ...")
                    try:
                        _processed_data, _input_tokens, _output_tokens, response = preptool_engine(preptool=request.preptool, prompt=input_prompt)
                        input_tokens  += _input_tokens
                        output_tokens += _output_tokens
                        classified_relationships = jsonlize_relationship(_processed_data)
                        logger.info(f"Success : Infernece Attempt <{retry_count} / {retry_max_no}>")
                        break

                    except:
                        if retry_count > retry_max_no:
                            success_flag = False
                            classified_relationships = []
                            logger.info("Exceeded Maximum Retry. Assigned Empty Relationships by Default")
                            break
                        logger.error(f"LLM Formatting Issue in <{retry_count} / {retry_max_no}> Attempt. Retrying")
                        retry_count += 1


                    """ 6. Map to Node ID """
                    merged_data = [current_data] + process_data
                    mapped_relationships = [
                        {
                            "source": merged_data[int(_relationship.get("source").split('-')[-1])-1].node_id,
                            "target": merged_data[int(_relationship.get("target").split('-')[-1])-1].node_id,
                            "relationship": _relationship.get("relationship")
                        }

                        for _relationship in classified_relationships

                        if (_relationship.get("source") and _relationship.get("target")) and 
                           (_relationship.get("source").split('-')[-1].isdigit() and _relationship.get("target").split('-')[-1].isdigit()) and
                           (1 <= int(_relationship.get("source").split('-')[-1]) <= len(process_data)+1 and 1 <= int(_relationship.get("target").split('-')[-1]) <= len(process_data)+1)
                    ]

                    """ 7. Construct Edge Create Object """
                    node_edges = [
                        EdgeCreate(
                            source_node_id = _relationship.get("source"),
                            target_node_id = _relationship.get("target"),
                            edge_type      = _relationship.get("relationship"),
                            knowledge_id   = current_data.knowledge_id
                        )
                        for _relationship in mapped_relationships
                    ]
                    edges += node_edges
                
                """ 8. Update Node Information """
                nodes = []
                for seq, _data in enumerate(process_data, start=1):
                    node_indegree  = len([_edge for _edge in node_edges if current_data.node_id == _edge.target_node_id])
                    node_outdegree = len([_edge for _edge in node_edges if current_data.node_id == _edge.source_node_id])

                    if node_indegree > 0 or node_outdegree > 0:
                        _node = NodeCreate(
                            _data.__dict__,
                            node_sequence  = node_sequence,
                            node_indegree  = node_indegree,
                            node_outdegree = node_outdegree
                        )
                        nodes.append(_node)
                        node_sequence += 1

                if success_flag == True:
                    success_nodes += nodes
                else:
                    fail_nodes += nodes

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepTool Engine Unfound Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid PreTool"))

        """ 9. Update Relationship Output """
        response_data.__dict__.update(
            **{
                "success_objects": KnowGraphObject(
                    nodes = success_nodes,
                    edges = edges
                ),
                "fail_objects": KnowGraphObject(
                    nodes = fail_nodes,
                    edges = []
                ),
                "preptool_time":          time.time() - start_at,
                "preptool_input_tokens":  input_tokens,
                "preptool_output_tokens": output_tokens,
                "total_no":               len(request.data_input),
                "success_no":             len(success_nodes),
                "fail_no":                len(fail_nodes),
                "response_at":            datetime.now(timezone.utc)
            }
        )
        response = Response(status_code=200, detail=self.response_format.ok(f"GenAI Completed : <{SETTINGS.BASE.APP_NAME}> Completed GenAI Process"))

        return response_data, response

    def batch_relationship_extraction(self, request: GenAIRequest) -> tuple[GenAIRelationshipResponse, Response]:
        
        # Use Default if DB PrepTool has no preptool_parameters["user_prompt"]
        default_user_prompt = """YOU ARE THE WORLD'S BEST INSURANCE AGENT ASSISTANT FROM Prudential Hong Kong. YOUR TASK IS TO ANALYZE THE CHUNKS IN A DOCUMENT AND IDENTIFY THE RELATIONSHIP BETWEEN CHUNKS.
              
              ### INSTRUCTIONS
              
              1. Do not request additional information or clarification.
              
              2. All chunks are from the same document. Make every effort to extract the relationship between the chunks based on given context.
              
              3. Respond in English.

              4. Analyze the relationship between the context of the given chunks. The chunks will be given with the following format:
                Reference Chunks:
                [
                    {{"chunk_id": "<id starting with R->", "data_type": "<text/image/table>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}}
                    ...
                ]
                
                Comparison Chunks:
                [
                    {{"chunk_id": "<id starting with C->", "data_type": "<text/image/table>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}},
                    ...
                ]

              5. Classify the relationships between the Reference Chunks and other Comparison Chunks into the following relationship types. The description of each relationship type is also given for your refernece. 
              
              6. If there is no relationship between the Reference Chunks and the Comparison Chunk, just skip it in your response.

              7. The relationship is directional. You must consider the relationship direction between the source chunk to the targe chunk.

              8. In the classification, you consider the relationship from the Reference Chunks (source) to the Comparison Chunks (target) and the relationship from the Comparison Chunks (source) to the Refernece Chunks (target).

              9. DO NOT classify the chunk relationships within the Reference Chunks and DO NOT classify the chunk relationships within the Comparison Chunks.

              10. For each classified relationship, one chunk must be Reference Chunk and another must be Comparison Chunk. 

              11. If a chunk appeared to be header or footer, DO NOT classify its relationship with other chunks. Just skip the header chunks and footer chunks.

              12. The reply format must be in JSON as follows:
                - If there are relationship between the chunks:
                ```
                [
                    {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                    {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
                ]
                ```
              
              ### Example Input:
              Reference Chunks:
              [
                  {{"chunk_id": "<id starting with R->", "content": "<content>"}},
                  ...
              ]

              Comparsion Chunks:
              [
                  {{"chunk_id": "<id starting with C->", "content": "<content>"}},
                  ...
              ]
              
              ### Example Expected Output (JSON):
              ```
              [
                  {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                  {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
              ]
              ```

              ### Relationship Types:
              {relationship}

              ### Chunk Context for Your Analysis:
              {context}
          """
        
        # Use Default if DB PrepTool has no preptool_parameters["relationship"]
        default_relationship_dict = {
            "SECTION_OF":      "Links subsections to their parent sections.",
            "PART_OF":         "Indicates that a component (like a table or image) belongs to a section or paragraph.",
            "CAUSES":          "Indicates that one concept or event leads to another.",
            "RESULTS_IN":      "Shows the outcome of an event or action described in the text.",
            "DESCRIBES":       "Links a section or paragraph to a concept it elaborates on.",
            "ILLUSTRATES":     "Connects images or tables to the text they visually represent.",
            "SIMILAR_TO":      "Indicates similarities between two concepts or sections.",
            "CONTRASTS_WITH":  "Shows a distinction between two ideas or sections.",
            "REFERENCES":      "Links sections to cited works or other relevant sections within the document.",
            "MENTIONS":        "Connects specific terms or entities within the text to their definitions or explanations.",
            "CONTEXT_OF":      "Provides context for a piece of information, linking it to relevant themes or subjects in the document.",
            "PURPOSE_OF":      "Explains why a section exists or what it aims to achieve.",
            "HAS_ATTRIBUTE":   "Links entities to their properties",
            "IS_DESCRIBED_BY": "Connects terms or sections to their descriptions."
        }

        def format_relationship_prompt(data: dict) -> str:
            prompt = "\n".join([f"{key} : {value}" for key, value in data.items()])
            return prompt

        def format_context_prompt(reference_data: list[KnowDataObject], comparison_data: list[KnowDataObject]) -> str:

            # Create the reference chunk
            reference_chunks = [
                {
                    "chunk_id":     f"R-{i}",
                    "data_type":    _data.data_type,
                    "content_type": _data.content_type,
                    "content":      _data.raw_data,
                    "page":         _data.page_start,
                    "coord_x1":     _data.coord_x1,
                    "coord_x2":     _data.coord_x2,
                    "coord_y1":     _data.coord_y1,
                    "coord_y2":     _data.coord_y2
                }
                for i, _data in enumerate(reference_data, start=1)
            ]

            # Create comparison chunks
            comparison_chunks = [
                {
                    "chunk_id":     f"C-{i}",
                    "data_type":    _data.data_type,
                    "content_type": _data.content_type,
                    "content":      _data.raw_data,
                    "page":         _data.page_start,
                    "coord_x1":     _data.coord_x1,
                    "coord_x2":     _data.coord_x2,
                    "coord_y1":     _data.coord_y1,
                    "coord_y2":     _data.coord_y2
                }
                for i, _data in enumerate(comparison_data, start=1)
            ]

            # Construct the prompt
            prompt = f'Reference Chunks:\n'
            
            prompt += '\n'.join(json.dumps(chunk, indent=2) for chunk in reference_chunks)
            
            prompt += 'Comparison Chunks:\n'

            prompt += '\n'.join(json.dumps(chunk, indent=2) for chunk in comparison_chunks)

            return prompt

        def jsonlize_relationship(text: str) -> list:
            match = re.search(r'```json\n(.*?)\n```', text, re.DOTALL)
            if match:
                json_str = match.group(1)
            else:
                json_str = text  

            try:
                data = json.loads(json_str)

                # Verify Data
                if isinstance(data, list) and all([isinstance(_data, dict) for _data in data]):
                    if all([isinstance(_data["source"], str) and isinstance(_data["target"], str) and isinstance(_data["relationship"], str) for _data in data]):
                        return data

            except json.JSONDecodeError:
                raise json.JSONDecodeError

            except KeyError:
                raise KeyError        

            return []

        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Starts Relationship Extraction")
        response_data  = GenAIRelationshipResponse(**request.__dict__)
        start_at       = time.time()
        know_graph_obj = []

        ### TODO: Add Token Limit Check
        """ 1. Select Engine """
        success_data    = []
        fail_data       = []
        input_tokens    = 0
        output_tokens   = 0
        preptool_engine = None

        if request.preptool.preptool_location.lower() == "azure":
            preptool_engine = self.azure_server
        elif request.preptool.preptool_location.lower() == "server":
            if request.preptool.preptool_engine.lower() == "ollama":
                preptool_engine = self.ollama_server
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))

        if preptool_engine:
            success_nodes = []
            fail_nodes    = []
            edges = []

            """ 2. Assign Node IDs and Node Types """
            for _data in request.data_input:
                _data.__dict__.update(
                    **{
                        "node_id":   _data.data_id,
                        "node_type": "chunk"
                    }
                )

            """ 3. Format Relationship Prompt """
            relationship_dict = request.preptool.preptool_parameters.get("relationship", default_relationship_dict)

            relationship_prompt = format_relationship_prompt(data=relationship_dict)

            """ 4. Iterate Over All Chunks to Classify the Relationship """
            retry_max_no     = int(request.preptool.preptool_retry.get("inference_error", 3))
            batch_size       = int(request.preptool.preptool_parameters.get("batch_size", 5))
            total_data_count = len(request.data_input)
            batch_count      = math.ceil(total_data_count / batch_size)

            for i, batch_index in enumerate(range(0, total_data_count, batch_size), start=1):
                success_flag = True
                logger.info(f"Processing <{i} / {batch_count}> Batch for Relationship Extraction ...")
                
                sub_batch_count = math.ceil((total_data_count - (i-1) * batch_size) / batch_size)
                if sub_batch_count <= 0:
                    sub_batch_count = 1
                node_edges = []

                if total_data_count == 1:
                    continue
                
                for j, sub_batch_index in enumerate(range(batch_index, total_data_count, batch_size), start=1):
                    logger.info(f"Processing <{j} / {sub_batch_count}> Sub-Batch for <{i} / {batch_count}> Batch ...")

                    if total_data_count <= batch_size:
                        _batch_size = total_data_count
                    else:
                        _batch_size = batch_size

                    # First Batch
                    if j == 1:
                        reference_data  = request.data_input[batch_index:(batch_index+int(_batch_size/2))]
                        comparison_data = request.data_input[(batch_index+int(_batch_size/2)):(batch_index+_batch_size)]

                        # Handle Single Node Left
                        if not comparison_data:
                            continue

                    else:
                        reference_data  = request.data_input[batch_index:(batch_index+_batch_size)]
                        comparison_data = request.data_input[sub_batch_index:(sub_batch_index+_batch_size)]

                    # Prompt Formatting
                    while True:
                        context_prompt = format_context_prompt(reference_data=reference_data, comparison_data=comparison_data)
                        user_prompt    = request.preptool.preptool_parameters.get("user_prompt", default_user_prompt)
                        input_prompt   = user_prompt.format(relationship=relationship_prompt, context=context_prompt)
                        prompt_tokens = num_tokens_from_string(input_prompt)
                        if prompt_tokens > SETTINGS.GEAI.MODEL_TOKEN_LIMIT:
                            comparison_data = comparison_data[:len(comparison_data)-1]
                        else:
                            break

                    """ 5. Start Inference """
                    classified_relationships = []
                    retry_count = 1
                    while retry_count <= retry_max_no:
                        logger.info(f"Infernece Attempt <{retry_count} / {retry_max_no}> for Extracting Relationship ...")
                        try:
                            _processed_data, _input_tokens, _output_tokens, response = preptool_engine(preptool=request.preptool, prompt=input_prompt)
                            input_tokens  += _input_tokens
                            output_tokens += _output_tokens
                            time.sleep(SETTINGS.GEAI.INFERENCE_INTERVAL)
                            classified_relationships = jsonlize_relationship(_processed_data)
                            logger.info(f"Success : Infernece Attempt <{retry_count} / {retry_max_no}>")
                            break

                        except:
                            if retry_count > retry_max_no:
                                success_flag = False
                                classified_relationships = []
                                logger.info("Exceeded Maximum Retry. Assigned Empty Relationships by Default")
                                break
                            logger.error(f"LLM Formatting Issue in <{retry_count} / {retry_max_no}> Attempt. Retrying")
                            retry_count += 1

                    """ 6. Map to Node ID """
                    mapped_relationships = []
                    for _relationship in classified_relationships:
                        if (_relationship.get("source") \
                            and _relationship.get("target")) \
                            and (_relationship.get("source").split('-')[-1].isdigit() \
                            and _relationship.get("target").split('-')[-1].isdigit()):

                            source_chunk_type  = str(_relationship.get("source").split('-')[0]).upper()
                            source_chunk_order = int(_relationship.get("source").split('-')[-1])
                            target_chunk_type  = str(_relationship.get("target").split('-')[0]).upper()
                            target_chunk_order = int(_relationship.get("target").split('-')[-1])

                            if source_chunk_type == 'R' and source_chunk_order <= len(reference_data):
                                source = reference_data[source_chunk_order-1].node_id
                            elif source_chunk_type == 'C' and source_chunk_order <= len(comparison_data):
                                source = comparison_data[source_chunk_order-1].node_id
                            else:
                                source = None

                            if target_chunk_type.upper() == 'R' and target_chunk_order <= len(reference_data):
                                target = reference_data[target_chunk_order-1].node_id
                            elif target_chunk_type.upper() == 'C' and target_chunk_order <= len(comparison_data):
                                target = comparison_data[target_chunk_order-1].node_id
                            else:
                                target = None

                            if source and target:
                                mapped_relationships.append(
                                    {
                                        "source": source,
                                        "target": target,
                                        "relationship": _relationship.get("relationship")
                                    }
                                )

                    """ 7. Construct Edge Create Object """
                    node_edges = [
                        EdgeCreate(
                            source_node_id = _relationship.get("source"),
                            target_node_id = _relationship.get("target"),
                            edge_type      = _relationship.get("relationship"),
                            knowledge_id   = reference_data[0].knowledge_id
                        )
                        for _relationship in mapped_relationships
                    ]
                    edges += node_edges
                    
                """ 8. Update Node Information """
                nodes = [
                    NodeCreate(
                        **current_data.__dict__, 
                        node_sequence  = batch_index + seq,
                        node_indegree  = len([_edge for _edge in node_edges if current_data.node_id == _edge.target_node_id]),
                        node_outdegree = len([_edge for _edge in node_edges if current_data.node_id == _edge.source_node_id])
                    )
                    for seq, current_data in enumerate(request.data_input[batch_index:(batch_index+batch_size)], start=1)
                ]

                if success_flag == True:
                    success_nodes += nodes
                else:
                    fail_nodes += nodes

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepTool Engine Unfound Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid PreTool"))

        """ 9. Update Relationship Output """
        response_data.__dict__.update(
            **{
                "success_objects": KnowGraphObject(
                    nodes = success_nodes,
                    edges = edges
                ),
                "fail_objects": KnowGraphObject(
                    nodes = fail_nodes,
                    edges = []
                ),
                "preptool_time":          time.time() - start_at,
                "preptool_input_tokens":  input_tokens,
                "preptool_output_tokens": output_tokens,
                "total_no":               len(request.data_input),
                "success_no":             len(success_nodes),
                "fail_no":                len(fail_nodes),
                "response_at":            datetime.now(timezone.utc)
            }
        )
        response = Response(status_code=200, detail=self.response_format.ok(f"GenAI Completed : <{SETTINGS.BASE.APP_NAME}> Completed GenAI Process"))

        return response_data, response

    def exhaustive_relationship_extraction(self, request: GenAIRequest) -> tuple[GenAIRelationshipResponse, Response]:
        
        # Use Default if DB PrepTool has no preptool_parameters["user_prompt"]
        default_user_prompt = """YOU ARE THE WORLD'S BEST INSURANCE AGENT ASSISTANT FROM Prudential Hong Kong. YOUR TASK IS TO ANALYZE THE CHUNKS IN A DOCUMENT AND IDENTIFY THE RELATIONSHIP BETWEEN CHUNKS.
          
          ### INSTRUCTIONS
          
          1. Do not request additional information or clarification.
          
          2. All chunks are from the same document. Make every effort to extract the relationship between the chunks based on given context.
          
          3. Respond in English.

          4. Analyze the relationship between the context of the given chunks. The chunks will be given with the following format:
            Reference Chunk:
            {{"chunk_id": "<C-1>", "data_type": "<text/image/table>", "content_type": "<default, OCR, image2text, etc.>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}}
            
            Comparison Chunks:
            [
                {{"chunk_id": "<id starting with C->", "data_type": "<text/image/table>", "content_type": "<default, OCR, image2text, etc.>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}},
                ...
            ]

          5. Classify the relationships between the Reference Chunk and other Comparison Chunks into the following relationship types. The description of each relationship type is also given for your refernece. 
          
          6. If there is no relationship between the Reference chunk and the Comparison Chunk, just skip it in your response.

          7. The relationship is directional. You must consider the relationship direction between the source chunk to the targe chunk.

          8. In the classification, you consider the relationship from the Reference Chunk (source) to the Comparison Chunks (target) and the relationship from the Comparison Chunks (source) to the Refernece Chunk (target).

          9. The reply format must be in JSON as follows:
            - If there are relationship between the chunks:
            ```
            [
                {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
            ]
            ```
          
          ### Example Input:
          [
              {{"chunk_id": "<id starting with C->", "content": "<content>"}},
              ...
          ]
          
          ### Example Expected Output (JSON):
          ```
          [
              {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
              {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
          ]
          ```

          ### Relationship Types:
          {relationship}

          ### Chunk Context for Your Analysis:
          {context}
          """
        
        # Use Default if DB PrepTool has no preptool_parameters["relationship"]
        default_relationship_dict = {
            "SECTION_OF":      "Links subsections to their parent sections.",
            "PART_OF":         "Indicates that a component (like a table or image) belongs to a section or paragraph.",
            "CAUSES":          "Indicates that one concept or event leads to another.",
            "RESULTS_IN":      "Shows the outcome of an event or action described in the text.",
            "DESCRIBES":       "Links a section or paragraph to a concept it elaborates on.",
            "ILLUSTRATES":     "Connects images or tables to the text they visually represent.",
            "SIMILAR_TO":      "Indicates similarities between two concepts or sections.",
            "CONTRASTS_WITH":  "Shows a distinction between two ideas or sections.",
            "REFERENCES":      "Links sections to cited works or other relevant sections within the document.",
            "MENTIONS":        "Connects specific terms or entities within the text to their definitions or explanations.",
            "CONTEXT_OF":      "Provides context for a piece of information, linking it to relevant themes or subjects in the document.",
            "PURPOSE_OF":      "Explains why a section exists or what it aims to achieve.",
            "HAS_ATTRIBUTE":   "Links entities to their properties",
            "IS_DESCRIBED_BY": "Connects terms or sections to their descriptions."
        }

        def format_relationship_prompt(data: dict) -> str:
            prompt = "\n".join([f"{key} : {value}" for key, value in data.items()])
            return prompt

        def format_context_prompt(current_data: KnowDataObject, process_data: list[KnowDataObject]) -> str:

            # Create the reference chunk
            reference_chunk = {
                "chunk_id": "C-1",
                "data_type":    current_data.data_type,
                "content_type": current_data.content_type,
                "content":      current_data.raw_data,
                "page":         current_data.page_start,
                "coord_x1":     current_data.coord_x1,
                "coord_x2":     current_data.coord_x2,
                "coord_y1":     current_data.coord_y1,
                "coord_y2":     current_data.coord_y2
            }

            # Create comparison chunks
            comparison_chunks = [
                {
                    "chunk_id":  f"C-{i}",
                    "data_type":    _data.data_type,
                    "content_type": _data.content_type,
                    "content":      _data.raw_data,
                    "page":         _data.page_start,
                    "coord_x1":     _data.coord_x1,
                    "coord_x2":     _data.coord_x2,
                    "coord_y1":     _data.coord_y1,
                    "coord_y2":     _data.coord_y2
                }
                for i, _data in enumerate(process_data, start=2)
            ]

            # Construct the prompt
            prompt = f'Reference Chunk:\n{json.dumps(reference_chunk, indent=2)}\nComparison Chunks:\n'

            # Append each comparison chunk
            prompt += '\n'.join(json.dumps(chunk, indent=2) for chunk in comparison_chunks)

            return prompt

        def jsonlize_relationship(text: str) -> list:
            match = re.search(r'```json\n(.*?)\n```', text, re.DOTALL)
            if match:
                json_str = match.group(1)
            else:
                json_str = text  

            try:
                data = json.loads(json_str)

                # Verify Data
                if isinstance(data, list) and all([isinstance(_data, dict) for _data in data]):
                    if all([isinstance(_data["source"], str) and isinstance(_data["target"], str) and isinstance(_data["relationship"], str) for _data in data]):
                        return data

            except json.JSONDecodeError:
                raise json.JSONDecodeError

            except KeyError:
                raise KeyError        

            return []

        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Starts Relationship Extraction")
        response_data  = GenAIRelationshipResponse(**request.__dict__)
        start_at       = time.time()
        know_graph_obj = []

        ### TODO: Add Token Limit Check
        """ 1. Select Engine """
        success_data    = []
        fail_data       = []
        input_tokens    = 0
        output_tokens   = 0
        preptool_engine = None

        if request.preptool.preptool_location.lower() == "azure":
            preptool_engine = self.azure_server
        elif request.preptool.preptool_location.lower() == "server":
            if request.preptool.preptool_engine.lower() == "ollama":
                preptool_engine = self.ollama_server
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))

        if preptool_engine:
            success_nodes = []
            fail_nodes    = []
            edges = []

            """ 2. Assign Node IDs and Node Types """
            for _data in request.data_input:
                _data.__dict__.update(
                    **{
                        "node_id":   _data.data_id,
                        "node_type": "chunk"
                    }
                )

            """ 3. Format Relationship Prompt """
            relationship_dict = request.preptool.preptool_parameters.get("relationship", default_relationship_dict)

            relationship_prompt = format_relationship_prompt(data=relationship_dict)

            """ 4. Iterate Over All Chunks to Classify the Relationship """
            retry_max_no     = int(request.preptool.preptool_retry.get("inference_error", 3))
            batch_size       = int(request.preptool.preptool_parameters.get("batch_size", 5))
            total_data_count = len(request.data_input)

            for current_index, current_data in enumerate(request.data_input, start=1):
                success_flag = True
                logger.info(f"Processing <{current_index} / {total_data_count}> Chunk for Relationship Extraction ...")
                current_batch_count = math.ceil((total_data_count - current_index) / batch_size)
                node_edges = []
                
                for _batch, index in enumerate(range(current_index, total_data_count, batch_size), start=1):
                    logger.info(f"Processing <{_batch} / {current_batch_count}> Batch for <{current_index} / {total_data_count}> Chunk ...")
                    
                    process_data = request.data_input[index : index + batch_size]
                    
                    # Prompt Formatting
                    context_prompt = format_context_prompt(current_data=current_data, process_data=process_data)
                    user_prompt = request.preptool.preptool_parameters.get("user_prompt", default_user_prompt)
                    input_prompt = user_prompt.format(relationship=relationship_prompt, context=context_prompt)

                    """ 5. Start Inference """
                    classified_relationships = []
                    retry_count = 1
                    while retry_count <= retry_max_no:
                        logger.info(f"Infernece Attempt <{retry_count} / {retry_max_no}> for Extracting Relationship ...")
                        try:
                            _processed_data, _input_tokens, _output_tokens, response = preptool_engine(preptool=request.preptool, prompt=input_prompt)
                            input_tokens  += _input_tokens
                            output_tokens += _output_tokens
                            classified_relationships = jsonlize_relationship(_processed_data)
                            logger.info(f"Success : Infernece Attempt <{retry_count} / {retry_max_no}>")
                            break

                        except:
                            if retry_count > retry_max_no:
                                success_flag = False
                                classified_relationships = []
                                logger.info("Exceeded Maximum Retry. Assigned Empty Relationships by Default")
                                break
                            logger.error(f"LLM Formatting Issue in <{retry_count} / {retry_max_no}> Attempt. Retrying")
                            retry_count += 1


                    """ 6. Map to Node ID """
                    merged_data = [current_data] + process_data
                    mapped_relationships = [
                        {
                            "source": merged_data[int(_relationship.get("source").split('-')[-1])-1].node_id,
                            "target": merged_data[int(_relationship.get("target").split('-')[-1])-1].node_id,
                            "relationship": _relationship.get("relationship")
                        }

                        for _relationship in classified_relationships

                        if (_relationship.get("source") and _relationship.get("target")) and 
                           (_relationship.get("source").split('-')[-1].isdigit() and _relationship.get("target").split('-')[-1].isdigit()) and
                           (1 <= int(_relationship.get("source").split('-')[-1]) <= batch_size and 1 <= int(_relationship.get("target").split('-')[-1]) <= batch_size)
                    ]

                    """ 7. Construct Edge Create Object """
                    node_edges = [
                        EdgeCreate(
                            source_node_id = _relationship.get("source"),
                            target_node_id = _relationship.get("target"),
                            edge_type      = _relationship.get("relationship"),
                            knowledge_id   = current_data.knowledge_id
                        )
                        for _relationship in mapped_relationships
                    ]
                    edges += node_edges
                
                """ 8. Update Node Information """
                node = NodeCreate(
                    **current_data.__dict__, 
                    node_sequence  = current_index,
                    node_indegree  = len([_edge for _edge in node_edges if current_data.node_id == _edge.target_node_id]),
                    node_outdegree = len([_edge for _edge in node_edges if current_data.node_id == _edge.source_node_id])
                )
                if success_flag == True:
                    success_nodes.append(node)
                else:
                    fail_nodes.append(node)

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepTool Engine Unfound Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid PreTool"))

        """ 9. Update Relationship Output """
        response_data.__dict__.update(
            **{
                "success_objects": KnowGraphObject(
                    nodes = success_nodes,
                    edges = edges
                ),
                "fail_objects": KnowGraphObject(
                    nodes = fail_nodes,
                    edges = []
                ),
                "preptool_time":          time.time() - start_at,
                "preptool_input_tokens":  input_tokens,
                "preptool_output_tokens": output_tokens,
                "total_no":               len(request.data_input),
                "success_no":             len(success_nodes),
                "fail_no":                len(fail_nodes),
                "response_at":            datetime.now(timezone.utc)
            }
        )
        response = Response(status_code=200, detail=self.response_format.ok(f"GenAI Completed : <{SETTINGS.BASE.APP_NAME}> Completed GenAI Process"))

        return response_data, response


    def image_to_text(self, request: GenAIRequest) -> tuple[GenAIResponse, Response]:
        response_data = GenAIResponse()
        start_at      = time.time()

        ### TODO: Add Token Limit Check
        """ 1. Perform Token Limit Check for the raw_data"""
        if not all([raw_data.data_url for raw_data in request.data_input]):
            response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI due to Missing Image URL"))
            logger.error(response.detail)
            return response_data, response
        
        """ 2. Select Engine """
        success_data    = []
        fail_data       = []
        input_tokens    = 0
        output_tokens   = 0
        preptool_engine = None

        if request.preptool.preptool_location.lower() == "azure":
            preptool_engine = self.azure_server
            
        elif request.preptool.preptool_location.lower() == "server":
            
            if request.preptool.preptool_engine.lower() == "ollama":
                preptool_engine = self.ollama_server
                
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))

        """ 3. GenAI Data """
        if preptool_engine:
            for data in request.data_input:
                local_image_path = normalize_path(get_local_file_path(data.data_url))
                _processed_data, _input_tokens, _output_tokens, response = preptool_engine(preptool=request.preptool, image_path=local_image_path)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    fail_data.append(data)
                    logger.error(f"{response.detail} --- {data.data_url}")
                    break
                else:
                    success_data.append(_processed_data)

                input_tokens  += _input_tokens
                output_tokens += _output_tokens

        # 3.1. GenAI Completed but Encountered Different Lengths between Raw Data and Processed Data
        if len(request.data_input) != len(success_data):
            response  = Response(status_code=500, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Found Unequal Number between Raw Data and Processed Data"))
            logger.error(response.detail)
            return response_data, response
        
        # 3.2. GenAI Success 
        else:
            for _data_obj, _processed_data in zip(request.data_input, success_data):
                _data_obj.__dict__.update(raw_data=_processed_data, data_length=len(_processed_data), content_type=request.preptool.preptool_type)
            success_data = request.data_input
            response = Response(status_code=200, detail=self.response_format.ok(f"GenAI Completed : <{SETTINGS.BASE.APP_NAME}> Completed GenAI Process"))
            logger.info(response.detail)

        ### TODO: Add tokens count
        """ 5. Process Data """
        response_data.__dict__.update(
            preptool_time          = time.time() - start_at,
            preptool_input_tokens  = input_tokens,
            preptool_output_tokens = output_tokens,
            success_objects        = success_data,
            fail_objects           = fail_data,
            total_no               = len(request.data_input),
            success_no             = len(success_data),
            fail_no                = len(fail_data),
            response_at            = datetime.now(timezone.utc)
        )

        return response_data, response

    def table_to_text(self, request: GenAIRequest) -> tuple[GenAIResponse, Response]:
        response_data = GenAIResponse()
        start_at      = time.time()

        """ 1. Perform Token Limit Check for the raw_data"""
        if not all([data.data_url for data in request.data_input]):
            response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI due to Missing Table URL"))
            logger.error(response.detail)
            return response_data, response
        
        """ 2. Select Engine """
        success_data    = []
        fail_data       = []
        input_tokens    = 0
        output_tokens   = 0
        preptool_engine = None
        max_embedding_token_size = 2000

        if request.preptool.preptool_location.lower() == "azure":
            preptool_engine = self.azure_server
            
        elif request.preptool.preptool_location.lower() == "server":
            
            if request.preptool.preptool_engine.lower() == "ollama":
                preptool_engine = self.ollama_server
                
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform GenAI <{request.preptool.preptool_engine}>"))

        """ 3. GenAI Data """
        if preptool_engine:
            for data in request.data_input:
                _processed_data = data.raw_data.strip()
                data_token_size = num_tokens_from_string(_processed_data)
                if not _processed_data or data_token_size >= max_embedding_token_size:
                    local_image_path = normalize_path(get_local_file_path(data.data_url))
                    _processed_data, _input_tokens, _output_tokens, response = preptool_engine(preptool=request.preptool, image_path=local_image_path)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        fail_data.append(data)
                        logger.error(f"{response.detail} --- {data.data_url}")
                        break
                    input_tokens  += _input_tokens
                    output_tokens += _output_tokens
                success_data.append(_processed_data)

        # 3.1. GenAI Completed but Encountered Different Lengths between Raw Data and Processed Data
        if len(request.data_input) != len(success_data):
            response  = Response(status_code=500, detail=self.response_format.error(f"GenAI Processing Error : <{SETTINGS.BASE.APP_NAME}> Found Unequal Number between Raw Data and Processed Data"))
            logger.error(response.detail)
            return response_data, response
        
        # 3.2. GenAI Success 
        else:
            for _data_obj, _processed_data in zip(request.data_input, success_data):
                _data_obj.__dict__.update(raw_data=_processed_data, data_length=len(_processed_data), content_type=request.preptool.preptool_type)
            success_data = request.data_input
            response = Response(status_code=200, detail=self.response_format.ok(f"GenAI Completed : <{SETTINGS.BASE.APP_NAME}> Completed GenAI Process"))
            logger.info(response.detail)

        """ 5. Process Data """
        response_data.__dict__.update(
            preptool_time          = time.time() - start_at,
            preptool_input_tokens  = input_tokens,
            preptool_output_tokens = output_tokens,
            success_objects        = success_data,
            fail_objects           = fail_data,
            total_no               = len(request.data_input),
            success_no             = len(success_data),
            fail_no                = len(fail_data),
            response_at            = datetime.now(timezone.utc)
        )

        return response_data, response


    def ollama_server(self, preptool: SecretPrepTool, prompt: str='', image_path: str | None = None) -> tuple[str, int, int, Response]:
        processed_data = ""
        input_tokens   = 0
        output_tokens  = 0

        payload = dict()

        # Model Options
        options = dict()
        if preptool.preptool_parameters.get("options", None):
            options.update(preptool.preptool_parameters.get("options"))
        if preptool.preptool_secrets.get("options", None):
            options.update(preptool.preptool_secrets.get("options"))
        if options:
            payload["options"] = options
        
        # Prompt Fomration
        formatted_prompt = ""

        # System Prompt Formation
        if preptool.preptool_parameters.get("system_prompt", None):
            formatted_prompt += "System:\n" + preptool.preptool_parameters.get("system_prompt", "")

        # User Prompt Formation
        user_prompt = ""
        if prompt:
            user_prompt = prompt
        elif not prompt and preptool.preptool_parameters.get("user_prompt", None):
            user_prompt = preptool.preptool_parameters.get("user_prompt")
        else:
            user_prompt = "Describe the Image"

        formatted_prompt += "User:\n" + user_prompt

        # formatted_prompt = ""
        # model_keywords = preptool.preptool_parameters.get("model_keywords", {})
        
        # # System Prompt Formation
        # if preptool.preptool_parameters.get("system_prompt", None):
        #     system_prompt = preptool.preptool_secrets.get("system_prompt", "")
            
        #     if system_prompt:
        #         system_role_prompt = model_keywords.get("role_start", "") + 'system' + model_keywords.get("role_end", "")
        #         system_content     = model_keywords.get("content_start", "") + system_prompt + model_keywords.get("content_end", "")
        #         formatted_prompt   += system_role_prompt + system_content
        
        # # User Prompt Formation
        # user_prompt = ""
        # if prompt:
        #     user_prompt = prompt
        
        # elif not prompt and preptool.preptool_parameters.get("user_prompt", None):
        #     user_prompt = preptool.preptool_parameters.get("user_prompt", "Describe the Image")
        
        # if user_prompt:
        #     user_role_prompt = model_keywords.get("role_start", "") + 'user' + model_keywords.get("role_end", "")
        #     user_content     = model_keywords.get("content_start", "") + user_prompt + model_keywords.get("content_end", "")
        #     formatted_prompt += user_role_prompt + user_content


        
        # # System Prompt Formation
        # if preptool.preptool_parameters.get("system_prompt", None):
        #     system_prompt = preptool.preptool_secrets.get("system_prompt", "")
            
        # formatted_prompt = ""
        # model_keywords = preptool.preptool_parameters.get("model_keywords", {})
        
        # # System Prompt Formation
        # if preptool.preptool_parameters.get("system_prompt", None):
        #     system_prompt = preptool.preptool_secrets.get("system_prompt", "")
            
        #     if system_prompt:
        #         system_role_prompt = model_keywords.get("role_start", "") + 'system' + model_keywords.get("role_end", "")
        #         system_content     = model_keywords.get("content_start", "") + system_prompt + model_keywords.get("content_end", "")
        #         formatted_prompt   += system_role_prompt + system_content
        
        # # User Prompt Formation
        # user_prompt = ""
        # if prompt:
        #     user_prompt = prompt
        
        # elif not prompt and preptool.preptool_parameters.get("user_prompt", None):
        #     user_prompt = preptool.preptool_parameters.get("user_prompt", "Describe the Image")
        
        # if user_prompt:
        #     user_role_prompt = model_keywords.get("role_start", "") + 'user' + model_keywords.get("role_end", "")
        #     user_content     = model_keywords.get("content_start", "") + user_prompt + model_keywords.get("content_end", "")
        #     formatted_prompt += user_role_prompt + user_content
        
        # Multimedia Formation
        if image_path:
            encoded_images = []
            try:
                with open(image_path, "rb") as image_file:
                    base64_data = base64.b64encode(image_file.read()).decode('utf-8')
                    encoded_images.append(base64_data)
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Image Encoding Error : <{SETTINGS.BASE.APP_NAME}> Failed to Read / Encode Images"))
                logger.error(response.detail)
            payload["images"] = encoded_images

        payload["model"]  = preptool.preptool_base
        payload["prompt"] = formatted_prompt
        payload["stream"] = False
        payload["raw"]    = False

        api_url = f"http://{preptool.preptool_host}:{preptool.preptool_port}/{preptool.preptool_api}"
        
        # Post Request to Inference Server
        try:
            resp   = httpx.post(api_url, json=payload, timeout=SETTINGS.PRTL.GENAI_TIMEOUT)
            result = resp.json()

            # Error during Calling Inference Server
            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=result["error"])
                logger.error(response.detail)
                return processed_data, input_tokens, output_tokens, response

            # Update Ouptut
            processed_data = result.get("response", "")
            input_tokens   = result.get("prompt_eval_count", 0)
            output_tokens  = result.get("eval_count", 0)
            response = Response(status_code=200, detail=self.response_format.ok(f"GenAI Success : <{SETTINGS.BASE.APP_NAME}> Completed GenAI"))

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)

        return processed_data, input_tokens, output_tokens, response


    def azure_server(self, preptool: SecretPrepTool, prompt: str='', image_path: str | None = None) -> tuple[str, int, int, Response]:
        processed_data = "Unknown"
        input_tokens   = 0
        output_tokens  = 0

        payload = dict()

        # Model Options
        # options = dict()
        # if request.preptool_parameters:
        #     options.update(request.preptool_parameters)
        # if options:
        #     payload["options"] = options
    
        # System Prompt Formation
        messages = []
        if preptool.preptool_secrets.get("system_prompt", None):
            messages.append({"role": "system", "content": preptool.preptool_secrets["system_prompt"]})

        # User Prompt Formation
        if not prompt and preptool.preptool_parameters.get("user_prompt"):
            prompt = preptool.preptool_parameters.get("user_prompt")
        user_content = [{"type": "text", "text": prompt}]

        # Multimedia Formation
        if image_path:
            user_content.append({"type": "image_url", "image_url": {"url": self.local_image_to_data_url(image_path)}})

        user_prompt = {"role": "user", "content": user_content}
        messages.append(user_prompt)

        payload["model"]    = preptool.preptool_base
        payload["messages"] = messages
        payload["max_tokens"] =preptool.preptool_parameters.get("max_tokens", 4000)

        api_url = f"{preptool.preptool_host}/{preptool.preptool_port}"

        genai_client = AzureOpenAI(
            api_key         = preptool.preptool_secrets.get("api_key", "dummy-key"),
            api_version     = preptool.preptool_secrets.get("api_version", ""),
            azure_endpoint  = api_url,
            default_headers = preptool.preptool_secrets.get("header", {})
        )
        # Post Request to Server
        try:
            resp = genai_client.chat.completions.create(
                model     = payload["model"],
                max_tokens= payload["max_tokens"],
                messages  = payload["messages"]
            )

            # Error during Calling Server
            if not resp or not resp.choices:
                e = "Unknown Error"
                response = Response(status_code=500, detail=self.response_format.error(f"Azure GenAI Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve GenAI Data from Azure Server", str(e)))
                logger.error(response.detail)
                return processed_data, input_tokens, output_tokens, response

            # Update Ouptut
            processed_data = resp.choices[0].message.content
            if not processed_data:
                processed_data = "No content"
            input_tokens   = resp.usage.prompt_tokens
            output_tokens  = resp.usage.completion_tokens
            response = Response(status_code=200, detail=self.response_format.ok(f"GenAI Success : <{SETTINGS.BASE.APP_NAME}> Completed GenAI"))

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Azure Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Azure Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Azure Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Azure Server", str(e)))
            logger.error(response.detail)

        return processed_data, input_tokens, output_tokens, response

    @staticmethod
    def local_image_to_data_url(image_path: str) -> str:

        # Guess the Mime type of the image based on the File Extension
        mime_type, _ = guess_type(image_path)
        if mime_type is None:
            mime_type = 'application/octet-stream'
        
        # Read and Encode Image
        with open(image_path, "rb") as image_file:
            encoded_iamge = base64.b64encode(image_file.read()).decode("utf-8")
        
        # Construct the data URL
        return f"data:{mime_type};base64,{encoded_iamge}"

    def truncate_content(self, content: list, max_token: int=SETTINGS.PRTL.MODLE_INPUT_TOKEN_LIMIT) -> list[list]:
        windows = []
        current_window = []
        current_token = 0

        # Token Check
        encoding = tiktoken.encoding_for_model("gpt-4o")

        for _content in content:
            text = _content.raw_data
            text_token =len(encoding.encode(text))

            if current_token + text_token > max_token:
                windows.append(current_window)
                current_window = [_content]
                current_token = text_token
            else:
                current_window.append(_content)
                current_token += text_token

        if current_window:
            windows.append(current_window)

        return windows
    
    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response


