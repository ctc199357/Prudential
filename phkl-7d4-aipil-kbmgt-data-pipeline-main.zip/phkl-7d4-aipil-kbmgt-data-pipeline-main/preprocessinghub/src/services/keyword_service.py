from datetime import datetime, timezone
import time
import inspect
import httpx
from openai import AzureOpenAI
import json
import re
from ..settings import SETTINGS
from ..schemas.format import ResponseFormatter, Response
from ..schemas.keywords import (
    KeywordEngine, 
    KeywordTextRequest, 
    KeywordTextResponse,
)
from ..logger.log_handler import get_logger
from ..schemas.preptool import SecretPrepTool, KnowDataObject
from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient
import tiktoken

logger = get_logger(__name__)

class KeywordServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, engine: KeywordEngine | None = None):
        self.engine = engine

    def init_engine(self, config: SecretPrepTool) -> Response:
        self.engine = KeywordEngine(**config.__dict__)

        if self.engine.preptool_location.lower() == "azure":
            response = Response(status_code=200, detail=self.response_format.ok(f"Init Keyword Extraction Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Keyword Engine in Azure"))
        elif self.engine.preptool_location.lower() == "server":
            response = Response(status_code=200, detail=self.response_format.ok(f"Init Keyword Extraction Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Keyword Engine in Server"))
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Init Keyword Engine Error : <{SETTINGS.BASE.APP_NAME}> Cannot Recognize Keyword Engine Location <{self.engine.preptool_location}>"))

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            logger.error(response.detail)

        return response
    

    def text_keyword(self, request: KeywordTextRequest) -> tuple[KeywordTextResponse, Response]:
        response_data = KeywordTextResponse()
        start_at = time.time()

        """ 1. Init Keyword Engine """
        response = self.init_engine(config=request.preptool)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response

        """ 2. Extract Keywords """
        success_data = []
        fail_data = []
        tool_tokens = 0

        if self.engine.preptool_location.lower() == "azure":
            processed_data, tool_tokens, response = self.azure_server(raw_data=[_data.raw_data for _data in request.data_input])
            
        elif self.engine.preptool_location.lower() == "server":
            
            if self.engine.preptool_engine.lower() == "ollama":
                processed_data, tool_tokens, response = self.ollama_server(raw_data=[_data.raw_data for _data in request.data_input])
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Keyword Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform Keyword <{self.engine.preptool_engine}>"))

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Keyword Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform Keyword <{self.engine.preptool_engine}>"))
            return response_data, response

        """ 3. Update result """
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response

        # Update the KnowDataObjects with keywords and detected languages
        for data_obj, keywords in zip(request.data_input, processed_data):
            data_obj.__dict__.update(
                data_keywords=keywords
            )
            success_data.append(data_obj)

        """ 4. Process Response """
        response_data.__dict__.update(
            preptool_time = time.time() - start_at,
            preptool_tool_tokens = tool_tokens,
            success_objects = success_data,
            fail_objects = fail_data,
            total_no = len(request.data_input),
            success_no = len(success_data),
            fail_no = len(fail_data),
            response_at = datetime.now(timezone.utc)
        )

        return response_data, response


    # def rerank_keyword(self, request: KeywordTextRequest) -> tuple[KeywordTextResponse, Response]:
    #     """
    #     Count occurrences of keywords across all documents and return the top ones.
    #     """
    #     logger.info("Processing : Start Reranking Keywords for Document")
    #     response_data = KeywordTextResponse()
    #     start_at = time.time()
    #     success_data = request.data_input
    #     fail_data = []
    #     tool_tokens = 0

    #     keyword_lists = []
    #     keyword_languages = set()
    #     if request.data_input:
    #         for _data in request.data_input:
    #             if _data.data_keywords:
    #                 keyword_lists.append(_data.data_keywords)
    #             if _data.data_languages:
    #                 for lang in _data.data_languages:
    #                     keyword_languages.add(lang)
    #     # Validate input
    #     if not keyword_lists:
    #         response = Response(status_code=200, detail=self.response_format.ok(f"No keyword : <{SETTINGS.BASE.APP_NAME}> Empty keyword lists provided"))
    #         logger.info(response.detail)
    #     else:
    #         # Flatten the list of lists and count occurrences
    #         keyword_counter = {}
    #         for keyword_list in keyword_lists:
    #             for keyword in keyword_list:
    #                 if keyword.strip():  # Skip empty keywords
    #                     keyword_counter[keyword] = keyword_counter.get(keyword, 0) + 1
            
    #         # Sort by count (descending) and get top keywords
    #         sorted_keywords = sorted(
    #             keyword_counter.items(), 
    #             key=lambda item: item[1], 
    #             reverse=True
    #         )[:request.preptool.preptool_parameters.get("limit", 20)]
        
    #         if not sorted_keywords:
    #             # fail_data.append(request.data_input)
    #             # response = Response(status_code=400, detail=self.response_format.error(f"No keywords found in the provided lists"))
    #             # logger.error(response.detail)
    #             sorted_keywords = []
            
    #         # tool_tokens = sum(len(keyword) for keyword in sorted_keywords)

    #         # Update the document KnowDataObjects with keywords if exists, else create new KnowDataObject and append to success_data
    #         sorted_keywords = [_keyword[0] for _keyword in sorted_keywords]
    #         document_index  = [i for i, _data_obj in enumerate(request.data_input) if _data_obj.data_type.upper() == "DOCUMENT"]
    #         if document_index:
    #             request.data_input[document_index[0]].__dict__.update(data_keywords=sorted_keywords, data_languages=list(keyword_languages))
    #         else:
    #             document_obj = KnowDataObject(
    #                 knowledge_id=request.data_input[0].knowledge_id,
    #                 raw_data="Summary",
    #                 data_keywords=sorted_keywords,
    #                 data_languages=list(keyword_languages),
    #                 data_type="DOCUMENT",
    #                 content_type="summarization"                        
    #             )
    #             success_data.append(document_obj)
    #         response = Response(status_code=200, detail=self.response_format.ok(f"Top Keywords Retrieved : <{SETTINGS.BASE.APP_NAME}> Found {len(sorted_keywords)} keywords"))

    #     """ 4. Process Response """
    #     response_data.__dict__.update(
    #         preptool_time = time.time() - start_at,
    #         preptool_tool_tokens = tool_tokens,
    #         success_objects = success_data,
    #         fail_objects = fail_data,
    #         total_no = len(request.data_input),
    #         success_no = len(success_data),
    #         fail_no = len(fail_data),
    #         response_at = datetime.now(timezone.utc)
    #     )

    #     return response_data, response

    def rerank_keyword(self, request: KeywordTextRequest) -> tuple[KeywordTextResponse, Response]:
        logger.info("Processing : Start Extract Keywords for Document")
        response_data = KeywordTextResponse()
        start_at = time.time()
        success_data = request.data_input
        fail_data = []
        tool_tokens = 0

        if not request.data_input:
            response_data.__dict__.update(
                preptool_time=time.time() - start_at,
                preptool_tool_tokens=tool_tokens,
                success_objects=success_data,
                fail_objects=fail_data,
                total_no=len(request.data_input),
                success_no=len(success_data),
                fail_no=len(fail_data),
                response_at=datetime.now(timezone.utc),
            )

            final_response = Response(
                status_code=200,
                detail=self.response_format.ok(
                    f"Keyword Extraction Completed : <{SETTINGS.BASE.APP_NAME}> Extracted 0 unique keywords"
                ),
            )
            return response_data, final_response

        # Determine Document Language
        try:
            # Count languages across all chunks
            language_counter = {}
            for chunk in request.data_input:
                if hasattr(chunk, 'data_languages') and chunk.data_languages:
                    # Handle data_languages as a list
                    for lang in chunk.data_languages:
                        # Normalize Chinese variants to 'zh_cht'
                        # if lang in ['zh', 'zh_chs']:
                        #     lang = 'zh_cht'
                        language_counter[lang] = language_counter.get(lang, 0) + 1
            
            # Determine most frequent languages (up to 2)
            sorted_languages = sorted(language_counter.items(), key=lambda x: x[1], reverse=True)
            document_languages = [lang for lang, count in sorted_languages[:2]]
            
            # If no languages detected, default to English and Chinese
            if not document_languages:
                document_languages = ['en', 'zh_cht', 'zh_chs']
            # If only one language detected, add the other common language
            elif len(document_languages) == 1:
                detected = document_languages[0]
                if detected == 'zh_cht':
                    document_languages.extend(['en', 'zh_chs'])
                elif detected == 'zh_chs':
                    document_languages.extend(['en', 'zh_cht'])
                else:
                    document_languages.extend(['zh_cht', 'zh_chs'])
            
            elif len(document_languages) == 2:
                if 'zh_cht' not in document_languages and 'zh_chs' not in document_languages:
                    document_languages.append('zh_cht')
                elif 'zh_cht' in document_languages and 'zh_chs' not in document_languages:
                    document_languages.append('zh_chs')
                elif 'zh_chs' in document_languages and 'zh_cht' not in document_languages:
                    document_languages.append('zh_cht')
                elif 'en' not in document_languages:
                    document_languages.append('en')
            
            logger.info(f"Detected document language: {document_languages}")
        except Exception as e:
            logger.error(f"Error determining document language: {str(e)}, using default language: en, zh_cht")
            document_languages = ['en', 'zh_cht']  

        # Keywords Grouping
        keywords = []
        for _data in request.data_input:
            if _data.data_keywords:
                keywords.extend(_data.data_keywords)

        final_keywords = list(dict.fromkeys(keywords))

        def serialize_and_check(keywords_list: list[str]) -> bytes:
            return json.dumps({"data_keywords": keywords_list}, ensure_ascii=False).encode("utf-8")

        data_bytes = serialize_and_check(final_keywords)
        MAX_BYTES = 16_777_216  # 16 MB

        if len(data_bytes) > MAX_BYTES:
            truncated_keywords = []
            for kw in final_keywords:
                test_list = truncated_keywords + [kw]
                if len(serialize_and_check(test_list)) <= MAX_BYTES:
                    truncated_keywords.append(kw)
                else:
                    break
            final_keywords = truncated_keywords

        document_index = [
            j for j, _data_obj in enumerate(request.data_input) if _data_obj.data_type.upper() == "DOCUMENT"
        ]
        if document_index:
            request.data_input[document_index[0]].__dict__.update(
                data_keywords=final_keywords, data_languages=document_languages
            )
        else:
            document_obj = KnowDataObject(
                knowledge_id=request.data_input[0].knowledge_id,
                raw_data="Final Aggregated Text", 
                data_keywords=final_keywords,
                data_languages=document_languages,
                data_type="DOCUMENT",
                content_type="summarization",
            )
            success_data.append(document_obj)

        response_data.__dict__.update(
            preptool_time=time.time() - start_at,
            preptool_tool_tokens=tool_tokens,
            success_objects=success_data,
            fail_objects=fail_data,
            total_no=len(request.data_input),
            success_no=len(success_data),
            fail_no=len(fail_data),
            response_at=datetime.now(timezone.utc),
        )

        final_response = Response(
            status_code=200,
            detail=self.response_format.ok(
                f"Keyword Extraction Completed : <{SETTINGS.BASE.APP_NAME}> Extracted {len(final_keywords)} unique keywords"
            ),
        )
        return response_data, final_response


    def ollama_server(self, raw_data: list[str]) -> tuple[list[list[str]], int, Response, list[dict]]:
        processed_data = []
        tool_tokens = 0

        # Base payload setup
        payload = dict()
        
        # Model Options
        options = dict()
        if self.engine.preptool_parameters.get("options", None):
            options.update(self.engine.preptool_parameters.get("options"))
        if self.engine.preptool_secrets.get("options", None):
            options.update(self.engine.preptool_secrets.get("options"))
        if options:
            payload["options"] = options

        # Build prompt
        formatted_prompt = ""
        
        # System Prompt Formation
        if self.engine.preptool_parameters.get("system_prompt", None):
            formatted_prompt += "System:\n" + self.engine.preptool_parameters.get("system_prompt", "")

        # User Prompt Formation
        if self.engine.preptool_parameters.get("user_prompt", None):
            formatted_prompt += "User:\n" + self.engine.preptool_parameters.get("user_prompt", "")
        else:
            formatted_prompt += "User:\n" + "Extract the most important keywords from this text. Respond with keywords only, separated by commas: "

        # Setup API call
        payload["model"] = self.engine.preptool_base
        payload["stream"] = False
        payload["raw"] = False
        api_url = f"http://{self.engine.preptool_host}:{self.engine.preptool_port}/{self.engine.preptool_api}"
                
        try:
            for _data in raw_data:
                # Add the text to prompt
                formatted_prompt += _data
                payload["prompt"] = formatted_prompt
                
                resp = httpx.post(api_url, json=payload, timeout=SETTINGS.PRTL.GENAI_TIMEOUT)
                result = resp.json()

                # Error during Calling Inference Server
                if not resp.status_code == httpx.codes.ok:
                    response = Response(status_code=resp.status_code, detail=result["error"])
                    logger.error(response.detail)
                    return processed_data, tool_tokens, response
                
                # Update Ouptut
                raw_keywords = result.get("response", "")
                # Split by comma and clean up each keyword (remove whitespace, filter empty)
                resp_list = [keyword.strip() for keyword in raw_keywords.split(",") if keyword.strip()]
                processed_data.append(resp_list)
                input_tokens   = result.get("prompt_eval_count", 0)
                output_tokens  = result.get("eval_count", 0)
                # Accumulate token counts
                tool_tokens += input_tokens + output_tokens
                response = Response(status_code=200, detail=self.response_format.ok(f"Keyword Extraction Success : <{SETTINGS.BASE.APP_NAME}> Completed Keyword Extraction"))

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)
        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)

        return processed_data, tool_tokens, response


    def jsonlize(self, text: str) -> dict:
        match = re.search(r'```json\s*(.*?)\s*```', text, re.DOTALL)
        if match:
            json_str = match.group(1)
        else:
            json_str = text  
        try:
            data = json.loads(json_str)
            return data
        except json.JSONDecodeError:
            raise json.JSONDecodeError

    def extract_keyword_prompt(self, retrieved_data: list[str], num: int):
        retrieved_data_str = ""
        retrieved_data_str +="\n\n".join([
                f'{{"chunks_id": "R-{i}"," "data_context": "{_data}"}}'
                for  i, _data in enumerate(retrieved_data, start=1)
              ]
            )
        default_system_prompt = f"""[System]
            YOU ARE AN EXPERT AT EXTRACTING KEYWORDS FROM DOCUMENTS. YOUR TASK IS TO ANALYZE THE GIVEN DOCUMENTS (EACH REFERRED TO AS A "CHUNK") AND IDENTIFY ALL MEANINGFUL TERMS, WHICH ARE SPECIFIC NOUNS OR PHRASES THAT CARRY SIGNIFICANT MEANING IN THE CONTEXT, SUCH AS PRODUCT NAMES, KEY CONCEPTS, OR IMPORTANT ENTITIES.

            ### INSTRUCTIONS

            1. **Document Analysis**
            - Carefully read each chunk in the input.
            - Identify all meaningful terms that are specific nouns or phrases used in each chunk.
            - Ensure that the terms are exact matches from the chunk; do not modify or paraphrase them.

            2. **Extraction Guidelines**
            - Extract terms that represent complete concepts or entities.
            - Exclude generic words (e.g., "the," "and," "or"), pronouns (e.g., "he," "she," "it"), and partial phrases that do not convey the full meaning on their own (e.g., "Plan" instead of "Evergreen Wealth Multi-Currency Plan").
            - Do not group terms based on synonyms or variations; list each term individually as it appears in the chunk.
            - If a keyword contains a slash (`/`), split it into separate terms. For example, if the text has "Data A/B," extract it as "Data A" and "Data B".
            - If the phrase includes a monetary value with a currency symbol or unit, only extract the currency portion. For instance, if the document says "HKD 10,000," only extract "HKD", not the numeric value.

            3. **Output Format**
            - chunks_data Must output {num} objects which are the same with the number of chunk
            - Provide your response in JSON format. Return an array called `chunks_data` where each element is an object with the following keys:
                - `"chunks_id"`: the chunk identifier (e.g., "R-1", "R-2", ...)
                - `"data_keywords"`: an array of the extracted keywords for that chunk
            - Example to illustrate the structure:

                ```json
                {{
                "chunks_data": [
                    {{
                    "chunks_id": "R-1",
                    "data_keywords": [
                        "Keyword1",
                        "Keyword2"
                    ]
                    }},
                    {{
                    "chunks_id": "R-2",
                    "data_keywords": [
                        "Keyword3",
                        "Keyword4"
                    ]
                    }},
                    {{
                    "chunks_id": "R-3",
                    "data_keywords": [
                    ]
                    }}
                ]
                }}
                ```

            4. **Additional Requirements**
            - Do not add explanations or commentary outside the JSON output.
            - Ensure all keywords are accurately extracted from each chunk.

            [Input Chunks]
            {retrieved_data_str}

            [Output]

            Provide your answer strictly in the JSON format specified above.
            """
        return default_system_prompt
    
    def truncate_content(
        self,
        content: list[tuple[int, str]],  
        max_token: int = 1024,
        max_vectors_per_window: int = 3
    ) ->  list[list[tuple[int, str]]]:
        window_vecs = []
        current_window = []
        current_token = 0

        encoding = tiktoken.get_encoding("cl100k_base")

        for vector in content:
            index, text = vector  

            text_token = len(encoding.encode(text))
            if (current_token + text_token > max_token) or (len(current_window) >= max_vectors_per_window):
                window_vecs.append(current_window)
                current_window = [vector]
                current_token = text_token
            else:
                current_window.append(vector)
                current_token += text_token

        if current_window:
            window_vecs.append(current_window)

        return window_vecs
    
    def azure_server(self, raw_data: list[str]) -> tuple[list[list[str]], int, Response]:
        indexed_data = [(i, text) for i, text in enumerate(raw_data)]
        processed_data = [[] for _ in range(len(raw_data))]
        tool_tokens = 0

        api_url = f"{self.engine.preptool_host}/{self.engine.preptool_port}"

        genai_client = AzureOpenAI(
            api_key=self.engine.preptool_secrets.get("api_key", "dummy-key"),
            api_version=self.engine.preptool_secrets.get("api_version", ""),
            azure_endpoint=api_url,
            default_headers=self.engine.preptool_secrets.get("header", {}),
        )

        try:
            window_vecs = self.truncate_content(indexed_data)
            logger.info(f"Azure Keyword : <{SETTINGS.BASE.APP_NAME}> Total Number of Partitions: <{len(window_vecs)}>")
            
            for chunk_of_pairs in window_vecs:
                chunk_strings = [pair[1] for pair in chunk_of_pairs]  
                prompt = self.extract_keyword_prompt(retrieved_data=chunk_strings, num = len(chunk_strings))
                
                payload = {
                    "model": self.engine.preptool_base,
                    "messages": [{"role": "user", "content": prompt}],
                }

                retry_count = 1
                while retry_count <= SETTINGS.GEAI.KEYWD_RETRY:
                    resp = genai_client.chat.completions.create(
                        model=payload["model"],
                        messages=payload["messages"]
                    )
                    if not resp or not resp.choices:
                        e = "Unknown error from Azure"
                        response = Response(
                            status_code=500,
                            detail=self.response_format.error(
                                f"Azure GenAI Error : <{SETTINGS.BASE.APP_NAME}>",
                                str(e),
                            ),
                        )
                        logger.error(response.detail)
                        return processed_data, tool_tokens, response

                    result_text = resp.choices[0].message.content

                    try:
                        parsed_json = self.jsonlize(result_text)
                        chunk_data = parsed_json.get("chunks_data", [])

                        if len(chunk_strings) != len(chunk_data):
                            raise Exception("Unmatched length of input and output from OpenAI")
                        
                        for i, chunk_dict in enumerate(chunk_data):
                            original_index = chunk_of_pairs[i][0] 
                            keywords_found = chunk_dict.get("data_keywords", [])
                            processed_data[original_index] = keywords_found
                        break

                    except json.JSONDecodeError as e:
                        response = Response(
                            status_code=500,
                            detail=self.response_format.error(
                                f"JSON Parsing Error : <{SETTINGS.BASE.APP_NAME}> Encountered JSON Parsing Error. Retrying {retry_count} times...",
                                str(e),
                            ),
                        )
                        logger.error(response.detail)
                        retry_count +=1

                    except Exception as e:
                        response = Response(
                            status_code=500,
                            detail=self.response_format.error(
                                f"Azure Keyword Error : <{SETTINGS.BASE.APP_NAME}> OpenAI Output Error. Retrying {retry_count} times...",
                                str(e),
                            ),
                        )
                        logger.info(response.detail)
                        retry_count +=1
                
                if retry_count > SETTINGS.GEAI.KEYWD_RETRY:
                    raise Exception(f"Failed to extract keywords after retried {SETTINGS.GEAI.KEYWD_RETRY} times")

                # Update token usage
                in_tokens = resp.usage.prompt_tokens
                out_tokens = resp.usage.completion_tokens
                tool_tokens += (in_tokens + out_tokens)

            # Everything succeeded
            response = Response(
                status_code=200,
                detail=self.response_format.ok(
                    f"Azure Keyword Success : <{SETTINGS.BASE.APP_NAME}> Completed Azure Keyword"
                ),
            )

        except httpx.TimeoutException as e:
            response = Response(
                status_code=502,
                detail=self.response_format.error(
                    f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error",
                    str(e),
                ),
            )
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(
                status_code=502,
                detail=self.response_format.error(
                    f"Connection Error : <{SETTINGS.BASE.APP_NAME}>",
                    str(e),
                ),
            )
            logger.error(response.detail)

        except (BaseException, Exception) as e:
            response = Response(
                status_code=500,
                detail=self.response_format.error(
                    f"Common Error : <{SETTINGS.BASE.APP_NAME}>",
                    str(e),
                ),
            )
            logger.error(response.detail)

        return processed_data, tool_tokens, response