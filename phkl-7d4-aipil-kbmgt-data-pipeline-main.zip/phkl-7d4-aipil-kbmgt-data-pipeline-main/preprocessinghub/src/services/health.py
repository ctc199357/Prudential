from sqlalchemy.orm import Session
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from datetime import datetime, timezone
import inspect

from ..schemas.format import Health, ResponseFormatter, Response
# from ..schemas.prepknow import BackupConfig

from ..settings import SETTINGS

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class HealthService:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    # default_backup_config = BackupConfig(
    #     format=SETTINGS.BKUP.FORM,
    #     location=SETTINGS.BKUP.LOCA,
    #     name=SETTINGS.BKUP.NAME,
    #     host=SETTINGS.BKUP.HOST,
    #     port=SETTINGS.BKUP.PORT,
    #     user=SETTINGS.BKUP.USER,
    #     pswd=SETTINGS.BKUP.PSWD,
    #     table=SETTINGS.BKUP.TABLE,
    #     rdir=SETTINGS.BKUP.RDIR,
    #     sdir=SETTINGS.BKUP.SDIR,
    #     limit=SETTINGS.BKUP.LIMIT
    # )

    def __init__(self, db_api: Session, db_func: Session, api_call: bool):
        self.db_api   = db_api
        self.db_func  = db_func
        self.api_call = api_call

    def health_check(self) -> Health:
        response_primary = self.primary_database_connection_check()
        # response_backup  = self.backup_database_connection_check()
   
        response_health = Health(app_name=SETTINGS.BASE.APP_NAME)
        if SETTINGS.BASE.APP_API == False:
            response_health.api_call = 'INACTIVE'
        if SETTINGS.BASE.APP_FUNC == False:
            response_health.function_call = 'INACTIVE'

        if response_primary.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_health.primary_db = 'OFFLINE'
            response_health.primary_reason = response_primary.detail
            response_health.status_code = 404

        # if response_backup.status_code >= SETTINGS.STAT.SUCC_CODE_END:
        #     response_health.backup_db = 'OFFLINE'
        #     response_health.backup_reason = response_backup.detail
        #     response_health.status_code = 206

        return response_health


    def primary_database_connection_check(self) -> Response:
        if self.api_call == True:
            call_method = "API Call"
        else:
            call_method = "Function Call"

        try:
            if self.api_call == True:
                if SETTINGS.BASE.APP_API == False:
                    response = Response(status_code=405, detail=self.response_format.ok(f"Conflict : API Call is Disabled but <{call_method}> is Used"))
                    logger.info(response.detail)
                    return response

                db = self.db_api
                db.execute(text('SELECT 1'))
            
            else:
                if SETTINGS.BASE.APP_FUNC == False:
                    response = Response(status_code=405, detail=self.response_format.ok(f"Conflict : Function Call is Disabled but <{call_method}> is Used"))
                    logger.info(response.detail)
                    return response
                
                with self.db_func() as db:
                    db.execute(text('SELECT 1'))

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Connected to Primary DB via <{call_method}>"))
            logger.info(response.detail)

        except SQLAlchemyError as e:
            response = Response(status_code=404, detail=self.response_format.error(f"Database Connection Error : Failed to Connect to Primary DB via <{call_method}>", str(e)))
            logger.error(response.detail)

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Failed to Connect to Primary DB via <{call_method}>"))
            logger.error(response.detail)

        return response
    
    # def backup_database_connection_check(self) -> Response:
    #     if self.api_call == True:
    #         call_method = "API Call"
    #     else:
    #         call_method = "Function Call"
        
    #     try:
    #         engine = init_bkup_db_engine(db_config=self.default_backup_config)
    #         response = Response(status_code=200, detail=self.response_format.ok(f"Success : Connected to Backup DB via <{call_method}>"))
    #         logger.info(response.detail)

    #     except SQLAlchemyError as e:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Database Connection Error : Failed to Connect to Backup DB via <{call_method}>", str(e)))
    #         logger.error(response.detail)

    #     except:
    #         response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Failed to Connect to Backup DB via <{call_method}>"))
    #         logger.error(response.detail)

    #     return response