import os
from datetime import datetime, timezone
import inspect
import httpx
import time
import uuid

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.preptool import (
    SecretPrepTool, 
    PrepToolStringFilter, 
    PrepToolNumericFilter, 
    PrepToolFilter, 
    SystemPrepToolRequest
)

from ..schemas.prepmedia import (
    SecretPrepMedia, 
    PrepMediaStringFilter, 
    PrepMediaNumericFilter, 
    PrepMediaFilter, 
    SystemPrepMediaRequest,
    PrepMediaPipelineRequest
)

from ..schemas.prepknow import (
    SecretPrepKnow,
    PrepKnowCustomConfiguration,
    PrepKnowStringFilter,
    PrepKnowNumericFilter,
    PrepKnowListFilter,
    PrepKnow,
    PrepKnowFilter,
    UserPrepKnowRequest,
    UserPrepKnowResponse,
    SystemPrepKnowRequest,
    PrepKnowInitRequest,
    PrepKnowInitResponse,
    PrepKnowPipelineRequest,
    PrepKnowPipelineResponse,
    PrepKnowMetric,
    PrepKnowMedia,
    PrepKnowPipeline,
    PrepKnowTermination,
    SystemTermination,
    PrepKnowPipelineRecord,
    PrepKnowOutput,
    LayoutAnalysisRequest
)

from ..routers.registry.system import (
    system_query_prepknow, 
    system_query_prepmedia, 
    system_query_preptool
)

from ..services.layout_service import LayoutServiceManager

from ..services.prepmedia_service import PrepMediaServiceManager

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class PrepKnowServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    
    def __init__(self, api_call: bool, pipeline: PrepKnowPipeline | None = None):
        self.api_call = api_call
        self.pipeline = pipeline
        
    """
        Request Operation
    """
    def prepknow_init(self, request: PrepKnowInitRequest) -> tuple[PrepKnowInitResponse, Response]:
        start_at = time.time()
        response_init = PrepKnowInitResponse(**request.__dict__)

        # 1. Retrieve PrepKnow from DB
        response_prepknow, response = self.get_prepknow(prepknow_ids=[request.prepknow_id])
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_init, response
        else:
            prepknow = response_prepknow[0]
            response_init.prepknow = prepknow

        # 2. Retrieve PrepMedia
        prepmedias, response = self.get_prepmedia(prepknow=prepknow)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_init, response
        else:
            prepknow_medias = [PrepKnowMedia(prepmedia=prepmedia) for prepmedia in prepmedias]

        # 3. Retrieve PrepTool
        prepknow_medias, response = self.get_preptool(prepknow_medias=prepknow_medias)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_init, response

        ### TODO:
        #  4. Update CustomConfig:

        # 5. Update Response
        response_init.prepknow_medias = prepknow_medias
        response_init.prepknow_init_time = time.time() - start_at

        return response_init, response


    def prepknow_pipeline(self, request: PrepKnowPipelineRequest) -> tuple[PrepKnowPipelineResponse, Response]:
        response_pipeline = PrepKnowPipelineResponse(**request.__dict__)
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Start Processing PrepKnow Pipeline")

        """ 1. Gather PrepKnow Information """
        prepknow_medias = []
        
        # 1.1 Init PrepKnow Instance if requested
        if not request.prepknow:

            # Check if prepknow_id is provided to retrieve pipeline
            if request.prepknow_id:
                response_init, response = self.prepknow_init(request=PrepKnowInitRequest(**request.__dict__))
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    response_pipeline.prepknow_pipeline_reason = response.detail
                    return response_pipeline, response
                else:
                    request.__dict__.update(**response_init.__dict__)
                    prepknow_medias = response_init.prepknow_medias
            
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"Missing Error : <{SETTINGS.BASE.APP_NAME}> is Missing <prepknow_id> to Init PrepKnowPipeline"))
                response_pipeline.prepknow_pipeline_reason = response.detail
                return response_pipeline, response


        # 1.2. Check if Resume PrepKnow
        ### TODO: Add Resume Pipeline
        if request.resume_pipeline:
            # retrieve from prepknow_pipeline_id
            # pipeline = PrepKnowPipeline
            self.pipeline = PrepKnowPipeline(**request.__dict__)
        
        # 1.3. New Pipeline
        else:
            self.pipeline = PrepKnowPipeline(**request.__dict__)
        
        # 1.4. Init Pipeline Status
        self.init_pipeline_status(prepknow_termination=self.pipeline.prepknow.prepknow_termination)

        _prepknow_pipeline_outputs = []
        ### TODO: Multithreading
        file_path = self.pipeline.prepknow_input.storage_directory
        blob_url = self.pipeline.prepknow_input.storage_directory_origin

        while True:
            prepknow_start_at           = time.time()
            _prepknow_pipeline_output   = PrepKnowOutput()
            _prepmedia_pipeline_outputs = []
            _prepmedia_turn_no          = 0
            _prepmedia_retry_no         = 0
            _prepmedia_input_tokens     = 0
            _prepmedia_output_tokens    = 0
            _prepmedia_tool_tokens      = 0
            
            response = None

            """ 2. PrepKnow Layout Analysis """
            response_analysis, response = LayoutServiceManager(api_call=self.api_call, prepknow=self.pipeline.prepknow).default_analysis(request=LayoutAnalysisRequest(**request.__dict__, knowledge_id=request.prepknow_input.knowledge_id, file_path=file_path, blob_url=blob_url))
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                logger.error(response.detail)
            
            else:
                """ 3. Media Analysis """                    
                ### TODO: Convert to Multithread
                response = Response(status_code=404, detail=self.response_format.error(f"Layout Object Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Supported Objects for Further Processing"))
                for prepmedia_type, prepmedia_objects in response_analysis.layout_success_objects.__dict__.items():
                    # 3.1. Check if Certain Type of PrepMedia Objects is Obtained
                    if not prepmedia_objects:
                        continue

                    matched_prepmedias = [_prepknow_media for _prepknow_media in self.pipeline.prepknow_medias if _prepknow_media.prepmedia.prepmedia_type.lower() == prepmedia_type.lower()]
                    
                    # 3.2. Match the PrepMedia
                    if not matched_prepmedias:
                        response = Response(status_code=204, detail=self.response_format.error(f"PrepMedia Matching Warning : <{SETTINGS.BASE.APP_NAME}> PrepMedia Does Not Support the Extracted Layout Object Type <{prepmedia_type}>"))
                        logger.warning(response.detail)
                        continue
                    else:
                        prepmedia_in_use = matched_prepmedias[0]
                        _prepknow_medias = [_prepknow_media for _prepknow_media in self.pipeline.prepknow_medias if _prepknow_media.prepmedia.prepmedia_id == matched_prepmedias[0].prepmedia.prepmedia_id]
                        if not _prepknow_medias:
                            response = Response(status_code=204, detail=self.response_format.error(f"PrepMedia Unfound Error : <{SETTINGS.BASE.APP_NAME}> PrepMedia Cannot Find prepknow_media"))
                            logger.error(response.detail)
                            break
                        else:
                            prepknow_media = _prepknow_medias[0]

                    # 3.3 Execute PrepMedia Pipeline
                    logger.info(f"Processing <{len(prepmedia_objects)}> <{prepmedia_type}> Objects")
                    prepmedia_request = PrepMediaPipelineRequest(
                        **self.pipeline.__dict__,
                        prepmedia_id    = prepmedia_in_use.prepmedia.prepmedia_id,
                        prepmedia_input = prepmedia_objects,
                        prepknow_media  = prepknow_media,
                        custom_config   = None,
                        prepmedia       = prepmedia_in_use.prepmedia
                    )
                    
                    response_prepmedia, response = PrepMediaServiceManager(api_call=self.api_call).prepmedia_pipeline(request=prepmedia_request)
                    _prepmedia_pipeline_outputs.append(response_prepmedia)
                    
                    # 3.4. Update pipeline statistics
                    _prepmedia_turn_no       += response_prepmedia.prepmedia_turn_no
                    _prepmedia_retry_no      += response_prepmedia.prepmedia_retry_no
                    _prepmedia_input_tokens  += response_prepmedia.prepmedia_total_input_tokens
                    _prepmedia_output_tokens += response_prepmedia.prepmedia_total_output_tokens
                    _prepmedia_tool_tokens   += response_prepmedia.prepmedia_total_tool_tokens
                    
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        logger.error(response.detail)
                        break
            
            # 3.5. Document Tasks
            document_prepmedias = [_prepknow_media for _prepknow_media in self.pipeline.prepknow_medias if _prepknow_media.prepmedia.prepmedia_type.lower() == 'document']
            if not document_prepmedias:
                response = Response(status_code=204, detail=self.response_format.error(f"PrepMedia Matching Warning : <{SETTINGS.BASE.APP_NAME}> PrepMedia Does Not Support the Extracted Layout Object Type DOCUMENT"))
                logger.warning(response.detail)
            else:
                document_prepmedia = document_prepmedias[0]
                _prepknow_medias = [_prepknow_media for _prepknow_media in self.pipeline.prepknow_medias if _prepknow_media.prepmedia.prepmedia_id == document_prepmedias[0].prepmedia.prepmedia_id]
                
                if not _prepknow_medias:
                    response = Response(status_code=204, detail=self.response_format.error(f"PrepMedia Unfound Error : <{SETTINGS.BASE.APP_NAME}> PrepMedia Cannot Find prepknow_media"))
                    logger.error(response.detail)
                else:
                    prepknow_media = _prepknow_medias[0]

                # 3.3 Execute PrepMedia Pipeline
                prepmedia_input = [_knowdata for _pipeline_output in _prepmedia_pipeline_outputs for _knowdata in _pipeline_output.prepmedia_output]
                logger.info(f"Document Input Length : <{len(prepmedia_input)}>")
                if prepmedia_input:
                    prepmedia_request = PrepMediaPipelineRequest(
                        **self.pipeline.__dict__,
                        prepmedia_id    = document_prepmedia.prepmedia.prepmedia_id,
                        prepmedia_input = prepmedia_input,
                        prepknow_media  = prepknow_media,
                        custom_config   = None,
                        prepmedia       = document_prepmedia.prepmedia
                    )
                    response_prepmedia, response = PrepMediaServiceManager(api_call=self.api_call).prepmedia_pipeline(request=prepmedia_request)
                    if response_prepmedia.prepmedia_pipeline_code == SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"):
                        response_prepmedia.__dict__.update(prepmedia_output=[_output for _output in response_prepmedia.prepmedia_output if _output.data_type.upper() == "DOCUMENT"])
                        _prepmedia_pipeline_outputs.append(response_prepmedia)
                    logger.info(f"Document Output Length : <{len(response_prepmedia.prepmedia_output)}>")
                    
                    # 3.4. Update pipeline statistics
                    _prepmedia_turn_no       += response_prepmedia.prepmedia_turn_no
                    _prepmedia_retry_no      += response_prepmedia.prepmedia_retry_no
                    _prepmedia_input_tokens  += response_prepmedia.prepmedia_total_input_tokens
                    _prepmedia_output_tokens += response_prepmedia.prepmedia_total_output_tokens
                    _prepmedia_tool_tokens   += response_prepmedia.prepmedia_total_tool_tokens
                
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        logger.error(response.detail)

            """ 4. Update PrepKnow Pipeline """
            # 4.1. Check PrepKnow Succeed or Not
            if not _prepmedia_pipeline_outputs:
                _prepknow_success = False
                _prepknow_reason  = response.detail
                _prepknow_code    = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)
                logger.error("PrepKnow Pipeline Execution Error : Found Empty PrepMedia Pipeline Output")

            else:
                # _prepknow_success = all([_output.prepmedia_pipeline_code == SETTINGS.PRMD.STATUS_CODE.get("SUCCESS") for _output in _prepmedia_pipeline_outputs])
                _prepknow_success = any([_output.prepmedia_pipeline_code == SETTINGS.PRMD.STATUS_CODE.get("SUCCESS") for _output in _prepmedia_pipeline_outputs])
                if not _prepknow_success:
                    _prepknow_reason = '; '.join([_output.prepmedia_pipeline_reason for _output in _prepmedia_pipeline_outputs if _output.prepmedia_pipeline_code != SETTINGS.PRMD.STATUS_CODE.get("SUCCESS")])
                    _prepknow_code   = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)
                else:
                    _prepknow_code   = 'SUCCESS'
                    _prepknow_reason = SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200)
                    _prepknow_pipeline_output = PrepKnowOutput(know_data=[_knowdata for _pipeline_output in _prepmedia_pipeline_outputs for _knowdata in _pipeline_output.prepmedia_output])
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Execution"))

            # 4.2. Update Pipeline Metrics
            self.update_pipeline_metrics(
                prepmedia_turn_no       = _prepmedia_turn_no,
                prepmedias_retry_no     = _prepmedia_retry_no,
                prepmedia_input_tokens  = _prepmedia_input_tokens,
                prepmedia_output_tokens = _prepmedia_output_tokens,
                prepmedia_tool_tokens   = _prepmedia_tool_tokens,
                prepmedia_metrics       = [_metric for _output in _prepmedia_pipeline_outputs for _metric in _output.prepmedia_metrics],
                prepknow_code           = _prepknow_code,
                prepknow_reason         = _prepknow_reason,
                prepknow_output         = _prepknow_pipeline_output,
                prepknow_start_at       = prepknow_start_at
            )

            # 4.3. Determine Next Agents and Next Inputs           
            if self.pipeline.prepknow_metric.prepknow_code == SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200):
                self.pipeline.prepknow_pipeline_completion = True
                
            # 4.4. Check Termination
            response = self.check_pipeline_status()

            # 4.5. Create New Record
            self.pipeline.prepknow_chain += [PrepKnowPipelineRecord(**self.pipeline.__dict__).copy(deep=True)]

            # 4.6. Add Successful PrepKnow into Output
            if _prepknow_success:
                self.pipeline.prepknow_pipeline_output = PrepKnowPipelineRecord(**self.pipeline.__dict__).copy(deep=True)
            
            """ 5. Proceed to Next Step """
            # 5.1. Terminate the PrepKnow Pipeline
            if self.pipeline.prepknow_pipeline_termination == True:
                if _prepknow_success:
                    self.unify_prepknow_output()
                break
            else:
                # 5.2. Init New Pipeline for Retry or Proceeding to Next Step
                self.pipeline.prepknow_pipeline_id = str(uuid.uuid4()) 
                self.update_pipeline_status()
        
            # """ 7. Post Result to Postprocessing """
            # response_postprocessing, response = self.postprocessing()
            # if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            #     response_pipeline.prepknow_pipeline_reason = response_postprocessing.postprocessing_reason
        
        if not request.get_full_chain:
            self.pipeline.prepknow_chain = []

        response_pipeline.__dict__.update(
            **self.pipeline.__dict__,
            response_at = datetime.now(timezone.utc)
        )

        response = Response(status_code=200, detail=self.response_format.ok(f"Preprocessing Knowledge Completed : <{SETTINGS.BASE.APP_NAME}> Completed Preprocesssing Knowledge"))
        return response_pipeline, response
                    
    def init_pipeline_status(self, prepknow_termination: dict) -> None:
        if prepknow_termination:
            self.pipeline.prepknow_criteria = PrepKnowTermination(**prepknow_termination)

        if SETTINGS.PRKW.SYSTEM_PREPKNOW_TERMINATION:
            self.pipeline.system_criteria   = SystemTermination(**SETTINGS.PRKW.SYSTEM_PREPKNOW_TERMINATION)

    def update_pipeline_metrics(
            self, 
            prepmedia_turn_no:       int, 
            prepmedias_retry_no:     int,
            prepmedia_input_tokens:  int,
            prepmedia_output_tokens: int,
            prepmedia_tool_tokens:   int,
            prepmedia_metrics:       list,
            prepknow_code:           str,
            prepknow_reason:         str,
            prepknow_output:         PrepKnowOutput,
            prepknow_start_at:       float
        ) -> None:
        
        # Update Individual PrepKnow Info
        self.pipeline.prepknow_time = time.time() - prepknow_start_at
        self.pipeline.output_at     = datetime.now(timezone.utc)

        self.pipeline.prepmedias_turn_no  = prepmedia_turn_no
        self.pipeline.prepmedias_retry_no = prepmedias_retry_no
        self.pipeline.prepknow_output     = prepknow_output
        self.pipeline.prepknow_metric     = PrepKnowMetric(
            **self.pipeline.__dict__,
            prepknow_code          = prepknow_code,
            prepknow_reason        = prepknow_reason,
            prepmedia_metrics      = prepmedia_metrics,
            prepknow_input_tokens  = prepmedia_input_tokens,
            prepknow_output_tokens = prepmedia_output_tokens,
            prepknow_tool_tokens   = prepmedia_tool_tokens,
            prepknow_request_at    = self.pipeline.input_at, 
            prepknow_response_at   = datetime.now(timezone.utc)
        )

        # Update Total PrepKnow Info
        self.pipeline.prepknow_total_input_tokens  += prepmedia_input_tokens
        self.pipeline.prepknow_total_output_tokens += prepmedia_output_tokens
        self.pipeline.prepknow_total_tool_tokens   += prepmedia_tool_tokens
        self.pipeline.prepmedias_total_turn_no     += self.pipeline.prepmedias_turn_no
        self.pipeline.prepmedias_total_retry_no    += self.pipeline.prepmedias_retry_no
        self.pipeline.prepknow_total_time          += self.pipeline.prepknow_time

    ### TODO: Add Token Limit
    def check_pipeline_status(self) -> Response:

        self.pipeline.prepknow_pipeline_reason = self.pipeline.prepknow_metric.prepknow_reason
        self.pipeline.prepknow_pipeline_termination = True

        # Check Completion
        if self.pipeline.prepknow_pipeline_completion == True:
            self.pipeline.prepknow_pipeline_reason  = 'PrepKnow Temrinated due to Completion'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200)

        # Check Termination Flag
        elif self.pipeline.prepknow_criteria.code and self.pipeline.prepknow_metric.prepknow_code == self.pipeline.prepknow_criteria.code:
            self.pipeline.prepknow_pipeline_reason  = 'Terminated due to Matched PrepKnow-defined Termination Success Flag'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200)

        elif self.pipeline.prepknow_criteria.code and self.pipeline.prepknow_metric.prepknow_code == self.pipeline.system_criteria.code:
            self.pipeline.prepknow_pipeline_reason  = 'Terminated due to Matched System-defined Termination Success Flag'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200)

        # Check PrepKnow-defined Termination Criteria
        elif self.pipeline.prepknow_criteria.max_prepknow_turn and self.pipeline.prepknow_total_turn_no >= self.pipeline.prepknow_criteria.max_prepknow_turn:
            self.pipeline.prepknow_pipeline_reason = 'Terminated due to the Number of PrepKnow Turns >= PrepKnow-defined Maximum Number of PrepKnow Turns'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)

        elif self.pipeline.prepknow_criteria.max_prepknow_retry and self.pipeline.prepknow_total_retry_no >= self.pipeline.prepknow_criteria.max_prepknow_retry:
            self.pipeline.prepknow_pipeline_reason = 'Terminated due to the Number of PrepKnow Retries >= PrepKnow-defined Maximum Number of PrepKnow Retries'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)

        elif self.pipeline.prepknow_criteria.max_prepknow_turn_retry and self.pipeline.prepknow_retry_no >= self.pipeline.prepknow_criteria.max_prepknow_turn_retry:
            self.pipeline.prepknow_pipeline_reason = 'Terminated due to the Number of PrepKnow Retries Per Turn >= PrepKnow-defined Maximum Number of PrepKnow Retries Per Turn'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)

        elif self.pipeline.prepknow_criteria.timeout and self.pipeline.prepknow_total_time >= self.pipeline.prepknow_criteria.timeout:
            self.pipeline.prepknow_pipeline_reason = 'Terminated due to the Duration of PrepKnow >= PrepKnow-defined Timeout'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)
    

        # Check System-defined Termination Criteria
        elif self.pipeline.system_criteria.max_prepknow_turn and self.pipeline.prepknow_total_turn_no >= self.pipeline.system_criteria.max_prepknow_turn:
            self.pipeline.prepknow_pipeline_reason = 'Terminated due to the Number of System Turns >= System-defined Maximum Number of System Turns'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)
          
        elif self.pipeline.system_criteria.max_prepknow_retry and self.pipeline.prepknow_total_retry_no >= self.pipeline.system_criteria.max_prepknow_retry:
            self.pipeline.prepknow_pipeline_reason = 'Terminated due to the Number of System Retries >= System-defined Maximum Number of System Retries'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)

        elif self.pipeline.prepknow_criteria.max_prepknow_turn_retry and self.pipeline.prepknow_retry_no >= self.pipeline.system_criteria.max_prepknow_turn_retry:
            self.pipeline.prepknow_pipeline_reason = 'Terminated due to the Number of PrepKnow Retries Per Turn >= System-defined Maximum Number of PrepKnow Retries Per Turn'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)

        elif self.pipeline.system_criteria.timeout and self.pipeline.prepknow_total_time >= self.pipeline.system_criteria.timeout:
            self.pipeline.prepknow_pipeline_reason = 'Terminated due to the Duration of System >= System-defined Timeout'
            self.pipeline.prepknow_pipeline_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)
            
        else:
            self.pipeline.prepknow_pipeline_termination = False

            # Proceeding to next steps
            if self.pipeline.prepknow_metric.prepknow_code == SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200):
                self.pipeline.prepknow_pipeline_reason = 'PROCEEDING'

        # Update Response
        if self.pipeline.prepknow_pipeline_completion == True:
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepKnow Pipeline Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepKnow Pipeline Execution"))
            logger.info(response.detail)
        elif self.pipeline.prepknow_pipeline_termination == True:
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepKnow Pipeline Terminated : <{SETTINGS.BASE.APP_NAME}> Terminated PrepKnow Pipeline due to {self.pipeline.prepknow_pipeline_reason}"))
            logger.info(response.detail)
        elif self.pipeline.prepknow_metric.prepknow_code == SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200):
            response = Response(status_code=206, detail=self.response_format.ok(f"PrepKnow Pipeline Proceeding : <{SETTINGS.BASE.APP_NAME}> PrepKnow Pipeline Execution Success and Proceeding to the Next Turn"))
            logger.info(response.detail)
        else:
            response = Response(status_code=500, detail=self.response_format.error(f"PrepKnow Pipeline Execution Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unepxected Error during Pipeline Execution"))
            logger.error(response.detail)

        return response


    def update_pipeline_status(self) -> None:

        # Proceeding to next steps
        if self.pipeline.prepknow_pipeline_completion:
            logger.info(self.pipeline.prepknow_pipeline_reason)

        elif self.pipeline.prepknow_metric.prepknow_code == SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200):
            self.pipeline.prepknow_total_turn_no += 1
            self.pipeline.prepknow_turn_no       += 1
            self.pipeline.prepknow_retry_no      = 0

        # Retry
        else:
            self.pipeline.prepknow_total_retry_no += 1
            self.pipeline.prepknow_retry_no       += 1

    def unify_prepknow_output(self):
        pass

    # Internal Module
    def get_prepknow(self, prepknow_ids: list[str]) -> tuple[list[SecretPrepKnow] | None, Response]:
        if not prepknow_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Empty PrepKnow List in the PrepKnow"))
            return [], response
        
        data_filter  = PrepKnowFilter(
            string_filter=PrepKnowStringFilter(prepknow_id_filter=prepknow_ids),
            numeric_filter=PrepKnowNumericFilter(prepknow_status_min=1)
            )
        data_request = SystemPrepKnowRequest(data_filter=data_filter)
        
        try:
            response_prepknows = system_query_prepknow(
                request  = data_request, 
                api_call = self.api_call
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved PrepKnow Profile"))
        except Exception as e:
            response = Response(status_code=500, detail=e)
            return [], response

        if response_prepknows.data_count != len(prepknow_ids):
            response = Response(status_code=404, detail=self.response_format.error(f"Missing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Retrieve All PrepKnow from PrepKnowDB"))
            return response_prepknows.filtered_data, response
        
        else:
            return response_prepknows.filtered_data, response
    

    # Internal Module
    def get_prepmedia(self, prepknow: SecretPrepKnow) -> tuple[list[SecretPrepMedia], Response]:
        if not prepknow.prepmedia_ids.keys():
            response = Response(status_code=404, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Found Empty PrepMedia List in the PrepKnow"))
            return [], response
        
        data_filter  = PrepMediaFilter(
            string_filter  = PrepMediaStringFilter(prepmedia_id_filter=[key for key in prepknow.prepmedia_ids.keys()]),
            numeric_filter = PrepMediaNumericFilter(prepmedia_status_min=1)
        )
        data_request = SystemPrepMediaRequest(data_filter=data_filter)
        
        try:
            response_data = system_query_prepmedia(
                request  = data_request, 
                api_call = self.api_call
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved PrepMedia Profile"))
        except Exception as e:
            response = Response(status_code=500, detail=e)
            return [], response

        # Check whether all data has been retrieved
        if response_data.data_count != len(prepknow.prepmedia_ids.keys()):
            response = Response(status_code=404, detail=self.response_format.error(f"Missing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Retrieve All PrepMedia from PrepMediaDB"))
            return response_data.filtered_data, response
        
        else:
            return response_data.filtered_data, response


    # Internal Module
    def get_preptool(self, prepknow_medias: list[PrepKnowMedia]) -> tuple[list[PrepKnowMedia], Response]:
        preptool_ids = list(set([preptool_id for _prepmedia in prepknow_medias for preptool_id in _prepmedia.prepmedia.preptool_ids.keys()]))
        
        data_filter = PrepToolFilter(
            string_filter  = PrepToolStringFilter(preptool_id_filter=preptool_ids),
            numeric_filter = PrepToolNumericFilter(preptool_status_min=1)
            )
        data_request = SystemPrepToolRequest(data_filter=data_filter)
        
        try:
            response_data = system_query_preptool(
                request  = data_request, 
                api_call = self.api_call
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved PrepTool Profile"))
        
        except Exception as e:
            response = Response(status_code=500, detail=e)
            return response

        if response_data.data_count != len(preptool_ids):
            response = Response(status_code=404, detail=self.response_format.error(f"Missing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Retrieve All PrepTools from PrepToolDB"))
            return response
        
        else:
            retrieved_preptools = response_data.filtered_data
            for prepknow_media in prepknow_medias:
                prepknow_media.preptools = [preptool for preptool in retrieved_preptools if preptool.preptool_id in prepknow_media.prepmedia.preptool_ids.keys()]
        
        return prepknow_medias, response


    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response