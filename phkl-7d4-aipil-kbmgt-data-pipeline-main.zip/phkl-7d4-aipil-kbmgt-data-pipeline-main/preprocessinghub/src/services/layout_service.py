from datetime import datetime, timezone
import time
import os
from io import BytesIO
import inspect
import httpx
import json
import base64
import shutil
import urllib.parse
import uuid
import fitz
import pdfplumber
from PIL import Image

from ..settings import SETTINGS
from ..utils import (
    normalize_path,
    delete_blob_file, 
    download_blob_files, 
    num_tokens_from_string, 
    rename_blob_file, 
    upload_to_blob, 
    download_from_blob,
    download_from_blob_by_url
)

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.prepmedia import KnowDataObject

from ..schemas.prepknow import (
    SecretPrepKnow, 
    LayoutAnalysisRequest, 
    LayoutAnalysisResponse, 
    ExtractedLayoutObject, 
    ExtractedLayoutType, 
    LayoutAnalysisMetrics
)
from azure.storage.blob import BlobServiceClient, ContentSettings
from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class LayoutServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool, prepknow: SecretPrepKnow | None = None):
        self.api_call = api_call
        self.prepknow = prepknow

    """
        Request Operation
    """
    ### TODO: To include layout object filter, e.g., text, image, table, etc.
    ### TODO: To detect set outrange coord to boundary
    def default_analysis(self, request: LayoutAnalysisRequest) -> tuple[LayoutAnalysisResponse, Response]:
        response_analysis = LayoutAnalysisResponse(**request.__dict__)
        
        """ 1. Init Custom Config """
        if not self.prepknow:
            self.prepknow = SecretPrepKnow()

        if request.prepknow_layout_func:
            self.prepknow.prepknow_layout_func = request.prepknow_layout_func
        # else:
        #     self.prepknow.prepknow_layout_func['media_snapshot'] = SETTINGS.PRKW.MEDIA_SNAPSHOT

        if request.prepknow_parameters:
            self.prepknow.prepknow_parameters = request.prepknow_parameters

        if request.prepknow_secrets:
            self.prepknow.prepknow_secrets = request.prepknow_secrets

        """ 2. Parse File Based on the Extension """        
        file_extension = os.path.basename(request.file_path).split('.')[-1]

        if file_extension.lower() in SETTINGS.PRKW.FILE_EXTENSION.get("PDF"):
            try:
                analysis_method = str(self.prepknow.prepknow_layout_func.get("PDF", "")).upper()
            except AttributeError as e:
                logger.warning(f"Cannot Find Analyzer in prepknow_layout_func. Use Default Analyzer")
                analysis_method = "DEFAULT"

            if analysis_method == "DEFAULT":
                success_list, fail_list, metrics, response = self.default_pdf_analyzer(knowledge_id=request.knowledge_id, file_path=request.file_path)

            elif analysis_method == "TEST":
                success_list, fail_list, metrics, response = self.test_pdf_analyzer(knowledge_id=request.knowledge_id, file_path=request.file_path, blob_url=request.blob_url)

            elif analysis_method == "FAKE":
                success_list, fail_list, metrics, response = self.fake_pdf_analyzer(knowledge_id=request.knowledge_id, file_path=request.file_path, blob_url=request.blob_url)
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Layout Analysis Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unsupported PDF Analyzer <{analysis_method}>"))
        
        # elif file_extension.lower() in SETTINGS.PRKW.FILE_EXTENSION.get("EXCEL"):
        #     pass
        
        # elif file_extension.lower() in SETTINGS.PRKW.FILE_EXTENSION.get("CSV"):
        #     pass

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Layout Analysis Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unsupported File Extension <{file_extension}>"))

        """ 3. Parsing Output from Analyzer """
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_analysis.layout_analysis_metrics.__dict__.update(
                layout_code   = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500), 
                layout_reason = response.detail
            )
    
            response_analysis.__dict__.update(response_at = datetime.now(timezone.utc))

        else:
            text_objects  = [_item for _item in success_list if _item.data_type.upper() == 'TEXT' or _item.data_type.upper() == 'TITLE']
            image_objects = [_item for _item in success_list if _item.data_type.upper() == 'IMAGE']
            table_objects = [_item for _item in success_list if _item.data_type.upper() == 'TABLE']

            response_analysis.__dict__.update(
                layout_success_objects  = ExtractedLayoutObject(
                    text  = text_objects,
                    image = image_objects,
                    table = table_objects,
                ),
                layout_fail_objects     = fail_list,
                layout_extracted_types  = ExtractedLayoutType(text=len(text_objects), image=len(image_objects), table=len(table_objects)),
                layout_analysis_metrics = metrics,
                response_at             = datetime.now(timezone.utc)
            )

            response = Response(status_code=200, detail=self.response_format.ok(f"Layout Analysis Completed : <{SETTINGS.BASE.APP_NAME}> Completed Layout Analysis"))
            
        return response_analysis, response


    def default_pdf_analyzer(self, knowledge_id: str, file_path: str, media_snapshot: bool=True) -> tuple[list[KnowDataObject], list[KnowDataObject], LayoutAnalysisMetrics, Response]:
        
        def bbox_intersects(bbox1, bbox2):
            """
                Check if two bounding boxes intersect
            """
            return not (bbox1[2] < bbox2[0] or
                        bbox1[0] > bbox2[2] or
                        bbox1[3] < bbox2[1] or
                        bbox1[1] > bbox2[3])

        def coord_check(value):
            return value if value > 0 else 0
        
        def downsize_image(image_page, default_resolution, max_token=100000):
            resolution = default_resolution
            while True:
                image_obj = image_page.to_image(resolution=resolution)
                buffer = BytesIO()
                image_obj.save(buffer)
                base64_str = base64.b64encode(buffer.getvalue()).decode("utf-8")
                base64_token_size = num_tokens_from_string(base64_str)

                if base64_token_size <= max_token:
                    # logger.info(f"The resolution resized image is {resolution}.")
                    return image_obj
                
                resolution -= 10
                if resolution <= 0:
                    logger.error(f"Unable to reduce image size enough to fit within the token limit.")
                    raise 

        start_at = time.time()

        line_threshold = 3
        total_page_no  = 0
        _success_list  = []
        _fail_list     = []
        sequence_no    = 1
        try:
            file_name = file_path.split(os.path.sep)[-1]
            name_without_ext = os.path.splitext(file_name)[0]

            with fitz.open(file_path) as file_text_parser, pdfplumber.open(file_path) as file_media_parser:
                total_page_no = len(file_text_parser)

                for _page_no in range(total_page_no):
                    page_text  = file_text_parser[_page_no]
                    page_media = file_media_parser.pages[_page_no]

                    # Get page elements
                    page_texts   = []
                    page_height  = page_media.height
                    page_images  = page_media.images
                    page_tables  = page_media.find_tables()
                    image_bboxes = [(_image['x0'], page_height - _image['y1'], _image['x1'], page_height - _image['y0']) for _image in page_images]
                    table_bboxes = [_table.bbox for _table in page_tables]

                    # Process text lines
                    words        = page_text.get_text("words")
                    sorted_words = sorted(words, key=lambda w: (w[3], w[0]))  # Sort by Y then X coordinates
                                        
                    current_line = []
                    line_bbox    = [float('inf'), float('inf'), -float('inf'), -float('inf')]

                    _line_no = 1
                    for word in sorted_words:
                        word_bbox = (word[0], word[1], word[2], word[3]) # x0, y0, x1, y1

                        # Skip text overlapping with images/tables
                        if any(bbox_intersects(word_bbox, bbox) for bbox in image_bboxes + table_bboxes):
                            continue
                        
                        # Detect new line based on Y coordinate change
                        if current_line and abs(word_bbox[1] - current_line[-1][1]) > line_threshold:
                            # Create text object for completed line
                            line_text = ' '.join([w[4] for w in current_line])
                            page_texts.append({'text': line_text, 'line': _line_no, 'line_bbox': line_bbox})
                            
                            _line_no     += 1
                            current_line = []
                            line_bbox    = [float('inf'), float('inf'), -float('inf'), -float('inf')]

                        # Update current line information
                        current_line.append(word)
                        line_bbox = [
                            min(line_bbox[0], word_bbox[0]),
                            min(line_bbox[1], word_bbox[1]),
                            max(line_bbox[2], word_bbox[2]),
                            max(line_bbox[3], word_bbox[3])
                        ]

                    # Process remaining line
                    if current_line:
                        line_text = ' '.join([w[4] for w in current_line])
                        page_texts.append({'text': line_text, 'line': _line_no, 'line_bbox': line_bbox})
                        
                    
                    # Process Text Objects
                    for _line in page_texts:         
                        if not _line['text'] or _line['text'].strip() == "" or not isinstance(_line['text'], str):
                            continue  # Skip empty lines

                        data_obj  = KnowDataObject(
                            data_type    = 'TEXT',
                            raw_data     = _line['text'],
                            data_length  = len(_line['text']),
                            coord_x1     = coord_check(_line['line_bbox'][0]),
                            coord_y1     = coord_check(_line['line_bbox'][1]),
                            coord_x2     = coord_check(_line['line_bbox'][2]),
                            coord_y2     = coord_check(_line['line_bbox'][3]),
                            page_start   = _page_no + 1,
                            page_end     = _page_no + 1,
                            line_start   = _line['line'],
                            line_end     = _line['line'],
                            seq_no       = sequence_no,
                            knowledge_id = knowledge_id
                        )
                        _success_list.append(data_obj)
                        sequence_no += 1

                    # Process images
                    for i, _image in enumerate(page_images, start=1):
                        try:
                            # Take Snapshot of Media
                            if media_snapshot == True:
                                filename  = knowledge_id + f'_image_page-{_page_no+1}_{i}_' + str(datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) + f'.{SETTINGS.PRKW.IMAGE_EXTENSION}'
                                file_path = normalize_path(os.path.join(SETTINGS.PREP.STORAGE_TEMP_RDIR, SETTINGS.PREP.STORAGE_TEMP_SDIR, filename))
                                cropped_image = page_media.crop((coord_check(_image['x0']), coord_check(page_height - _image['y1']), coord_check(_image['x1']), coord_check(page_height - _image['y0'])))
                                image_object = downsize_image(image_page=cropped_image, default_resolution=SETTINGS.PRKW.IMAGE_RESOLUTION)
                                image_object.save(file_path)
                                blob_path = f"{SETTINGS.BLOB.PASRER_FOLDER_NAME}/parsed-result/{name_without_ext}/images/{filename}"
                                file_path = upload_to_blob(local_path=file_path, blob_path=blob_path, content_type='image/jpeg')
                                response = Response(status_code=201, detail=self.response_format.ok(f"Saved Cropped Image : <{SETTINGS.BASE.APP_NAME}> Saved Cropped Image <{i}>"))
                            else:
                                file_path = ""
                                response  = Response(status_code=200, detail=self.response_format.ok(f"Skipped Media Snapshot : <{SETTINGS.BASE.APP_NAME}> Skipped Media Snapshot <{i}>"))
                            
                        except Exception as e:
                            response = Response(status_code=500, detail=self.response_format.error(f"Cropped Image Saving Error : <{SETTINGS.BASE.APP_NAME}> Failed to Save Cropped Image <{i}>", str(e)))
                            logger.error(response.detail)

                        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:   
                            data_obj   = KnowDataObject(
                                data_type    = 'IMAGE',
                                raw_data     = 'ERROR',
                                coord_x1     = coord_check(_image['x0']),
                                coord_y1     = coord_check(page_height - _image['y1']),
                                coord_x2     = coord_check(_image['x1']),
                                coord_y2     = coord_check(page_height - _image['y0']),
                                page_start   = _page_no + 1,
                                page_end     = _page_no + 1,
                                seq_no       = sequence_no,
                                knowledge_id = knowledge_id
                            )
                            _fail_list.append(data_obj)
                            sequence_no += 1

                        else:
                            data_obj = KnowDataObject(
                                data_type    = 'IMAGE',
                                data_url     = file_path,
                                coord_x1     = coord_check(_image['x0']),
                                coord_y1     = coord_check(page_height - _image['y1']),
                                coord_x2     = coord_check(_image['x1']),
                                coord_y2     = coord_check(page_height - _image['y0']),
                                page_start   = _page_no + 1,
                                page_end     = _page_no + 1,
                                seq_no       = sequence_no,
                                knowledge_id = knowledge_id
                            )
                            _success_list.append(data_obj)
                            sequence_no += 1

                    # Process tables
                    for i, _table in enumerate(page_tables, start=1):
                        try:
                            table_text    = '\n'.join([' | '.join([_row if _row else '' for _row in row]) for row in _table.extract()])

                            # Take Snapshot of Media
                            if media_snapshot == True:
                                filename      = knowledge_id + f'_table_page-{_page_no+1}_{i}_' + str(datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) + f'.{SETTINGS.PRKW.TABLE_EXTENSION}'
                                file_path     = normalize_path(os.path.join(SETTINGS.PREP.STORAGE_TEMP_RDIR, SETTINGS.PREP.STORAGE_TEMP_SDIR, filename))
                                cropped_table = page_media.crop((coord_check(_table.bbox[0]), coord_check(_table.bbox[1]), coord_check(_table.bbox[2]), coord_check(_table.bbox[3])))
                                image_object = downsize_image(image_page=cropped_table, default_resolution=SETTINGS.PRKW.TABLE_RESOLUTION)
                                image_object.save(file_path)
                                blob_path = f"{SETTINGS.BLOB.PASRER_FOLDER_NAME}/parsed-result/{name_without_ext}/images/{filename}"
                                file_path = upload_to_blob(local_path=file_path, blob_path=blob_path, content_type='image/jpeg') 
                                response = Response(status_code=201, detail=self.response_format.ok(f"Saved Cropped Table : <{SETTINGS.BASE.APP_NAME}> Saved Cropped Table <{i}>"))
                            else:
                                file_path = ""
                                response  = Response(status_code=200, detail=self.response_format.ok(f"Skipped Media Snapshot : <{SETTINGS.BASE.APP_NAME}> Skipped Media Snapshot <{i}>"))
                                                    
                        except Exception as e:
                            response = Response(status_code=500, detail=self.response_format.error(f"Table Analysis Error : <{SETTINGS.BASE.APP_NAME}> Failed to Analyze Table <{i}>", str(e)))
                            logger.error(response.detail)

                        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:   
                            data_obj   = KnowDataObject(
                                data_type    = 'TABLE',
                                raw_data     = 'ERROR',
                                coord_x1     = coord_check(_table.bbox[0]),
                                coord_y1     = coord_check(_table.bbox[1]),
                                coord_x2     = coord_check(_table.bbox[2]),
                                coord_y2     = coord_check(_table.bbox[3]),
                                page_start   = _page_no + 1,
                                page_end     = _page_no + 1,
                                seq_no       = sequence_no,
                                knowledge_id = knowledge_id
                            )
                            _fail_list.append(data_obj)
                            sequence_no += 1
                        else:
                            data_obj   = KnowDataObject(
                                data_type    = 'TABLE',
                                raw_data     = table_text,
                                data_url     = file_path,
                                coord_x1     = coord_check(_table.bbox[0]),
                                coord_y1     = coord_check(_table.bbox[1]),
                                coord_x2     = coord_check(_table.bbox[2]),
                                coord_y2     = coord_check(_table.bbox[3]),
                                page_start   = _page_no + 1,
                                page_end     = _page_no + 1,
                                seq_no       = sequence_no,
                                knowledge_id = knowledge_id
                            )
                            _success_list.append(data_obj)
                            sequence_no += 1
                            
            response = Response(status_code=200, detail=self.response_format.ok(f"Layout Analysis Completed : <{SETTINGS.BASE.APP_NAME}> Completed Layout Analysis"))
            logger.info(response.detail)
    
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Layout Analysis Error : <{SETTINGS.BASE.APP_NAME}> Failed to Load PDF"))
            logger.error(response.detail)

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            layout_code = SETTINGS.PRKW.STATUS_CODE.get("FAIL", 500)
        else:
            layout_code = SETTINGS.PRKW.STATUS_CODE.get("SUCCESS", 200)

        analysis_metrics = LayoutAnalysisMetrics(
            layout_code          = layout_code,
            layout_reason        = response.detail,
            layout_total_no      = len(_success_list) + len(_fail_list),
            layout_success_no    = len(_success_list),
            layout_fail_no       = len(_fail_list),
            layout_total_page_no = total_page_no,
            layout_analysis_time = time.time() - start_at
        )

        return _success_list, _fail_list, analysis_metrics, response


    def test_pdf_analyzer(self, knowledge_id: str, file_path: str, blob_url: str, media_snapshot: bool=True) -> tuple[list[KnowDataObject], list[KnowDataObject], LayoutAnalysisMetrics, Response]:
        """
        Analyzes PDF documents using external processing service to extract structured content.
        Maintains consistent error handling and metrics reporting with default_pdf_analyzer.
        """
        def downsize_image(image_path, default_resolution, max_token=100000):
            original_image = Image.open(image_path)
            resolution = default_resolution
            while True:
                original_width, original_height = original_image.size
                if original_width < original_height:
                    new_width = resolution
                    new_height = min(max(int(original_height * (new_width / original_width)),  50), 5000)
                else:
                    new_height = resolution
                    new_width = min(max(int(original_width * (new_height / original_height)), 50), 5000)

                resized_image = original_image.resize((new_width, new_height), Image.Resampling.LANCZOS)
                logger.info(f"Image resized to {new_width}x{new_height}")
                
                buffer = BytesIO()
                resized_image.save(buffer, format="JPEG")
                base64_str = base64.b64encode(buffer.getvalue()).decode("utf-8")
                base64_token_size = num_tokens_from_string(base64_str)

                if base64_token_size <= max_token:
                    # logger.info(f"The resolution resized image is {resolution}.")
                    return resized_image
                
                resolution -= 10
                if resolution <= 0:
                    logger.error(f"Unable to reduce image size enough to fit within the token limit.")
                    raise
        
        def rename_file(directory, prev_file_name, new_file_name):
            # Rename local image file
            prev_path = os.path.join(directory, prev_file_name)
            new_path = os.path.join(directory, new_file_name)
            os.rename(prev_path, new_path)
            return new_path
        
        def split_text_with_overlap(text, max_tokens=1024, overlap_words=50):
            """Helper function to split text into chunks with overlap"""
            words = text.split()
            chunks = []
            current_chunk = []
            current_tokens = 0
            space_buffer = 1
            
            for word in words:
                word_tokens = num_tokens_from_string(word) + space_buffer
                if current_tokens + word_tokens > max_tokens and current_chunk:
                    # Store current chunk
                    chunks.append(' '.join(current_chunk))
                    # Keep last few words for overlap
                    overlap_text = ' '.join(current_chunk[-overlap_words:])
                    current_chunk = overlap_text.split()
                    current_tokens = num_tokens_from_string(overlap_text)
                
                current_chunk.append(word)
                current_tokens += word_tokens
            
            if current_chunk:
                chunks.append(' '.join(current_chunk))
            
            return chunks
        
        _success_list = []
        _fail_list = []
        sequence_no = 1
        total_page_no = 0
        start_at = time.time()
        response = Response(status_code=500, detail=self.response_format.error("Analysis Not Started"))

        try:
            if not blob_url:
                # Upload PDF to Azure Blob Storage for pdf parser API call
                file_name = file_path.split(os.path.sep)[-1]
                blob_path = f"{SETTINGS.BLOB.PASRER_FOLDER_NAME}/pdf/{file_name}"
                blob_file_url = upload_to_blob(local_path=file_path, blob_path=blob_path, content_type='application/pdf')
            else:
                blob_file_url = blob_url

            attempt = 0
            while attempt < SETTINGS.PDFEXT.RETRY:
                try:
                    # External service initialization
                    create_response = httpx.post(
                        f'{SETTINGS.PDFEXT.HOST}:{SETTINGS.PDFEXT.PORT}/{SETTINGS.PDFEXT.REQUEST_CREATE_API}',
                        json={'file_path': blob_file_url},
                        verify=SETTINGS.BASE.APP_PRODUCTION
                    )
                    if create_response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        raise Exception(f"Job creation failed: {create_response.text}")
                    
                    job_id = create_response.json().get('job_id')
                    if not job_id:
                        raise Exception("Invalid job ID received")

                    # Job status polling
                    start_poll_time = time.time()
                    processing_complete = False
                    
                    while (time.time() - start_poll_time) < SETTINGS.PDFEXT.MAX_DURATION:
                        status_response = httpx.get(
                            f'{SETTINGS.PDFEXT.HOST}:{SETTINGS.PDFEXT.PORT}/{SETTINGS.PDFEXT.REQUEST_STATUS_API}?job_id={job_id}',
                            verify=SETTINGS.BASE.APP_PRODUCTION
                        )
                        logger.info(f"Current job status: {status_response.json().get('job_status')}")
                        
                        if status_response.json().get('job_status') == 'done':
                            processing_complete = True
                            break
                        elif status_response.json().get('job_status') == 'failed':
                            raise Exception(f"Error processing PDF")
                        elif status_response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                            raise Exception(f"Failed to get job status: {status_response.text}")
                        time.sleep(SETTINGS.PDFEXT.POLL_INTERVAL)

                    if not processing_complete:
                        raise Exception(f"Processing timed out after {SETTINGS.PDFEXT.MAX_DURATION/3600:.1f} hours")
                    else:
                        break
                except Exception as e:
                    attempt += 1
                    logger.info(f"Failed to parse pdf due to {str(e)}, retrying {attempt} times...")
                
            if attempt >= SETTINGS.PDFEXT.RETRY or not processing_complete:
                raise Exception(f"Failed to parse pdf after retried {attempt} times")

            # Results processing
            try:
                result_info = status_response.json().get('result_info')
                json_blob_url = result_info.get('res_path')
                image_blob_dir = result_info.get('images_path')
                logger.info(f"Resulting files url: {json_blob_url} and {image_blob_dir}")
            except Exception as e:
                logger.error(f"Failed to extract blob url from response: {str(e)}")
                raise FileNotFoundError(f"Failed to extract blob url from response: {str(e)}")

            json_file_name = urllib.parse.unquote(json_blob_url.split('/')[-1])
            local_dir = os.path.join(SETTINGS.PREP.STORAGE_TEMP_RDIR, SETTINGS.PREP.STORAGE_TEMP_SDIR)
            local_json_path = normalize_path(os.path.join(local_dir, SETTINGS.BLOB.PASRER_FOLDER_NAME, 'parsed-result', job_id, json_file_name))
            local_images_dir = normalize_path(os.path.join(local_dir, SETTINGS.BLOB.PASRER_FOLDER_NAME, 'parsed-result', job_id, 'images'))
            
            try:                    
                # Ensure local directories exist for downloaded files
                os.makedirs(local_dir, exist_ok=True)
                os.makedirs(local_images_dir, exist_ok=True)

                # remoted_blob_prefix = f"{SETTINGS.BLOB.PASRER_FOLDER_NAME}/parsed-result/{job_id}"

                # Download the main JSON file
                # blob_path = f"{remoted_blob_prefix}/{json_file_name}"
                # download_from_blob(blob_path=blob_path, local_path=local_json_path)
                if json_blob_url:
                    download_from_blob_by_url(blob_file_url=json_blob_url, local_path=local_json_path)

                # Download all images in the images folder
                # images_prefix = f"{remoted_blob_prefix}/images/"
                # download_blob_files(blob_path_prefix=images_prefix, local_dir=local_images_dir, skip_folders=['images'])
                if image_blob_dir:
                    download_blob_files(blob_path_prefix=image_blob_dir, local_dir=local_images_dir, skip_folders=['images'])

            except Exception as e:
                logger.error(f"Failed to download from Azure Blob Storage: {str(e)}")
                raise FileNotFoundError(f"Failed to retrieve files from Azure: {str(e)}")

            # Check if the file exists (whether from Azure download or local path)
            if not os.path.exists(local_json_path):
                raise FileNotFoundError(f"Processed results not found at {local_json_path}")

            with open(local_json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                total_page_no = len(data['pdf_info'])
                response = Response(status_code=200, detail=self.response_format.ok(f"Total page no: {total_page_no}"))
                logger.info(response.detail)

                for page in data['pdf_info']:
                    page_idx = page['page_idx']
                    image_idx = 1
                    table_idx = 1

                    for block in page.get('para_blocks', []):
                        # Text processing
                        if block['type'] in {'text', 'title', 'list', 'index'}:
                            current_chunk = []
                            current_lines = []
                            line_tracker = {'start': None, 'end': None}
                            data_type = block['type'] == 'title' and 'TITLE' or 'TEXT'
                            
                            # Paragraph processing
                            for line in block.get('lines', []):
                                # Line processing
                                line_text = ' '.join(
                                    span['content'] 
                                    for span in line.get('spans', []) 
                                    if span.get('content')
                                )

                                if not current_chunk:
                                    line_tracker = {'start': line.get('index', 0), 'end': line.get('index', 0)}
                                
                                line_tokens = num_tokens_from_string(line_text)
                                current_tokens = num_tokens_from_string(' '.join(current_chunk))
                                
                                # Chunk processing logic
                                if not current_chunk and line_tokens > SETTINGS.PRKW.MAX_TOKEN_LIMIT:
                                    # Split text into chunks with overlap when the line text is too long
                                    chunks = split_text_with_overlap(line_text, SETTINGS.PRKW.MAX_TOKEN_LIMIT)
                                    for text_chunk in chunks:
                                        if text_chunk.strip():
                                            _success_list.append(KnowDataObject(
                                                data_type=    data_type,
                                                raw_data=     text_chunk.strip(),
                                                data_length=  len(text_chunk.strip()),
                                                coord_x1=     line['bbox'][0],
                                                coord_y1=     line['bbox'][1],
                                                coord_x2=     line['bbox'][2],
                                                coord_y2=     line['bbox'][3],
                                                page_start=   page_idx + 1,
                                                page_end=     page_idx + 1,
                                                line_start=   line_tracker['start'] + 1,
                                                line_end=     line_tracker['end'] + 1,
                                                seq_no=       sequence_no,
                                                knowledge_id= knowledge_id
                                            ))
                                            sequence_no += 1
                                elif current_chunk and current_tokens + line_tokens > SETTINGS.PRKW.MAX_TOKEN_LIMIT:
                                    current_chunk_text = ' '.join(current_chunk).strip()
                                    if current_chunk_text:
                                        # Calculate coordinates for current chunk
                                        if current_lines:
                                            first_line = current_lines[0]
                                            last_line = current_lines[-1]
                                            chunk_coords = {
                                                "coord_x1": min(line['bbox'][0] for line in current_lines),
                                                "coord_y1": first_line['bbox'][1],  # Top Y of first line
                                                "coord_x2": max(line['bbox'][2] for line in current_lines),
                                                "coord_y2": last_line['bbox'][3]   # Bottom Y of last line
                                            }
                                        else:
                                            chunk_coords = {
                                                "coord_x1": block['bbox'][0],
                                                "coord_y1": block['bbox'][1],
                                                "coord_x2": block['bbox'][2],
                                                "coord_y2": block['bbox'][3]
                                            }

                                        _success_list.append(KnowDataObject(
                                            data_type=    data_type,
                                            raw_data=     current_chunk_text,
                                            data_length=  len(current_chunk_text),
                                            coord_x1=     chunk_coords['coord_x1'],
                                            coord_y1=     chunk_coords['coord_y1'],
                                            coord_x2=     chunk_coords['coord_x2'],
                                            coord_y2=     chunk_coords['coord_y2'],
                                            page_start=   page_idx + 1,
                                            page_end=     page_idx + 1,
                                            line_start=   line_tracker['start'] + 1,
                                            line_end=     line_tracker['end'] + 1,
                                            seq_no=       sequence_no,
                                            knowledge_id= knowledge_id
                                        ))
                                        sequence_no += 1
                                    
                                    # Start new chunk with previous line for overlap
                                    current_chunk = [current_chunk[-1], line_text] 
                                    current_lines = [current_lines[-1], line]
                                    line_tracker = {'start': current_lines[-1].get('index'), 'end': line.get('index', 0)}
                                else:
                                    current_chunk.append(line_text)
                                    current_lines.append(line)
                                    line_tracker['end'] = line.get('index', 0)

                            remaining_line_text = ' '.join(current_chunk).strip()
                            if current_chunk and remaining_line_text:
                                if current_lines:
                                    first_line = current_lines[0]
                                    last_line = current_lines[-1]
                                    chunk_coords = {
                                        "coord_x1": min(line['bbox'][0] for line in current_lines),
                                        "coord_y1": first_line['bbox'][1],
                                        "coord_x2": max(line['bbox'][2] for line in current_lines),
                                        "coord_y2": last_line['bbox'][3]
                                    }
                                else:
                                    chunk_coords = {
                                        "coord_x1": block['bbox'][0],
                                        "coord_y1": block['bbox'][1],
                                        "coord_x2": block['bbox'][2],
                                        "coord_y2": block['bbox'][3]
                                    }

                                _success_list.append(KnowDataObject(
                                    data_type=    data_type,
                                    raw_data=     remaining_line_text,
                                    data_length=  len(remaining_line_text),
                                    coord_x1=     chunk_coords['coord_x1'],
                                    coord_y1=     chunk_coords['coord_y1'],
                                    coord_x2=     chunk_coords['coord_x2'],
                                    coord_y2=     chunk_coords['coord_y2'],
                                    page_start=   page_idx + 1,
                                    page_end=     page_idx + 1,
                                    line_start=   line_tracker['start'] + 1,
                                    line_end=     line_tracker['end'] + 1,
                                    seq_no=       sequence_no,
                                    knowledge_id= knowledge_id
                                ))
                                sequence_no += 1

                        # Image processing
                        elif block['type'] == 'image' and image_blob_dir:
                            for image_block in block.get('blocks', []):
                                for line in image_block.get('lines', []):
                                    for span in line.get('spans', []):
                                        if span.get('type') == 'image' and span.get('image_path'):
                                            file_path = ""
                                            try:
                                                if media_snapshot:
                                                    prev_filename = span['image_path']
                                                    filename = knowledge_id + f'_image_page-{page_idx+1}_{image_idx}_' + str(datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) + f'.{SETTINGS.PRKW.IMAGE_EXTENSION}'
                                                    file_path = rename_file(local_images_dir, prev_filename, filename)
                                                    resized_image = downsize_image(image_path=file_path, default_resolution=SETTINGS.PRKW.IMAGE_RESOLUTION)
                                                    resized_image.save(file_path)
                                                    
                                                    prev_blob_path = f"{image_blob_dir}/{prev_filename}"
                                                    new_blob_path = f"{image_blob_dir}/{filename}"
                                                    file_path = rename_blob_file(local_path=file_path, new_blob_path=new_blob_path, prev_blob_path=prev_blob_path, content_type='image/jpeg')

                                                    # new_image_blob_dir = image_blob_dir.replace(SETTINGS.BLOB.PASRER_FOLDER_NAME, SETTINGS.BLOB.FOLDER_NAME)
                                                    # new_blob_path = f"{new_image_blob_dir}/{filename}"
                                                    # file_path = upload_to_blob(local_path=file_path, blob_path=new_blob_path, content_type='image/jpeg') 
                                                    response = Response(status_code=201, detail=self.response_format.ok(f"Saved Image : <{SETTINGS.BASE.APP_NAME}> Saved Image <{image_idx}>"))
                                                else:
                                                    response  = Response(status_code=200, detail=self.response_format.ok(f"Skipped Media Snapshot : <{SETTINGS.BASE.APP_NAME}> Skipped Media Snapshot <{image_idx}>"))
                                                image_idx += 1
                                            except Exception as e:
                                                response = Response(status_code=500, detail=self.response_format.error(f"Image Saving Error : <{SETTINGS.BASE.APP_NAME}> Failed to Save Image <{image_idx}>", str(e)))
                                                logger.error(response.detail)

                                            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:   
                                                _fail_list.append(KnowDataObject(
                                                    data_type='IMAGE',
                                                    raw_data='ERROR',
                                                    coord_x1=block['bbox'][0],
                                                    coord_y1=block['bbox'][1],
                                                    coord_x2=block['bbox'][2],
                                                    coord_y2=block['bbox'][3],
                                                    page_start=page_idx + 1,
                                                    page_end=page_idx + 1,
                                                    seq_no=sequence_no,
                                                    knowledge_id=knowledge_id
                                                ))
                                                sequence_no += 1
                                            else:
                                                _success_list.append(KnowDataObject(
                                                    data_type='IMAGE',
                                                    data_url=file_path,
                                                    coord_x1=block['bbox'][0],
                                                    coord_y1=block['bbox'][1],
                                                    coord_x2=block['bbox'][2],
                                                    coord_y2=block['bbox'][3],
                                                    page_start=page_idx + 1,
                                                    page_end=page_idx + 1,
                                                    seq_no=sequence_no,
                                                    knowledge_id=knowledge_id
                                                ))
                                                sequence_no += 1

                        # Table processing        
                        elif block['type'] == 'table' and image_blob_dir:
                            for table_block in block.get('blocks', []):
                                for line in table_block.get('lines', []):
                                    for span in line.get('spans', []):
                                        if span.get('type') == 'table' and span.get('html'):
                                            file_path = ""
                                            try:
                                                if media_snapshot:
                                                    prev_filename = span['image_path']
                                                    filename = knowledge_id + f'_table_page-{page_idx+1}_{table_idx}_' + str(datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) + f'.{SETTINGS.PRKW.TABLE_EXTENSION}'
                                                    file_path = rename_file(local_images_dir, prev_filename, filename)
                                                    resized_image = downsize_image(image_path=file_path, default_resolution=SETTINGS.PRKW.TABLE_RESOLUTION)
                                                    resized_image.save(file_path)

                                                    prev_blob_path = f"{image_blob_dir}/{prev_filename}"
                                                    new_blob_path = f"{image_blob_dir}/{filename}"
                                                    file_path = rename_blob_file(local_path=file_path, new_blob_path=new_blob_path, prev_blob_path=prev_blob_path, content_type='image/jpeg')

                                                    # new_image_blob_dir = image_blob_dir.replace(SETTINGS.BLOB.PASRER_FOLDER_NAME, SETTINGS.BLOB.FOLDER_NAME)
                                                    # new_blob_path = f"{new_image_blob_dir}/{filename}"
                                                    # file_path = upload_to_blob(local_path=file_path, blob_path=new_blob_path, content_type='image/jpeg') 
                                                    response = Response(status_code=201, detail=self.response_format.ok(f"Saved Table : <{SETTINGS.BASE.APP_NAME}> Saved Table <{table_idx}>"))
                                                else:
                                                    response  = Response(status_code=200, detail=self.response_format.ok(f"Skipped Media Snapshot : <{SETTINGS.BASE.APP_NAME}> Skipped Media Snapshot <{table_idx}>"))
                                                table_idx += 1
                                            except Exception as e:
                                                response = Response(status_code=500, detail=self.response_format.error(f"Table Saving Error : <{SETTINGS.BASE.APP_NAME}> Failed to Save Table <{table_idx}>", str(e)))
                                                logger.error(response.detail)

                                            # Ignore table capture error 

                                            _success_list.append(KnowDataObject(
                                                data_type='TABLE',
                                                data_url=file_path,
                                                raw_data=span['html'],
                                                coord_x1=block['bbox'][0],
                                                coord_y1=block['bbox'][1],
                                                coord_x2=block['bbox'][2],
                                                coord_y2=block['bbox'][3],
                                                page_start=page_idx + 1,
                                                page_end=page_idx + 1,
                                                seq_no=sequence_no,
                                                knowledge_id=knowledge_id
                                            ))
                                            sequence_no += 1

            # Delete the temporary uploaded PDF from Azure Blob Storage
            # delete_blob_file(blob=blob_file_url)
            response = Response(status_code=200, detail=self.response_format.ok(f"Layout Analysis Completed : <{SETTINGS.BASE.APP_NAME}> Completed Layout Analysis"))
            logger.info(response.detail)

        except Exception as e:
            response = Response(
                status_code=500, 
                detail=self.response_format.error(f"Layout Analysis Error : <{SETTINGS.BASE.APP_NAME}> Failed to Process PDF", str(e))
            )
            logger.error(response.detail)

        analysis_metrics = LayoutAnalysisMetrics(
            layout_code          = response.status_code,
            layout_reason        = response.detail,
            layout_total_no      = len(_success_list) + len(_fail_list),
            layout_success_no    = len(_success_list),
            layout_fail_no       = len(_fail_list),
            layout_total_page_no = total_page_no,
            layout_analysis_time = time.time() - start_at
        )

        return _success_list, _fail_list, analysis_metrics, response
    
    def fake_pdf_analyzer(self, knowledge_id: str, file_path: str, blob_url: str, media_snapshot: bool=True) -> tuple[list[KnowDataObject], list[KnowDataObject], LayoutAnalysisMetrics, Response]:
        """
        Fake pdf analyzer, only for faking
        """
        def downsize_image(image_path, default_resolution, max_token=100000):
            original_image = Image.open(image_path)
            resolution = default_resolution
            while True:
                original_width, original_height = original_image.size
                if original_width < original_height:
                    new_width = resolution
                    new_height = min(max(int(original_height * (new_width / original_width)),  50), 1000)
                else:
                    new_height = resolution
                    new_width = min(max(int(original_width * (new_height / original_height)), 50), 1000)

                resized_image = original_image.resize((new_width, new_height), Image.Resampling.LANCZOS)
                
                buffer = BytesIO()
                resized_image.save(buffer, format="JPEG")
                base64_str = base64.b64encode(buffer.getvalue()).decode("utf-8")
                base64_token_size = num_tokens_from_string(base64_str)

                if base64_token_size <= max_token:
                    # logger.info(f"The resolution resized image is {resolution}.")
                    return resized_image
                
                resolution -= 10
                if resolution <= 0:
                    logger.error(f"Unable to reduce image size enough to fit within the token limit.")
                    raise
        
        def rename_file(directory, prev_file_name, new_file_name):
            # Rename local image file
            prev_path = os.path.join(directory, prev_file_name)
            new_path = os.path.join(directory, new_file_name)
            os.rename(prev_path, new_path)
            return new_path
        
        def split_text_with_overlap(text, max_tokens=1024, overlap_words=50):
            """Helper function to split text into chunks with overlap"""
            words = text.split()
            chunks = []
            current_chunk = []
            current_tokens = 0
            space_buffer = 1
            
            for word in words:
                word_tokens = num_tokens_from_string(word) + space_buffer
                if current_tokens + word_tokens > max_tokens and current_chunk:
                    # Store current chunk
                    chunks.append(' '.join(current_chunk))
                    # Keep last few words for overlap
                    overlap_text = ' '.join(current_chunk[-overlap_words:])
                    current_chunk = overlap_text.split()
                    current_tokens = num_tokens_from_string(overlap_text)
                
                current_chunk.append(word)
                current_tokens += word_tokens
            
            if current_chunk:
                chunks.append(' '.join(current_chunk))
            
            return chunks
        
        _success_list = []
        _fail_list = []
        sequence_no = 1
        total_page_no = 0
        start_at = time.time()
        response = Response(status_code=500, detail=self.response_format.error("Analysis Not Started"))

        try:
            blob_file_url = urllib.parse.unquote(file_path)
            file_name = blob_file_url.split('/')[-1]

            name_without_ext = os.path.splitext(file_name)[0]
            prudential_folder = 'prudential_parse_result'

            # Results processing
            local_dir = normalize_path(os.path.join(SETTINGS.PREP.STORAGE_TEMP_RDIR, SETTINGS.PREP.STORAGE_TEMP_SDIR, name_without_ext))
            source_dir = normalize_path(os.path.join(SETTINGS.PREP.STORAGE_TEMP_RDIR, prudential_folder, name_without_ext))
            fake_job_id = str(uuid.uuid4())

            if not os.path.exists(source_dir):
                logger.error(f"Source directory does not exits: {source_dir}")
                raise Exception(f"Source directory does not exits: {source_dir}")

            os.makedirs(local_dir, exist_ok=True)

            # Copy entire pdf folder to local directory
            try:
                for item in os.listdir(source_dir):
                    s = os.path.join(source_dir, item)
                    d = os.path.join(local_dir, item)
                    if os.path.isdir(s):
                        shutil.copytree(s, d)
                    elif item.endswith('_middle.json'):
                        local_json_path = d
                        shutil.copy2(s, d)
                logger.info(f"Folder copied successfully from '{source_dir}' to '{local_dir}")
            except Exception as e:
                logger.error(f"Error occur while copying folder: {str(e)}")
                raise

            local_images_dir = os.path.join(local_dir, "images")

            # Check if the file exists (whether from Azure download or local path)
            if not os.path.exists(local_json_path):
                raise FileNotFoundError(f"Processed results not found at {local_json_path}")
            
            # json_blob_path = f"{SETTINGS.BLOB.PASRER_FOLDER_NAME}/parsed-result/{name_without_ext}/{name_without_ext}_middle.json"
            # json_blob_path = upload_to_blob(local_path=local_json_path, blob_path=json_blob_path, content_type='application/json')
    
            with open(local_json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                total_page_no = len(data['pdf_info'])
                response = Response(status_code=200, detail=self.response_format.ok(f"Total page no: {total_page_no}"))
                logger.info(response.detail)

                for page in data['pdf_info']:
                    page_idx = page['page_idx']
                    image_idx = 1
                    table_idx = 1

                    for block in page.get('para_blocks', []):
                        # Text processing
                        if block['type'] in {'text', 'title', 'list', 'index'}:
                            current_chunk = []
                            current_lines = []
                            line_tracker = {'start': None, 'end': None}
                            data_type = block['type'] == 'title' and 'TITLE' or 'TEXT'
                            
                            # Paragraph processing
                            for line in block.get('lines', []):
                                # Line processing
                                line_text = ' '.join(
                                    span['content'] 
                                    for span in line.get('spans', []) 
                                    if span.get('content')
                                )

                                if not current_chunk:
                                    line_tracker = {'start': line.get('index', 0), 'end': line.get('index', 0)}
                                
                                line_tokens = num_tokens_from_string(line_text)
                                current_tokens = num_tokens_from_string(' '.join(current_chunk))
                                
                                # Chunk processing logic
                                if not current_chunk and line_tokens > SETTINGS.PRKW.MAX_TOKEN_LIMIT:
                                    # Split text into chunks with overlap when the line text is too long
                                    chunks = split_text_with_overlap(line_text, SETTINGS.PRKW.MAX_TOKEN_LIMIT)
                                    for text_chunk in chunks:
                                        if text_chunk.strip():
                                            _success_list.append(KnowDataObject(
                                                data_type=    data_type,
                                                raw_data=     text_chunk.strip(),
                                                data_length=  len(text_chunk.strip()),
                                                coord_x1=     line['bbox'][0],
                                                coord_y1=     line['bbox'][1],
                                                coord_x2=     line['bbox'][2],
                                                coord_y2=     line['bbox'][3],
                                                page_start=   page_idx + 1,
                                                page_end=     page_idx + 1,
                                                line_start=   line_tracker['start'] + 1,
                                                line_end=     line_tracker['end'] + 1,
                                                seq_no=       sequence_no,
                                                knowledge_id= knowledge_id
                                            ))
                                            sequence_no += 1
                                elif current_chunk and current_tokens + line_tokens > SETTINGS.PRKW.MAX_TOKEN_LIMIT:
                                    current_chunk_text = ' '.join(current_chunk).strip()
                                    if current_chunk_text:
                                        # Calculate coordinates for current chunk
                                        if current_lines:
                                            first_line = current_lines[0]
                                            last_line = current_lines[-1]
                                            chunk_coords = {
                                                "coord_x1": min(line['bbox'][0] for line in current_lines),
                                                "coord_y1": first_line['bbox'][1],  # Top Y of first line
                                                "coord_x2": max(line['bbox'][2] for line in current_lines),
                                                "coord_y2": last_line['bbox'][3]   # Bottom Y of last line
                                            }
                                        else:
                                            chunk_coords = {
                                                "coord_x1": block['bbox'][0],
                                                "coord_y1": block['bbox'][1],
                                                "coord_x2": block['bbox'][2],
                                                "coord_y2": block['bbox'][3]
                                            }

                                        _success_list.append(KnowDataObject(
                                            data_type=    data_type,
                                            raw_data=     current_chunk_text,
                                            data_length=  len(current_chunk_text),
                                            coord_x1=     chunk_coords['coord_x1'],
                                            coord_y1=     chunk_coords['coord_y1'],
                                            coord_x2=     chunk_coords['coord_x2'],
                                            coord_y2=     chunk_coords['coord_y2'],
                                            page_start=   page_idx + 1,
                                            page_end=     page_idx + 1,
                                            line_start=   line_tracker['start'] + 1,
                                            line_end=     line_tracker['end'] + 1,
                                            seq_no=       sequence_no,
                                            knowledge_id= knowledge_id
                                        ))
                                        sequence_no += 1
                                    
                                    # Start new chunk with previous line for overlap
                                    current_chunk = [current_chunk[-1], line_text] 
                                    current_lines = [current_lines[-1], line]
                                    line_tracker = {'start': current_lines[-1].get('index'), 'end': line.get('index', 0)}
                                else:
                                    current_chunk.append(line_text)
                                    current_lines.append(line)
                                    line_tracker['end'] = line.get('index', 0)

                            remaining_line_text = ' '.join(current_chunk).strip()
                            if current_chunk and remaining_line_text:
                                if current_lines:
                                    first_line = current_lines[0]
                                    last_line = current_lines[-1]
                                    chunk_coords = {
                                        "coord_x1": min(line['bbox'][0] for line in current_lines),
                                        "coord_y1": first_line['bbox'][1],
                                        "coord_x2": max(line['bbox'][2] for line in current_lines),
                                        "coord_y2": last_line['bbox'][3]
                                    }
                                else:
                                    chunk_coords = {
                                        "coord_x1": block['bbox'][0],
                                        "coord_y1": block['bbox'][1],
                                        "coord_x2": block['bbox'][2],
                                        "coord_y2": block['bbox'][3]
                                    }

                                _success_list.append(KnowDataObject(
                                    data_type=    data_type,
                                    raw_data=     remaining_line_text,
                                    data_length=  len(remaining_line_text),
                                    coord_x1=     chunk_coords['coord_x1'],
                                    coord_y1=     chunk_coords['coord_y1'],
                                    coord_x2=     chunk_coords['coord_x2'],
                                    coord_y2=     chunk_coords['coord_y2'],
                                    page_start=   page_idx + 1,
                                    page_end=     page_idx + 1,
                                    line_start=   line_tracker['start'] + 1,
                                    line_end=     line_tracker['end'] + 1,
                                    seq_no=       sequence_no,
                                    knowledge_id= knowledge_id
                                ))
                                sequence_no += 1

                        # Image processing
                        elif block['type'] == 'image':
                            for image_block in block.get('blocks', []):
                                for line in image_block.get('lines', []):
                                    for span in line.get('spans', []):
                                        if span.get('type') == 'image' and span.get('image_path'):
                                            file_path = ""
                                            try:
                                                if media_snapshot:
                                                    prev_filename = span['image_path']
                                                    filename = knowledge_id + f'_image_page-{page_idx+1}_{image_idx}_' + str(datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) + f'.{SETTINGS.PRKW.IMAGE_EXTENSION}'
                                                    file_path = rename_file(local_images_dir, prev_filename, filename)
                                                    resized_image = downsize_image(image_path=file_path, default_resolution=SETTINGS.PRKW.IMAGE_RESOLUTION)
                                                    resized_image.save(file_path)

                                                    blob_path = f"{SETTINGS.BLOB.PASRER_FOLDER_NAME}/parsed-result/{fake_job_id}/images/{filename}"
                                                    file_path = upload_to_blob(local_path=file_path, blob_path=blob_path, content_type='image/jpeg')
                                                    response = Response(status_code=201, detail=self.response_format.ok(f"Saved Image : <{SETTINGS.BASE.APP_NAME}> Saved Image <{image_idx}>"))
                                                else:
                                                    response  = Response(status_code=200, detail=self.response_format.ok(f"Skipped Media Snapshot : <{SETTINGS.BASE.APP_NAME}> Skipped Media Snapshot <{image_idx}>"))
                                                image_idx += 1
                                            except Exception as e:
                                                response = Response(status_code=500, detail=self.response_format.error(f"Image Saving Error : <{SETTINGS.BASE.APP_NAME}> Failed to Save Image <{image_idx}>", str(e)))
                                                logger.error(response.detail)

                                            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:   
                                                _fail_list.append(KnowDataObject(
                                                    data_type='IMAGE',
                                                    raw_data='ERROR',
                                                    coord_x1=block['bbox'][0],
                                                    coord_y1=block['bbox'][1],
                                                    coord_x2=block['bbox'][2],
                                                    coord_y2=block['bbox'][3],
                                                    page_start=page_idx + 1,
                                                    page_end=page_idx + 1,
                                                    seq_no=sequence_no,
                                                    knowledge_id=knowledge_id
                                                ))
                                                sequence_no += 1
                                            else:
                                                _success_list.append(KnowDataObject(
                                                    data_type='IMAGE',
                                                    data_url=file_path,
                                                    coord_x1=block['bbox'][0],
                                                    coord_y1=block['bbox'][1],
                                                    coord_x2=block['bbox'][2],
                                                    coord_y2=block['bbox'][3],
                                                    page_start=page_idx + 1,
                                                    page_end=page_idx + 1,
                                                    seq_no=sequence_no,
                                                    knowledge_id=knowledge_id
                                                ))
                                                sequence_no += 1

                        # Table processing        
                        elif block['type'] == 'table':
                            for table_block in block.get('blocks', []):
                                for line in table_block.get('lines', []):
                                    for span in line.get('spans', []):
                                        if span.get('type') == 'table' and span.get('html'):
                                            file_path = ""
                                            try:
                                                if media_snapshot:
                                                    prev_filename = span['image_path']
                                                    filename = knowledge_id + f'_table_page-{page_idx+1}_{table_idx}_' + str(datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) + f'.{SETTINGS.PRKW.TABLE_EXTENSION}'
                                                    file_path = rename_file(local_images_dir, prev_filename, filename)
                                                    resized_image = downsize_image(image_path=file_path, default_resolution=SETTINGS.PRKW.TABLE_RESOLUTION)
                                                    resized_image.save(file_path)
                                                    
                                                    blob_path = f"{SETTINGS.BLOB.PASRER_FOLDER_NAME}/parsed-result/{fake_job_id}/images/{filename}"
                                                    file_path = upload_to_blob(local_path=file_path, blob_path=blob_path, content_type='image/jpeg')
                                                    response = Response(status_code=201, detail=self.response_format.ok(f"Saved Table : <{SETTINGS.BASE.APP_NAME}> Saved Table <{table_idx}>"))
                                                else:
                                                    response  = Response(status_code=200, detail=self.response_format.ok(f"Skipped Media Snapshot : <{SETTINGS.BASE.APP_NAME}> Skipped Media Snapshot <{table_idx}>"))
                                                table_idx += 1
                                            except Exception as e:
                                                response = Response(status_code=500, detail=self.response_format.error(f"Table Saving Error : <{SETTINGS.BASE.APP_NAME}> Failed to Save Table <{table_idx}>", str(e)))
                                                logger.error(response.detail)

                                            _success_list.append(KnowDataObject(
                                                data_type='TABLE',
                                                data_url=file_path,
                                                raw_data=span['html'],
                                                data_length=len(span['html']),
                                                coord_x1=block['bbox'][0],
                                                coord_y1=block['bbox'][1],
                                                coord_x2=block['bbox'][2],
                                                coord_y2=block['bbox'][3],
                                                page_start=page_idx + 1,
                                                page_end=page_idx + 1,
                                                seq_no=sequence_no,
                                                knowledge_id=knowledge_id
                                            ))
                                            sequence_no += 1

            # Delete the temporary uploaded PDF from Azure Blob Storage
            # delete_blob_file(blob=blob_file_url)
            response = Response(status_code=200, detail=self.response_format.ok(f"Layout Analysis Completed : <{SETTINGS.BASE.APP_NAME}> Completed Layout Analysis"))
            logger.info(response.detail)

        except Exception as e:
            response = Response(
                status_code=500, 
                detail=self.response_format.error(f"Layout Analysis Error : <{SETTINGS.BASE.APP_NAME}> Failed to Process PDF", str(e))
            )
            logger.error(response.detail)

        analysis_metrics = LayoutAnalysisMetrics(
            layout_code          = response.status_code,
            layout_reason        = response.detail,
            layout_total_no      = len(_success_list) + len(_fail_list),
            layout_success_no    = len(_success_list),
            layout_fail_no       = len(_fail_list),
            layout_total_page_no = total_page_no,
            layout_analysis_time = time.time() - start_at
        )

        return _success_list, _fail_list, analysis_metrics, response