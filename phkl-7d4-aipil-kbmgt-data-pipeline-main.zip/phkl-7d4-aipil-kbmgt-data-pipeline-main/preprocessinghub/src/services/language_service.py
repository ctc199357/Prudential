from datetime import datetime, timezone
import time
import inspect
import httpx
from openai import AzureOpenAI
import json
import re
from ..settings import SETTINGS
from ..schemas.format import ResponseFormatter, Response
from ..schemas.language import (
    LanguageEngine, 
    LanguageTextRequest,
    LanguageTextResponse
)
from ..logger.log_handler import get_logger
from ..schemas.preptool import SecretPrepTool, KnowDataObject
from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient
import tiktoken

logger = get_logger(__name__)

def num_tokens_from_string(string: str, encoding_name: str="cl100k_base") -> int:
        encoding = tiktoken.get_encoding(encoding_name)
        num_tokens = len(encoding.encode(string))
        return num_tokens

class LanguageServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, engine: LanguageEngine | None = None):
        self.engine = engine

    def init_engine(self, config: SecretPrepTool) -> Response:
        self.engine = LanguageEngine(**config.__dict__)

        if self.engine.preptool_location.lower() == "azure":
            response = Response(status_code=200, detail=self.response_format.ok(f"Init Language Extraction Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Language Engine in Azure"))
        elif self.engine.preptool_location.lower() == "server":
            response = Response(status_code=200, detail=self.response_format.ok(f"Init Language Extraction Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Language Engine in Server"))
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Init Language Engine Error : <{SETTINGS.BASE.APP_NAME}> Cannot Recognize Language Engine Location <{self.engine.preptool_location}>"))

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            logger.error(response.detail)

        return response
    
    def text_language(self, request: LanguageTextRequest) -> tuple[LanguageTextResponse, Response]:
        response_data = LanguageTextResponse()
        start_at = time.time()

        """ 1. Init Language Engine """
        response = self.init_engine(config=request.preptool)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response

        """ 2. Extract Languages """
        success_data = []
        fail_data = []
        tool_tokens = 0
        
        if self.engine.preptool_location.lower() == "azure":
            languages, tool_tokens, response = self.azure_server(raw_data=[_data.raw_data for _data in request.data_input])
            
        elif self.engine.preptool_location.lower() == "server":
            if self.engine.preptool_engine.lower() == "ollama":
                processed_data, tool_tokens, response = self.ollama_server(raw_data=[_data.raw_data for _data in request.data_input])
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Language Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform Language <{self.engine.preptool_engine}>"))

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Language Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform Language <{self.engine.preptool_engine}>"))
            return response_data, response

        """ 3. Update result """
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response

        # Update the KnowDataObjects with detected languages
        for data_obj, lang_info in zip(request.data_input, languages):
            data_obj.__dict__.update(
                data_languages=[lang_info["language"]]
            )
            success_data.append(data_obj)

        """ 4. Process Response """
        response_data.__dict__.update(
            preptool_time = time.time() - start_at,
            preptool_tool_tokens = tool_tokens,
            success_objects = success_data,
            fail_objects = fail_data,
            total_no = len(request.data_input),
            success_no = len(success_data),
            fail_no = len(fail_data),
            response_at = datetime.now(timezone.utc)
        )

        return response_data, response
    

    def ollama_server(self, raw_data: list[str]) -> tuple[list[list[str]], int, Response, list[dict]]:
        processed_data = []
        tool_tokens = 0

        # Base payload setup
        payload = dict()
        
        # Model Options
        options = dict()
        if self.engine.preptool_parameters.get("options", None):
            options.update(self.engine.preptool_parameters.get("options"))
        if self.engine.preptool_secrets.get("options", None):
            options.update(self.engine.preptool_secrets.get("options"))
        if options:
            payload["options"] = options

        # Build prompt
        formatted_prompt = ""
        
        # System Prompt Formation
        if self.engine.preptool_parameters.get("system_prompt", None):
            formatted_prompt += "System:\n" + self.engine.preptool_parameters.get("system_prompt", "")

        # User Prompt Formation
        if self.engine.preptool_parameters.get("user_prompt", None):
            formatted_prompt += "User:\n" + self.engine.preptool_parameters.get("user_prompt", "")
        else:
            formatted_prompt += "User:\n" + "Extract the languages used from this text. Respond with languages only, separated by commas: "

        # Setup API call
        payload["model"] = self.engine.preptool_base
        payload["stream"] = False
        payload["raw"] = False
        api_url = f"http://{self.engine.preptool_host}:{self.engine.preptool_port}/{self.engine.preptool_api}"
                
        try:
            for _data in raw_data:
                processed_data.append({
                    "language": "en"
                })
            
            response = Response(status_code=200, detail=self.response_format.ok(f"Language Extraction Success : <{SETTINGS.BASE.APP_NAME}> Completed Language Extraction"))

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)
        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)

        return processed_data, tool_tokens, response

    def azure_server(self, raw_data: list[str]) -> tuple[list[dict], int, Response]:
        processed_data = []
        tool_tokens = 0

        try:
            # Create Text Analytics Client
            text_analytics_client = TextAnalyticsClient(
                endpoint=self.engine.preptool_host,
                credential=AzureKeyCredential(self.engine.preptool_secrets.get("api_key", ""))
            )

            batch_size = 10
            # response = []

            # Detect language in batches
            for i in range(0, len(raw_data), batch_size):
                batch_data = raw_data[i : i + batch_size]
                language_response = text_analytics_client.detect_language(documents=batch_data)

                documents_with_language = []
                for j, doc_text in enumerate(batch_data):
                    lang_result = language_response[j]
                    if not lang_result.is_error:
                        detected_lang = lang_result.primary_language.iso6391_name
                        if detected_lang == 'zh_cht' or detected_lang == 'zh_chs':
                            language = detected_lang
                        else:
                            language = 'en'
                    else:
                        if hasattr(lang_result.error, 'code') and lang_result.error.code == 'unsupportedLanguageCode':
                            language = 'en'
                            logger.warning(f"Unsupported language for document {i+j}, defaulting to English")
                        else:
                            language = 'en'
                            logger.error(f"Language detection error for document {i+j}: {lang_result.error.message}")

                    documents_with_language.append({
                        "id": str(i + j),
                        "text": doc_text,
                        "language": language
                    })

                processed_data.extend(documents_with_language)
            
            response = Response(
                status_code=200,
                detail=self.response_format.ok(
                    f"Azure Language Success : <{SETTINGS.BASE.APP_NAME}> Completed Azure Language Detection"
                ),
            )

        except httpx.TimeoutException as e:
            response = Response(
                status_code=502,
                detail=self.response_format.error(
                    f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Azure Server",
                    str(e),
                ),
            )
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(
                status_code=502,
                detail=self.response_format.error(
                    f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Azure Server",
                    str(e),
                ),
            )
            logger.error(response.detail)

        except (BaseException, Exception) as e:
            response = Response(
                status_code=500,
                detail=self.response_format.error(
                    f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Azure Server",
                    str(e),
                ),
            )
            logger.error(response.detail)

        except:
            response = Response(
                status_code=500,
                detail=self.response_format.error(
                    f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Azure Server",
                    str(e),
                ),
            )
            logger.error(response.detail)

        return processed_data, tool_tokens, response