from datetime import datetime, timezone
import time
import uuid
import inspect
import httpx

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.preptool import (
    PrepToolMetric,
    PrepToolPipelineRequest,
    PrepToolPipelineResponse
)

from ..schemas.embedding import EmbeddingTextRequest

from ..schemas.chunking import ChunkingTextRequest

from ..schemas.genai import GenAIRequest

from ..schemas.ocr import OCRRequest

from ..schemas.keywords import KeywordTextRequest

from ..schemas.summarization import SummarizationTextRequest

from ..services.embedding_service import EmbeddingServiceManager

from ..services.chunking_service import ChunkingServiceManager

from ..services.genai_service import GenAIServiceManager

from ..services.ocr_service import OCRServiceManager

from ..services.keyword_service import KeywordServiceManager

from ..services.language_service import LanguageServiceManager

from ..services.summarization_service import SummarizationServiceManager

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class PrepToolServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool):
        self.api_call = api_call

    """
        Request Operation
    """
    def preptool_pipeline(self, request: PrepToolPipelineRequest) -> tuple[PrepToolPipelineResponse, Response]:
        response_pipeline = PrepToolPipelineResponse(**request.__dict__)
        start_at = time.time()
        
        # 1. PrepTool Execution
        if request.preptool.preptool_type.lower() == "embedding":
            preptool_request = EmbeddingTextRequest(**request.__dict__)
            response_preptool, response = EmbeddingServiceManager().text_embedding(request=preptool_request)
            
        elif request.preptool.preptool_type.lower() == "chunking":
            preptool_request = ChunkingTextRequest(**request.__dict__)
            response_preptool, response = ChunkingServiceManager().text_chunking(request=preptool_request)

        elif request.preptool.preptool_type.lower() == "keyword":
            preptool_request = KeywordTextRequest(**request.__dict__)
            response_preptool, response = KeywordServiceManager().text_keyword(request=preptool_request)

        elif request.preptool.preptool_type.lower() == "language":
            preptool_request = KeywordTextRequest(**request.__dict__)
            response_preptool, response = LanguageServiceManager().text_language(request=preptool_request)

        elif request.preptool.preptool_type.lower() == "rerank_keyword":
            logger.info("Start Reranking Keyword")
            preptool_request = KeywordTextRequest(**request.__dict__)
            response_preptool, response = KeywordServiceManager().rerank_keyword(request=preptool_request)
                
        elif request.preptool.preptool_type.lower() == "summarization":
            preptool_request = SummarizationTextRequest(**request.__dict__)
            response_preptool, response = SummarizationServiceManager().text_summarization(request=preptool_request)

        elif request.preptool.preptool_type.lower() == "ocr":
            preptool_request = OCRRequest(**request.__dict__)
            response_preptool, response = OCRServiceManager().ocr(request=preptool_request)

        elif request.preptool.preptool_type.lower() == "image2text":
            preptool_request = GenAIRequest(**request.__dict__)
            response_preptool, response = GenAIServiceManager().image_to_text(request=preptool_request)

        elif request.preptool.preptool_type.lower() == "table2text":
            preptool_request = GenAIRequest(**request.__dict__)
            response_preptool, response = GenAIServiceManager().table_to_text(request=preptool_request)

        elif request.preptool.preptool_type.lower() == "relationship":
            preptool_request = GenAIRequest(**request.__dict__)
            response_preptool, response = GenAIServiceManager().relationship_extraction(request=preptool_request)

        elif request.preptool.preptool_type.lower() == "genai":
            # Output should be <KnowDataObject>
            pass

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Preptool Pipeline Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unrecognized preptool_type <{request.preptool.preptool_type}>"))
            
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            preptool_output = []
            preptool_metric = PrepToolMetric(
                **response_preptool.__dict__, 
                preptool_code        = SETTINGS.PRTL.STATUS_CODE.get("FAIL"), 
                preptool_reason      = response.detail,
                preptool_request_at  = request.request_at,
                preptool_response_at = datetime.now(timezone.utc)
            )

        else:
            preptool_output = response_preptool.success_objects
            preptool_metric = PrepToolMetric(
                **response_preptool.__dict__, 
                preptool_code        = SETTINGS.PRTL.STATUS_CODE.get("SUCCESS"), 
                preptool_reason      = "SUCCESS",
                preptool_request_at  = request.request_at,
                preptool_response_at = datetime.now(timezone.utc)
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepTool Completion : <{SETTINGS.BASE.APP_NAME}> Completed PrepTool Pipeline"))
        
        if request.preptool.preptool_type.lower() == "relationship":
            response_pipeline.__dict__.update(
            preptool_pipeline_code   = preptool_metric.preptool_code,
            preptool_pipeline_reason = preptool_metric.preptool_reason,
            preptool_relationship    = preptool_output,
            preptool_metric          = preptool_metric,
            response_at              = datetime.now(timezone.utc)
        )
        else:
            response_pipeline.__dict__.update(
                preptool_pipeline_code   = preptool_metric.preptool_code,
                preptool_pipeline_reason = preptool_metric.preptool_reason,
                preptool_output          = preptool_output,
                preptool_metric          = preptool_metric,
                response_at              = datetime.now(timezone.utc)
            )
        
        return response_pipeline, response

    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response