from datetime import datetime, timezone
import time
import uuid
import inspect
import httpx

# For encode image into image_url
import base64
from mimetypes import guess_type
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import OperationStatusCodes
from msrest.authentication import CognitiveServicesCredentials

from ..utils import (
    normalize_path,
    get_local_file_path
)
from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.preptool import SecretPrepTool

from ..schemas.ocr import (
    OCRRequest, 
    OCRResponse
)

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class OCRServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    """
        Request Operation
    """
    def ocr(self, request: OCRRequest) -> tuple[OCRResponse, Response]:
        response_data = OCRResponse()
        start_at      = time.time()

        ### TODO: Add Token Limit Check
        """ 1. Perform Token Limit Check for the raw_data"""
        if not all([raw_data.data_url for raw_data in request.data_input]):
            response = Response(status_code=404, detail=self.response_format.error(f"OCR Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform OCR due to Missing Image URL"))
            logger.error(response.detail)
            return response_data, response
        
        """ 2. Select Engine """
        success_data    = []
        fail_data       = []
        input_tokens    = 0
        output_tokens   = 0
        preptool_engine = None

        if request.preptool.preptool_location.lower() == "azure":
            preptool_engine = self.azure_server
            
        elif request.preptool.preptool_location.lower() == "server":
            
            if request.preptool.preptool_engine.lower() == "ollama":
                preptool_engine = self.ollama_server
                
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"OCR Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform OCR <{request.preptool.preptool_engine}>"))

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"OCR Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform OCR <{request.preptool.preptool_engine}>"))
        
        """ 3. OCR Data """
        if preptool_engine:
            for data in request.data_input:
                _processed_data, _input_tokens, _output_tokens, response = preptool_engine(preptool=request.preptool, image_path=data.data_url)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    fail_data.append(data)
                    logger.error(f"{response.detail} --- {data.data_url}")
                    break
                else:
                    success_data.append(_processed_data)

                input_tokens  += _input_tokens
                output_tokens += _output_tokens

        # 3.1. OCR Completed but Encountered Different Lengths between Raw Data and Processed Data
        if len(request.data_input) != len(success_data):
            response  = Response(status_code=500, detail=self.response_format.error(f"OCR Processing Error : <{SETTINGS.BASE.APP_NAME}> Found Unequal Number between Raw Data and Processed Data"))
            logger.error(response.detail)
            return response_data, response
        # 3.2. OCR Success 
        else:
            for _data_obj, _processed_data in zip(request.data_input, success_data):
                _data_obj.__dict__.update(data_id=str(uuid.uuid4()), data_traceid=str(uuid.uuid4()), raw_data=_processed_data, data_length=len(_processed_data), content_type=request.preptool.preptool_type)
            success_data = request.data_input
            response = Response(status_code=200, detail=self.response_format.ok(f"OCR Completed : <{SETTINGS.BASE.APP_NAME}> Completed OCR Process <{len(success_data)}>"))
            logger.info(response.detail)

        """ 5. Process Data """
        response_data.__dict__.update(
            preptool_time          = time.time() - start_at,
            preptool_input_tokens  = input_tokens,
            preptool_output_tokens = output_tokens,
            success_objects        = success_data,
            fail_objects           = fail_data,
            total_no               = len(request.data_input),
            success_no             = len(success_data),
            fail_no                = len(fail_data),
            response_at            = datetime.now(timezone.utc)
        )

        return response_data, response

    def ollama_server(self, preptool: SecretPrepTool, prompt: str='', image_path: str | None = None) -> tuple[str, int, int, Response]:
        processed_data = ""
        input_tokens   = 0
        output_tokens  = 0

        payload = dict()

        # Model Options
        options = dict()
        if preptool.preptool_parameters.get("options", None):
            options.update(preptool.preptool_parameters.get("options"))
        if preptool.preptool_secrets.get("options", None):
            options.update(preptool.preptool_secrets.get("options"))
        if options:
            payload["options"] = options
        
        # Prompt Fomration
        formatted_prompt = ""

        # System Prompt Formation
        if preptool.preptool_parameters.get("system_prompt", None):
            formatted_prompt += "System:\n" + preptool.preptool_parameters.get("system_prompt", "")

        # User Prompt Formation
        user_prompt = ""
        if prompt:
            user_prompt = prompt
        elif not prompt and preptool.preptool_parameters.get("user_prompt", None):
            user_prompt = preptool.preptool_parameters.get("user_prompt")
        else:
            user_prompt = "Describe the Image"

        formatted_prompt += "User:\n" + user_prompt

        # formatted_prompt = ""
        # model_keywords = preptool.preptool_parameters.get("model_keywords", {})
        
        # # System Prompt Formation
        # if preptool.preptool_parameters.get("system_prompt", None):
        #     system_prompt = preptool.preptool_secrets.get("system_prompt", "")
            
        #     if system_prompt:
        #         system_role_prompt = model_keywords.get("role_start", "") + 'system' + model_keywords.get("role_end", "")
        #         system_content     = model_keywords.get("content_start", "") + system_prompt + model_keywords.get("content_end", "")
        #         formatted_prompt   += system_role_prompt + system_content
        
        # # User Prompt Formation
        # user_prompt = ""
        # if prompt:
        #     user_prompt = prompt
        
        # elif not prompt and preptool.preptool_parameters.get("user_prompt", None):
        #     user_prompt = preptool.preptool_parameters.get("user_prompt", "Describe the Image")
        
        # if user_prompt:
        #     user_role_prompt = model_keywords.get("role_start", "") + 'user' + model_keywords.get("role_end", "")
        #     user_content     = model_keywords.get("content_start", "") + user_prompt + model_keywords.get("content_end", "")
        #     formatted_prompt += user_role_prompt + user_content


        
        # # System Prompt Formation
        # if preptool.preptool_parameters.get("system_prompt", None):
        #     system_prompt = preptool.preptool_secrets.get("system_prompt", "")
            
        # formatted_prompt = ""
        # model_keywords = preptool.preptool_parameters.get("model_keywords", {})
        
        # # System Prompt Formation
        # if preptool.preptool_parameters.get("system_prompt", None):
        #     system_prompt = preptool.preptool_secrets.get("system_prompt", "")
            
        #     if system_prompt:
        #         system_role_prompt = model_keywords.get("role_start", "") + 'system' + model_keywords.get("role_end", "")
        #         system_content     = model_keywords.get("content_start", "") + system_prompt + model_keywords.get("content_end", "")
        #         formatted_prompt   += system_role_prompt + system_content
        
        # # User Prompt Formation
        # user_prompt = ""
        # if prompt:
        #     user_prompt = prompt
        
        # elif not prompt and preptool.preptool_parameters.get("user_prompt", None):
        #     user_prompt = preptool.preptool_parameters.get("user_prompt", "Describe the Image")
        
        # if user_prompt:
        #     user_role_prompt = model_keywords.get("role_start", "") + 'user' + model_keywords.get("role_end", "")
        #     user_content     = model_keywords.get("content_start", "") + user_prompt + model_keywords.get("content_end", "")
        #     formatted_prompt += user_role_prompt + user_content
        
        # Multimedia Formation
        if image_path:
            encoded_images = []
            try:
                with open(image_path, "rb") as image_file:
                    base64_data = base64.b64encode(image_file.read()).decode('utf-8')
                    encoded_images.append(base64_data)
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Image Encoding Error : <{SETTINGS.BASE.APP_NAME}> Failed to Read / Encode Images"))
                logger.error(response.detail)
            payload["images"] = encoded_images

        payload["model"]  = preptool.preptool_base
        payload["prompt"] = formatted_prompt
        payload["stream"] = False
        payload["raw"]    = False

        api_url = f"http://{preptool.preptool_host}:{preptool.preptool_port}/{preptool.preptool_api}"
        
        # Post Request to Inference Server
        try:
            resp   = httpx.post(api_url, json=payload, timeout=SETTINGS.PRTL.OCR_TIMEOUT)
            result = resp.json()

            # Error during Calling Inference Server
            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=result["error"])
                logger.error(response.detail)
                return processed_data, input_tokens, output_tokens, response

            # Update Ouptut
            processed_data = result.get("response", "")
            input_tokens   = result.get("prompt_eval_count", 0)
            output_tokens  = result.get("eval_count", 0)
            response = Response(status_code=200, detail=self.response_format.ok(f"OCR Success : <{SETTINGS.BASE.APP_NAME}> Completed OCR"))

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)

        return processed_data, input_tokens, output_tokens, response


    def azure_server(self, preptool: SecretPrepTool, image_path: str | None = None) -> tuple[str, int, int, Response]:
        processed_data = ""
        input_tokens   = 0  # Will represent number of images processed
        output_tokens  = 0  # Will represent number of text lines extracted

        try:
            # Initialize the Computer Vision client
            vision_client = ComputerVisionClient(
                endpoint=f"{preptool.preptool_host}",
                credentials=CognitiveServicesCredentials(preptool.preptool_secrets.get("api_key", ""))
            )

            # Call API with image path and get operation location
            local_image_path = normalize_path(get_local_file_path(image_path))
    
            with open(local_image_path, "rb") as image_file:
                read_response = vision_client.read_in_stream(image_file, raw=True)

            # Get the operation location from the response
            operation_location = read_response.headers["Operation-Location"]
            operation_id = operation_location.split("/")[-1]

            # Wait for the operation to complete
            while True:
                read_result = vision_client.get_read_result(operation_id)
                if read_result.status not in ['notStarted', 'running']:
                    break
                time.sleep(1)

            # Process the results
            if read_result.status == OperationStatusCodes.succeeded:
                text_results = []
                for text_result in read_result.analyze_result.read_results:
                    for line in text_result.lines:
                        text_results.append(line.text)
                
                processed_data = "\n".join(text_results)
                if not processed_data or processed_data.strip() == '':
                    processed_data = "No text detected through OCR"
                
                response = Response(
                    status_code=200, 
                    detail=self.response_format.ok(f"OCR Success : <{SETTINGS.BASE.APP_NAME}> Completed OCR for Image {local_image_path}")
                )
                logger.info(response.detail)

            else:
                response = Response(
                    status_code=500,
                    detail=self.response_format.error(f"Azure OCR Error : <{SETTINGS.BASE.APP_NAME}> Failed to Process Image")
                )

        except Exception as e:
            response = Response(
                status_code=500,
                detail=self.response_format.error(f"Azure OCR Error : <{SETTINGS.BASE.APP_NAME}> {str(e)}")
            )
            logger.error(response.detail)

        return processed_data, input_tokens, output_tokens, response

    @staticmethod
    def local_image_to_data_url(image_path: str) -> str:

        # Guess the Mime type of the image based on the File Extension
        mime_type, _ = guess_type(image_path)
        if mime_type is None:
            mime_type = 'application/octet-stream'
        
        # Read and Encode Image
        with open(image_path, "rb") as image_file:
            encoded_iamge = base64.b64encode(image_file.read()).decode("utf-8")
        
        # Construct the data URL
        return f"data:{mime_type};base64,{encoded_iamge}"

    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response


