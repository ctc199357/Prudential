from datetime import datetime, timezone
import time
import uuid
import inspect
import httpx

# from langchain_community.embeddings import OpenAIEmbeddings
# from langchain_community.embeddings import HuggingFaceEmbeddings
# from langchain_community.embeddings import HuggingFaceInstructEmbeddings

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.preptool import SecretPrepTool

from ..schemas.embedding import (
    EmbeddingEngine, 
    EmbeddingTextRequest, 
    EmbeddingTextResponse
)

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class EmbeddingServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, engine: EmbeddingEngine | None = None):
        self.engine = engine

    """
        Request Operation
    """
    def init_engine(self, config: SecretPrepTool) -> Response:
        self.engine = EmbeddingEngine(**config.__dict__)

        if self.engine.preptool_location.lower() == "azure":
            response  = Response(status_code=200, detail=self.response_format.ok(f"Init Embedding Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Embedding Engine in Azure"))

        elif self.engine.preptool_location.lower() == "server":
            response = Response(status_code=200, detail=self.response_format.ok(f"Init Embedding Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Embedding Engine in Server"))

        # elif self.engine.preptool_location.lower() == "local":

        #     if self.engine.preptool_engine.lower() == "huggingfaceinstructembeddings":
        #         try:
        #             self.engine.preptool_local_engine = HuggingFaceInstructEmbeddings()
        #             response = Response(status_code=200, detail=self.response_format.ok(f"Init Embedding Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Embedding Engine in Local"))
        #         except:
        #             response = Response(status_code=500, detail=self.response_format.error(f"Init Embedding Engine Error : <{SETTINGS.BASE.APP_NAME}> Failed to Init Embedding Engine <{self.engine.preptool_engine}>"))
            
        #     elif self.engine.preptool_engine.lower() == "hugginfacemebddings":
        #         try:
        #             self.engine.preptool_local_engine = HuggingFaceEmbeddings(model_name=self.engine.preptool_model)
        #             response = Response(status_code=200, detail=self.response_format.ok(f"Init Embedding Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Embedding Engine in Local"))
        #         except:
        #             response = Response(status_code=500, detail=self.response_format.error(f"Init Embedding Engine Error : <{SETTINGS.BASE.APP_NAME}> Failed to Init Embedding Engine <{self.engine.preptool_engine}>"))
            
        #     elif self.engine.preptool_engine.lower() == "openaiembeddings":
        #         try:
        #             self.engine.preptool_local_engine = OpenAIEmbeddings()
        #             response = Response(status_code=200, detail=self.response_format.ok(f"Init Embedding Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Embedding Engine in Local"))
        #         except:
        #             response = Response(status_code=500, detail=self.response_format.error(f"Init Embedding Engine Error : <{SETTINGS.BASE.APP_NAME}> Failed to Init Embedding Engine <{self.engine.preptool_engine}>"))
                    
        #     else:
        #         response = Response(status_code=404, detail=self.response_format.error(f"Init Embedding Engine Error : <{SETTINGS.BASE.APP_NAME}> Cannot Recognie Embedding Engine <{self.engine.preptool_engine}>"))

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Init Embedding Engine Error : <{SETTINGS.BASE.APP_NAME}> Cannot Recognie Embedding Engine Location <{self.engine.preptool_location}>"))

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            logger.error(response.detail)

        return response

    def text_embedding(self, request: EmbeddingTextRequest) -> tuple[EmbeddingTextResponse, Response]:
        response_data = EmbeddingTextResponse()
        start_at      = time.time()

        """ 1. Init Embedding Engine """
        response = self.init_engine(config=request.preptool)

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response

        ### TODO: Add Token Limit Check
        """ 2. Perform Token Limit Check for the raw_data"""
        
        """ 3. Embed Data """
        success_data = []
        fail_data    = []
        tool_tokens  = 0
        if self.engine.preptool_location.lower() == "azure":
            processed_data, tool_tokens, response = self.azure_server(raw_data=[_data.raw_data for _data in request.data_input])

        elif self.engine.preptool_location.lower() == "server":
            
            if self.engine.preptool_engine.lower() == "ollama":
                processed_data, tool_tokens, response = self.ollama_server(raw_data=[_data.raw_data for _data in request.data_input])
                
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Embedding Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform Embedding <{self.engine.preptool_engine}>"))

        elif self.engine.preptool_location.lower() == "local":
            processed_data, tool_tokens, response = self.local_engine(raw_data=[_data.raw_data for _data in request.data_input])

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Embedding Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform Embedding <{self.engine.preptool_engine}>"))

        """ 4. Updated Result """
        # 4.1. Embedding Fail
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            logger.error(response.detail)
            return response_data, response

        # 4.2. Embedding Completed but Encountered Different Lengths between Raw Data and Processed Data
        elif len(request.data_input) != len(processed_data):
            fail_data = request.data_input
            response  = Response(status_code=500, detail=self.response_format.error(f"Embedding Processing Error : <{SETTINGS.BASE.APP_NAME}> Found Unequal Number between Raw Data and Processed Data"))
            logger.error(response.detail)
            return response_data, response
        
        # 4.3. Embedding Success 
        else:
            for _data_obj, _processed_data in zip(request.data_input, processed_data):
                _data_obj.__dict__.update(processed_data=_processed_data, data_dimension=len(_processed_data))
            success_data = request.data_input
            response = Response(status_code=200, detail=self.response_format.ok(f"Embedding Completed : <{SETTINGS.BASE.APP_NAME}> Completed Embedding Process"))
            logger.info(response.detail)

        ### TODO: Add tokens count
        """ 5. Process Data """
        response_data.__dict__.update(
            preptool_time        = time.time() - start_at,
            preptool_tool_tokens = tool_tokens,
            preptool_config      = {"embedding_dimension": len(processed_data[0])},
            success_objects      = success_data,
            fail_objects         = fail_data,
            total_no             = len(request.data_input),
            success_no           = len(success_data),
            fail_no              = len(fail_data),
            response_at          = datetime.now(timezone.utc)
        )

        return response_data, response

    def local_engine(self, raw_data: list[str]) -> tuple[list[list[float]], int, Response]:
        processed_data = []
        tool_tokens    = 0

        try:
            processed_data = self.engine.preptool_local_engine.embed_documents(raw_data)
            response = Response(status_code=200, detail=self.response_format.ok(f"Embedding Success : <{SETTINGS.BASE.APP_NAME}> Completed Embedding via Local Engine"))
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Embedding Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error during Embedding via Local Engine"))
            logger.error(response.detail)

        return processed_data, tool_tokens, response

    def ollama_server(self, raw_data: list[str]) -> tuple[list[list[float]], int, Response]:
        processed_data = []
        tool_tokens    = 0

        payload = dict()

        # Model Options
        options = dict()
        if self.engine.preptool_parameters:
            options.update(self.engine.preptool_parameters)
        if self.engine.preptool_secrets:
            options.update(self.engine.preptool_secrets)
        if options:
            payload["options"] = options
            
        payload["model"] = self.engine.preptool_base
        payload["input"] = raw_data

        api_url = f"http://{self.engine.preptool_host}:{self.engine.preptool_port}/{self.engine.preptool_api}"
        
        # Post Request to Server
        try:
            resp   = httpx.post(api_url, json=payload, timeout=SETTINGS.PRTL.EMBEDDING_TIMEOUT)
            result = resp.json()

            # Error during Calling Server
            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=result["error"])
                logger.error(response.detail)
                return processed_data, tool_tokens, response

            # Update Ouptut
            processed_data = result["embeddings"]
            tool_tokens    = result.get("prompt_eval_count", 0)
            response = Response(status_code=200, detail=self.response_format.ok(f"Embedding Success : <{SETTINGS.BASE.APP_NAME}> Completed Embedding"))

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Ollama Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Ollama Server", str(e)))
            logger.error(response.detail)

        return processed_data, tool_tokens, response


    def azure_server(self, raw_data: list[str]) -> tuple[list[list[float]], int, Response]:
        from openai import AzureOpenAI

        processed_data = []
        tool_tokens    = 0

        payload = dict()

        # Model Options
        options = dict()
        if self.engine.preptool_parameters:
            options.update(self.engine.preptool_parameters)
        if options:
            payload["options"] = options
    
        payload["model"] = self.engine.preptool_base
        payload["input"] = raw_data

        api_url = f"{self.engine.preptool_host}/{self.engine.preptool_port}"

        embedding_client = AzureOpenAI(
            api_key         = self.engine.preptool_secrets.get("api_key", "dummy-key"),
            api_version     = self.engine.preptool_secrets.get("api_version", ""),
            azure_endpoint  = api_url,
            default_headers = self.engine.preptool_secrets.get("header", {})
        )

        # Post Request to Server
        try:
            resp = embedding_client.embeddings.create(
                model = payload["model"],
                input = payload["input"]
            )

            # Error during Calling Server
            if not resp or not resp.data:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Azure Embedding Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Embedding Data from Azure Server"))
                logger.error(response.detail)
                return processed_data, tool_tokens, response

            # Update Ouptut
            processed_data = [_data.embedding for _data in resp.data]
            tool_tokens   = resp.usage.total_tokens
            response = Response(status_code=200, detail=self.response_format.ok(f"Embedding Success : <{SETTINGS.BASE.APP_NAME}> Completed Embedding"))

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Azure Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Azure Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Azure Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Azure Server", str(e)))
            logger.error(response.detail)

        return processed_data, tool_tokens, response


    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response


