from datetime import datetime, timezone
import time
import inspect
import httpx
import tiktoken
from openai import AzureOpenAI

from ..schemas.preptool import SecretPrepTool, KnowDataObject

from ..settings import SETTINGS
from ..utils import num_tokens_from_string

from ..schemas.format import ResponseFormatter, Response
from ..schemas.summarization import (
    SummarizationEngine,
    SummarizationTextRequest,
    SummarizationTextResponse
)
from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class SummarizationServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, engine: SummarizationEngine | None = None):
        self.engine = engine

    def init_engine(self, config: SecretPrepTool) -> Response:
        self.engine = SummarizationEngine(**config.__dict__)

        if self.engine.preptool_location.lower() == "azure":
            response = Response(status_code=200, detail=self.response_format.ok(f"Init Summarization Completed : <{SETTINGS.BASE.APP_NAME}> Initiated Summarization Engine in Azure"))
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Init Summarization Engine Error : <{SETTINGS.BASE.APP_NAME}> Cannot Recognize Summarization Engine Location <{self.engine.preptool_location}>"))

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            logger.error(response.detail)

        return response

    def text_summarization(self, request: SummarizationTextRequest) -> tuple[SummarizationTextResponse, Response]:
        logger.info("Start Text Summarization")
        response_data = SummarizationTextResponse()
        start_at = time.time()

        """ 1. Init Keyword Engine """
        response = self.init_engine(config=request.preptool)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response

        """ 2. Summarize all chunks """
        success_data = []
        fail_data = []
        total_input_tokens = 0
        total_output_tokens = 0

        if self.engine.preptool_location.lower() == "azure":
            final_summary, input_tokens, output_tokens, response = self.azure_server(raw_data=[_data.raw_data for _data in request.data_input])

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Summarization Processing Error : <{SETTINGS.BASE.APP_NAME}> Failed to Perform Summarization with engine <{self.engine.preptool_engine}>"))
            return response_data, response

        """ 3. Update result """
        success_data = request.data_input
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            fail_data.append(request.data_input)
            logger.error(response.detail)
        else:
            total_input_tokens += input_tokens
            total_output_tokens += output_tokens
            
            # Copy request.data_input to success_data and append summary data
            new_obj = KnowDataObject(
                knowledge_id=request.data_input[0].knowledge_id,
                raw_data=final_summary,
                data_length=len(final_summary),
                data_type="DOCUMENT",
                content_type="summarization"
            )
            
            # Add the new object to success_data
            success_data.append(new_obj)

        """ 4. Process Response """
        response_data.__dict__.update(
            preptool_time=time.time() - start_at,
            preptool_input_tokens=total_input_tokens,
            preptool_output_tokens=total_output_tokens,
            preptool_tool_tokens=0,
            success_objects=success_data,
            fail_objects=fail_data,
            total_no=len(request.data_input),
            success_no=len(success_data),
            fail_no=len(fail_data),
            response_at=datetime.now(timezone.utc)
        )
        return response_data, response

    def azure_server(self, raw_data: list[str]) -> tuple[str, int, int, Response]:
        total_input_tokens = 0
        total_output_tokens = 0
        final_summary = ""
        all_summaries = [] # To collect summaries temporarily

        payload = dict()
        logger.info("Start SUmmarization")
        # Get group size from parameters or default to 5
        group_size = self.engine.preptool_parameters.get("summary_group_size", 5)
        overlap_size = self.engine.preptool_parameters.get("overlap_size", 2)
        context_window_size = self.engine.preptool_parameters.get("context_window_size", 128000)
        context_window_buffer = 28000
        system_prompt = self.engine.preptool_secrets.get("system_prompt", None)
        user_prompt = self.engine.preptool_parameters.get("user_prompt", "Summarize the following text:")

        api_url = f"{self.engine.preptool_host}/{self.engine.preptool_port}"

        genai_client = AzureOpenAI(
            api_key         = self.engine.preptool_secrets.get("api_key", "dummy-key"),
            api_version     = self.engine.preptool_secrets.get("api_version", ""),
            azure_endpoint  = api_url,
            default_headers = self.engine.preptool_secrets.get("header", {})
        )
            
        try:
            # Helper function to summarize text using Azure OpenAI
            def summarize_text(text):
                summary = ""
                input_tokens = 0
                output_tokens = 0

                # User Prompt Formation
                prompt = "Summarize the Texts into 50-100 words:"
                if user_prompt:
                    prompt = user_prompt

                messages = [{'role': 'user', 'content': f"{prompt}\n\n{text}"}]

                payload["model"]    = self.engine.preptool_base
                payload["messages"] = messages
                
                try:
                    logger.info("Calling Azure OpenAI Service")
                    resp = genai_client.chat.completions.create(
                        model    = payload["model"],
                        messages = payload["messages"]
                    )
                    
                    # Error during Calling Server
                    if not resp or not resp.choices:
                        e = "Unknown Error"
                        response = Response(status_code=500, detail=self.response_format.error(f"Azure GenAI Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve GenAI Data from Azure Server", str(e)))
                        logger.error(response.detail)
                        return summary, input_tokens, output_tokens, response

                    # Update Ouptut
                    summary = resp.choices[0].message.content
                    input_tokens   = resp.usage.prompt_tokens
                    output_tokens  = resp.usage.completion_tokens
                    response = Response(status_code=200, detail=self.response_format.ok(f"GenAI Success : <{SETTINGS.BASE.APP_NAME}> Completed GenAI"))

                except httpx.TimeoutException as e:
                    response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : <{SETTINGS.BASE.APP_NAME}> Encountered Timeout Error when Connecting to Azure Server", str(e)))
                    logger.error(response.detail)

                except httpx.HTTPError as e:
                    response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : <{SETTINGS.BASE.APP_NAME}> Encountered Connection Error when Connecting to Azure Server", str(e)))
                    logger.error(response.detail)

                # Handle common exceptions that might occur
                except (BaseException, Exception) as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encountered Common Error when Calling Azure Server", str(e)))
                    logger.error(response.detail)

                # Handle any other exceptions that might occur
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unexpected Error when Calling Azure Server", str(e)))
                    logger.error(response.detail)

                return summary, input_tokens, output_tokens, response

            # Hierarchical summarization until we get a single summary
            current_chunks = raw_data.copy()
            
            while len(current_chunks) > 1:
                next_level_chunks = []
                
                # Process chunks with sliding window (allowing overlap)
                i = 0
                while i < len(current_chunks):
                    logger.info(f"Processing chunk {i} of {group_size}")
                    # Get chunk group with overlap consideration
                    end_idx = min(i + group_size, len(current_chunks))
                    chunk_group = current_chunks[i:end_idx]
                    
                    # Combine chunks in the group
                    combined_text = "\n\n".join(chunk_group)

                    if num_tokens_from_string(combined_text) + context_window_buffer > context_window_size:
                        # Reduce the group size
                        group_size = max(1, group_size - 1)
                        continue
                    else:
                        # Increase the group size
                        group_size += 1
                    
                    # Summarize the combined text
                    summary, input_tokens, output_tokens, response = summarize_text(combined_text)

                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        logger.error(response.detail)
                        return "", 0, 0, response
                    else:
                        next_level_chunks.append(summary)
                        all_summaries.append(summary)
                        total_input_tokens += input_tokens
                        total_output_tokens += output_tokens

                    # Move to next group, considering overlap
                    i += max(1, group_size - overlap_size)
                
                # Update current_chunks for next iteration
                current_chunks = next_level_chunks
                
            # The final result is the last summary
            if current_chunks:
                final_summary = current_chunks[0]
                all_summaries.append(final_summary)
                
            # Join all summaries into a single string
            final_summary = "\n\n".join(all_summaries)
            
            response = Response(status_code=200, detail=self.response_format.ok(
                f"Hierarchical Summarization Success : <{SETTINGS.BASE.APP_NAME}> Completed Summarization"))
            logger.info(response.detail)
        except Exception as e:
            logger.error(f"Error in Azure server: {str(e)}")
            return "", 0, 0, Response(status_code=500, detail=self.response_format.error(f"Azure Server Error: {str(e)}"))

        return final_summary, total_input_tokens, total_output_tokens, response