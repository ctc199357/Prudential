from datetime import datetime, timezone
import time
import os
import uuid
import inspect
import httpx
import fitz

# Excel Chunking
import pandas as pd
import json

# from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain.text_splitter import CharacterTextSplitter

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.preptool import SecretPrepTool, KnowDataObject

from ..schemas.chunking import (
    ChunkingMetrics,
    ChunkingTextRequest, 
    ChunkingTextResponse
)

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class ChunkingServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    """
        Request Operation
    """
    def text_chunking(self, request: ChunkingTextRequest) -> tuple[ChunkingTextResponse, Response]:
        response_data = ChunkingTextResponse()
        start_at      = time.time()

        success_objects = []
        fail_objects    = []

        processed_data, metrics, response = self.default_chunking(
            data_input = request.data_input, 
            preptool_parameters = request.preptool.preptool_parameters
        )

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            fail_objects    = processed_data
        else:
            success_objects = processed_data

        response_data.__dict__.update(
            preptool_time   = time.time() - start_at,
            preptool_config = metrics.__dict__,
            success_objects = success_objects,
            fail_objects    = fail_objects,
            total_no        = len(success_objects) + len(fail_objects),
            success_no      = len(success_objects),
            fail_no         = len(fail_objects),
            response_at     = datetime.now(timezone.utc)
        )

        return response_data, response
    
    def default_chunking(self, data_input: list[KnowDataObject], preptool_parameters: dict) -> tuple[list[KnowDataObject], ChunkingMetrics, Response]:
        processed_data = []
        metrics = ChunkingMetrics()

        if not data_input:
            response = Response(status_code=404, response=self.response_format.error(f"Chunking Data Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Data for Chunking"))
            logger.error(response.detail)

        elif data_input[0].data_type.upper() == 'DOCUMENT':
            _raw_data = data_input[0]
            file_extension = os.path.basename(_raw_data.data_url).split('.')[-1]

            if file_extension.lower() in SETTINGS.PRTL.FILE_EXTENSION.get("PDF"):
                analysis_method = preptool_parameters.get("PDF", dict())
                processed_data, metrics, response = self.default_chunk_pdf(
                    file_path    = _raw_data.data_url, 
                    method       = analysis_method.get("method", ""),
                    config       = analysis_method.get("config", dict()),
                    knowledge_id = _raw_data.knowledge_id
                )
            
            elif file_extension.lower() in SETTINGS.PRTL.FILE_EXTENSION.get("EXCEL"):
                analysis_method = preptool_parameters.get("EXCEL", dict())
                processed_data, metrics, response = self.default_chunk_excel(
                    file_path    = _raw_data.data_url, 
                    method       = analysis_method.get("method", ""),
                    config       = analysis_method.get("config", dict()),
                    knowledge_id = _raw_data.knowledge_id
                )

            elif file_extension.lower() in SETTINGS.PRTL.FILE_EXTENSION.get("CSV"):
                analysis_method = preptool_parameters.get("CSV", dict())
                processed_data, metrics, response = self.default_chunk_csv(
                    file_path    = _raw_data.data_url, 
                    method       = analysis_method.get("method", ""),
                    config       = analysis_method.get("config", dict()),
                    knowledge_id = _raw_data.knowledge_id
                )

            else:
                response = Response(status_code=404, response=self.response_format.error(f"Chunking File Error : <{SETTINGS.BASE.APP_NAME}> Has Not Supported File Format <{file_extension}> Yet"))
                logger.error(response.detail)
                
        else:
            response = Response(status_code=500, response=self.response_format.error(f"Chunking Data Error : <{SETTINGS.BASE.APP_NAME}> Has Not Supported Data Type Yet"))
            logger.error(response.detail)

        return processed_data, metrics, response
        
        
    def default_chunk_pdf(self, file_path: str, method: str, config: dict, knowledge_id: str='anonymous') -> tuple[list[KnowDataObject], ChunkingMetrics, Response]:       
        chunk_size    = config.get("chunk_size",    SETTINGS.PRTL.DEFAULT_CHUNK_CONFIG.get("chunk_size")),
        chunk_overlap = config.get("chunk_overlap", SETTINGS.PRTL.DEFAULT_CHUNK_CONFIG.get("chunk_overlap"))

        processed_data = []
        metrics = ChunkingMetrics()

        if method.lower() in ["default", "recursivecharactertextsplitter"]:
            chunk_engine = RecursiveCharacterTextSplitter(
                chunk_size    = chunk_size,
                chunk_overlap = chunk_overlap
            )

        elif method.lower() == "charactertextsplitter":
            chunk_engine = CharacterTextSplitter(
                chunk_size    = chunk_size,
                chunk_overlap = chunk_overlap
            )

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Chunking Error : <{SETTINGS.BASE.APP_NAME}> Failed to Recognize Chunking Method <{method}>"))
            logger.error(response.detail)
            return processed_data, metrics, response
        
        try:
            with fitz.open(file_path) as file_text_parser:
                chunk_contents = chunk_engine.split_documents([file_text_parser])
            
            processed_data = [
                KnowDataObject(
                    data_type    = 'TEXT', 
                    content_type = 'chunking',
                    raw_data     = _content.page_content,
                    knowledge_id = knowledge_id
                ) 
                for _content in chunk_contents
            ]

            response = Response(status_code=200, detail=self.response_format.ok(f"Chunking Success : <{SETTINGS.BASE.APP_NAME}> Completed Chunking"))
        
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Chunking Error : <{SETTINGS.BASE.APP_NAME}> Failed to Chunk the Document"))
            logger.error(response.detail)

        metrics.__dict__.update(
            chunk_size    = chunk_size,
            chunk_overlap = chunk_overlap
        )

        return processed_data, metrics, response

    ### TODO: Not Yet Reviewed
    def default_chunk_excel(self, file_path: str, method: str, config: dict, knowledge_id: str='anonymous') -> tuple[list[KnowDataObject], ChunkingMetrics, Response]:
        chunk_size    = -1
        chunk_overlap = -1

        processed_data = []
        metrics = ChunkingMetrics()

        try:
            df = pd.read_excel(file_path, engine="openpyxl", sheet_name=None)
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"File Loading Error : <{SETTINGS.BASE.APP_NAME}> Failed to Load Document for Chunking"))
            logger.error(response.detail)
            return processed_data, metrics, response

        try:
            for sheet_name in df.keys():
                json_str  = df[sheet_name].to_json()
                code_json = json.loads(json_str)
                keys_arr  = list(code_json.keys())
                code_rows = []

                for val in code_json[keys_arr[0]]:
                    code_rows.append({keys_arr[0]:code_json[keys_arr[0]][val]})

                for k in keys_arr[1:]:
                    for r, row in enumerate(code_rows):
                        row[k] = code_json[k][str(r)]

            processed_data = [
                KnowDataObject(
                    data_type    = 'TEXT', 
                    content_type = 'chunking',
                    raw_data     = str(row),
                    knowledge_id = knowledge_id
                ) 
                for row in code_rows
            ]

            chunk_size    = max(len(chunk) for chunk in processed_data)
            chunk_overlap = 0

            response = Response(status_code=200, detail=self.response_format.ok(f"Chunking Success : <{SETTINGS.BASE.APP_NAME}> Completed Chunking"))

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Chunking Error : <{SETTINGS.BASE.APP_NAME}> Failed to Chunk the Document"))
            logger.error(response.detail)

        metrics.__dict__.update(
            chunk_size    = chunk_size,
            chunk_overlap = chunk_overlap
        )

        return processed_data, metrics, response

    ### TODO: Not Yet Reviewed
    def default_chunk_csv(self, file_path: str, method: str, config: dict, knowledge_id: str='anonymous') -> tuple[list[KnowDataObject], ChunkingMetrics, Response]:
        chunk_size    = -1
        chunk_overlap = -1

        processed_data = []
        metrics = ChunkingMetrics()

        try:
            df = pd.read_csv(file_path)
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"File Loading Error : <{SETTINGS.BASE.APP_NAME}> Failed to Load Document for Chunking"))
            logger.error(response.detail)
            return processed_data, metrics, response

        try:
            json_str  = df.to_json()
            code_json = json.loads(json_str)
            keys_arr  = list(code_json.keys())
            code_rows = []

            for val in code_json[keys_arr[0]]:
                code_rows.append({keys_arr[0]:code_json[keys_arr[0]][val]})

            for k in keys_arr[1:]:
                for r, row in enumerate(code_rows):
                    row[k] = code_json[k][str(r)]

            processed_data = [
                KnowDataObject(
                    data_type    = 'TEXT', 
                    content_type = 'chunking',
                    raw_data     = str(row),
                    knowledge_id = knowledge_id
                ) 
                for row in code_rows
            ]

            chunk_size    = max(len(chunk) for chunk in processed_data)
            chunk_overlap = 0

            response = Response(status_code=200, detail=self.response_format.ok(f"Chunking Success : <{SETTINGS.BASE.APP_NAME}> Completed Chunking"))

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Chunking Error : <{SETTINGS.BASE.APP_NAME}> Failed to Chunk the Document"))
            logger.error(response.detail)

        metrics.__dict__.update(
            chunk_size    = chunk_size,
            chunk_overlap = chunk_overlap
        )

        return processed_data, metrics, response


    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response


