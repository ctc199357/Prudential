from datetime import datetime, timezone
import time
import re
import inspect
import httpx
import uuid
from sqlalchemy.orm import Session

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.prepknow import (
    PrepKnowMedia,
    SecretPrepMedia,
)

from ..schemas.prepmedia import (
    PrepMediaStringFilter,
    PrepMediaNumericFilter,
    PrepMediaFilter,
    SystemPrepMediaRequest,
    PrepMediaInitRequest,
    PrepMediaInitResponse,
    SystemPrepMediaRequest,
    PrepMediaPipelineRequest,
    PrepMediaMetric,
    PrepMediaPipeline,
    PrepMediaPipelineResponse,
    PrepMediaTermination,
    SystemTermination
)

from ..schemas.preptool import (
    PrepToolStringFilter, 
    PrepToolNumericFilter, 
    PrepToolFilter, 
    SystemPrepToolRequest,
    PrepToolPipelineRequest
)

from ..services.preptool_service import PrepToolServiceManager

from ..routers.registry.system import system_query_prepmedia, system_query_preptool

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

# Import Functions when APP_FUNC is enabled
# if SETTINGS.BASE.APP_FUNC == True:
#     from ..services import prepmedia_request_inference

class PrepMediaServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool, pipeline: PrepMediaPipeline | None = None):
        self.api_call = api_call
        self.pipeline = pipeline

    """
        Request Operation
    """
    def prepmedia_init(self, request: PrepMediaInitRequest) -> tuple[PrepMediaInitResponse, Response]:
        start_at = time.time()
        response_init = PrepMediaInitResponse(**request.__dict__)

        # 1. Retrieve PrepMedia from DB
        response_prepmedia, response = self.get_prepmedia(prepmedia_ids=[request.prepmedia_id])
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_init, response
        
        elif not response_prepmedia:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Init Error : <{SETTINGS.BASE.APP_NAME}> Cannot Retrieve PrepMedia"))
            return response_init, response

        else:
            prepmedia = response_prepmedia[0]
            response_init.prepmedia = prepmedia
            prepknow_medias = [PrepKnowMedia(prepmedia=prepmedia)]

        # 2. Retrieve PrepTool    
        prepknow_medias, response = self.get_preptool(prepknow_medias=prepknow_medias)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_init, response
        
        if not prepknow_medias:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Init Error : <{SETTINGS.BASE.APP_NAME}> Cannot Retrieve All PrepTools"))
            return response_init, response

        ### TODO:
        # 3. Update CustomConfig

        # 4. Update Response
        
        response_init.prepknow_media = prepknow_medias[0]
        response_init.prepmedia_init_time = time.time() - start_at

        return response_init, response

    def get_prepmedia(self, prepmedia_ids: list[str]) -> tuple[list[SecretPrepMedia], Response]:
        if not prepmedia_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Found Empty PrepMedia List"))
            return [], response
        
        data_filter  = PrepMediaFilter(
            string_filter  = PrepMediaStringFilter(prepmedia_id_filter=prepmedia_ids),
            numeric_filter = PrepMediaNumericFilter(prepmedia_status_min=1)
        )
        data_request = SystemPrepMediaRequest(data_filter=data_filter)
        try:
            response_data = system_query_prepmedia(
                request  = data_request, 
                api_call = self.api_call
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved PrepMedia Profile"))
        except Exception as e:
            response = Response(status_code=500, detail=e)
            return [], response

        return response_data.filtered_data, response
    
    def get_preptool(self, prepknow_medias: list[PrepKnowMedia]) -> tuple[list[PrepKnowMedia], Response]:
        preptool_ids = list(set([preptool_id for _prepmedia in prepknow_medias for preptool_id in _prepmedia.prepmedia.preptool_ids.keys()]))
        data_filter = PrepToolFilter(
            string_filter  = PrepToolStringFilter(preptool_id_filter=preptool_ids),
            numeric_filter = PrepToolNumericFilter(preptool_status_min=1)
            )
        data_request = SystemPrepToolRequest(data_filter=data_filter)
        
        try:
            response_data = system_query_preptool(
                request  = data_request, 
                api_call = self.api_call
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Retrieved PrepTool Profile"))
        
        except Exception as e:
            response = Response(status_code=500, detail=e)
            return response

        if response_data.data_count != len(preptool_ids):
            response = Response(status_code=404, detail=self.response_format.error(f"Missing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Retrieve All PrepTools from PrepToolDB"))
            return response
        
        else:
            retrieved_preptools = response_data.filtered_data
            for prepknow_media in prepknow_medias:
                prepknow_media.preptools = [preptool for preptool in retrieved_preptools if preptool.preptool_id in prepknow_media.prepmedia.preptool_ids.keys()]
        
        return prepknow_medias, response

    def prepmedia_pipeline(self, request: PrepMediaPipelineRequest) -> tuple[PrepMediaPipelineResponse, Response]:
        response_pipeline = PrepMediaPipelineResponse(**request.__dict__)
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Start Processing PrepMedia Pipeline")

        """ 1. Init PrepMedia """
        if not request.prepknow_media:
            init_request = PrepMediaInitRequest(
                prepmedia_requestid=request.prepmedia_requestid,
                prepmedia_id=request.prepmedia_id, 
                custom_config=request.custom_config
            )
            response_init, response = self.prepmedia_init(request=init_request)
            
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                response_pipeline.prepmedia_pipeline_code   = SETTINGS.PRMD.STATUS_CODE.get("FAIL")
                response_pipeline.prepmedia_pipeline_reason = response.detail
                return response_pipeline, response
            else:
                request.__dict__.update(**response_init.__dict__)
                    
        """ 2. Init Pipeline """
        self.pipeline = PrepMediaPipeline(**request.__dict__, input_at=time.time())
        
        """ 3. Init Termination Criteria """
        self.init_pipeline_status(prepmedia_termination=self.pipeline.prepknow_media.prepmedia.prepmedia_termination)
        
        """ 4. Pipeline Execution """
        while True:
            logger.info(f"PrepMedia Processing : {self.pipeline.prepknow_media.prepmedia.prepmedia_type.lower()}")
            # Router to Different PrepMedia Function
            if self.pipeline.prepknow_media.prepmedia.prepmedia_type.lower() == 'text':
                response = self.prepmedia_processing_text()

            elif self.pipeline.prepknow_media.prepmedia.prepmedia_type.lower() == 'image':
                response = self.prepmedia_processing_image()

            elif self.pipeline.prepknow_media.prepmedia.prepmedia_type.lower() == 'table':
                response = self.prepmedia_processing_table()
            
            elif self.pipeline.prepknow_media.prepmedia.prepmedia_type.lower() == 'document':
                response = self.prepmedia_processing_document()

            elif self.pipeline.prepknow_media.prepmedia.prepmedia_type.lower() == 'relationship':
                response = self.prepmedia_processing_relationship()

            else:
                response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Type Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unsupported PrepMedia Type <{self.pipeline.prepknow_media.prepmedia.prepmedia_typeself.pipeline.prepknow_media.prepmedia.prepmedia_type}>"))

            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                logger.error(response.detail)
                break

            """ 5. Update PrepMedia Pipeline """
            # 5.1. Update Pipeline Status
            self.update_pipeline_metrics(
                input_tokens   = self.pipeline.prepmedia_metric.total_input_tokens,
                output_tokens  = self.pipeline.prepmedia_metric.total_output_tokens,
                tool_tokens    = self.pipeline.prepmedia_metric.total_tool_tokens,
                prepmedia_time = self.pipeline.prepmedia_metric.prepmedia_time
            )

            # 5.2. Check whether PrepMedia Completed
            if self.pipeline.prepmedia_metric.prepmedia_code == SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"):
                self.pipeline.prepmedia_pipeline_completion = True

            # 5.3. Check Termination
            response = self.check_pipeline_status()

            # 5.4. Create New Record
            self.pipeline.prepmedia_metrics.append(self.pipeline.prepmedia_metric)

            """ 6. Proceed to Next Step """
            # 6.1. Check Termination/Retry
            if self.pipeline.prepmedia_pipeline_termination == True:
                break
            
            else:
                # 6.2. Init New PrepMedia Trial
                self.pipeline.prepmedia_pipeline_id = str(uuid.uuid4())
                self.update_pipeline_status()
        
        response_pipeline = PrepMediaPipelineResponse(
            **self.pipeline.__dict__, 
            response_at=datetime.now(timezone.utc)
        )

        return response_pipeline, response

    
    def init_pipeline_status(self, prepmedia_termination: dict) -> None:   
        if prepmedia_termination:
            self.pipeline.prepmedia_criteria = PrepMediaTermination(**prepmedia_termination)

        if SETTINGS.PRMD.SYSTEM_PREPMDIA_TERMINATION:
            self.pipeline.system_criteria = SystemTermination(**SETTINGS.PRMD.SYSTEM_PREPMDIA_TERMINATION)

    def update_pipeline_metrics(
            self,
            input_tokens:       int,
            output_tokens:      int,
            tool_tokens:        int,
            prepmedia_time:     float
        ) -> None:

        self.pipeline.output_at = datetime.now(timezone.utc)

        # Update Total PrepMedia Info
        self.pipeline.prepmedia_total_time          += prepmedia_time
        self.pipeline.prepmedia_total_input_tokens  += input_tokens
        self.pipeline.prepmedia_total_output_tokens += output_tokens
        self.pipeline.prepmedia_total_tool_tokens   += tool_tokens


    ### TODO: Add Termination Criteria on Token Limit
    def check_pipeline_status(self) -> Response:

        self.pipeline.prepmedia_pipeline_reason = self.pipeline.prepmedia_metric.prepmedia_reason        
        self.pipeline.prepmedia_pipeline_termination = True

        # Check Completion
        if self.pipeline.prepmedia_pipeline_completion == True:
            self.pipeline.prepmedia_pipeline_reason  = 'PrepMedia Terminated due to Completion'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS")
            logger.info(self.pipeline.prepmedia_pipeline_reason)

        # Check Termination Flag
        elif self.pipeline.prepmedia_criteria.code and self.pipeline.prepmedia_metric.prepmedia_code == self.pipeline.prepmedia_criteria.code:
            self.pipeline.prepmedia_pipeline_reason  = 'Terminated due to Matched PrepMedia-defined Termination Success Flag'
        
        elif self.pipeline.prepmedia_criteria.code and self.pipeline.prepmedia_metric.prepmedia_code == self.pipeline.system_criteria.code:
            self.pipeline.prepmedia_pipeline_reason  = 'Terminated due to Matched System-defined Termination Success Flag'

        # Check PrepMedia-defined Termination Criteria
        elif self.pipeline.prepmedia_criteria.max_prepmedia_turn and self.pipeline.prepmedia_turn_no >= self.pipeline.prepmedia_criteria.max_prepmedia_turn:
            self.pipeline.prepmedia_pipeline_reason = 'Terminated due to the Number of PrepMedia Turns >= PrepMedia-defined Maximum Number of PrepMedia Turns'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL")

        elif self.pipeline.prepmedia_criteria.max_prepmedia_retry and self.pipeline.prepmedia_retry_no >= self.pipeline.prepmedia_criteria.max_prepmedia_retry:
            self.pipeline.prepmedia_pipeline_reason = 'Terminated due to the Number of PrepMedia Retries >= PrepMedia-defined Maximum Number of PrepMedia Retries'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL")

        elif self.pipeline.prepmedia_criteria.max_prepmedia_turn_retry and self.pipeline.prepmedia_turn_retry_no >= self.pipeline.prepmedia_criteria.max_prepmedia_turn_retry:
            self.pipeline.prepmedia_pipeline_reason = 'Terminated due to the Number of PrepMedia Retries Per Turn >= PrepMedia-defined Maximum Number of PrepMedia Retries Per Turn'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL")

        elif self.pipeline.prepmedia_criteria.timeout and self.pipeline.prepmedia_total_time >= self.pipeline.prepmedia_criteria.timeout:
            self.pipeline.prepmedia_pipeline_reason = 'Terminated due to the Duration of PrepMedia >= PrepMedia-defined Timeout'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL")

        # Check System-defined Termination Criteria
        elif self.pipeline.system_criteria.max_prepmedia_turn and self.pipeline.prepmedia_turn_no >= self.pipeline.system_criteria.max_prepmedia_turn:
            self.pipeline.prepmedia_pipeline_reason = 'Terminated due to the Number of PrepMedia Turns >= System-defined Maximum Number of PrepMedia Turns'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL")

        elif self.pipeline.system_criteria.max_prepmedia_retry and self.pipeline.prepmedia_retry_no >= self.pipeline.system_criteria.max_prepmedia_retry:
            self.pipeline.prepmedia_pipeline_reason = 'Terminated due to the Number of PrepMedia Retries >= System-defined Maximum Number of PrepMedia Retries'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL")

        elif self.pipeline.prepmedia_criteria.max_prepmedia_turn_retry and self.pipeline.prepmedia_turn_retry_no >= self.pipeline.system_criteria.max_prepmedia_turn_retry:
            self.pipeline.prepmedia_pipeline_reason = 'Terminated due to the Number of PrepMedia Retries Per Turn >= System-defined Maximum Number of PrepMedia Retries Per Turn'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL")

        elif self.pipeline.system_criteria.timeout and self.pipeline.prepmedia_total_time >= self.pipeline.system_criteria.timeout:
            self.pipeline.prepmedia_pipeline_reason = 'Terminated due to the Duration of System >= System-defined Timeout'
            self.pipeline.prepmedia_pipeline_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL")

        else:
            self.pipeline.prepmedia_pipeline_termination = False

            # Proceeding to next steps
            if self.pipeline.prepmedia_metric.prepmedia_code == SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"):
                self.pipeline.prepmedia_pipeline_reason = 'PROCEEDING'

        # Update Response
        if self.pipeline.prepmedia_pipeline_completion == True:
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Pipeline Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Pipeline Execution"))
            logger.info(response.detail)
        elif self.pipeline.prepmedia_pipeline_termination == True:
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Pipeline Terminated : <{SETTINGS.BASE.APP_NAME}> Terminated PrepMedia Pipeline due to {self.pipeline.prepmedia_pipeline_reason}"))
            logger.info(response.detail)
        elif self.pipeline.prepmedia_metric.prepmedia_code == SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"):
            response = Response(status_code=206, detail=self.response_format.ok(f"PrepMedia Pipeline Proceeding : <{SETTINGS.BASE.APP_NAME}> PrepMedia Pipeline Execution Success and Proceeding to the Next Turn"))
            logger.info(response.detail)
        else:
            response = Response(status_code=500, detail=self.response_format.error(f"PrepMedia Pipeline Execution Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unepxected Error during Pipeline Execution"))
            logger.error(response.detail)

        return response

    def update_pipeline_status(self) -> None:

        # Proceeding to next steps
        if self.pipeline.prepmedia_metric.prepmedia_code == SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"):
            self.pipeline.prepmedia_pipeline_reason = 'PROCEEDING'
            self.pipeline.prepmedia_turn_no       += 1
            self.pipeline.prepmedia_turn_retry_no = 0

        # Retry
        else:
            self.pipeline.prepmedia_turn_retry_no += 1
            self.pipeline.prepmedia_retry_no      += 1


    """
        Preprocessing Text Logic
    """
    def prepmedia_processing_text(self) -> Response:
        if self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'default_prepmedia_text':
            response = self.default_prepmedia_text()
        elif self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'test_prepmedia_text':
            response = self.test_prepmedia_text()
        
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Unfound Error : <{SETTINGS.BASE.APP_NAME}> Failed to Recognize PrepMedia Group <{self.pipeline.prepknow_media.prepmedia.prepmedia_group}>"))

        return response
    

    def default_prepmedia_text(self) -> Response:
        self.pipeline.prepmedia_metric = PrepMediaMetric(**self.pipeline.__dict__)

        """ 1. Identify All PrepTools for Tasks """
        tasks     = ["embedding"]
        preptools = []
        for _task in tasks:
            preptool = [_preptool for _preptool in self.pipeline.prepknow_media.preptools if _preptool.preptool_type.lower() == _task.lower()]
            if not preptool:
                response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Text Preprocessing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Appropriate PrepTool Type <{_task}> for Processing"))
                logger.error(response.detail)
                break
            else:
                preptools.append(preptool[0])
                response = Response(status_code=200, detail=self.response_format.ok("PrepMedia Processing : Found PrepTool for Processing"))
        
        # Return Error Response if Certain PrepTools cannot be Retrieved
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                prepmedia_reason      = response.detail,
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            return response

        """ 2. Iterate All PrepTool Execution """
        data_io = self.pipeline.prepmedia_input
        for _preptool in preptools:
            preptool_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_io,
                preptool   = _preptool
            )
            
            response_preptool, response = PrepToolServiceManager(api_call=self.api_call).preptool_pipeline(request=preptool_request)
            
            # Update PrepMedia Metrics
            self.pipeline.prepmedia_metric.total_input_tokens  += response_preptool.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += response_preptool.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens   += response_preptool.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time      += response_preptool.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(response_preptool.preptool_metric)
                    
            # Check Result
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                self.pipeline.prepmedia_output = []
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                    prepmedia_reason      = response.detail,
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
                return response
        
            else:
                data_io = response_preptool.preptool_output
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
                    prepmedia_reason      = "SUCCESS",
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
        
        self.pipeline.prepmedia_output = data_io
        response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Text Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Text Processing"))

        return response


    def test_prepmedia_text(self) -> Response:
        self.pipeline.prepmedia_metric = PrepMediaMetric(**self.pipeline.__dict__)

        """ 1. Identify All PrepTools for Tasks """
        tasks = ["keyword", "language", "embedding"]
        preptools = []
        for _task in tasks:
            preptool = [_preptool for _preptool in self.pipeline.prepknow_media.preptools if _preptool.preptool_type.lower() == _task.lower()]
            if not preptool:
                response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Text Preprocessing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Appropriate PrepTool Type <{_task}> for Processing"))
                logger.error(response.detail)
                break
            else:
                preptools.append(preptool[0])
                response = Response(status_code=200, detail=self.response_format.ok("PrepMedia Processing : Found PrepTool for Processing"))
        
        # Return Error Response if Certain PrepTools cannot be Retrieved
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                prepmedia_reason      = response.detail,
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            return response

        """ 2. Process Text Objects """
        data_io = self.pipeline.prepmedia_input
        for _preptool in preptools:
            preptool_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_io,
                preptool   = _preptool
            )
            
            response_preptool, response = PrepToolServiceManager(api_call=self.api_call).preptool_pipeline(request=preptool_request)
            
            # Update PrepMedia Metrics
            self.pipeline.prepmedia_metric.total_input_tokens  += response_preptool.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += response_preptool.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens   += response_preptool.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time      += response_preptool.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(response_preptool.preptool_metric)
                    
            # Check Result
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                self.pipeline.prepmedia_output = []
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                    prepmedia_reason      = response.detail,
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
                return response
        
            else:
                data_io = response_preptool.preptool_output
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
                    prepmedia_reason      = "SUCCESS",
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
        
        self.pipeline.prepmedia_output = data_io
        response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Text Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Text Processing"))

        return response


    """
        Preprocessing Image Logic
    """
    def prepmedia_processing_image(self) -> Response:
        if self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'default_prepmedia_image':
            response = self.default_prepmedia_image()
        elif self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'test_prepmedia_image':
            response = self.test_prepmedia_image()
        
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Unfound Error : <{SETTINGS.BASE.APP_NAME}> Failed to Recognize PrepMedia Group <{self.pipeline.prepknow_media.prepmedia.prepmedia_group}>"))

        return response

    def default_prepmedia_image(self) -> Response:
        self.pipeline.prepmedia_metric = PrepMediaMetric(**self.pipeline.__dict__)

        """ 1. Identify All PrepTools for Tasks """
        tasks     = ["image2text", "embedding"]
        preptools = []
        for _task in tasks:
            preptool = [_preptool for _preptool in self.pipeline.prepknow_media.preptools if _preptool.preptool_type.lower() == _task.lower()]
            if not preptool:
                response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Image Preprocessing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Appropriate PrepTool Type <{_task}> for Processing"))
                logger.error(response.detail)
                break
            else:
                preptools.append(preptool[0])
                response = Response(status_code=200, detail=self.response_format.ok("PrepMedia Processing : Found PrepTool for Processing"))
        
        # Return Error Response if Certain PrepTools cannot be Retrieved
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                prepmedia_reason      = response.detail,
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            return response

        """ 2. Iterate All PrepTool Execution """
        data_io = self.pipeline.prepmedia_input
        for _preptool in preptools:
            preptool_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_io,
                preptool   = _preptool
            )
            
            response_preptool, response = PrepToolServiceManager(api_call=self.api_call).preptool_pipeline(request=preptool_request)
            
            # Update PrepMedia Metrics
            self.pipeline.prepmedia_metric.total_input_tokens  += response_preptool.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += response_preptool.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens   += response_preptool.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time      += response_preptool.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(response_preptool.preptool_metric)
                    
            # Check Result
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                self.pipeline.prepmedia_output = []
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                    prepmedia_reason      = response.detail,
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
                return response
        
            else:
                data_io = response_preptool.preptool_output
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
                    prepmedia_reason      = "SUCCESS",
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
        
        self.pipeline.prepmedia_output = data_io
        response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Image Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Image Processing"))

        return response

    def test_prepmedia_image(self) -> Response:
        """
            Processes the image media using the available preparation tools.
            This method implements two parallel processing pipelines:
            1. image2text -> embedding
            2. ocr -> embedding
            
            Returns:
                Response: A Response object indicating the status of the processing.
        """
        # Initialize metrics
        self.pipeline.prepmedia_metric = PrepMediaMetric(**self.pipeline.__dict__)
        
        # Get original input data
        original_data = self.pipeline.prepmedia_input
        processed_data = []
        
        # ===== Pipeline 1: image2text -> embedding =====
        # Find image2text tool
        image2text_tools = [tool for tool in self.pipeline.prepknow_media.preptools 
                         if tool.preptool_type.lower() == "image2text"]
        
        if image2text_tools:
            data_io = [_data.copy(deep=True) for _data in original_data]
            # Process with image2text
            image2text_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_io,
                preptool = image2text_tools[0]
            )
            
            image2text_response, response = PrepToolServiceManager(
                
                api_call=self.api_call
            ).preptool_pipeline(request=image2text_request)
            
            # Update metrics
            self.pipeline.prepmedia_metric.total_input_tokens += image2text_response.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += image2text_response.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens += image2text_response.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time += image2text_response.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(image2text_response.preptool_metric)

            # If image2text successful, proceed to embedding
            if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                # Find embedding tool
                embedding_tools = [tool for tool in self.pipeline.prepknow_media.preptools 
                                if tool.preptool_type.lower() == "embedding"]
                
                if not embedding_tools:
                    logger.error(f"PrepMedia Image Preprocessing Error: <{SETTINGS.BASE.APP_NAME}> Cannot find embedding tool")
                else:
                    # Process with embedding
                    embedding_request = PrepToolPipelineRequest(
                        **self.pipeline.__dict__,
                        data_input = image2text_response.preptool_output,
                        preptool = embedding_tools[0]
                    )
                    
                    embedding_response, embedding_result = PrepToolServiceManager(
                        
                        api_call=self.api_call
                    ).preptool_pipeline(request=embedding_request)
                    
                    # Update metrics
                    self.pipeline.prepmedia_metric.total_input_tokens += embedding_response.preptool_metric.preptool_input_tokens
                    self.pipeline.prepmedia_metric.total_output_tokens += embedding_response.preptool_metric.preptool_output_tokens
                    self.pipeline.prepmedia_metric.total_tool_tokens += embedding_response.preptool_metric.preptool_tool_tokens
                    self.pipeline.prepmedia_metric.prepmedia_time += embedding_response.preptool_metric.preptool_time
                    self.pipeline.prepmedia_metric.preptool_metrics.append(embedding_response.preptool_metric)
                    
                    # Add to processed data if successful
                    if embedding_result.status_code < SETTINGS.STAT.SUCC_CODE_END:
                        processed_data.extend(embedding_response.preptool_output)

        # ===== Pipeline 2: ocr -> embedding =====
        # Find OCR tool
        ocr_tools = [tool for tool in self.pipeline.prepknow_media.preptools 
                   if tool.preptool_type.lower() == "ocr"]
        
        if ocr_tools:
            data_io = [_data.copy(deep=True) for _data in original_data]
            # Process with OCR
            ocr_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_io,
                preptool = ocr_tools[0]
            )
            
            ocr_response, ocr_result = PrepToolServiceManager(
                
                api_call=self.api_call
            ).preptool_pipeline(request=ocr_request)
            
            # Update metrics
            self.pipeline.prepmedia_metric.total_input_tokens += ocr_response.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += ocr_response.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens += ocr_response.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time += ocr_response.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(ocr_response.preptool_metric)
            
            # If OCR successful, proceed to embedding
            if ocr_result.status_code < SETTINGS.STAT.SUCC_CODE_END:
                # Find embedding tool (use the same one as before if available)
                embedding_tools = [tool for tool in self.pipeline.prepknow_media.preptools 
                                if tool.preptool_type.lower() == "embedding"]
                
                if embedding_tools:
                    # Process with embedding
                    embedding_request = PrepToolPipelineRequest(
                        **self.pipeline.__dict__,
                        data_input = ocr_response.preptool_output,
                        preptool = embedding_tools[0]
                    )
                    
                    embedding_response, embedding_result = PrepToolServiceManager(
                        
                        api_call=self.api_call
                    ).preptool_pipeline(request=embedding_request)
                    
                    # Update metrics
                    self.pipeline.prepmedia_metric.total_input_tokens += embedding_response.preptool_metric.preptool_input_tokens
                    self.pipeline.prepmedia_metric.total_output_tokens += embedding_response.preptool_metric.preptool_output_tokens
                    self.pipeline.prepmedia_metric.total_tool_tokens += embedding_response.preptool_metric.preptool_tool_tokens
                    self.pipeline.prepmedia_metric.prepmedia_time += embedding_response.preptool_metric.preptool_time
                    self.pipeline.prepmedia_metric.preptool_metrics.append(embedding_response.preptool_metric)
                    
                    # Add to processed data if successful
                    if embedding_result.status_code < SETTINGS.STAT.SUCC_CODE_END:
                        processed_data.extend(embedding_response.preptool_output)

        # ===== Pipeline 3: keyword =====
        # Find keyword tool
        keyword_tools = [tool for tool in self.pipeline.prepknow_media.preptools 
                   if tool.preptool_type.lower() == "keyword"]
    
        if keyword_tools:
            # Process with Keywords
            keyword_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = processed_data,
                preptool = keyword_tools[0]
            )
            
            keyword_response, keyword_result = PrepToolServiceManager(
                
                api_call=self.api_call
            ).preptool_pipeline(request=keyword_request)
            
            # Update metrics
            self.pipeline.prepmedia_metric.total_input_tokens += keyword_response.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += keyword_response.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens += keyword_response.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time += keyword_response.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(keyword_response.preptool_metric)

            # Add to processed data if successful
            if keyword_result.status_code < SETTINGS.STAT.SUCC_CODE_END:
                processed_data = keyword_response.preptool_output

        # ===== Pipeline 4: language =====
        # Find language tool
        language_tools = [tool for tool in self.pipeline.prepknow_media.preptools 
                   if tool.preptool_type.lower() == "language"]
    
        if language_tools:
            # Process with Languages
            language_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = processed_data,
                preptool = language_tools[0]
            )
            
            language_response, lanaguage_result = PrepToolServiceManager(
                
                api_call=self.api_call
            ).preptool_pipeline(request=language_request)
            
            # Update metrics
            self.pipeline.prepmedia_metric.total_input_tokens += language_response.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += language_response.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens += language_response.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time += language_response.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(language_response.preptool_metric)

            # Add to processed data if successful
            if lanaguage_result.status_code < SETTINGS.STAT.SUCC_CODE_END:
                processed_data = language_response.preptool_output

        # Update pipeline output with processed data
        self.pipeline.prepmedia_output = processed_data

        # Check if we have any processed data
        if processed_data:
            # Success case
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
                prepmedia_reason = "SUCCESS",
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            
            response = Response(status_code=200, detail=self.response_format.ok(
                f"PrepMedia Image Processing Completed: <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Image Processing"))
        else:
            # Failure case - no data was processed successfully
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                prepmedia_reason = "Failed to process image with any pipeline",
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            
            response = Response(status_code=500, detail=self.response_format.error(
                f"PrepMedia Image Processing Failed: <{SETTINGS.BASE.APP_NAME}> No successful processing pipeline"))
        
        return response



    """
        Preprocessing Table Logic
    """
    def prepmedia_processing_table(self) -> Response:
        if self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'default_prepmedia_table':
            response = self.default_prepmedia_table()
        elif self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'test_prepmedia_table':
            response = self.test_prepmedia_table()
        
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Unfound Error : <{SETTINGS.BASE.APP_NAME}> Failed to Recognize PrepMedia Group <{self.pipeline.prepknow_media.prepmedia.prepmedia_group}>"))

        return response

    def default_prepmedia_table(self) -> Response:
        response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Image Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Image Processing"))
        return response
    
    def test_prepmedia_table(self) -> Response:
        self.pipeline.prepmedia_metric = PrepMediaMetric(**self.pipeline.__dict__)

        tasks    = ["table2text", "embedding", "keyword", "language"]
        preptools = []
        for _task in tasks:
            preptool = [_preptool for _preptool in self.pipeline.prepknow_media.preptools if _preptool.preptool_type.lower() == _task.lower()]
            if not preptool:
                response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia table Preprocessing Error : <{SETTINGS.BASE.APP_NAME} Cannot Find Appropriate PrepTool Type <{_task}> for Processing>"))
                logger.error(response.detail)
                break
            else:
                preptools.append(preptool[0])
                response = Response(status_code=200, detail=self.response_format.ok("PrepMedia Processing : Found PrepTool for "))


        #Return Error Response if Certain Preptools cannot be Retrieved
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code       = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                prepmedia_reason     = response.detail,
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            return response
        
        """ 2. Iterate All the Preptool Execution """
        data_io = self.pipeline.prepmedia_input
        for _preptool in preptools:

            preptool_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_io,
                preptool    = _preptool
            )

            response_preptool, response = PrepToolServiceManager(api_call=self.api_call).preptool_pipeline(request=preptool_request)

            # Update the prepmedia Metrics
            self.pipeline.prepmedia_metric.total_input_tokens  += response_preptool.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += response_preptool.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens   += response_preptool.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time      += response_preptool.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(response_preptool.preptool_metric)

            # Check Results
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                self.pipeline.prepmedia_output = []
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code       = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                    prepmedia_reason     = response.detail,
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
                return response
            
            else:
                data_io = response_preptool.preptool_output
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code       = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
                    prepmedia_reason     = "SUCCESS",
                    prepmedia_response_at = datetime.now(timezone.utc)
                )

            self.pipeline.prepmedia_output = data_io
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Table Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Image Processing"))

        return response

    def prepmedia_processing_document(self) -> Response:
        if self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'default_prepmedia_document':
            response = self.default_prepmedia_document()
        elif self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'test_prepmedia_document':
            response = self.test_prepmedia_document()
        
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Unfound Error : <{SETTINGS.BASE.APP_NAME}> Failed to Recognize PrepMedia Group <{self.pipeline.prepknow_media.prepmedia.prepmedia_group}>"))

        return response

    def default_prepmedia_document(self) -> Response:
        # TODO: Implement Default Document Processing - Woody
        response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Document Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Document Processing"))
        return response
    
    def test_prepmedia_document(self) -> Response:
        self.pipeline.prepmedia_metric = PrepMediaMetric(**self.pipeline.__dict__)

        tasks    = ["summarization", "rerank_keyword", "embedding"]
        preptools = []
        for _task in tasks:
            preptool = [_preptool for _preptool in self.pipeline.prepknow_media.preptools if _preptool.preptool_type.lower() == _task.lower()]
            if not preptool:
                response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia document Preprocessing Error : <{SETTINGS.BASE.APP_NAME} Cannot Find Appropriate PrepTool Type <{_task}> for Processing>"))
                logger.error(response.detail)
                break
            else:
                preptools.append(preptool[0])
                response = Response(status_code=200, detail=self.response_format.ok("PrepMedia Processing : Found PrepTool for "))

        #Return Error Response if Certain Preptools cannot be Retrieved
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code       = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                prepmedia_reason     = response.detail,
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            return response
        
        """ 2. Iterate All the Preptool Execution """
        data_io = self.pipeline.prepmedia_input
        for _preptool in preptools:
            preptool_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_io,
                preptool   = _preptool
            )

            response_preptool, response = PrepToolServiceManager(api_call=self.api_call).preptool_pipeline(request=preptool_request)

            # Update the prepmedia Metrics
            self.pipeline.prepmedia_metric.total_input_tokens  += response_preptool.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += response_preptool.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens   += response_preptool.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time      += response_preptool.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(response_preptool.preptool_metric)

            # Check Results
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                self.pipeline.prepmedia_output = []
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code       = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                    prepmedia_reason     = response.detail,
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
                return response
            
            else:
                data_io = response_preptool.preptool_output
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code       = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
                    prepmedia_reason     = "SUCCESS",
                    prepmedia_response_at = datetime.now(timezone.utc)
                )

            self.pipeline.prepmedia_output = data_io
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Document Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Document Processing"))
            logger.info(response.detail)
        return response


    """
        Preprocessing Relationship Logic
    """
    def prepmedia_processing_relationship(self) -> Response:
        if self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'default_prepmedia_relationship':
            response = self.default_prepmedia_relationship()
        elif self.pipeline.prepknow_media.prepmedia.prepmedia_group.lower() == 'test_prepmedia_relationship':
            response = self.test_prepmedia_relationship()
        else:
            response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Unfound Error : <{SETTINGS.BASE.APP_NAME}> Failed to Recognize PrepMedia Group <{self.pipeline.prepknow_media.prepmedia.prepmedia_group}>"))

        return response


    def default_prepmedia_relationship(self) -> Response:
        self.pipeline.prepmedia_metric = PrepMediaMetric(**self.pipeline.__dict__)

        """ 1. Identify All PrepTools for Tasks """
        tasks     = ["relationship"]
        preptools = []
        for _task in tasks:
            preptool = [_preptool for _preptool in self.pipeline.prepknow_media.preptools if _preptool.preptool_type.lower() == _task.lower()]
            if not preptool:
                response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Relationship Preprocessing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Appropriate PrepTool Type <{_task}> for Processing"))
                logger.error(response.detail)
                break
            else:
                preptools.append(preptool[0])
                response = Response(status_code=200, detail=self.response_format.ok("PrepMedia Processing : Found PrepTool for Processing"))
        
        # Return Error Response if Certain PrepTools cannot be Retrieved
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                prepmedia_reason      = response.detail,
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            return response

        """ 2. Iterate All PrepTool Execution """
        
        data_io = self.pipeline.prepmedia_input
        
        for _preptool in preptools:
            preptool_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_io,
                preptool   = _preptool
            )

            response_preptool, response = PrepToolServiceManager(api_call=self.api_call).preptool_pipeline(request=preptool_request)

            # Update PrepMedia Metrics
            self.pipeline.prepmedia_metric.total_input_tokens  += response_preptool.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += response_preptool.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens   += response_preptool.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time      += response_preptool.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(response_preptool.preptool_metric)
                    
            # Check Result
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                self.pipeline.prepmedia_relationship = []
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                    prepmedia_reason      = response.detail,
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
                return response
        
            else:
                data_output = response_preptool.preptool_relationship
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
                    prepmedia_reason      = "SUCCESS",
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
        
                self.pipeline.prepmedia_relationship = data_output
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Text Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Text Processing"))

        return response
    
    def test_prepmedia_relationship(self) -> Response:
        self.pipeline.prepmedia_metric = PrepMediaMetric(**self.pipeline.__dict__)

        """ 1. Identify All PrepTools for Tasks """
        tasks     = ["relationship"]
        preptools = []
        for _task in tasks:
            preptool = [_preptool for _preptool in self.pipeline.prepknow_media.preptools if _preptool.preptool_type.lower() == _task.lower()]
            if not preptool:
                response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Relationship Preprocessing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Appropriate PrepTool Type <{_task}> for Processing"))
                logger.error(response.detail)
                break
            else:
                preptools.append(preptool[0])
                response = Response(status_code=200, detail=self.response_format.ok("PrepMedia Processing : Found PrepTool for Processing"))
        
        # Return Error Response if Certain PrepTools cannot be Retrieved
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            self.pipeline.prepmedia_metric.__dict__.update(
                prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                prepmedia_reason      = response.detail,
                prepmedia_response_at = datetime.now(timezone.utc)
            )
            return response

        """ 2. Iterate All PrepTool Execution """
        data_input = self.pipeline.prepmedia_input
        data_output = []
        for _preptool in preptools:

            preptool_request = PrepToolPipelineRequest(
                **self.pipeline.__dict__,
                data_input = data_input,
                preptool   = _preptool
            )

            response_preptool, response = PrepToolServiceManager(api_call=self.api_call).preptool_pipeline(request=preptool_request)

            # Update PrepMedia Metrics
            self.pipeline.prepmedia_metric.total_input_tokens  += response_preptool.preptool_metric.preptool_input_tokens
            self.pipeline.prepmedia_metric.total_output_tokens += response_preptool.preptool_metric.preptool_output_tokens
            self.pipeline.prepmedia_metric.total_tool_tokens   += response_preptool.preptool_metric.preptool_tool_tokens
            self.pipeline.prepmedia_metric.prepmedia_time      += response_preptool.preptool_metric.preptool_time
            self.pipeline.prepmedia_metric.preptool_metrics.append(response_preptool.preptool_metric)
                    
            # Check Result
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                self.pipeline.prepmedia_relationship = []
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
                    prepmedia_reason      = response.detail,
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
                return response
        
            else:
                data_output = response_preptool.preptool_relationship
                self.pipeline.prepmedia_metric.__dict__.update(
                    prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
                    prepmedia_reason      = "SUCCESS",
                    prepmedia_response_at = datetime.now(timezone.utc)
                )
        
                self.pipeline.prepmedia_relationship = data_output
            response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Text Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Relationship Processing"))

        return response
    

    # def direct_prepmedia_relationship(self, request: RelationshipExtractRequest) -> tuple[RelationshipExtractResponse, Response]:
    #     relationship_response    = RelationshipExtractResponse(**request.__dict__)
    #     prepknow_media, response = self.prepmedia_init(request.prepmedia_id)
        
    #     """ 1. Identify All PrepTools for Tasks """
    #     preptools = []
    #     preptool = [_preptool for _preptool in prepknow_media.preptools]
    #     if not preptool:
    #         response = Response(status_code=404, detail=self.response_format.error(f"PrepMedia Relationship Preprocessing Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Appropriate PrepTool Type <{_task}> for Processing"))
    #         logger.error(response.detail)
    #     else:
    #         preptools.append(preptool[0])
    #         response = Response(status_code=200, detail=self.response_format.ok("PrepMedia Processing : Found PrepTool for Processing"))
    
    #     # Return Error Response if Certain PrepTools cannot be Retrieved
    #     if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
    #         relationship_response.prepmedia_metric.__dict__.update(
    #             prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
    #             prepmedia_reason      = response.detail,
    #             prepmedia_response_at = datetime.now(timezone.utc)
    #         )
    #         return relationship_response, response

    #     """ 2. Iterate All PrepTool Execution """
        
    #     for _preptool in preptools:
    #         request.__dict__.update(
    #             preptool   = _preptool
    #         )
    #         preptool_request = PrepToolPipelineRequest(
    #             **request.__dict__,
    #         )

    #         response_preptool, response = PrepToolServiceManager(api_call=self.api_call).preptool_pipeline(request=preptool_request)

    #         # Update PrepMedia Metrics
    #         relationship_response.prepmedia_metric.total_input_tokens  += response_preptool.preptool_metric.preptool_input_tokens
    #         relationship_response.prepmedia_metric.total_output_tokens += response_preptool.preptool_metric.preptool_output_tokens
    #         relationship_response.prepmedia_metric.total_tool_tokens   += response_preptool.preptool_metric.preptool_tool_tokens
    #         relationship_response.prepmedia_metric.prepmedia_time      += response_preptool.preptool_metric.preptool_time
    #         relationship_response.prepmedia_metric.preptool_metrics.append(response_preptool.preptool_metric)
                    
    #         # Check Result
    #         if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
    #             relationship_response.relationship = []
    #             relationship_response.prepmedia_metric.__dict__.update(
    #                 prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("FAIL"),
    #                 prepmedia_reason      = response.detail,
    #                 prepmedia_response_at = datetime.now(timezone.utc)
    #             )
    #             return relationship_response, response
        
    #         else:
    #             data_io = response_preptool.preptool_relationship
    #             data_node_id_pairs = {}
    #             for relation_obj in data_io:
    #                 data_node_id_pairs[relation_obj.data_id] = relation_obj.node_id
    #             processed_input = request.__dict__.get("data_input", [])
    #             for index, know_obj in enumerate(request.data_input):
    #                 node_id = data_node_id_pairs[know_obj.data_id]
    #                 processed_input[index].__dict__.update(
    #                     node_id = node_id
    #                 )

    #             relationship_response.prepmedia_metric.__dict__.update(
    #                 prepmedia_code        = SETTINGS.PRMD.STATUS_CODE.get("SUCCESS"),
    #                 prepmedia_reason      = "SUCCESS",
    #                 prepmedia_response_at = datetime.now(timezone.utc)
    #             )
        
    #     relationship_response.processed_input = processed_input
    #     relationship_response.relationship = data_io
    #     response = Response(status_code=200, detail=self.response_format.ok(f"PrepMedia Text Processing Completed : <{SETTINGS.BASE.APP_NAME}> Completed PrepMedia Text Processing"))

    #     return relationship_response, response
    

    """
        Utilis
    """
    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response