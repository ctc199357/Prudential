from ..settings import SETTINGS

default_preptools = [
  {
    "preptool_id": "test_azure_embedding_1",
    "preptool_traceid": "test_azure_embedding_1",
    "preptool_version": 1,
    "preptool_name": "azure-ada-002",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "default",
    "preptool_type": "embedding",
    "preptool_location": SETTINGS.GEAI.EMBED_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.EMBED_HOST,
    "preptool_port": SETTINGS.GEAI.EMBED_PORT,
    "preptool_api": SETTINGS.GEAI.EMBED_API,
    "preptool_engine": SETTINGS.GEAI.EMBED_ENGINE,
    "preptool_base": SETTINGS.GEAI.EMBED_BASE,
    "preptool_model": SETTINGS.GEAI.EMBED_MODEL,
    "preptool_parameters": SETTINGS.GEAI.EMBED_PARAMETERS,
    "preptool_secrets": SETTINGS.GEAI.EMBED_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.EMBED_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {"dimension": 1536, "array_input_limit": 2048},
    "preptool_description": "Test Azure Embedding",
    "input_types": {'text': 1},
    "output_types": {'vector': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_keyword_1",
    "preptool_traceid": "test_azure_keyword_1",
    "preptool_version": 1,
    "preptool_name": "test_azure_keyword_1",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "azure",
    "preptool_type": "keyword",
    "preptool_location": SETTINGS.GEAI.KEYWD_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.KEYWD_HOST,
    "preptool_port": SETTINGS.GEAI.KEYWD_PORT,
    "preptool_api": SETTINGS.GEAI.KEYWD_API,
    "preptool_engine": SETTINGS.GEAI.KEYWD_ENGINE,
    "preptool_base": SETTINGS.GEAI.KEYWD_BASE,
    "preptool_model": SETTINGS.GEAI.KEYWD_MODEL,
    "preptool_parameters": SETTINGS.GEAI.KEYWD_PARAMETERS,
    "preptool_secrets": SETTINGS.GEAI.KEYWD_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.KEYWD_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {},
    "preptool_description": "",
    "input_types": {'text': 1},
    "output_types": {'text': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_keyword_2",
    "preptool_traceid": "test_azure_keyword_2",
    "preptool_version": 1,
    "preptool_name": "test_azure_keyword_2",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "genai",
    "preptool_type": "keyword",
    "preptool_location": SETTINGS.GEAI.MODEL_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.MODEL_HOST,
    "preptool_port": SETTINGS.GEAI.MODEL_PORT,
    "preptool_api": SETTINGS.GEAI.MODEL_API,
    "preptool_engine": SETTINGS.GEAI.MODEL_ENGINE,
    "preptool_base": SETTINGS.GEAI.MODEL_BASE,
    "preptool_model": SETTINGS.GEAI.MODEL_NAME,
    "preptool_parameters": {"user_prompt": "", "context_window_size": 128000},
    "preptool_secrets": SETTINGS.GEAI.MODEL_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.MODEL_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {"dimension": 1024, "para_num": 334, "quan": 16, "vram": 2.0},
    "preptool_description": "Test Azure GenAI Keywords Extraction by LLM",
    "input_types": {'text': 1},
    "output_types": {'text': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_rerank_keyword_1",
    "preptool_traceid": "test_azure_rerank_keyword_1",
    "preptool_version": 1,
    "preptool_name": "test_azure_rerank_keyword_1",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "azure",
    "preptool_type": "rerank_keyword",
    "preptool_location": SETTINGS.GEAI.KEYWD_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.KEYWD_HOST,
    "preptool_port": SETTINGS.GEAI.KEYWD_PORT,
    "preptool_api": SETTINGS.GEAI.KEYWD_API,
    "preptool_engine": SETTINGS.GEAI.KEYWD_ENGINE,
    "preptool_base": SETTINGS.GEAI.KEYWD_BASE,
    "preptool_model": SETTINGS.GEAI.KEYWD_MODEL,
    "preptool_parameters": {"limit": 10},
    "preptool_secrets": SETTINGS.GEAI.KEYWD_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.KEYWD_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {},
    "preptool_description": "",
    "input_types": {'text': 1},
    "output_types": {'text': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_language_1",
    "preptool_traceid": "test_azure_language_1",
    "preptool_version": 1,
    "preptool_name": "test_azure_language_1",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "azure",
    "preptool_type": "language",
    "preptool_location": SETTINGS.GEAI.KEYWD_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.KEYWD_HOST,
    "preptool_port": SETTINGS.GEAI.KEYWD_PORT,
    "preptool_api": SETTINGS.GEAI.KEYWD_API,
    "preptool_engine": SETTINGS.GEAI.KEYWD_ENGINE,
    "preptool_base": SETTINGS.GEAI.KEYWD_BASE,
    "preptool_model": SETTINGS.GEAI.KEYWD_MODEL,
    "preptool_parameters": SETTINGS.GEAI.KEYWD_PARAMETERS,
    "preptool_secrets": SETTINGS.GEAI.KEYWD_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.KEYWD_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {},
    "preptool_description": "",
    "input_types": {'text': 1},
    "output_types": {'text': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_summarization_1",
    "preptool_traceid": "test_azure_summarization_1",
    "preptool_version": 1,
    "preptool_name": "",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "genai",
    "preptool_type": "summarization",
    "preptool_location": SETTINGS.GEAI.MODEL_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.MODEL_HOST,
    "preptool_port": SETTINGS.GEAI.MODEL_PORT,
    "preptool_api": SETTINGS.GEAI.MODEL_API,
    "preptool_engine": SETTINGS.GEAI.MODEL_ENGINE,
    "preptool_base": SETTINGS.GEAI.MODEL_BASE,
    "preptool_model": SETTINGS.GEAI.MODEL_NAME,
    "preptool_parameters": {"user_prompt": "Summarize the Texts into 50-100 words:", "summary_group_size": 30, "overlap_size": 2, "context_window_size": 128000},
    "preptool_secrets": SETTINGS.GEAI.MODEL_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.MODEL_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {"dimension": 1024, "para_num": 334, "quan": 16, "vram": 2.0},
    "preptool_description": "Test Azure GenAI Summarization",
    "input_types": {'text': 1},
    "output_types": {'text': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_ocr_1",
    "preptool_traceid": "test_azure_ocr_1",
    "preptool_version": 1,
    "preptool_name": "ai-vision",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "genai",
    "preptool_type": "ocr",
    "preptool_location": SETTINGS.GEAI.VISION_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.VISION_HOST,
    "preptool_port": SETTINGS.GEAI.VISION_PORT,
    "preptool_api": SETTINGS.GEAI.VISION_API,
    "preptool_engine": SETTINGS.GEAI.VISION_ENGINE,
    "preptool_base": SETTINGS.GEAI.VISION_BASE,
    "preptool_model": SETTINGS.GEAI.VISION_MODEL,
    "preptool_parameters": SETTINGS.GEAI.VISION_PARAMETERS,
    "preptool_secrets": SETTINGS.GEAI.VISION_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.VISION_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {},
    "preptool_description": "",
    "input_types": {'image': 1},
    "output_types": {'text': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_image2text_1",
    "preptool_traceid": "test_azure_image2text_1",
    "preptool_version": 1,
    "preptool_name": "test_azure_image2text_1",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "genai",
    "preptool_type": "image2text",
    "preptool_location": SETTINGS.GEAI.MODEL_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.MODEL_HOST,
    "preptool_port": SETTINGS.GEAI.MODEL_PORT,
    "preptool_api": SETTINGS.GEAI.MODEL_API,
    "preptool_engine": SETTINGS.GEAI.MODEL_ENGINE,
    "preptool_base": SETTINGS.GEAI.MODEL_BASE,
    "preptool_model": SETTINGS.GEAI.MODEL_NAME,
    "preptool_parameters": {"user_prompt": "Describe the Image with Text using original language of the Image"},
    "preptool_secrets": SETTINGS.GEAI.MODEL_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.MODEL_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {"dimension": 1024, "para_num": 334, "quan": 16, "vram": 2.0},
    "preptool_description": "Test Azure GenAI Image2Text",
    "input_types": {'image': 1},
    "output_types": {'text': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_table2text_1",
    "preptool_traceid": "test_azure_table2text_1",
    "preptool_version": 1,
    "preptool_name": "test_azure_table2text_1",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "genai",
    "preptool_type": "table2text",
    "preptool_location": SETTINGS.GEAI.MODEL_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.MODEL_HOST,
    "preptool_port": SETTINGS.GEAI.MODEL_PORT,
    "preptool_api": SETTINGS.GEAI.MODEL_API,
    "preptool_engine": SETTINGS.GEAI.MODEL_ENGINE,
    "preptool_base": SETTINGS.GEAI.MODEL_BASE,
    "preptool_model": SETTINGS.GEAI.MODEL_NAME,
    "preptool_parameters": {"user_prompt": "Describe the Table with Text using original language of the Table"},
    "preptool_secrets": SETTINGS.GEAI.MODEL_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {},
    "preptool_termination": {'max_retry': 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.MODEL_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {"dimension": 1024, "para_num": 334, "quan": 16, "vram": 2.0},
    "preptool_description": "Test Azure GenAI Table2Text",
    "input_types": {'table': 1},
    "output_types": {'text': 1,},
    "preptool_languages": ["ENG"],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_relationship_1",
    "preptool_traceid": "test_azure_relationship_1",
    "preptool_version": 1,
    "preptool_name": "test_azure_relationship_1",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "genai",
    "preptool_type": "relationship",
    "preptool_location": SETTINGS.GEAI.MODEL_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.MODEL_HOST,
    "preptool_port": SETTINGS.GEAI.MODEL_PORT,
    "preptool_api": SETTINGS.GEAI.MODEL_API,
    "preptool_engine": SETTINGS.GEAI.MODEL_ENGINE,
    "preptool_base": SETTINGS.GEAI.MODEL_BASE,
    "preptool_model": SETTINGS.GEAI.MODEL_NAME,
    "preptool_parameters": {
              "user_prompt": """YOU ARE THE WORLD'S BEST INSURANCE AGENT ASSISTANT FROM Prudential Hong Kong. YOUR TASK IS TO ANALYZE THE CHUNKS IN A DOCUMENT AND IDENTIFY THE RELATIONSHIP BETWEEN CHUNKS.
              
              ### INSTRUCTIONS
              
              1. Do not request additional information or clarification.
              
              2. All chunks are from the same document. Make every effort to extract the relationship between the chunks based on given context.
              
              3. Respond in English.

              4. Analyze the relationship between the context of the given chunks. The chunks will be given with the following format:
                Reference Chunks:
                [
                    {{"chunk_id": "<id starting with R->", "data_type": "<text/image/table>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}}
                    ...
                ]
                
                Comparison Chunks:
                [
                    {{"chunk_id": "<id starting with C->", "data_type": "<text/image/table>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}},
                    ...
                ]

              5. Classify the relationships between the Reference Chunks and other Comparison Chunks into the following relationship types. The description of each relationship type is also given for your refernece. 
              
              6. If there is no relationship between the Reference Chunks and the Comparison Chunk, just skip it in your response.

              7. The relationship is directional. You must consider the relationship direction between the source chunk to the targe chunk.

              8. In the classification, you consider the relationship from the Reference Chunks (source) to the Comparison Chunks (target) and the relationship from the Comparison Chunks (source) to the Refernece Chunks (target).

              9. DO NOT classify the chunk relationships within the Reference Chunks and DO NOT classify the chunk relationships within the Comparison Chunks.

              10. For each classified relationship, one chunk must be Reference Chunk and another must be Comparison Chunk. 

              11. If a chunk appeared to be header or footer, DO NOT classify its relationship with other chunks. Just skip the header chunks and footer chunks.

              12. If the relationship between the chunks is uncertain, just skip it.

              13. The reply format must be in JSON as follows:
                - If there are relationship between the chunks:
                ```
                [
                    {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                    {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
                ]
                ```
              
              ### Example Input:
              Reference Chunks:
              [
                  {{"chunk_id": "<id starting with R->", "content": "<content>"}},
                  ...
              ]

              Comparsion Chunks:
              [
                  {{"chunk_id": "<id starting with C->", "content": "<content>"}},
                  ...
              ]
              
              ### Example Expected Output (JSON):
              ```
              [
                  {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                  {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
              ]
              ```

              ### Relationship Types:
              {relationship}

              ### Chunk Context for Your Analysis:
              {context}
              """,
              "relationship": {
                "SECTION_OF":      "Links subsections to their parent sections.",
                "PART_OF":         "Indicates that a component (like a table or image) belongs to a section or paragraph.",
                "CAUSES":          "Indicates that one concept or event leads to another.",
                "RESULTS_IN":      "Shows the outcome of an event or action described in the text.",
                "DESCRIBES":       "Links a section or paragraph to a concept it elaborates on.",
                "ILLUSTRATES":     "Connects images or tables to the text they visually represent.",
                "SIMILAR_TO":      "Indicates similarities between two concepts or sections.",
                "CONTRASTS_WITH":  "Shows a distinction between two ideas or sections.",
                "REFERENCES":      "Links sections to cited works or other relevant sections within the document.",
                "MENTIONS":        "Connects specific terms or entities within the text to their definitions or explanations.",
                "CONTEXT_OF":      "Provides context for a piece of information, linking it to relevant themes or subjects in the document.",
                "PURPOSE_OF":      "Explains why a section exists or what it aims to achieve.",
                "HAS_ATTRIBUTE":   "Links entities to their properties",
                "IS_DESCRIBED_BY": "Connects terms or sections to their descriptions."
              },
              "batch_size": 50
          },
    "preptool_secrets": SETTINGS.GEAI.MODEL_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {"inference_error": 3},
    "preptool_termination": {"max_retry": 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.MODEL_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {},
    "preptool_description": "Test Server Knowledge Data Obj to Relationships",
    "input_types": {"text": 1},
    "output_types": {"text": 1},
    "preptool_languages": [],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_relationship_2",
    "preptool_traceid": "test_azure_relationship_2",
    "preptool_version": 1,
    "preptool_name": "test_azure_relationship_2",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "genai",
    "preptool_type": "relationship",
    "preptool_location": SETTINGS.GEAI.MODEL_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.MODEL_HOST,
    "preptool_port": SETTINGS.GEAI.MODEL_PORT,
    "preptool_api": SETTINGS.GEAI.MODEL_API,
    "preptool_engine": SETTINGS.GEAI.MODEL_ENGINE,
    "preptool_base": SETTINGS.GEAI.MODEL_BASE,
    "preptool_model": SETTINGS.GEAI.MODEL_NAME,
    "preptool_parameters": {
              "user_prompt": """YOU ARE THE WORLD'S BEST INSURANCE AGENT ASSISTANT FROM Prudential Hong Kong. YOUR TASK IS TO ANALYZE THE CHUNKS IN A DOCUMENT AND IDENTIFY THE RELATIONSHIP BETWEEN CHUNKS.
              
              ### INSTRUCTIONS
              
              1. Do not request additional information or clarification.
              
              2. All chunks are from the same document. Make every effort to extract the relationship between the chunks based on given context.
              
              3. Respond in English.

              4. Analyze the relationship between the context of the given chunks. The chunks will be given with the following format:
                Reference Chunks:
                [
                    {{"chunk_id": "<id starting with R->", "data_type": "<text/image/table>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}}
                    ...
                ]
                
                Comparison Chunks:
                [
                    {{"chunk_id": "<id starting with C->", "data_type": "<text/image/table>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}},
                    ...
                ]

              5. Classify the relationships between the Reference Chunks and other Comparison Chunks into the following relationship types. The description of each relationship type is also given for your refernece. 
              
              6. If there is no relationship between the Reference Chunks and the Comparison Chunk, just skip it in your response.

              7. The relationship is directional. You must consider the relationship direction between the source chunk to the targe chunk.

              8. In the classification, you consider the relationship from the Reference Chunks (source) to the Comparison Chunks (target) and the relationship from the Comparison Chunks (source) to the Refernece Chunks (target).

              9. DO NOT classify the chunk relationships within the Reference Chunks and DO NOT classify the chunk relationships within the Comparison Chunks.

              10. For each classified relationship, one chunk must be Reference Chunk and another must be Comparison Chunk. 

              11. If a chunk appeared to be header or footer, DO NOT classify its relationship with other chunks. Just skip the header chunks and footer chunks.

              12. If the relationship between the chunks is uncertain, just skip it.

              13. The reply format must be in JSON as follows:
                - If there are relationship between the chunks:
                ```
                [
                    {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                    {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
                ]
                ```
              
              ### Example Input:
              Reference Chunks:
              [
                  {{"chunk_id": "<id starting with R->", "content": "<content>"}},
                  ...
              ]

              Comparsion Chunks:
              [
                  {{"chunk_id": "<id starting with C->", "content": "<content>"}},
                  ...
              ]
              
              ### Example Expected Output (JSON):
              ```
              [
                  {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                  {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
              ]
              ```

              ### Relationship Types:
              {relationship}

              ### Chunk Context for Your Analysis:
              {context}
              """,
              "relationship": {
                "SECTION_OF":      "Links subsections to their parent sections.",
                "PART_OF":         "Indicates that a component (like a table or image) belongs to a section or paragraph.",
                "CAUSES":          "Indicates that one concept or event leads to another.",
                "RESULTS_IN":      "Shows the outcome of an event or action described in the text.",
                "DESCRIBES":       "Links a section or paragraph to a concept it elaborates on.",
                "ILLUSTRATES":     "Connects images or tables to the text they visually represent.",
                "SIMILAR_TO":      "Indicates similarities between two concepts or sections.",
                "CONTRASTS_WITH":  "Shows a distinction between two ideas or sections.",
                "REFERENCES":      "Links sections to cited works or other relevant sections within the document.",
                "MENTIONS":        "Connects specific terms or entities within the text to their definitions or explanations.",
                "CONTEXT_OF":      "Provides context for a piece of information, linking it to relevant themes or subjects in the document.",
                "PURPOSE_OF":      "Explains why a section exists or what it aims to achieve.",
                "HAS_ATTRIBUTE":   "Links entities to their properties",
                "IS_DESCRIBED_BY": "Connects terms or sections to their descriptions."
              },
              "batch_size": 50
          },
    "preptool_secrets": SETTINGS.GEAI.MODEL_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {"inference_error": 3},
    "preptool_termination": {"max_retry": 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.MODEL_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {},
    "preptool_description": "Test Server Knowledge Data Obj to Relationships",
    "input_types": {"text": 1},
    "output_types": {"text": 1},
    "preptool_languages": [],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  },
  {
    "preptool_id": "test_azure_relationship_3",
    "preptool_traceid": "test_azure_relationship_3",
    "preptool_version": 1,
    "preptool_name": "test_azure_relationship_3",
    "creator_id": "system",
    "creator_name": "system",
    "preptool_group": "genai",
    "preptool_type": "relationship",
    "preptool_location": SETTINGS.GEAI.MODEL_LOCATION,
    "preptool_permission": 1,
    "preptool_management": 10,
    "preptool_status": 1,
    "preptool_host": SETTINGS.GEAI.MODEL_HOST,
    "preptool_port": SETTINGS.GEAI.MODEL_PORT,
    "preptool_api": SETTINGS.GEAI.MODEL_API,
    "preptool_engine": SETTINGS.GEAI.MODEL_ENGINE,
    "preptool_base": SETTINGS.GEAI.MODEL_BASE,
    "preptool_model": SETTINGS.GEAI.MODEL_NAME,
    "preptool_parameters": {
              "user_prompt": """YOU ARE THE WORLD'S BEST INSURANCE AGENT ASSISTANT FROM Prudential Hong Kong. YOUR TASK IS TO ANALYZE THE CHUNKS IN A DOCUMENT AND IDENTIFY THE RELATIONSHIP BETWEEN CHUNKS.
              
              ### INSTRUCTIONS
              
              1. Do not request additional information or clarification.
              
              2. All chunks are from the same document. Make every effort to extract the relationship between the chunks based on given context.
              
              3. Respond in English.

              4. Analyze the relationship between the context of the given chunks. The chunks will be given with the following format:
                Reference Chunk:
                {{"chunk_id": "<C-1>", "data_type": "<text/image/table>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}}
                
                Comparison Chunks:
                [
                    {{"chunk_id": "<id starting with C->", "data_type": "<text/image/table>", "content": "<content>", "page": "<page that the content located>", "coord_x1": "<context coordinate>", "coord_x2": "<context coordinate>", "coord_y1": "<context coordinate>", "coord_y2": "<context coordinate>"}},
                    ...
                ]

              5. Classify the relationships between the Reference Chunk and other Comparison Chunks into the following relationship types. The description of each relationship type is also given for your refernece. 
              
              6. If there is no relationship between the Reference chunk and the Comparison Chunk, just skip it in your response.

              7. The relationship is directional. You must consider the relationship direction between the source chunk to the targe chunk.

              8. In the classification, you consider the relationship from the Reference Chunk (source) to the Comparison Chunks (target) and the relationship from the Comparison Chunks (source) to the Refernece Chunk (target).

              9. It could be multiple relationship types between two chunks. Classify all relationship types between two chunks.

              9. The reply format must be in JSON as follows:
                - If there are relationship between the chunks:
                ```
                [
                    {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                    {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
                ]
                ```
              
              ### Example Input:
              [
                  {{"chunk_id": "<id starting with C->", "content": "<content>"}},
                  ...
              ]
              
              ### Example Expected Output (JSON):
              ```
              [
                  {{"source": "chunk_id", "target": "chunk_id", "relationship": "relationship_type"}},
                  {{"source": "chunk_id", "target": "chunk_id", "relationship": 'relationship_type'}}
              ]
              ```

              ### Relationship Types:
              {relationship}

              ### Chunk Context for Your Analysis:
              {context}
              """,
              "relationship": {
                "SECTION_OF":      "Links subsections to their parent sections.",
                "PART_OF":         "Indicates that a component (like a table or image) belongs to a section or paragraph.",
                "CAUSES":          "Indicates that one concept or event leads to another.",
                "RESULTS_IN":      "Shows the outcome of an event or action described in the text.",
                "MENTIONS":        "Connects specific terms or entities within the text to their definitions or explanations.",
              },
              "batch_size": 40,
              "max_tokens": 4000,
          },
    "preptool_secrets": SETTINGS.GEAI.MODEL_SECRETS,
    "preptool_inputs": {},
    "preptool_outputs": {},
    "preptool_environment": "test",
    "preptool_retry": {"inference_error": 3},
    "preptool_termination": {"max_retry": 3},
    "preptool_key": "",
    "preptool_timeout": SETTINGS.GEAI.MODEL_TIMEOUT,
    "input_format": "",
    "output_format": "",
    "preptool_complexity": 1,
    "preptool_use_gpu": False,
    "preptool_instance_num": 1,
    "preptool_info": {},
    "preptool_description": "Test Server Knowledge Data Obj to Relationships",
    "input_types": {"text": 1},
    "output_types": {"text": 1},
    "preptool_languages": [],
    "preptool_tags": [],
    "user_groups": [],
    "agent_groups": []
  }
]

default_prepmedias=[
    {
      "prepmedia_id": "test_prepmedia_text_1",
      "prepmedia_traceid": "test_prepmedia_text_1",
      "prepmedia_version": 1,
      "prepmedia_name": "test_prepmedia_text_1",
      "creator_id": "system",
      "creator_name": "system",
      "prepmedia_group": "test_prepmedia_text",
      "prepmedia_type": "text",
      "prepmedia_location": "default",
      "prepmedia_status": 1,
      "prepmedia_permission": 1,
      "prepmedia_management": 10,
      "prepmedia_parameters": {},
      "prepmedia_secrets": {},
      "prepmedia_inputs": {},
      "prepmedia_outputs": {},
      "prepmedia_retry": {},
      "prepmedia_termination": {'max_retry': 3},
      "prepmedia_key": "",
      "prepmedia_timeout": 300,
      "input_format": "",
      "output_format": "",
      "preptool_selection": "default",
      "preptool_ids": {"test_azure_keyword_2": 1, "test_azure_language_1": 1, "test_azure_embedding_1": 1},
      "prepmedia_complexity": 1,
      "prepmedia_use_gpu": False,
      "prepmedia_instance_num": 1,
      "prepmedia_info": {}, 
      "prepmedia_description": "Test Preprocessing Text",

      "input_types": {'text': 1},
      "output_types": {'text': 1},
      "prepmedia_languages": ['ENG'],
      "prepmedia_tags": [],
      "user_groups": [],
      "agent_groups": []
    },
    {
      "prepmedia_id": "test_prepmedia_image_1",
      "prepmedia_traceid": "test_prepmedia_image_1",
      "prepmedia_version": 1,
      "prepmedia_name": "test_prepmedia_image_1",
      "creator_id": "system",
      "creator_name": "system",
      "prepmedia_group": "test_prepmedia_image",
      "prepmedia_type": "image",
      "prepmedia_location": "default",
      "prepmedia_status": 1,
      "prepmedia_permission": 1,
      "prepmedia_management": 10,
      "prepmedia_parameters": {},
      "prepmedia_secrets": {},
      "prepmedia_inputs": {},
      "prepmedia_outputs": {},
      "prepmedia_retry": {},
      "prepmedia_termination": {'max_retry': 3},
      "prepmedia_key": "",
      "prepmedia_timeout": 300,
      "input_format": "",
      "output_format": "",
      "preptool_selection": "default",
      "preptool_ids": {"test_azure_image2text_1": 1, "test_azure_ocr_1": 1, "test_azure_embedding_1": 1, "test_azure_keyword_2": 1, "test_azure_language_1": 1},
      "prepmedia_complexity": 1,
      "prepmedia_use_gpu": False,
      "prepmedia_instance_num": 1,
      "prepmedia_info": {},
      "prepmedia_description": "Test Preprocessing Image",

      "input_types": {'image': 1},
      "output_types": {'text': 1},
      "prepmedia_languages": ['ENG'],
      "prepmedia_tags": [],
      "user_groups": [],
      "agent_groups": []
    },
    {
      "prepmedia_id": "test_prepmedia_table_1",
      "prepmedia_traceid": "test_prepmedia_table_1",
      "prepmedia_version": 1,
      "prepmedia_name": "test_prepmedia_table_1",
      "creator_id": "system",
      "creator_name": "system",
      "prepmedia_group": "test_prepmedia_table",
      "prepmedia_type": "table",
      "prepmedia_location": "default",
      "prepmedia_status": 1,
      "prepmedia_permission": 1,
      "prepmedia_management": 10,
      "prepmedia_parameters": {},
      "prepmedia_secrets": {},
      "prepmedia_inputs": {},
      "prepmedia_outputs": {},
      "prepmedia_retry": {},
      "prepmedia_termination": {'max_retry': 3},
      "prepmedia_key": "",
      "prepmedia_timeout": 300,
      "input_format": "",
      "output_format": "",
      "preptool_selection": "default",
      "preptool_ids": {"test_azure_table2text_1": 1, "test_azure_embedding_1": 1, "test_azure_keyword_2": 1, "test_azure_language_1": 1},
      "prepmedia_complexity": 1,
      "prepmedia_use_gpu": False,
      "prepmedia_instance_num": 1,
      "prepmedia_info": {},
      "prepmedia_description": "Test Preprocessing Table",

      "input_types": {'text': 1},
      "output_types": {'text': 1},
      "prepmedia_languages": ['ENG'],
      "prepmedia_tags": [],
      "user_groups": [],
      "agent_groups": []
    },
    {
      "prepmedia_id": "test_prepmedia_document_1",
      "prepmedia_traceid": "test_prepmedia_document_1",
      "prepmedia_version": 1,
      "prepmedia_name": "test_prepmedia_document_1",
      "creator_id": "system",
      "creator_name": "system",
      "prepmedia_group": "test_prepmedia_document",
      "prepmedia_type": "document",
      "prepmedia_location": "default",
      "prepmedia_status": 1,
      "prepmedia_permission": 1,
      "prepmedia_management": 10,
      "prepmedia_parameters": {},
      "prepmedia_secrets": {},
      "prepmedia_inputs": {},
      "prepmedia_outputs": {},
      "prepmedia_retry": {},
      "prepmedia_termination": {'max_retry': 3},
      "prepmedia_key": "",
      "prepmedia_timeout": 300,
      "input_format": "",
      "output_format": "",
      "preptool_selection": "default",
      "preptool_ids": {"test_azure_summarization_1": 1, "test_azure_rerank_keyword_1": 1, "test_azure_embedding_1": 1},
      "prepmedia_complexity": 1,
      "prepmedia_use_gpu": False,
      "prepmedia_instance_num": 1,
      "prepmedia_info": {},
      "prepmedia_description": "Test Preprocessing Document",

      "input_types": {'text': 1},
      "output_types": {'text': 1},
      "prepmedia_languages": ['ENG'],
      "prepmedia_tags": [],
      "user_groups": [],
      "agent_groups": []
    },
    {
      "prepmedia_id": "test_prepmedia_relationship_1",
      "prepmedia_traceid": "test_prepmedia_relationship_1",
      "prepmedia_version": 1,
      "prepmedia_name": "test_prepmedia_relationship_1",
      "creator_id": "system",
      "creator_name": "system",
      "prepmedia_group": "test_prepmedia_relationship",
      "prepmedia_type": "relationship",
      "prepmedia_location": "azure",
      "prepmedia_status": 1,
      "prepmedia_permission": 1,
      "prepmedia_management": 10,
      "prepmedia_parameters": {},
      "prepmedia_secrets": {},
      "prepmedia_inputs": {},
      "prepmedia_outputs": {},
      "prepmedia_retry": {},
      "prepmedia_termination": {"max_retry": 3},
      "prepmedia_key": "",
      "prepmedia_timeout": 300,
      "input_format": "",
      "output_format": "",
      "preptool_selection": "default",
      "preptool_ids": {"test_azure_relationship_1": 1},
      "prepmedia_complexity": 1,
      "prepmedia_use_gpu": False,
      "prepmedia_instance_num": 1,
      "prepmedia_info": {},
      "prepmedia_description": "Test Preprocessing Relationship",
      "input_types": {"text": 1},
      "output_types": {"text": 1},
      "prepmedia_languages": [],
      "prepmedia_tags": [],
      "user_groups": [],
      "agent_groups": [],
      "created_at": "2025-03-13T14:48:22.178925",
      "updated_at": "2025-03-13T14:48:22.178925"
    },
    {
      "prepmedia_id": "test_prepmedia_relationship_2",
      "prepmedia_traceid": "test_prepmedia_relationship_2",
      "prepmedia_version": 1,
      "prepmedia_name": "test_prepmedia_relationship_2",
      "creator_id": "system",
      "creator_name": "system",
      "prepmedia_group": "test_prepmedia_relationship",
      "prepmedia_type": "relationship",
      "prepmedia_location": "default",
      "prepmedia_status": 1,
      "prepmedia_permission": 1,
      "prepmedia_management": 10,
      "prepmedia_parameters": {},
      "prepmedia_secrets": {},
      "prepmedia_inputs": {},
      "prepmedia_outputs": {},
      "prepmedia_retry": {},
      "prepmedia_termination": {'max_retry': 3},
      "prepmedia_key": "",
      "prepmedia_timeout": 300,
      "input_format": "",
      "output_format": "",
      "preptool_selection": "default",
      "preptool_ids": {"test_azure_summarization_1": 1, "test_azure_rerank_keyword_1": 1, "test_azure_embedding_1": 1},
      "prepmedia_complexity": 1,
      "prepmedia_use_gpu": False,
      "prepmedia_instance_num": 1,
      "prepmedia_info": {},
      "prepmedia_description": "Test Relationship Extraction",

      "input_types": {'text': 1},
      "output_types": {'text': 1},
      "prepmedia_languages": [],
      "prepmedia_tags": [],
      "user_groups": [],
      "agent_groups": []
    }
]

default_prepknows=[
    {
      "prepknow_id": "test_prepknow_1",
      "prepknow_traceid": "test_prepknow_1",
      "prepknow_version": 1,
      "prepknow_name": "test_prepknow_1",
      "creator_id": "system",
      "creator_name": "system",
      "prepknow_group": "default",
      "prepknow_type": "general",
      "prepknow_location": "default",
      "prepknow_status": 1,
      "prepknow_permission": 1,
      "prepknow_management": 10,
      "prepknow_layout_func": {"PDF": "TEST"},
      "prepknow_parameters": {},
      "prepknow_secrets": {},
      "prepknow_inputs": {},
      "prepknow_outputs": {},
      "prepknow_retry": {},
      "prepknow_termination":{'max_retry': 3},
      "prepknow_key": "",
      "prepknow_timeout": 300,
      "input_format": "",
      "output_format": "",
      "prepmedia_selection": "default",
      "prepmedia_ids": {"test_prepmedia_text_1": 1, "test_prepmedia_image_1": 1,  "test_prepmedia_table_1": 1, "test_prepmedia_document_1": 1},
      "prepknow_complexity": 1,
      "prepknow_use_gpu": False,
      "prepknow_instance_num": 1,
      "prepknow_description": "Test Preprocessing Knowledge",
      "input_types": {'text': 1},
      "output_types": {'text': 1},
      "prepknow_languages": [],
      "prepknow_tags": [],
      "user_groups": [],
      "agent_groups": []
    },
    {
      "prepknow_id": "test_prepknow_2",
      "prepknow_traceid": "test_prepknow_2",
      "prepknow_version": 1,
      "prepknow_name": "test_prepknow_2",
      "creator_id": "system",
      "creator_name": "system",
      "prepknow_group": "default",
      "prepknow_type": "general",
      "prepknow_location": "default",
      "prepknow_status": 1,
      "prepknow_permission": 1,
      "prepknow_management": 10,
      "prepknow_layout_func": {"PDF": "FAKE"},
      "prepknow_parameters": {},
      "prepknow_secrets": {},
      "prepknow_inputs": {},
      "prepknow_outputs": {},
      "prepknow_retry": {},
      "prepknow_termination":{'max_retry': 3},
      "prepknow_key": "",
      "prepknow_timeout": 300,
      "input_format": "",
      "output_format": "",
      "prepmedia_selection": "default",
      "prepmedia_ids": {"test_prepmedia_text_1": 1, "test_prepmedia_image_1": 1,  "test_prepmedia_table_1": 1, "test_prepmedia_document_1": 1},
      "prepknow_complexity": 1,
      "prepknow_use_gpu": False,
      "prepknow_instance_num": 1,
      "prepknow_description": "Test Preprocessing Knowledge",
      "input_types": {'text': 1},
      "output_types": {'text': 1},
      "prepknow_languages": [],
      "prepknow_tags": [],
      "user_groups": [],
      "agent_groups": []
    }
]