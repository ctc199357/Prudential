from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.preptool_data import (
        DataManager as PrepToolDataManager,
        SystemDataRequest as SystemPrepToolRequest, 
        SystemDataResponse as SystemPrepToolResponse,
        DataBackupRequest as PrepToolBackupRequest, 
        DataBackupListRequest as PrepToolBackupListRequest,
        DataBackupListResponse as PrepToolBackupListResponse,
        DBRestoreRequest as PrepToolRestoreRequest,
        DataImportRequest as PrepToolImportRequest,
        DataExportRequest as PrepToolExportRequest,
        get_db_api
    )

from ...database.registry.services.prepmedia_data import (
        DataManager as PrepMediaDataManager,
        SystemDataRequest as SystemPrepMediaRequest, 
        SystemDataResponse as SystemPrepMediaResponse,
        DataBackupRequest as PrepMediaBackupRequest, 
        DataBackupListRequest as PrepMediaBackupListRequest,
        DataBackupListResponse as PrepMediaBackupListResponse,
        DBRestoreRequest as PrepMediaRestoreRequest,
        DataImportRequest as PrepMediaImportRequest,
        DataExportRequest as PrepMediaExportRequest,
    )

from ...database.registry.services.prepknow_data import (
        DataManager as PrepKnowDataManager,
        SystemDataRequest as SystemPrepKnowRequest, 
        SystemDataResponse as SystemPrepKnowResponse,
        DataBackupRequest as PrepKnowBackupRequest, 
        DataBackupListRequest as PrepKnowBackupListRequest,
        DataBackupListResponse as PrepKnowBackupListResponse,
        DBRestoreRequest as PrepKnowRestoreRequest,
        DataImportRequest as PrepKnowImportRequest,
        DataExportRequest as PrepKnowExportRequest,
    )

router = APIRouter(tags=["Registry-Admin"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


"""
    System - PrepTool
"""
@router.post("/system/preptool/query", status_code=status.HTTP_200_OK, response_model=SystemPrepToolResponse)
def system_query_preptool(request: SystemPrepToolRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> SystemPrepToolResponse:
    request = SystemPrepToolRequest(**request.__dict__)
    response_data, response = PrepToolDataManager(db_api=db_api, api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/preptool/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_preptool(db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    System - PrepMedia
"""
@router.post("/system/prepmedia/query", status_code=status.HTTP_200_OK, response_model=SystemPrepMediaResponse)
def system_query_prepmedia(request: SystemPrepMediaRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> SystemPrepMediaResponse:
    request = SystemPrepMediaRequest(**request.__dict__)
    response_data, response = PrepMediaDataManager(db_api=db_api, api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/prepmedia/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_prepmedia(db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    System - PrepKnow
"""
@router.post("/system/prepknow/query", status_code=status.HTTP_200_OK, response_model=SystemPrepKnowResponse)
def system_query_prepknow(request: SystemPrepKnowRequest, api_call: bool=default_api_call) -> SystemPrepKnowResponse:
    request = SystemPrepKnowRequest(**request.__dict__)
    response_data, response = PrepKnowDataManager(api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/prepknow/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_prepknow(api_call: bool=default_api_call) -> Response:
    response = PrepKnowDataManager(api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response