from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.preptool_data import (
        DataManager as PrepToolDataManager,
        UserDataRequest as UserPrepToolRequest, 
        UserDataResponse as UserPrepToolResponse,
        get_db_api
    )

from ...database.registry.services.prepmedia_data import (
        DataManager as PrepMediaDataManager,
        UserDataRequest as UserPrepMediaRequest, 
        UserDataResponse as UserPrepMediaResponse,
    )

from ...database.registry.services.prepknow_data import (
        DataManager as PrepKnowDataManager,
        UserDataRequest as UserPrepKnowRequest, 
        UserDataResponse as UserPrepKnowResponse,
    )

router = APIRouter(tags=["Registry-User"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False

"""
    User - PrepTool
"""
@router.post("/user/preptool/query", status_code=status.HTTP_200_OK, response_model=UserPrepToolResponse)
def user_query_preptool(request: UserPrepToolRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> UserPrepToolResponse:
    request = UserPrepToolRequest(**request.__dict__)
    response_data, response = PrepToolDataManager(db_api=db_api, api_call=api_call).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

""" 
    User - PrepMedia
"""
@router.post("/user/prepmedia/query", status_code=status.HTTP_200_OK, response_model=UserPrepMediaResponse)
def user_query_prepmedia(request: UserPrepMediaRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> UserPrepMediaResponse:
    request = UserPrepMediaRequest(**request.__dict__)
    response_data, response = PrepMediaDataManager(db_api=db_api, api_call=api_call).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

"""
    User - PrepKnow
"""
@router.post("/user/prepknow/query", status_code=status.HTTP_200_OK, response_model=UserPrepKnowResponse)
def user_query_prepknow(request: UserPrepKnowRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> UserPrepKnowResponse:
    request = UserPrepKnowRequest(**request.__dict__)
    response_data, response = PrepKnowDataManager(db_api=db_api, api_call=api_call).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data