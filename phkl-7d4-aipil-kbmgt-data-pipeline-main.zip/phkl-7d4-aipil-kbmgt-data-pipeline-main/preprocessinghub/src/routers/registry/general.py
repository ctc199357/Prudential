from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.preptool_data import (
        DataManager as PrepToolDataManager,
        CreateRequest as PrepToolCreateRequest, 
        BatchCreateRequest as PrepToolBatchCreateRequest,
        UpdateRequest as PrepToolUpdateRequest, 
        CommonRequest as PrepToolRequest,
        BatchCommonRequest as PrepToolBatchRequest,
        get_db_api
    )

from ...database.registry.services.prepmedia_data import (
        DataManager as PrepMediaDataManager,
        CreateRequest as PrepMediaCreateRequest, 
        BatchCreateRequest as PrepMediaBatchCreateRequest,
        UpdateRequest as PrepMediaUpdateRequest, 
        CommonRequest as PrepMediaRequest,
        BatchCommonRequest as PrepMediaBatchRequest
    )

from ...database.registry.services.prepknow_data import (
        DataManager as PrepKnowDataManager,
        CreateRequest as PrepKnowCreateRequest, 
        BatchCreateRequest as PrepKnowBatchCreateRequest,
        UpdateRequest as PrepKnowUpdateRequest, 
        CommonRequest as PrepKnowRequest,
        BatchCommonRequest as PrepKnowBatchRequest
    )

router = APIRouter(tags=["Registry-General"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


"""
    General - Tool
"""
@router.post("/general/preptool/single/create", status_code=status.HTTP_201_CREATED)
def general_create_preptool(request: PrepToolCreateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolCreateRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/preptool/single/update", status_code=status.HTTP_200_OK)
def general_update_preptool(request: PrepToolUpdateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolUpdateRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/preptool/single/delete", status_code=status.HTTP_200_OK)
def general_delete_preptool(request: PrepToolRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/preptool/single/drop", status_code=status.HTTP_200_OK)
def general_drop_preptool(request: PrepToolRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/preptool/single/activate", status_code=status.HTTP_200_OK)
def general_activate_preptool(request: PrepToolRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/preptool/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_preptool(request: PrepToolRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/preptool/batch/create", status_code=status.HTTP_201_CREATED)
def general_batch_create_preptool(request: PrepToolBatchCreateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolBatchCreateRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/preptool/batch/delete", status_code=status.HTTP_200_OK)
def general_batch_delete_preptool(request: PrepToolBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolBatchRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/preptool/batch/drop", status_code=status.HTTP_200_OK)
def general_batch_drop_preptool(request: PrepToolBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolBatchRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/preptool/batch/activate", status_code=status.HTTP_200_OK)
def general_batch_activate_preptool(request: PrepToolBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolBatchRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/preptool/batch/deactivate", status_code=status.HTTP_200_OK)
def general_batch_deactivate_preptool(request: PrepToolBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepToolBatchRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response


""" 
    General - PrepMedia
"""
@router.post("/general/prepmedia/single/create", status_code=status.HTTP_201_CREATED)
def general_create_prepmedia(request: PrepMediaCreateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaCreateRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/prepmedia/single/update", status_code=status.HTTP_200_OK)
def general_update_prepmedia(request: PrepMediaUpdateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaUpdateRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/prepmedia/single/delete", status_code=status.HTTP_200_OK)
def general_delete_prepmedia(request: PrepMediaRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/prepmedia/single/drop", status_code=status.HTTP_200_OK)
def general_drop_prepmedia(request: PrepMediaRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepmedia/single/activate", status_code=status.HTTP_200_OK)
def general_activate_prepmedia(request: PrepMediaRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepmedia/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_prepmedia(request: PrepMediaRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepmedia/batch/create", status_code=status.HTTP_201_CREATED)
def general_batch_create_prepmedia(request: PrepMediaBatchCreateRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaBatchCreateRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/prepmedia/batch/delete", status_code=status.HTTP_200_OK)
def general_batch_delete_prepmedia(request: PrepMediaBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaBatchRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/prepmedia/batch/drop", status_code=status.HTTP_200_OK)
def general_batch_drop_prepmedia(request: PrepMediaBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaBatchRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepmedia/batch/activate", status_code=status.HTTP_200_OK)
def general_batch_activate_prepmedia(request: PrepMediaBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaBatchRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepmedia/batch/deactivate", status_code=status.HTTP_200_OK)
def general_batch_deactivate_prepmedia(request: PrepMediaBatchRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request = PrepMediaBatchRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response


""" 
    General - PrepKnow
"""
@router.post("/general/prepknow/single/create", status_code=status.HTTP_201_CREATED)
def general_create_prepknow(request: PrepKnowCreateRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowCreateRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/prepknow/single/update", status_code=status.HTTP_200_OK)
def general_update_prepknow(request: PrepKnowUpdateRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowUpdateRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/prepknow/single/delete", status_code=status.HTTP_200_OK)
def general_delete_prepknow(request: PrepKnowRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/prepknow/single/drop", status_code=status.HTTP_200_OK)
def general_drop_prepknow(request: PrepKnowRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepknow/single/activate", status_code=status.HTTP_200_OK)
def general_activate_prepknow(request: PrepKnowRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepknow/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_prepknow(request: PrepKnowRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepknow/batch/create", status_code=status.HTTP_201_CREATED)
def general_batch_create_prepknow(request: PrepKnowBatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowBatchCreateRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/prepknow/batch/delete", status_code=status.HTTP_200_OK)
def general_batch_delete_prepknow(request: PrepKnowBatchRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowBatchRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/prepknow/batch/drop", status_code=status.HTTP_200_OK)
def general_batch_drop_prepknow(request: PrepKnowBatchRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowBatchRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepknow/batch/activate", status_code=status.HTTP_200_OK)
def general_batch_activate_prepknow(request: PrepKnowBatchRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowBatchRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/prepknow/batch/deactivate", status_code=status.HTTP_200_OK)
def general_batch_deactivate_prepknow(request: PrepKnowBatchRequest, api_call: bool=default_api_call) -> Response:
    request = PrepKnowBatchRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response