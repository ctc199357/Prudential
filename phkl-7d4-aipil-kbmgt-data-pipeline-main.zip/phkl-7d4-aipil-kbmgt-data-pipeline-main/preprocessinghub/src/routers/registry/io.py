from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.preptool_data import (
        DataManager as PrepToolDataManager,
        SystemDataRequest as SystemPrepToolRequest, 
        SystemDataResponse as SystemPrepToolResponse,
        DataBackupRequest as PrepToolBackupRequest, 
        DataBackupListRequest as PrepToolBackupListRequest,
        DataBackupListResponse as PrepToolBackupListResponse,
        DBRestoreRequest as PrepToolRestoreRequest,
        DataImportRequest as PrepToolImportRequest,
        DataExportRequest as PrepToolExportRequest,
        get_db_api
    )

from ...database.registry.services.prepmedia_data import (
        DataManager as PrepMediaDataManager,
        SystemDataRequest as SystemPrepMediaRequest, 
        SystemDataResponse as SystemPrepMediaResponse,
        DataBackupRequest as PrepMediaBackupRequest, 
        DataBackupListRequest as PrepMediaBackupListRequest,
        DataBackupListResponse as PrepMediaBackupListResponse,
        DBRestoreRequest as PrepMediaRestoreRequest,
        DataImportRequest as PrepMediaImportRequest,
        DataExportRequest as PrepMediaExportRequest,
    )

from ...database.registry.services.prepknow_data import (
        DataManager as PrepKnowDataManager,
        SystemDataRequest as SystemPrepKnowRequest, 
        SystemDataResponse as SystemPrepKnowResponse,
        DataBackupRequest as PrepKnowBackupRequest, 
        DataBackupListRequest as PrepKnowBackupListRequest,
        DataBackupListResponse as PrepKnowBackupListResponse,
        DBRestoreRequest as PrepKnowRestoreRequest,
        DataImportRequest as PrepKnowImportRequest,
        DataExportRequest as PrepKnowExportRequest,
    )

router = APIRouter(tags=["Registry-IO"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


"""
    System - PrepTool
"""
@router.post("/system/preptool/export", status_code=status.HTTP_200_OK)
def system_export_preptool(request: PrepToolExportRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = PrepToolExportRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/preptool/import", status_code=status.HTTP_200_OK)
def system_import_preptool(request: PrepToolImportRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = PrepToolImportRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/preptool/backup", status_code=status.HTTP_200_OK)
def system_backup_preptool(request: PrepToolBackupRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = PrepToolBackupRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/preptool/backup/list", status_code=status.HTTP_200_OK, response_model=PrepToolBackupListResponse)
def system_backup_list_preptool(request: PrepToolBackupListRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> PrepToolBackupListResponse:
    request  = PrepToolBackupListRequest(**request.__dict__)
    response_table, response = PrepToolDataManager(db_api=db_api, api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/system/preptool/restore/backup", status_code=status.HTTP_200_OK)
def system_restore_backup_preptool(request: PrepToolRestoreRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = PrepToolRestoreRequest(**request.__dict__)
    response = PrepToolDataManager(db_api=db_api, api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    System - PrepMedia
"""
@router.post("/system/prepmedia/export", status_code=status.HTTP_200_OK)
def system_export_prepmedia(request: PrepMediaExportRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = PrepMediaExportRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/prepmedia/import", status_code=status.HTTP_200_OK)
def system_import_prepmedia(request: PrepMediaImportRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = PrepMediaImportRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/prepmedia/backup", status_code=status.HTTP_200_OK)
def system_backup_prepmedia(request: PrepMediaBackupRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = PrepMediaBackupRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/prepmedia/backup/list", status_code=status.HTTP_200_OK, response_model=PrepMediaBackupListResponse)
def system_backup_list_prepmedia(request: PrepMediaBackupListRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> PrepMediaBackupListResponse:
    request  = PrepMediaBackupListRequest(**request.__dict__)
    response_table, response = PrepMediaDataManager(db_api=db_api, api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/system/prepmedia/restore/backup", status_code=status.HTTP_200_OK)
def system_restore_backup_prepmedia(request: PrepMediaRestoreRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = PrepMediaRestoreRequest(**request.__dict__)
    response = PrepMediaDataManager(db_api=db_api, api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

"""
    System - PrepKnow
"""
@router.post("/system/prepknow/export", status_code=status.HTTP_200_OK)
def system_export_prepknow(request: PrepKnowExportRequest, api_call: bool=default_api_call) -> Response:
    request  = PrepKnowExportRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/prepknow/import", status_code=status.HTTP_200_OK)
def system_import_prepknow(request: PrepKnowImportRequest, api_call: bool=default_api_call) -> Response:
    request  = PrepKnowImportRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/prepknow/backup", status_code=status.HTTP_200_OK)
def system_backup_prepknow(request: PrepKnowBackupRequest, api_call: bool=default_api_call) -> Response:
    request  = PrepKnowBackupRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/prepknow/backup/list", status_code=status.HTTP_200_OK, response_model=PrepKnowBackupListResponse)
def system_backup_list_prepknow(request: PrepKnowBackupListRequest, api_call: bool=default_api_call) -> PrepKnowBackupListResponse:
    request  = PrepKnowBackupListRequest(**request.__dict__)
    response_table, response = PrepKnowDataManager(api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/system/prepknow/restore/backup", status_code=status.HTTP_200_OK)
def system_restore_backup_prepknow(request: PrepKnowRestoreRequest, api_call: bool=default_api_call) -> Response:
    request  = PrepKnowRestoreRequest(**request.__dict__)
    response = PrepKnowDataManager(api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response