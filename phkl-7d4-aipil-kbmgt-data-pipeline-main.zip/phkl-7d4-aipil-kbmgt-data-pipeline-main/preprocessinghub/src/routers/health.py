from fastapi import APIRouter
from ..schemas.format import Health

router = APIRouter(tags=["Health"])

@router.get("/", status_code=200)
def index():
    """
    For health check

    :return:
    """
    return {"domain": ""}


from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..settings import SETTINGS

from ..database.registry.connections.registry_connection import get_db_func, get_db_api
from ..schemas.format import Health
from ..services.health import HealthService

router = APIRouter(tags=["Health"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False

# Function DB Session
if SETTINGS.BASE.APP_FUNC == True:
    db_func = get_db_func
else:
    db_func = None
    

@router.get("/health/prompt", status_code=status.HTTP_200_OK, response_model=Health)
def health_check(db_api: Session = db_api, api_call: bool = default_api_call) -> Health:
    response_health = HealthService(db_api=db_api, db_func=db_func, api_call=api_call).health_check()
    if response_health.status_code >= SETTINGS.STAT.SUCC_CODE_END:
        _detail = [f"{key} : {value}" for key, value in response_health.__dict__.items() if '_reason' in key]
        detail  = '; '.join(_detail)

        if api_call == True:
            raise HTTPException(status_code=response_health.status_code, detail=detail)
        else:
            raise Exception(detail)
        
    return response_health