from fastapi import APIRouter, status

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..schemas.format import Response

from ..services.prepmedia_service import PrepMediaServiceManager

from ..schemas.prepknow import (
    PrepKnowInitRequest,
    PrepKnowInitResponse,
    PrepKnowPipelineRequest,
    PrepKnowPipelineResponse,
    LayoutAnalysisRequest,
    LayoutAnalysisResponse
    )

from ..services.prepknow_service import PrepKnowServiceManager

from ..schemas.prepmedia import (
    PrepMediaPipelineRequest,
    PrepMediaPipelineResponse,
)

from ..services.prepmedia_service import PrepMediaServiceManager

from ..services.layout_service import LayoutServiceManager

router = APIRouter(tags=["Request"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

"""
    Request - PrepTool
"""
# @router.post("/request/preptool/execute", status_code=status.HTTP_200_OK, response_model=LangInferencePrepToolResponse)
# def langrequest_get_preptool(request: LangInferencePrepToolRequest,  db_api: Session = db_api, api_call: bool = default_api_call) -> LangInferencePrepToolResponse:
#     response_preptool, response = PrepMediaServiceManager(api_call=api_call).prepmedia_execution(request=request)
#     router_response_handler(response=response, api_call=api_call)
#     return response_preptool

"""
    Request - PrepMedia
"""
@router.post("/request/prepmedia/execute", status_code=status.HTTP_200_OK, response_model=PrepMediaPipelineResponse)
def request_exec_prepmedia(request: PrepMediaPipelineRequest, api_call: bool = default_api_call) -> PrepMediaPipelineResponse:
    request = PrepMediaPipelineRequest(**request.__dict__)
    response_prepmedia, response = PrepMediaServiceManager(api_call=api_call).prepmedia_pipeline(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_prepmedia


"""
    Request - PrepKnow
"""
@router.post("/request/prepknow/init", status_code=status.HTTP_200_OK, response_model=PrepKnowInitResponse)
def request_init_prepknow(request: PrepKnowInitRequest, api_call: bool = default_api_call) -> PrepKnowInitResponse:
    request = PrepKnowInitRequest(**request.__dict__)
    response_prepknow, response = PrepKnowServiceManager(api_call=api_call).prepknow_init(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_prepknow

@router.post("/request/prepknow/execute", status_code=status.HTTP_200_OK, response_model=PrepKnowPipelineResponse)
def request_exec_prepknow(request: PrepKnowPipelineRequest, api_call: bool = default_api_call) -> PrepKnowPipelineResponse:
    request = PrepKnowPipelineRequest(**request.__dict__)
    response_prepknow, response = PrepKnowServiceManager(api_call=api_call).prepknow_pipeline(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_prepknow

"""
    Request - Layout Analysis
"""
@router.post("/request/layout/analysis", status_code=status.HTTP_200_OK, response_model=LayoutAnalysisResponse)
def request_anly_layout(request: LayoutAnalysisRequest, api_call: bool = default_api_call) -> LayoutAnalysisResponse:
    request = LayoutAnalysisRequest(**request.__dict__)
    response_prepknow, response = LayoutServiceManager(api_call=api_call).default_analysis(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_prepknow

"""
    Request - Process relationship
"""
@router.post("/request/relationship/execute", status_code=status.HTTP_200_OK, response_model=PrepMediaPipelineResponse)
def request_exec_relationship(request: PrepMediaPipelineRequest, api_call: bool = default_api_call) -> PrepMediaPipelineResponse:
    request = PrepMediaPipelineRequest(**request.__dict__)
    response_prepknow, response = PrepMediaServiceManager(api_call=api_call).prepmedia_pipeline(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_prepknow