import os
from typing import List, NamedTuple
from pydantic import BaseSettings, validator
import json

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
SERVICE_DIR = os.path.dirname(CURRENT_DIR)
PROJECT_DIR = os.path.dirname(SERVICE_DIR)
SETTING_FILE_ENCODING = 'utf-8'
SETTING_FILE_AKS = os.path.join(PROJECT_DIR, 'knowledgehub', 'src', 'config', 'aks.env')

# Load Global Config File if Any
GLOBAL_SETTING_KEY = 'share_'
GLOBAL_LOGGING_KEY = 'log_'
GLOBAL_BACKUP_KEY  = 'backup_'
GLOBAL_EXPORT_KEY  = 'export_'

# Load App Setting File
SETTING_FILE = os.path.join(SERVICE_DIR, 'src', 'config', 'settings.env')

# Load Default DB Template if Any
INIT_DB_FILE = os.path.join(SERVICE_DIR, 'src', 'config', 'init_config.py')

# Load Global Setting File (will override local app setting)
GLOBAL_SETTING_FILE = os.path.join(PROJECT_DIR, 'config', 'settings.json')


def read_file_to_dict(file_path: str) -> dict:
    try:
        if not file_path.startswith("/"):
            # load secret from local path
            file_path = os.path.join(PROJECT_DIR, "files", file_path)
            
        if os.path.isfile(file_path) and os.path.exists(file_path):
            with open(file_path, "r") as file:
                data_dict = json.load(file)
                return data_dict
    except Exception as e:
            raise IOError(f"Error reading file: {str(e)}")

def read_string_to_dict(input_str: str) -> dict:
    try:
        if not input_str or input_str.strip() == "{}":
            return {}
        return json.loads(input_str)
    except Exception as e:
        return {}
        
class AppSettings(BaseSettings):
    APP_NAME:        str
    APP_HOST:        str = ''
    APP_PORT:        int = ''
    APP_INIT_CHECK:  bool = True
    APP_API:         bool = False
    APP_FUNC:        bool = False
    APP_TIMEOUT:     float = 60.0
    APP_VER:         str = 'v1.0'
    APP_STANDALONE:  bool = True
    APP_PRODUCTION:  bool = False
    APP_ENCRYPTION:  bool = False
    ORIGINS:         List[str] = ["*"]
    ENDPOINT_PREFIX: str = "/api"

    class Config:
        env_file = SETTING_FILE
        env_prefix = ''
        env_file_encoding = SETTING_FILE_ENCODING


class ConstraintSettings(BaseSettings):
    NAMING:          list[str]
    VALID_PARAM_KEY: list[str]
    VALID_PARAM_VAL: list[str]
    ADMIN_PARAM_KEY: list[str]

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'CSTR_'
        env_file_encoding = SETTING_FILE_ENCODING


class DatabaseSettings(BaseSettings):
    DB_FORM:        list = ["SLDB", "PGDB", "MODB"]
    FORM:           str
    LOCA:           str
    NAME:           str # DB Name
    HOST:           str # DB Host 
    PORT:           str # DB Port
    USER:           str # DB User
    PSWD:           str # DB Pswd
    RDIR:           str # DB Root
    SDIR:           str # DB Dir
    PREPTOOL_TABLE: str
    PREPMDIA_TABLE: str
    PREPKNOW_TABLE: str
    SEP:            str # Separator for converting list to string in db
    
    ### TODO: Should update to field_validator('RDIR', 'SDIR', mode='before')
    @validator('RDIR', 'SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_SETTING_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")

        return value

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'PP_DATB_'
        env_file_encoding = SETTING_FILE_ENCODING

class BackupSettings(BaseSettings):
    DB_FORM:        list[str] = ['SLDB', 'PGDB']
    FORM:           str       = 'SLDB'
    LOCA:           str       = 'local'
    NAME:           str       = 'test_backup' # DB Name
    HOST:           str       = '' # DB Host 
    PORT:           str       = '' # DB Port
    USER:           str       = '' # DB User
    PSWD:           str       = '' # DB Pswd
    RDIR:           str       = SERVICE_DIR # DB Root
    SDIR:           str       = 'sldb_backup' # DB Dir
    PREPTOOL_TABLE: str       = 'preptool'
    PREPMDIA_TABLE: str       = 'prepmedia'
    PREPKNOW_TABLE: str       = 'prepknow'
    LIMIT:          int       = 100 # Backup Number
    
    ### TODO: Should update to field_validator('RDIR', 'SDIR', mode='before')
    @validator('RDIR', 'SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_BACKUP_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")

        return value
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'BKUP_'
        env_file_encoding = SETTING_FILE_ENCODING


class ImportSettings(BaseSettings):
    DB_FORM:   list[str] = ['SLDB', 'PGDB']
    FILE_FORM: list[str] = ['JSON', 'CSV']
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'IMPT_'
        env_file_encoding = SETTING_FILE_ENCODING


class ExportSettings(BaseSettings):
    DB_FORM:            list[str] = ['SLDB', 'PGDB']
    FILE_FORM:          list[str] = ['JSON', 'CSV']
    FORM:               str       = 'JSON'
    LOCA:               str       = 'local'
    NAME:               str       = 'test_export'
    HOST:               str       = ''
    PORT:               str       = ''
    USER:               str       = ''
    PSWD:               str       = ''
    PREPTOOL_TABLE:     str       = 'preptool'
    PREPMDIA_TABLE:     str       = 'prepmedia'
    PREPKNOW_TABLE:     str       = 'prepknow'
    RDIR:               str       = SERVICE_DIR
    SDIR:               str       = 'sldb_backup'
    FILE_RDIR:          str       = SERVICE_DIR
    FILE_SDIR:          str       = 'export'
    PREPTOOL_FILE_NAME: str       = 'preptool'
    PREPMDIA_FILE_NAME: str       = 'prepmedia'
    PREPKNOW_FILE_NAME: str       = 'prepknow'

    # @field_validator('TAG_RDIR', 'TAG_SDIR', mode='before')
    @validator('RDIR', 'SDIR', 'FILE_RDIR', 'FILE_SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_EXPORT_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")

        return value
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'EXPT_'
        env_file_encoding = SETTING_FILE_ENCODING


class PreprocessingSettings(BaseSettings):
    EMBEDDING_ENGINE_TIMEOUT: float

    STORAGE_TEMP_INIT:        bool

    STORAGE_TEMP_FORM:        str
    STORAGE_TEMP_LOCA:        str
    STORAGE_TEMP_HOST:        str
    STORAGE_TEMP_PORT:        str
    STORAGE_TEMP_SCRT:        dict
    STORAGE_TEMP_RDIR:        str
    STORAGE_TEMP_SDIR:        str

    STORAGE_PERM_FORM:        str
    STORAGE_PERM_LOCA:        str
    STORAGE_PERM_HOST:        str
    STORAGE_PERM_PORT:        str
    STORAGE_PERM_SCRT:        dict
    STORAGE_PERM_RDIR:        str
    STORAGE_PERM_SDIR:        str

    ### TODO: Should update to field_validator('RDIR', 'SDIR', mode='before')
    @validator('STORAGE_TEMP_RDIR', 'STORAGE_TEMP_SDIR', 'STORAGE_PERM_RDIR', 'STORAGE_PERM_SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_SETTING_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")

        return value

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'PREP_'
        env_file_encoding = SETTING_FILE_ENCODING


class PrepKnowledgeSettings(BaseSettings):
    STATUS_CODE:                 dict
    SYSTEM_PREPKNOW_TERMINATION: dict
    FILE_EXTENSION:              dict
    MEDIA_SNAPSHOT:              bool
    IMAGE_EXTENSION:             str
    IMAGE_RESOLUTION:            int
    TABLE_EXTENSION:             str
    TABLE_RESOLUTION:            int
    MAX_TOKEN_LIMIT:             int

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'PRKW_'
        env_file_encoding = SETTING_FILE_ENCODING

class PrepMediaSettings(BaseSettings):
    STATUS_CODE: dict
    SYSTEM_PREPMDIA_TERMINATION: dict

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'PRMD_'
        env_file_encoding = SETTING_FILE_ENCODING

class PrepToolSettings(BaseSettings):
    STATUS_CODE:              dict
    FILE_EXTENSION:           dict
    EMBEDDING_TIMEOUT:        float=60.0
    GENAI_TIMEOUT:            float=60.0
    DEFAULT_CHUNK_CONFIG:     dict
    MODLE_INPUT_TOKEN_LIMIT:  int=100000
    MODLE_OUTPUT_TOKEN_LIMIT: int=40
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'PRTL_'
        env_file_encoding = SETTING_FILE_ENCODING

class UserHubSettings(BaseSettings):
    HOST:                       str
    PORT:                       str
    INTERACTION_REQUEST_API:    str
    INTERACTION_REQUEST_MODULE: str
    INTERACTION_REQUEST_FUNC:   str
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'USER_'
        env_file_encoding = SETTING_FILE_ENCODING

class SecurityHubSettings(BaseSettings):
    HOST:                      str
    PORT:                      str
    REQUEST_USERKEY_API:       str
    REQUEST_USERKEY_MODULE:    str
    REQUEST_USERKEY_FUNC:      str
    KEYVAULT_KEY_AGNT_TRANSIT: bytes
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'SCRT_'
        env_file_encoding = SETTING_FILE_ENCODING


class LoggerSettings(BaseSettings):
    DB_FORM:   list = ['SLDB', 'PGDB']
    FORM:      str  = 'SLDB'
    LOCA:      str  = 'local'
    NAME:      str  = 'test_log'
    HOST:      str  = ''
    PORT:      str  = ''
    USER:      str  = ''
    PSWD:      str  = ''
    RDIR:      str  = SERVICE_DIR
    SDIR:      str  = 'log'
    TABLE:     str  = 'app_log'
    LIMIT:     int  = 10000
    FILE_RDIR: str  = SERVICE_DIR
    FILE_SDIR: str  = 'log'
    FILE_NAME: str  = 'app.log'
    FILE_BYTE: int  = 1000000 # Backup file maximum bytes
    FILE_NUM:  int  = 2 # Backup file number
    SAVE_DB:   bool = False
    SAVE_FILE: bool = False
    LEVEL:     str  = 'INFO'

    ### TODO: Should update to field_validator('RDIR', 'SDIR', mode='before')
    @validator('RDIR', 'SDIR', 'FILE_RDIR', 'FILE_SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_LOGGING_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")
            
        return value
        
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'LOG_'
        env_file_encoding = SETTING_FILE_ENCODING


class StatusSettings(BaseSettings):
    INFO_CODE_START:    int = 100
    INFO_CODE_END:      int = 200
    SUCC_CODE_START:    int = 200
    SUCC_CODE_END:      int = 300
    REDIR_CODE_START:   int = 300
    REDIR_CODE_END:     int = 400
    CLIENT_CODE_START:  int = 400
    CLIENT_CODE_END:    int = 500
    SERERR_CODE_START:  int = 500
    SERERR_CODE_END:    int = 600    

class GenAISettings(BaseSettings):
    MODEL_ID:         str
    MODEL_VERSION:    int
    MODEL_NAME:       str
    MODEL_TYPE:       str
    MODEL_CLUSTER:    str
    MODEL_LOCATION:   str
    MODEL_HOST:       str
    MODEL_PORT:       str
    MODEL_API:        str
    MODEL_ENGINE:     str
    MODEL_BASE:       str
    MODEL_PARAMETERS: dict = {}
    MODEL_PARAMETERS_STR: str
    MODEL_SECRETS:    dict = {}
    MODEL_SECRETS_PATH: str
    MODEL_SECRETS_KEY_NAME: str
    MODEL_SECRETS_KEY_VALUE: str
    MODEL_SECRETS_API_VERSION: str
    MODEL_SECRETS_REGION: str
    MODEL_KEY:        str
    MODEL_TIMEOUT:    int

    EMBED_ID:         str
    EMBED_HOST:       str
    EMBED_PORT:       str
    EMBED_API:        str
    EMBED_LOCATION:   str
    EMBED_ENGINE:     str
    EMBED_BASE:       str
    EMBED_MODEL:      str
    EMBED_PARAMETERS: dict = {}
    EMBED_PARAMETERS_STR: str
    EMBED_SECRETS:    dict = {}
    EMBED_SECRETS_PATH: str
    EMBED_SECRETS_KEY_NAME: str
    EMBED_SECRETS_KEY_VALUE: str
    EMBED_SECRETS_API_VERSION: str
    EMBED_SECRETS_REGION: str
    EMBED_KEY:        str
    EMBED_TIMEOUT:    int

    KEYWD_ID:         str
    KEYWD_HOST:       str
    KEYWD_PORT:       str
    KEYWD_API:        str
    KEYWD_LOCATION:   str
    KEYWD_ENGINE:     str
    KEYWD_BASE:       str
    KEYWD_MODEL:      str
    KEYWD_PARAMETERS: dict = {}
    KEYWD_PARAMETERS_STR: str
    KEYWD_SECRETS:    dict = {}
    KEYWD_KEY: str = ""
    KEYWD_KEY_PATH: str 
    KEYWD_KEY_NAME:   str
    KEYWD_TIMEOUT:    int
    KEYWD_RETRY:      int

    VISION_ID:         str
    VISION_HOST:       str
    VISION_PORT:       str
    VISION_API:        str
    VISION_LOCATION:   str
    VISION_ENGINE:     str
    VISION_BASE:       str
    VISION_MODEL:      str
    VISION_PARAMETERS: dict = {}
    VISION_PARAMETERS_STR: str
    VISION_SECRETS:    dict = {}
    VISION_KEY:        str = ""
    VISION_KEY_PATH:   str
    VISION_KEY_NAME:   str
    VISION_TIMEOUT:    int

    INFERENCE_INTERVAL: int=1
    MODEL_TOKEN_LIMIT: int=128000

    def __init__(self, **args):
        super().__init__(**args)

        self.MODEL_PARAMETERS = read_string_to_dict(self.MODEL_PARAMETERS_STR)
        self.EMBED_PARAMETERS = read_string_to_dict(self.EMBED_PARAMETERS_STR)
        self.KEYWD_PARAMETERS = read_string_to_dict(self.KEYWD_PARAMETERS_STR)

        self.MODEL_SECRETS = {
            "header": {"x-api-key": None, "app-id": None},
            "api_version": self.MODEL_SECRETS_API_VERSION,
        }
        model_dict = read_file_to_dict(self.MODEL_SECRETS_PATH)
        self.MODEL_SECRETS["header"]["app-id"] = model_dict[self.MODEL_SECRETS_KEY_NAME]
        self.MODEL_SECRETS["header"]["x-api-key"] = model_dict[self.MODEL_SECRETS_KEY_VALUE]
        if self.MODEL_SECRETS_REGION != "":
            self.MODEL_SECRETS["header"]["x-ms-region"] = self.MODEL_SECRETS_REGION
            
        self.EMBED_SECRETS = {  
            "header": {"x-api-key": None, "app-id": None},
            "api_version": self.EMBED_SECRETS_API_VERSION,
        }
        embd_dict = read_file_to_dict(self.EMBED_SECRETS_PATH)
        self.EMBED_SECRETS["header"]["app-id"] = embd_dict[self.EMBED_SECRETS_KEY_NAME]
        self.EMBED_SECRETS["header"]["x-api-key"] = embd_dict[self.EMBED_SECRETS_KEY_VALUE]
        if self.EMBED_SECRETS_REGION != "":
            self.EMBED_SECRETS["header"]["x-ms-region"] = self.EMBED_SECRETS_REGION

        cog_dict = read_file_to_dict(self.KEYWD_KEY_PATH)
        self.KEYWD_KEY = cog_dict[self.KEYWD_KEY_NAME]

        self.KEYWD_SECRETS = {
            "api_key": self.KEYWD_KEY,
        }

        cog_dict = read_file_to_dict(self.VISION_KEY_PATH)
        self.VISION_KEY = cog_dict[self.VISION_KEY_NAME]

        self.VISION_SECRETS = {
            "api_key": self.VISION_KEY,
        }

    class Config:
        env_file = SETTING_FILE_AKS
        env_prefix = 'GEAI_'
        env_file_encoding = SETTING_FILE_ENCODING

class BlobStorageSettings(BaseSettings):
    CONNECTION_STRING: str = ""
    CONNECTION_STRING_PREFIX: str
    KEY_PATH: str
    KEY_NAME: str
    ACCOUNT_NAME: str
    CONTAINER_NAME: str
    FOLDER_NAME: str
    PASRER_FOLDER_NAME: str
    KEY: str

    def __init__(self, **args):
        super().__init__(**args)
        secret_dict = read_file_to_dict(self.KEY_PATH)
        #self.CONNECTION_STRING = f"{self.CONNECTION_STRING_PREFIX}AccountName={self.ACCOUNT_NAME};AccountKey={secret_dict[self.KEY_NAME]};"
        self.CONNECTION_STRING = f"{self.CONNECTION_STRING_PREFIX}AccountName={self.ACCOUNT_NAME};AccountKey={self.KEY};"
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'BLOB_'
        env_file_encoding = SETTING_FILE_ENCODING


class PDFExtractionSettings(BaseSettings):
    HOST: str
    PORT: int
    TIMEOUT: float
    RETRY: int
    MAX_DURATION: int
    POLL_INTERVAL: int
    REQUEST_CREATE_API: str
    REQUEST_STATUS_API: str

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'PDFEXT_'
        env_file_encoding = SETTING_FILE_ENCODING


class Config(NamedTuple):
    BASE: AppSettings = AppSettings()
    CSTR: ConstraintSettings = ConstraintSettings()
    DATB: DatabaseSettings = DatabaseSettings()
    BKUP: BackupSettings = BackupSettings()
    IMPT: ImportSettings = ImportSettings()
    EXPT: ExportSettings = ExportSettings()
    
    PREP: PreprocessingSettings = PreprocessingSettings()

    PRKW: PrepKnowledgeSettings = PrepKnowledgeSettings()
    PRMD: PrepMediaSettings = PrepMediaSettings()
    PRTL: PrepToolSettings = PrepToolSettings()
    
    USER: UserHubSettings = UserHubSettings()
    SCRT: SecurityHubSettings = SecurityHubSettings()

    LOG:  LoggerSettings = LoggerSettings()
    STAT: StatusSettings = StatusSettings()
    GEAI: GenAISettings = GenAISettings()
    BLOB: BlobStorageSettings = BlobStorageSettings()
    PDFEXT: PDFExtractionSettings = PDFExtractionSettings()

SETTINGS = Config()