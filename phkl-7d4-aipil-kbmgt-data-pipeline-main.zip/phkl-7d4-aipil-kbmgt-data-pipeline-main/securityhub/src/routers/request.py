from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..database.registry_connection import get_db_func, get_db_api

from ..schemas.userkey import (
    UserKeyGenRequest,
    UserKeyGenResponse,
    UserKeyRetrievalRequest,
    UserKeyRetrievalResponse
)

from ..schemas.security import (
    ServiceKeyGenRequest,
    ServiceKeyGenResponse
)

from ..services.userkey_service import UserKeyServiceManager

router = APIRouter(tags=["Request"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False

# Function DB Session
if SETTINGS.BASE.APP_FUNC == True:
    db_func = get_db_func
else:
    db_func = None


@router.post("/request/userkey/create", status_code=status.HTTP_200_OK, response_model=UserKeyGenResponse)
def request_create_userkey(request: UserKeyGenRequest, db_api: Session = db_api, api_call: bool = default_api_call) -> UserKeyGenResponse:
    request = UserKeyGenRequest(**request.__dict__)
    response_request, response = UserKeyServiceManager(db_api=db_api, api_call=api_call).create_userkey(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_request

@router.post("/request/service/create", status_code=status.HTTP_200_OK, response_model=ServiceKeyGenResponse)
def request_create_servicekey(request: ServiceKeyGenRequest, db_api: Session = db_api, api_call: bool = default_api_call) -> ServiceKeyGenResponse:
    request = ServiceKeyGenRequest(**request.__dict__)
    response_request, response = UserKeyServiceManager(db_api=db_api, api_call=api_call).create_servicekey(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_request

@router.post("/request/userkey/retrieve", status_code=status.HTTP_200_OK, response_model=UserKeyRetrievalResponse)
def request_retrieve_userkey(request: UserKeyRetrievalRequest, db_api: Session = db_api, api_call: bool = default_api_call) -> UserKeyRetrievalResponse:
    request = UserKeyRetrievalRequest(**request.__dict__)
    response_request, response = UserKeyServiceManager(db_api=db_api, api_call=api_call).retrieve_userkey(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_request
