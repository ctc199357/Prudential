from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.userkey_data import (
        DataManager as UserKeyDataManager,
        SystemDataRequest as SystemUserKeyRequest, 
        SystemDataResponse as SystemUserKeyResponse,
        DataBackupRequest as UserKeyBackupRequest, 
        DataBackupListRequest as UserKeyBackupListRequest,
        DataBackupListResponse as UserKeyBackupListResponse,
        DBRestoreRequest as UserKeyRestoreRequest,
        DataImportRequest as UserKeyImportRequest,
        DataExportRequest as UserKeyExportRequest,
        get_db_api
    )

router = APIRouter(tags=["Registry-IO"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


@router.post("/system/userkey/export", status_code=status.HTTP_200_OK)
def system_export_userkey(request: UserKeyExportRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = UserKeyExportRequest(**request.__dict__)
    response = UserKeyDataManager(db_api=db_api, api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/userkey/import", status_code=status.HTTP_200_OK)
def system_import_userkey(request: UserKeyImportRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = UserKeyImportRequest(**request.__dict__)
    response = UserKeyDataManager(db_api=db_api, api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/userkey/backup", status_code=status.HTTP_200_OK)
def system_backup_userkey(request: UserKeyBackupRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = UserKeyBackupRequest(**request.__dict__)
    response = UserKeyDataManager(db_api=db_api, api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/system/userkey/backup/list", status_code=status.HTTP_200_OK, response_model=UserKeyBackupListResponse)
def system_backup_list_userkey(request: UserKeyBackupListRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> UserKeyBackupListResponse:
    request = UserKeyBackupListRequest(**request.__dict__)
    response_table, response = UserKeyDataManager(db_api=db_api, api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/system/userkey/restore/backup", status_code=status.HTTP_200_OK)
def system_restore_backup_userkey(request: UserKeyRestoreRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    request  = UserKeyRestoreRequest(**request.__dict__)
    response = UserKeyDataManager(db_api=db_api, api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response