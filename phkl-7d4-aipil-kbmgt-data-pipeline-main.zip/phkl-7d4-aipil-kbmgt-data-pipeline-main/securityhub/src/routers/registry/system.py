from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.userkey_data import (
        DataManager as UserKeyDataManager,
        SystemDataRequest as SystemUserKeyRequest, 
        SystemDataResponse as SystemUserKeyResponse,
        DataBackupRequest as UserKeyBackupRequest, 
        DataBackupListRequest as UserKeyBackupListRequest,
        DataBackupListResponse as UserKeyBackupListResponse,
        DBRestoreRequest as UserKeyRestoreRequest,
        DataImportRequest as UserKeyImportRequest,
        DataExportRequest as UserKeyExportRequest,
        get_db_api
    )

router = APIRouter(tags=["Registry-Admin"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False


@router.post("/system/userkey/query", status_code=status.HTTP_200_OK, response_model=SystemUserKeyResponse)
def system_query_userkey(request: SystemUserKeyRequest, db_api: Any=db_api, api_call: bool=default_api_call) -> SystemUserKeyResponse:
    request = SystemUserKeyRequest(**request.__dict__)
    response_data, response = UserKeyDataManager(db_api=db_api, api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/userkey/drop/inactive", status_code=status.HTTP_200_OK)
def system_drop_inactive_userkey(db_api: Any=db_api, api_call: bool=default_api_call) -> Response:
    response = UserKeyDataManager(db_api=db_api, api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response


