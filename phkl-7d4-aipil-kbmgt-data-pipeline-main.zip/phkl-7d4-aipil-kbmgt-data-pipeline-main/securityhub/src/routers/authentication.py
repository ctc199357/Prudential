from fastapi import APIRouter, Depends, status

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..database.registry_connection import get_db_func, get_db_api

from ..schemas.authentication import (
    AzureAuthenticationRequest,
    AzureAuthenticationResponse,
    AzureTokenReuqest,
    AzureTokenResponse
)

from ..services.authentication_service import AuthenticationServiceManager

router = APIRouter(tags=["Request"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = Depends(get_db_api)
    default_api_call = True
else:
    db_api = None
    default_api_call = False

# Function DB Session
if SETTINGS.BASE.APP_FUNC == True:
    db_func = get_db_func
else:
    db_func = None


@router.post("/auth/azure/get_url", status_code=status.HTTP_200_OK, response_model=AzureAuthenticationResponse)
def auth_get_azure_auth_url(request: AzureAuthenticationRequest, api_call: bool = default_api_call) -> AzureAuthenticationResponse:
    request = AzureAuthenticationRequest(**request.__dict__)
    response_request, response = AuthenticationServiceManager(api_call=api_call).get_azure_authentication_url(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_request

@router.post("/auth/azure/get_token", status_code=status.HTTP_200_OK, response_model=AzureTokenResponse)
def auth_get_azure_access_token(request: AzureTokenReuqest, api_call: bool = default_api_call) -> AzureTokenResponse:
    request = AzureTokenReuqest(**request.__dict__)
    response_request, response = AuthenticationServiceManager(api_call=api_call).get_azure_access_token(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_request

@router.get("/auth/azure/user_info/{access_token}", status_code=status.HTTP_200_OK, response_model=dict)
def auth_get_azure_userinfo(access_token: str, api_call: bool = default_api_call) -> dict:
    response_request, response = AuthenticationServiceManager(api_call=api_call).get_azure_user_info(access_token=access_token)
    router_response_handler(response=response, api_call=api_call)
    return response_request

@router.get("/auth/azure/validate_token/{access_token}", status_code=status.HTTP_200_OK, response_model=dict)
def auth_validate_azure_token(access_token: str, api_call: bool = default_api_call) -> dict:
    response_request, response = AuthenticationServiceManager(api_call=api_call).validate_azure_access_token(access_token=access_token)
    router_response_handler(response=response, api_call=api_call)
    return response_request