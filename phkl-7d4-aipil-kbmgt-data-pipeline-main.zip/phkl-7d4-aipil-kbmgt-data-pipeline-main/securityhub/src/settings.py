import os
from typing import List, NamedTuple
from pydantic import BaseSettings, validator
import json

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
SERVICE_DIR = os.path.dirname(CURRENT_DIR)
PROJECT_DIR = os.path.dirname(SERVICE_DIR)
SETTING_FILE_ENCODING = 'utf-8'

# Load Global Config File if Any
GLOBAL_SETTING_KEY = 'share_'
GLOBAL_LOGGING_KEY = 'log_'
GLOBAL_BACKUP_KEY  = 'backup_'
GLOBAL_EXPORT_KEY  = 'export_'

# Load App Setting File
SETTING_FILE = os.path.join(SERVICE_DIR, 'src', 'config', 'settings.env')

# Load Default DB Template if Any
INIT_DB_FILE = os.path.join(SERVICE_DIR, 'src', 'config', 'init_config.py')

# Load Global Setting File (will override local app setting)
GLOBAL_SETTING_FILE = os.path.join(PROJECT_DIR, 'config', 'settings.json')


class AppSettings(BaseSettings):
    APP_NAME:        str
    APP_HOST:        str = ''
    APP_PORT:        int = ''
    APP_INIT_CHECK:  bool = True
    APP_API:         bool = False
    APP_FUNC:        bool = False
    APP_TIMEOUT:     float = 60.0
    APP_VER:         str = 'v1.0'
    APP_STANDALONE:  bool = True
    APP_PRODUCTION:  bool = False
    APP_ENCRYPTION:  bool = False
    ORIGINS:         List[str] = ["*"]
    ENDPOINT_PREFIX: str = "/api"
    TIMEZONE:        str = 'Asia/Hong_Kong'

    class Config:
        env_file = SETTING_FILE
        env_prefix = ''
        env_file_encoding = SETTING_FILE_ENCODING


class ConstraintSettings(BaseSettings):
    NAMING:               list[str]

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'CSTR_'
        env_file_encoding = SETTING_FILE_ENCODING

class SecuritySettings(BaseSettings):
    DB_KEY:                    bytes
    DB_KEYGEN_PSWD:            bytes
    KEYVAULT_KEYGEN_PSWD:      str   
    KEYVAULT_KEY_AGNT_TRANSIT: bytes
    KEYVAULT_KEY_KWIN_TRANSIT: bytes
    KEYVAULT_KEY_KNOW_TRANSIT: bytes
    KEYVAULT_KEY_POST_TRANSIT: bytes
    KEYVAULT_KEY_TOOL_TRANSIT: bytes
    KEYVAULT_KEY_USER_TRANSIT: bytes

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'SCRT_'
        env_file_encoding = SETTING_FILE_ENCODING

class AuthenticationSettings(BaseSettings):
    AZURE_CLIENT_ID:           str
    AZURE_CLIENT_SECRET:       str
    AZURE_CODE_CHALLENGE_SEED: bytes
    AZURE_AUTHORITY:           str
    AZURE_REDIRECT_URI:        str
    AZURE_SCOPES:              List[str]
    AZURE_USER_INFO_URL:       str

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'AUTH_'
        env_file_encoding = SETTING_FILE_ENCODING

""" Registry DB Settings """
class DatabaseSettings(BaseSettings):
    DB_FORM:       list = ["SLDB", "PGDB", "MODB"]
    FORM:          str
    LOCA:          str
    NAME:          str # DB Name
    HOST:          str # DB Host 
    PORT:          str # DB Port
    USER:          str # DB User
    PSWD:          str # DB Pswd
    RDIR:          str # DB Root
    SDIR:          str # DB Dir
    USERKEY_TABLE: str
    SEP:           str # Separator for converting list to string in db
    ENCRYPTION:    str=''
    
    ### TODO: Should update to field_validator('RDIR', 'SDIR', mode='before')
    @validator('RDIR', 'SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_SETTING_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")

        return value

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'SH_DATB_'
        env_file_encoding = SETTING_FILE_ENCODING


class BackupSettings(BaseSettings):
    DB_FORM:       list[str] = ['SLDB', 'PGDB']
    FORM:          str       = 'SLDB'
    LOCA:          str       = 'local'
    NAME:          str       = 'test_backup' # DB Name
    HOST:          str       = '' # DB Host 
    PORT:          str       = '' # DB Port
    USER:          str       = '' # DB User
    PSWD:          str       = '' # DB Pswd
    RDIR:          str       = SERVICE_DIR # DB Root
    SDIR:          str       = 'sldb_backup' # DB Dir
    USERKEY_TABLE: str       = 'userkey'
    LIMIT:         int       = 100 # Backup Number
    ENCRYPTION:    str       = ''

    ### TODO: Should update to field_validator('RDIR', 'SDIR', mode='before')
    @validator('RDIR', 'SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_BACKUP_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")

        return value
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'BKUP_'
        env_file_encoding = SETTING_FILE_ENCODING


class ImportSettings(BaseSettings):
    DB_FORM:   list[str] = ['SLDB', 'PGDB']
    FILE_FORM: list[str] = ['JSON', 'CSV']
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'IMPT_'
        env_file_encoding = SETTING_FILE_ENCODING


class ExportSettings(BaseSettings):
    DB_FORM:       list[str] = ['SLDB', 'PGDB']
    FILE_FORM:     list[str] = ['JSON', 'CSV']
    FORM:          str       = 'JSON'
    LOCA:          str       = 'local'
    NAME:          str       = 'test_export'
    HOST:          str       = ''
    PORT:          str       = ''
    USER:          str       = ''
    PSWD:          str       = ''
    USERKEY_TABLE: str       = 'userkey'
    RDIR:          str       = SERVICE_DIR
    SDIR:          str       = 'sldb_backup'
    FILE_RDIR:     str       = SERVICE_DIR
    FILE_SDIR:     str       = 'export'
    FILE_NAME:     str       = 'userkey'
    ENCRYPTION:    str       = ''

    # @field_validator('TAG_RDIR', 'TAG_SDIR', mode='before')
    @validator('RDIR', 'SDIR', 'FILE_RDIR', 'FILE_SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_EXPORT_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")

        return value
    
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'EXPT_'
        env_file_encoding = SETTING_FILE_ENCODING

class SecurityHubSettings(BaseSettings):
    HOST:                      str
    PORT:                      str
    REQUEST_USERKEY_API:       str
    REQUEST_USERKEY_MODULE:    str
    REQUEST_USERKEY_FUNC:      str
    KEYVAULT_KEY_TOOL_TRANSIT: bytes

    class Config:
        env_file = SETTING_FILE
        env_prefix = 'SCRT_'
        env_file_encoding = SETTING_FILE_ENCODING

class LoggerSettings(BaseSettings):
    DB_FORM:   list = ['SLDB', 'PGDB']
    FORM:      str  = 'SLDB'
    LOCA:      str  = 'local'
    NAME:      str  = 'test_log'
    HOST:      str  = ''
    PORT:      str  = ''
    USER:      str  = ''
    PSWD:      str  = ''
    RDIR:      str  = SERVICE_DIR
    SDIR:      str  = 'log'
    TABLE:     str  = 'app_log'
    LIMIT:     int  = 10000
    FILE_RDIR: str  = SERVICE_DIR
    FILE_SDIR: str  = 'log'
    FILE_NAME: str  = 'app.log'
    FILE_BYTE: int  = 1000000 # Backup file maximum bytes
    FILE_NUM:  int  = 2 # Backup file number
    SAVE_DB:   bool = False
    SAVE_FILE: bool = False
    LEVEL:     str  = 'INFO'

    ### TODO: Should update to field_validator('RDIR', 'SDIR', mode='before')
    @validator('RDIR', 'SDIR', 'FILE_RDIR', 'FILE_SDIR', pre=True)
    def validate_dir(cls, value, field):
        # Check if global settings
        if os.path.isfile(GLOBAL_SETTING_FILE):
            with open(GLOBAL_SETTING_FILE) as global_setting_file:
                global_settings = json.load(global_setting_file)
                key = GLOBAL_LOGGING_KEY + field.name.lower()
                if key in global_settings.keys():
                    value = global_settings[key]

        # Check if value is an executable function
        if isinstance(value, str) and "os.path" in value:
            # Use eval to convert it to a full path
            try:
                value = eval(value)
            except:
                raise ValueError(f"Error in Evaluating {value}")
            
        return value
        
    class Config:
        env_file = SETTING_FILE
        env_prefix = 'LOG_'
        env_file_encoding = SETTING_FILE_ENCODING


class StatusSettings(BaseSettings):
    INFO_CODE_START:    int = 100
    INFO_CODE_END:      int = 200
    SUCC_CODE_START:    int = 200
    SUCC_CODE_END:      int = 300
    REDIR_CODE_START:   int = 300
    REDIR_CODE_END:     int = 400
    CLIENT_CODE_START:  int = 400
    CLIENT_CODE_END:    int = 500
    SERERR_CODE_START:  int = 500
    SERERR_CODE_END:    int = 600    


class Config(NamedTuple):
    BASE: AppSettings = AppSettings()
    CSTR: ConstraintSettings = ConstraintSettings()

    SCRT: SecuritySettings = SecuritySettings()
    AUTH: AuthenticationSettings = AuthenticationSettings()

    DATB: DatabaseSettings = DatabaseSettings()
    BKUP: BackupSettings = BackupSettings()
    IMPT: ImportSettings = ImportSettings()
    EXPT: ExportSettings = ExportSettings()
    LOG:  LoggerSettings = LoggerSettings()
    STAT: StatusSettings = StatusSettings()

SETTINGS = Config()