from sqlalchemy import Column, String, Integer, DateTime, LargeBinary, Float, JSON, Boolean, UniqueConstraint
from sqlalchemy import Table, MetaData
from sqlalchemy.engine import Engine

from sqlalchemy.orm import declarative_base
from sqlalchemy.sql import func

import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS


def set_io_db_table(table_name: str, engine: Engine):
    Base = declarative_base()

    class IOUserkeyDB(Base):

        __tablename__ = table_name

        # Trace Information
        userkey_id         = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()), index=True, unique=True)
        userkey_traceid    = Column(String,  default=lambda: str(uuid.uuid4())) # trace the changes of userkey
        userkey_version    = Column(Integer, default=1)   # 1=original    
        _user_id           = Column("user_id", LargeBinary, primary_key=True,  default='')

        # Category Information
        userkey_type       = Column(String,  default='default') # default, user, group, agent
        userkey_encryption = Column(String,  default='DEFAULT') # encryption method used by the key

        # Control Information
        userkey_status     = Column(Integer, default=1)   # 0=inactvie, 1=active

        # Specification
        password_key       = Column(LargeBinary)
        interaction_key    = Column(LargeBinary)
        input_key          = Column(LargeBinary)
        text_key           = Column(LargeBinary)
        image_key          = Column(LargeBinary)
        audio_key          = Column(LargeBinary)
        video_key          = Column(LargeBinary)
        prompt_key         = Column(LargeBinary)
        tool_key           = Column(LargeBinary)

        # Tags
        _userkey_tags      = Column("userkey_tags", String, default="")

        # Creator Information
        creator_id         = Column(String,  default='system') # user or group ID
        aprrover_id        = Column(String,  default='system') # user or group name
        
        # Time Information
        keygen_time        = Column(Float, default=0)
        created_at         = Column(DateTime(timezone=True), server_default=func.now(), default=datetime.now(timezone.utc))
        updated_at         = Column(DateTime(timezone=True), onupdate=lambda: datetime.now(timezone.utc), default=datetime.now(timezone.utc))

        @property
        def user_id(self):
            """Convert value from byte to str."""
            if self._user_id:
                if SETTINGS.DATB.ENCRYPTION.upper() == "DEFAULT":               
                    user_id, response = CryptoServiceManager(api_call=False).decode_content(content=self._user_id)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        raise ValueError(f"Error : Failed to Decode Value")
                    else:
                        return user_id
            return ""

        @user_id.setter
        def user_id(self, value):
            """Convert value from str to byte."""
            if isinstance(value, str):
                encoded_value, response = CryptoServiceManager(api_call=False).encode_content(content=value)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    raise ValueError(f"Error : Failed to Encode {value}")
                else:
                    self._user_id = encoded_value
            elif isinstance(value, bytes):
                self._user_id = value
            else:
                raise ValueError(f"Error : {value} must be a string or a bytes.")

        @property
        def userkey_tags(self):
            """Convert value from str to list."""
            if self._userkey_tags:
                return [value.strip() for value in self._userkey_tags.split(SETTINGS.DATB.SEP)]
            return []

        @userkey_tags.setter
        def userkey_tags(self, values):
            """Convert value from list to str."""
            if isinstance(values, list):
                if all(constrained_word not in value for constrained_word in SETTINGS.CSTR.NAMING for value in values):
                    self._userkey_tags = SETTINGS.DATB.SEP.join(values)
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            
            elif isinstance(values, str):
                if all(constrained_word not in values for constrained_word in SETTINGS.CSTR.NAMING):
                    self._userkey_tags = values
                else:
                    ValueError(f"Error : {values} contains constrained characters/symbols.")
            else:
                raise ValueError(f"Error : {values} must be a string or a list.")

        def to_dict(self):
            return {**self.__dict__,
                "user_id":      self.user_id,
                "userkey_tags": self.userkey_tags
            }
    
    Base.metadata.create_all(engine)
    return IOUserkeyDB

def get_io_db_table(table_name: str, engine: Engine) -> Table:
    metadata = MetaData()
    table = Table(table_name, metadata, autoload_with=engine)
    return table