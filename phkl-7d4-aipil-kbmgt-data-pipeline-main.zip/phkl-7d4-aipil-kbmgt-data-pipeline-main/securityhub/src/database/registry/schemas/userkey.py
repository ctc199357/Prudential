from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

""""
    UserKey General Operation
"""
class UserKeyCreate(BaseModel):
    # Trace Information
    userkey_id:         str=Field(default_factory=lambda: str(uuid.uuid4()))
    userkey_traceid:    str=Field(default_factory=lambda: str(uuid.uuid4()))
    userkey_version:    int=1
    user_id:            str
    
    # Category Information
    userkey_type:       str='default'
    userkey_encryption: str='DEFAULT' # encryption method used by the key

    # Control Information
    userkey_status:     int=1

    # Specification
    password_key:       bytes
    interaction_key:    bytes
    input_key:          bytes
    text_key:           bytes
    image_key:          bytes
    audio_key:          bytes
    video_key:          bytes
    prompt_key:         bytes
    tool_key:           bytes

    # Tags
    userkey_tags:       list[str]=[]

    # Creator Information
    creator_id:         str='system'
    aprrover_id:        str='system'

    # Time Information
    keygen_time:        float=0.0
    created_at:         datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:         datetime | None = None

class UserKeyCreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           UserKeyCreate

class UserKeyBatchCreateRequest(BaseModel):
    create_requests: list[UserKeyCreateRequest]

# UserKey CRUD
class UserKeyUpdate(BaseModel):
    # Trace Information
    userkey_id:         str   | None = None
    userkey_traceid:    str   | None = None
    userkey_version:    int   | None = None
    user_id:            str   | None = None
    
    # Category Information
    userkey_type:       str   | None = None
    userkey_encryption: str   | None = None

    # Control Information
    userkey_status:     int   | None = None

    # Specification
    password_key:       bytes | None = None
    interaction_key:    bytes | None = None
    input_key:          bytes | None = None
    text_key:           bytes | None = None
    image_key:          bytes | None = None
    audio_key:          bytes | None = None
    video_key:          bytes | None = None
    prompt_key:         bytes | None = None
    tool_key:           bytes | None = None

    # Tags
    userkey_tags:       list[str] | None = None

    # Creator Information
    creator_id:         str   | None = None
    aprrover_id:        str   | None = None

    # Time Information
    keygen_time:        float    | None = None
    created_at:         datetime | None = None
    updated_at:         datetime | None = None
    
class UserKeyUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    is_admin:       bool=False
    userkey_id:     str | None = None
    update_data:    UserKeyUpdate=UserKeyUpdate()
    overwrite:      bool = True
    
class UserKeyRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str | None = None
    user_name:      str | None = None
    userkey_id:     str | None = None

class UserKeyBatchRequest(BaseModel):
    batch_requests: list[UserKeyRequest]

# System-level Access
class SecretUserKey(BaseModel):
    # Trace Information
    userkey_id:         str   | None = None
    userkey_traceid:    str   | None = None
    userkey_version:    int   | None = None
    user_id:            str   | None = None
    
    # Category Information
    userkey_type:       str   | None = None
    userkey_encryption: str   | None = None

    # Control Information
    userkey_status:     int   | None = None

    # Specification
    password_key:       bytes | None = None
    interaction_key:    bytes | None = None
    input_key:          bytes | None = None
    text_key:           bytes | None = None
    image_key:          bytes | None = None
    audio_key:          bytes | None = None
    video_key:          bytes | None = None
    prompt_key:         bytes | None = None
    tool_key:           bytes | None = None

    # Tags
    userkey_tags:       list[str] | None = None

    # Creator Information
    creator_id:         str   | None = None
    aprrover_id:        str   | None = None

    # Time Information
    keygen_time:        float    | None = None
    created_at:         datetime | None = None
    updated_at:         datetime | None = None


"""
    UserKey Filter
"""
class UserKeyStringFilter(BaseModel):
    userkey_id_filter:      list[str] | None = None
    userkey_traceid_filter: list[str] | None = None
    userkey_name_filter:    list[str] | None = None

    userkey_type_filter:    list[str] | None = None
    userkey_encryption:     list[str] | None = None

    creator_id_filter:      list[str] | None = None
    auditor_id_filter:      list[str] | None = None

class UserKeyNumericFilter(BaseModel):
    userkey_status_min: int | None = None
    userkey_status_max: int | None = None

    keygen_time_min:    int | None = None
    keygen_time_max:    int | None = None 

class UserKeyListFilter(BaseModel):
    userkay_tags_or:  list[str] | None = None
    userkay_tags_and: list[str] | None = None

class UserKeyDictionaryFilter(BaseModel):
    not_use_or:  list[str] | None = None
    not_use_and: list[str] | None = None

class UserKeyBooleanFilter(BaseModel):
    not_use_filter: bool | None = None

class UserKeyDatetimeFilter(BaseModel):
    created_at_start: datetime  | None = None
    created_at_end:   datetime  | None = None
    updated_at_start: datetime  | None = None
    updated_at_end:   datetime  | None = None

class UserKeyByteFilter(BaseModel):
    user_id_filter:   list[str] | None = None

class UserKeyFilter(BaseModel):
    string_filter:     UserKeyStringFilter     | None = None
    numeric_filter:    UserKeyNumericFilter    | None = None
    list_filter:       UserKeyListFilter       | None = None
    dictionary_filter: UserKeyDictionaryFilter | None = None
    boolean_filter:    UserKeyBooleanFilter    | None = None
    datetime_filter:   UserKeyDatetimeFilter   | None = None
    byte_filter:       UserKeyByteFilter       | None = None
    sorting:           dict={"userkey_id": "asc", "updated_at": "desc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access UserKeys
"""
class SystemUserKeyRequest(BaseModel):
    userkey_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:       UserKeyFilter | None = None

class SystemUserKeyResponse(BaseModel):
    userkey_requestid: str
    filtered_data:     list[SecretUserKey]=[]
    data_count:        int=0


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class UserKeyBackupRequest(BaseModel):
    userkey_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:       UserKeyFilter | None = None
    backup_config:     BackupConfig | None = None

class UserKeyBackupListRequest(BaseModel):
    userkey_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:     BackupConfig | None = None

class UserKeyBackupListResponse(BaseModel):
    userkey_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:        list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class UserKeyRestoreRequest(BaseModel):
    userkey_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:   RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class UserKeyImportRequest(BaseModel):
    userkey_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:         IOConfig | None = None
    backup:            bool=True

class UserKeyExportRequest(BaseModel):
    userkey_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:       UserKeyFilter | None = None
    io_config:         IOConfig | None = None
    include_datetime:  bool = True


"""
    Request and Response for User Access Permitted UserKeys
"""
# User-level Access
class UserKey(BaseModel):
    # Trace Information
    userkey_id:         str   | None = None
    userkey_traceid:    str   | None = None
    userkey_version:    int   | None = None
    user_id:            str   | None = None
    
    # Category Information
    userkey_type:       str   | None = None
    userkey_encryption: str   | None = None

    # Control Information
    userkey_status:     int   | None = None

    # Specification
    password_key:       bytes | None = None
    interaction_key:    bytes | None = None
    input_key:          bytes | None = None
    text_key:           bytes | None = None
    image_key:          bytes | None = None
    audio_key:          bytes | None = None
    video_key:          bytes | None = None
    prompt_key:         bytes | None = None
    tool_key:           bytes | None = None

    # Tags
    userkey_tags:       list[str] | None = None

    # Time Information
    keygen_time:        float    | None = None
    created_at:         datetime | None = None
    updated_at:         datetime | None = None
    
class UserSecretKeyRequest(BaseModel):
    userkey_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:       UserKeyFilter

class UserSecretKeyResponse(BaseModel):
    userkey_requestid: str
    filtered_data:     list[UserKey]=[]