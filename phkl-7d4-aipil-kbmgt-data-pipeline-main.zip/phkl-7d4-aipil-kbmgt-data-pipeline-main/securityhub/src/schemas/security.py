from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

"""
    Service Key Generation Operation
"""
class ServiceKeyGenRequest(BaseModel):
    keygen_requestid:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    servicekey_type:       str='default'
    servicekey_encryption: str='DEFAULT'
    servicekey_service:    str | None = None
    request_at:            datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class ServiceKeyGenResponse(BaseModel):
    keygen_requestid:      str

    servicekey_type:       str='default'
    servicekey_encryption: str='DEFAULT'
    servicekey_service:    str | None = None

    public_key:            bytes | None = None
    private_key:           bytes | None = None

    keygen_result:         str='FAIL'
    keygen_time:           float    | None = 0.0
    response_at:           datetime | None = None


