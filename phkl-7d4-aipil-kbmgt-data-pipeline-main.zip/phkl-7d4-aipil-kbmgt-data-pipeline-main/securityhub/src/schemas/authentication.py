from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, timezone
import json

"""
    Azure Authentication
"""
class AzureAuthenticationRequest(BaseModel):
    code_challenge_method: str='DEFAULT'

class AzureAuthenticationResponse(BaseModel):
    auth_url: str | None = None

class AzureTokenReuqest(BaseModel):
    auth_code: str

class AzureTokenResponse(BaseModel):
    access_token: dict | None = None
