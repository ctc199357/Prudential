from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

from ..database.registry.schemas.userkey import *

"""
    User Key Generation Operation
"""
class UserKeyGenRequest(BaseModel):
    keygen_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_id:            str=''
    userkey_type:       str='default'
    userkey_encryption: str='DEFAULT'
    request_at:         datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class UserKeyGenResponse(BaseModel):
    keygen_requestid:   str
    userkey_id:         str=''

    user_id:            str=''
    userkey_type:       str='default'
    userkey_encryption: str='DEFAULT'

    keygen_result:      str='FAIL'
    keygen_time:        float    | None = 0.0
    response_at:        datetime | None = None

class SecretUserKeyGenRequest(BaseModel):
    keygen_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_id:            str | None = None
    userkey_type:       str='default'
    userkey_encryption: str='DEFAULT'

    password_key:       bytes | None = None
    interaction_key:    bytes | None = None
    input_key:          bytes | None = None
    text_key:           bytes | None = None
    image_key:          bytes | None = None
    audio_key:          bytes | None = None
    video_key:          bytes | None = None
    prompt_key:         bytes | None = None
    tool_key:           bytes | None = None

    keygen_time:        float | None = 0.0
    request_at:         datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

"""
    User Key Retrieval Operation
"""
class UserKeyRetrievalRequest(BaseModel):
    key_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_id:         str=''
    
    userkey_type:    str='default'
    request_origin:  str='USERHUB'
    requested_keys:  list[str]=[] # password_key, interaction_key, text_key, image_key, audio_key, video_key, prompt_key, tool_key
    
    request_at:      datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class UserKeyRetrievalResponse(BaseModel):
    key_requestid:      str
    user_id:            str=''

    userkey_type:       str='default'
    userkey_encryption: str='DEFAULT'

    password_key:       bytes | None = None
    interaction_key:    bytes | None = None
    text_key:           bytes | None = None
    image_key:          bytes | None = None
    audio_key:          bytes | None = None
    video_key:          bytes | None = None
    prompt_key:         bytes | None = None
    tool_key:           bytes | None = None

    key_retrieval_time: float | None =0.0
    response_at:        datetime | None = None