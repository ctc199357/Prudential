import os
from datetime import datetime, timezone
import inspect
import httpx
import time
import uuid
from sqlalchemy.orm import Session

from cryptography.hazmat.primitives.asymmetric import rsa, padding, ec
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.backends import default_backend
import base64

from ..settings import SETTINGS

from ..schemas.userkey import (
    UserKeyCreate,
    UserKeyCreateRequest,
    SystemUserKeyRequest,
    UserKeyFilter,
    UserKeyByteFilter,
    UserKeyNumericFilter,
    UserKeyGenRequest,
    UserKeyGenResponse,
    SecretUserKeyGenRequest,    
    UserKeyRetrievalRequest,
    UserKeyRetrievalResponse
)

from ..schemas.security import (
    ServiceKeyGenRequest,
    ServiceKeyGenResponse
)

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..routers.general import general_create_userkey
from ..routers.system  import system_query_userkey

if SETTINGS.BASE.APP_ENCRYPTION == True:
    from ..security.services.crypto_service import CryptoServiceManager

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class UserKeyServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    
    def __init__(self, api_call: bool):
        self.api_call = api_call
        
    """
        Request Operation
    """
    def create_userkey(self, request: UserKeyGenRequest) -> tuple[UserKeyGenResponse, Response]:
        keygen_start_at = time.time()
        keygen_response = UserKeyGenResponse(**request.__dict__)
        secret_keygen_request = SecretUserKeyGenRequest(**request.__dict__)

        for key, value in secret_keygen_request.__dict__.items():
            if '_key' in key:
                # Generate Symmetric Key
                generated_key, response = CryptoServiceManager(api_call=self.api_call).generate_symmetric_key(key_encryption=request.userkey_encryption)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    break
                
                # Encrypt the Generated Symmetric Key
                encrypted_generated_key, response = CryptoServiceManager(api_call=self.api_call).encrypt_with_symmetric_key(content=generated_key, encryption_key=eval(SETTINGS.SCRT.DB_KEY))
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    break
                
                secret_keygen_request.__dict__[key] = encrypted_generated_key

        keygen_time = time.time() - keygen_start_at

        # Store Key in DB
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            keygen_response.response_at = datetime.now(timezone.utc)
            return keygen_response, response    
        else:
            secret_keygen_request.keygen_time = keygen_time
            userkey_data = UserKeyCreate(**secret_keygen_request.__dict__)
            response = general_create_userkey(
                request  = UserKeyCreateRequest(**request.__dict__, is_admin=True, data=userkey_data), 
                api_call = self.api_call
            )

        # Update Response
        if response.status_code <= SETTINGS.STAT.SUCC_CODE_END:
            keygen_response.__dict__.update(
                userkey_id    = userkey_data.userkey_id,
                keygen_result = 'SUCCEED',
                keygen_time   = keygen_time,
                response_at   = datetime.now(timezone.utc)
            )
        
        return keygen_response, response


    ### TODO: Add Update Service Key in Other Modules via Calling API / Function and Update settings.env
    def create_servicekey(self, request: ServiceKeyGenRequest) -> tuple[ServiceKeyGenResponse, Response]:
        keygen_start_at = time.time()
        keygen_response = ServiceKeyGenResponse(**request.__dict__)

        generated_key, response = CryptoServiceManager(api_call=self.api_call).generate_asymmetric_key(key_encryption=request.servicekey_encryption)

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            keygen_response.response_at = datetime.now(timezone.utc)
            return keygen_response, response
        else:
            keygen_time = time.time() - keygen_start_at

        if request.servicekey_service:
            ### TODO: Update Service Key
            generated_key = {"PUBLIC": None, "PRIVATE": None} # Remove keys from response
            pass

        # Update Response
        if response.status_code <= SETTINGS.STAT.SUCC_CODE_END:
            keygen_response.__dict__.update(
                public_key    = generated_key.get("PUBLIC"),
                private_key   = generated_key.get("PRIVATE"),
                keygen_result = 'SUCCEED',
                keygen_time   = keygen_time,
                response_at   = datetime.now(timezone.utc)
            )
        
        return keygen_response, response

    def retrieve_userkey(self, request: UserKeyRetrievalRequest) -> tuple[UserKeyRetrievalResponse, Response]:
        key_retrieval_at = time.time()
        retrieved_key_response = UserKeyRetrievalResponse(**request.__dict__)

        # 1. Search UserKey based on user_id
        data_filter = UserKeyFilter(
            numeric_filter = UserKeyNumericFilter(userkey_status_min=1),
            byte_filter    = UserKeyByteFilter(user_id_filter=[request.user_id])
        )

        system_response_data = system_query_userkey(
            request  = SystemUserKeyRequest(data_filter=data_filter), 
            api_call = self.api_call
        )
        if not system_response_data.filtered_data:
            response = Response(status_code=404, detail=self.response_format.error(f"UserKey Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve UserKey"))
            return retrieved_key_response, response
        else:
            encrypted_userkey = system_response_data.filtered_data[0]

        # 2. Identify types of keys to be retrieved
        update_keys = dict()
        for _requested_key in request.requested_keys:
            stored_key = encrypted_userkey.__dict__.get(_requested_key)
            if stored_key:

                # 3.1. Decrypt Stored Key
                decrypted_key, response = CryptoServiceManager(api_call=self.api_call).decrypt_with_symmetric_key(
                    content=stored_key,
                    decryption_key=eval(SETTINGS.SCRT.DB_KEY)
                )

                # 3.2. Check if Decrytion Succeeds
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return retrieved_key_response, response
                else:
                    update_keys[_requested_key] = decrypted_key
                
                # 3.3 Retreieve Asymmetric Key for Encrypt Key in Transit
                if request.request_origin.upper() == "AGENTHUB":
                    encryption_key = SETTINGS.SCRT.KEYVAULT_KEY_AGNT_TRANSIT
                elif request.request_origin.upper() == "KNOWLEDGEHUB":
                    encryption_key = SETTINGS.SCRT.KEYVAULT_KEY_KNOW_TRANSIT
                elif request.request_origin.upper() == "POSTPROCESSINGHUB":
                    encryption_key = SETTINGS.SCRT.KEYVAULT_KEY_POST_TRANSIT
                elif request.request_origin.upper() == "TOOLHUB":
                    encryption_key = SETTINGS.SCRT.KEYVAULT_KEY_TOOL_TRANSIT
                elif request.request_origin.upper() == "USERHUB":
                    encryption_key = SETTINGS.SCRT.KEYVAULT_KEY_USER_TRANSIT
                else:
                    response = Response(status_code=404, detail=self.response_format.error(f"UserKey Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Encountered Unknown Request Origin"))
                    return retrieved_key_response, response

                # 3.4. Encrypt UserKey for Transition
                for _key, _value in update_keys.items():
                    encrypted_key, response = CryptoServiceManager(api_call=self.api_call).encrypt_with_asymmetric_key(
                        content=_value,
                        encryption_key=eval(encryption_key)
                    )

                    # 3.5. Check if Encryption Succeeds
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        return retrieved_key_response, response
                    else:
                        update_keys[_key] = encrypted_key

        # 3. Update Response
        retrieved_key_response.__dict__.update(update_keys)
        retrieved_key_response.key_retrieval_time = time.time() - key_retrieval_at
        response = Response(status_code=200, detail=self.response_format.ok(f"UserKey Retrieval Success : <{SETTINGS.BASE.APP_NAME}> Completed UserKey Retrieval"))

        return retrieved_key_response, response