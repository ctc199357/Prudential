import os

from ..settings import SETTINGS

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


# Calling Method Check
if SETTINGS.BASE.APP_FUNC == False and SETTINGS.BASE.APP_API == False:
    err_msg = f"Failed to Inititate <{SETTINGS.BASE.APP_NAME}> : APP_FUNC and APP_API cannot be ALL False"
    logger.error(err_msg)
    raise Exception(err_msg)
