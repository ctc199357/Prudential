import os
import inspect
import httpx

from msal import ConfidentialClientApplication

from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

from ..settings import SETTINGS

from ..schemas.authentication import (
    AzureAuthenticationRequest,
    AzureAuthenticationResponse,
    AzureTokenReuqest,
    AzureTokenResponse
)

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class AuthenticationServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    
    def __init__(self, api_call: bool):
        self.api_call = api_call
        
    """
        Request Operation
    """
    def get_azure_authentication_url(self, request: AzureAuthenticationRequest) -> tuple[AzureAuthenticationResponse, Response]:
        response_auth = AzureAuthenticationResponse()

        try:
            msal_instance = ConfidentialClientApplication(
                client_id=SETTINGS.AUTH.AZURE_CLIENT_ID, 
                client_credential=SETTINGS.AUTH.AZURE_CLIENT_SECRET, 
                authority=SETTINGS.AUTH.AZURE_AUTHORITY
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Initiated MSAL Instance : <{SETTINGS.BASE.APP_NAME}> Initiated MSAL Instance"))
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"MSAL Instance Initiation Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Initiate MSAL Instance"))

        code_challenge, response = self.generate_code_challenge(method=request.code_challenge_method)

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_auth, response

        try:
            auth_url = msal_instance.get_authorization_request_url(
                SETTINGS.AUTH.AZURE_SCOPES,
                redirect_uri=SETTINGS.AUTH.AZURE_REDIRECT_URI,
                code_challenge=code_challenge,
                code_challenge_method="S256"
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Azure Auth Url Retrieval Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Azure Auth Url"))
            response_auth.auth_url = auth_url
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Azure Auth Url Retrieva Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Azure Auth Url"))

        return response_auth, response

    def get_azure_access_token(self, request: AzureTokenReuqest) -> tuple[AzureTokenResponse, Response]:
        response_token = AzureTokenResponse()

        try:
            msal_instance = ConfidentialClientApplication(
                client_id=SETTINGS.AUTH.AZURE_CLIENT_ID, 
                client_credential=SETTINGS.AUTH.AZURE_CLIENT_SECRET, 
                authority=SETTINGS.AUTH.AZURE_AUTHORITY
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Initiated MSAL Instance : <{SETTINGS.BASE.APP_NAME}> Initiated MSAL Instance"))
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"MSAL Instance Initiation Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Initiate MSAL Instance"))

        try:
            _response_token = msal_instance.acquire_token_by_authorization_code(
                request.auth_code,
                SETTINGS.AUTH.AZURE_SCOPES,
                credirect_uri=SETTINGS.AUTH.AZURE_REDIRECT_URI,
            )
            access_token = _response_token.get("access_token")
            if access_token:
                response_token.access_token = access_token
                response = Response(status_code=200, detail=self.response_format.ok(f"Azure Access Token Retrieval Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Azure Access Token"))
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Azure Access Token Authentication Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Access Token due to Authentication"))
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Azure Access Token Retrieval Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Access Token"))

        return response_token, response

    def get_azure_user_info(self, access_token: str) -> tuple[dict, Response]:
        response_info = dict()
        headers = {"Authorization": f"Bearer {access_token}"}
        response = httpx.get(SETTINGS.AUTH.AZURE_USER_INFO_URL, headers=headers)

        if response.status_code == 200:
            response = Response(status_code=200, detail=self.response_format.ok(f"Azure User Info Retrieval Success : <{SETTINGS.BASE.APP_NAME}> Retrieved Azure User Info"))
            response_info = response.json()
        else:
            response = Response(status_code=500, detail=self.response_format.error(f"Azure User Info Retrieval Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve User Info"))
            
        return response_info, response

    def validate_azure_access_token(self, access_token: str) -> tuple[dict, Response]:
        response_info = dict()
        headers = {"Authorization": f"Bearer {access_token}"}
        response = httpx.get(SETTINGS.AUTH.AZURE_USER_INFO_URL, headers=headers)

        if response.status_code == 200:
            response_info = {"status": "valid"}
        else:
            response_info = {"status": "invalid"}
        response = Response(status_code=200, detail=self.response_format.ok(f"Azure Access Token Validation Success : <{SETTINGS.BASE.APP_NAME}> Validated Azure Access Token"))
        return response_info, response


    def generate_code_challenge(self, method: str) -> tuple[bytes | None, Response]:
        code_challenge = None 

        if method.upper() in ["DEFAULT", 'AES256']:
            
            salt = os.urandom(16)
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=100000,
            )
            code_challenge = kdf.derive(eval(SETTINGS.SCRT.DB_KEYGEN_PSWD))
            response = Response(status_code=200, detail=self.response_format.ok(f"Code Challenge Completed : <{SETTINGS.BASE.APP_NAME}> Completed Code Challenge Generation"))
        else:
            response = Response(status_code=500, detail=self.response_format.error(f"Code Challenge Generation Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Generate Code Challenge"))
            
        return code_challenge, response