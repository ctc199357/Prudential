"""
    DB Service Manager
"""

from ....settings import SETTINGS

from datetime import datetime, timezone
import inspect

from azure.cosmos import CosmosClient
import azure.cosmos.exceptions as exceptions
from gremlin_python.driver import client, serializer

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)
from ..schemas.database import (
    GraphInfo,
    GBGraphInfoResponse,
)

from ..connections.graph_connection import create_gb_client, DATABASE_URL

from ....logger.log_handler import get_logger

logger = get_logger(__name__)

class GBManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            gb_name: str=SETTINGS.GPDB.NAME,
            gb_host: str=SETTINGS.GPDB.ENDPOINT,
            gb_key:  str=SETTINGS.GPDB.PSWD

        ):
        self.gb_name = gb_name
        self.gb_host = gb_host
        self.gb_key  = gb_key

    def get_primary_gb_info(self) -> tuple[GBGraphInfoResponse, Response]:
        response_data = GBGraphInfoResponse()
        graph_info    = []
    
        try:
            client_conn = CosmosClient(self.gb_host, self.gb_key)
            gb_client   = client_conn.get_database_client(self.gb_name)
            containers  = gb_client.list_containers()

            # for container in containers:
            #     gremlin_client = client.Client(
            #         url=DATABASE_URL,
            #         traversal_source="g",
            #         username=f"/dbs/{self.gb_name}/colls/{container['id']}",
            #         password=self.gb_key,
            #         message_serializer=serializer.GraphSONSerializersV2d0()
            #     )
            
            #     node_count = list(gremlin_client.submit("g.V().count()"))[0][0]
            #     edge_count = list(gremlin_client.submit("g.E().count()"))[0][0]

            #     graph_info.append(GraphInfo(
            #         graph_name = container['id'], 
            #         node_count = node_count,
            #         edge_count = edge_count
            #     ))

            #     gremlin_client.close()

            response_data = GBGraphInfoResponse(
                # total_graph_count = len(graph_info),
                total_graph_count = len(list(containers)),
                graph_list        = [str(_container['id']) for _container in list(containers) if _container.get('id')],
                total_node_count  = -1,
                total_edge_count  = -1
            )

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Got GB Graph Info"))
        
        except exceptions.CosmosResourceExistsError:
            response = Response(status_code=500, detail=self.response_format.error(f"DB Found and Connected : <{SETTINGS.BASE.APP_NAME}> <{self.gb_name}> Connected"))
            return response_data, response
        
        except exceptions.CosmosHttpResponseError as e:
            response = Response(status_code=500, detail=self.response_format.error(f"DB Connection Error : <{SETTINGS.BASE.APP_NAME}> <{self.gb_name}> Database"))
            return response_data, response

        return response_data, response

    def get_gb_graph_info(self, graph_name: str) -> tuple[GBGraphInfoResponse, Response]:
        response_data = GBGraphInfoResponse()
        graph_info    = []
    
        try:            
            gremlin_client = client.Client(
                url=DATABASE_URL,
                traversal_source="g",
                username=f"/dbs/{self.gb_name}/colls/{graph_name}",
                password=self.gb_key,
                message_serializer=serializer.GraphSONSerializersV2d0()
            )

            node_count = list(gremlin_client.submit("g.V().count()"))[0][0]
            edge_count = list(gremlin_client.submit("g.E().count()"))[0][0]

            graph_info.append(GraphInfo(
                graph_name = graph_name,
                node_count = node_count,
                edge_count = edge_count
            ))

            gremlin_client.close()

            response_data = GBGraphInfoResponse(
                total_graph_count = len(graph_info),
                total_node_count  = sum([info.node_count for info in graph_info]),
                total_edge_count  = sum([info.edge_count for info in graph_info])
            )

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Got GB Graph Info"))
        
        except exceptions.CosmosResourceExistsError:
            response = Response(status_code=500, detail=self.response_format.error(f"DB Found and Connected : <{SETTINGS.BASE.APP_NAME}> <{self.gb_name}> Connected"))
            return response_data, response
        
        except exceptions.CosmosHttpResponseError as e:
            response = Response(status_code=500, detail=self.response_format.error(f"DB Connection Error : <{SETTINGS.BASE.APP_NAME}> <{self.gb_name}> Database"))
            return response_data, response

        return response_data, response

    def drop_graph(self, graph_name: str) -> Response:
        try:
            gb_client = create_gb_client()
            gb_client.get_container_client(graph_name)
            gb_client.delete_container(graph_name)
            response = Response(status_code=200, detail=self.response_format.ok(f"Graph Cotaniner <{graph_name}> Dropped Successfully"))
            logger.info(response.detail)
        
        except exceptions.CosmosResourceNotFoundError:
            response = Response(status_code=200, detail=self.response_format.ok(f"Graph Cotaniner <{graph_name}> Does Not Exist. No Actions have been Taken"))
            logger.info(response.detail)
        
        return response