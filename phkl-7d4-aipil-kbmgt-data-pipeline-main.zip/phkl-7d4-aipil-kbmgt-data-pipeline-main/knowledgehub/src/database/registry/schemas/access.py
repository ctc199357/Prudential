from pydantic import BaseModel, Field, validator
from typing import List, Optional, Union
import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS

""""
    Access General Operation
"""
class AccessCreate(BaseModel):
    # Trace Information
    access_id:             str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Access ID")
    access_traceid:        str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Access Trace ID")
    access_status:         int=Field(default=1, description="[Optional] Access Status")
    access_version:        int=Field(default=1, description="[Optional] Access Version")
    batch_order:           str=Field(default_factory=lambda: datetime.now().strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp

    group_id:              str=''
    group_display_name_en: str=''
    group_display_name_zh: str=''
    owner:                 str=''
    role_name:             str=''
    designation_code:      str=''
    channel:               str=''
    sub_channel:           str=''

    created_at:            datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Created DateTime") # Created DateTime
    updated_at:            datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Updated DateTime") # Updated DateTime


class AccessCreateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Access")
    user_name:      str=Field(default="", description="[Optional] User Name for the Access")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Access")
    data:           AccessCreate=Field(..., description="[Required] Access Data", example=AccessCreate())

class AccessBatchCreateRequest(BaseModel):
    create_requests: list[AccessCreateRequest]

# Access CRUD
class AccessUpdate(BaseModel):
    # Trace Information
    access_id:             str | None = None
    access_traceid:        str | None = None
    access_status:         int | None = None
    access_version:        int | None = None
    batch_order:           str | None = None

    group_id:              str | None = None
    group_display_name_en: str | None = None
    group_display_name_zh: str | None = None
    owner:                 str | None = None
    role_name:             str | None = None
    designation_code:      str | None = None
    channel:               str | None = None
    sub_channel:           str | None = None

    created_at:            datetime | None = None
    updated_at:            datetime | None = None


class AccessUpdateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Access")
    user_name:      str=Field(default="", description="[Optional] User Name for the Access")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Access")
    access_id:      str=Field(..., description="[Required] Access ID for the Update")
    update_data:    AccessUpdate=Field(..., description="[Required] Access Data for the Update")
    overwrite:      bool=Field(default=True, description="[Optional] Overwrite Flag for the Update") # Overwrite Flag for the Update
    
class AccessRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Access")
    user_name:      str=Field(default="", description="[Optional] User Name for the Access")
    access_id:      str=Field(..., description="[Required] Access ID for the Request")

class AccessBatchRequest(BaseModel):
    batch_requests: list[AccessRequest]

# System-level Access
class SecretAccess(BaseModel):
    # Trace Information
    access_id:             str | None = None
    access_traceid:        str | None = None
    access_status:         int | None = None
    access_version:        int | None = None
    batch_order:           str | None = None

    group_id:              str | None = None
    group_display_name_en: str | None = None
    group_display_name_zh: str | None = None
    owner:                 str | None = None
    role_name:             str | None = None
    designation_code:      str | None = None
    channel:               str | None = None
    sub_channel:           str | None = None

    created_at:            datetime | None = None
    updated_at:            datetime | None = None

# User-level Access
class Access(BaseModel):
    # Trace Information
    access_id:             str | None = None
    access_traceid:        str | None = None
    access_status:         int | None = None
    access_version:        int | None = None
    batch_order:           str | None = None

    group_id:              str | None = None
    group_display_name_en: str | None = None
    group_display_name_zh: str | None = None
    owner:                 str | None = None
    role_name:             str | None = None
    designation_code:      str | None = None
    channel:               str | None = None
    sub_channel:           str | None = None

    created_at:            datetime | None = None
    updated_at:            datetime | None = None


"""
    Access Filter
"""   
class AccessStringFilter(BaseModel):
    access_id_filter:             list[str] | None = None
    access_traceid_filter:        list[str] | None = None
    batch_order:                  list[str] | None = None
    
    group_id_filter:              list[str] | None = None
    group_display_name_en_filter: list[str] | None = None
    group_display_name_zh_filter: list[str] | None = None
    owner_filter:                 list[str] | None = None
    role_name_filter:             list[str] | None = None
    designation_code_filter:      list[str] | None = None

    channel_filter:               list[str] | None = None
    sub_channel_filter:           list[str] | None = None
   

class AccessNumericFilter(BaseModel):
    access_status_min:  int | None = None
    access_status_max:  int | None = None
    access_version_min: int | None = None
    access_version_max: int | None = None

class AccessListFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None
    
class AccessDictionaryFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None

class AccessBooleanFilter(BaseModel):
    not_used_filter: bool | None = None

class AccessDatetimeFilter(BaseModel):
    not_used_start: datetime | None = None
    not_used_end:   datetime | None = None
    
class AccessByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class AccessFilter(BaseModel):
    string_filter:     AccessStringFilter     | None = None
    numeric_filter:    AccessNumericFilter    | None = None
    list_filter:       AccessListFilter       | None = None
    dictionary_filter: AccessDictionaryFilter | None = None
    boolean_filter:    AccessBooleanFilter    | None = None
    datetime_filter:   AccessDatetimeFilter   | None = None
    byte_filter:       AccessByteFilter       | None = None
    sorting:           dict={"access_id": "asc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access Accesss
"""
class SystemAccessRequest(BaseModel):
    access_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:         AccessFilter=Field(..., description="[Required] Access Filter", example=AccessFilter(
                                        string_filter=AccessStringFilter(
                                            access_id_filter=["access_id_1", "access_id_2"]
                                        ),
                                        numeric_filter=AccessNumericFilter(
                                            access_status_min=1
                                        )
                                    ))  

    class Config:
        schema_extra = {
            "example": {
                "access_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "numeric_filter": {
                        "access_status_min": 0
                    },
                    "filter_no": 1
                }
            }
        }

class SystemAccessResponse(BaseModel):
    access_requestid:    str=Field(..., description="Unique ID for the Request")
    filtered_data:       list[SecretAccess]=Field(default=[], description="Filtered Access Data")
    data_count:          int=Field(default=0, description="Count of Filtered Access Data", example=1)

"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class AccessBackupRequest(BaseModel):
    access_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:      AccessFilter | None = None
    backup_config:    BackupConfig | None = None

class AccessBackupListRequest(BaseModel):
    access_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:    BackupConfig | None = None

class AccessBackupListResponse(BaseModel):
    access_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:       list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class AccessRestoreRequest(BaseModel):
    access_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:   RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class AccessImportRequest(BaseModel):
    access_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:        IOConfig | None = None
    backup:           bool=True

class AccessExportRequest(BaseModel):
    access_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:      AccessFilter | None = None
    io_config:        IOConfig | None = None
    include_datetime: bool = True

"""
    Request and Response for User Access Permitted Accesss
"""
class UserAccessRequest(BaseModel):
    access_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:         AccessFilter

class UserAccessResponse(BaseModel):
    access_requestid: str
    filtered_data:       list[Access]=[]