from pydantic import BaseModel, Field, validator
from typing import List, Optional, Union
import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS

""""
    Knowledge General Operation
"""
class KnowledgeCreate(BaseModel):
    # Trace Information
    knowledge_id:                str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Knowledge ID")
    knowledge_traceid:           str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Knowledge Trace ID")
    knowledge_name:              str=Field(default='', description="[Optional] Knowledge Name")
    knowledge_version:           int=Field(default=1, description="[Optional] Knowledge Version")
    knowledge_ingestion_stage:   str=Field(default='Pending to Ingest', description="[Optional] Knowledge Ingestion Stage")
    knowledge_ingestion_reason:  str=Field(default='', description="[Optional] Ingestion Fail Reason")
    knowledge_processing_stage:  str=Field(default='Metadata Registered', description="[Optional] Metadata Registered, KnowledgeInput Registered, Preprocessing Completed, Vector Registered, Graph Registered, Ingest Done")
    knowledge_processing_reason: str=Field(default='', description="[Optional] Processing Fail Reason")
    batch_order:                 str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S"), description="Batch Name") # single if not batch, otherwise timestamp

    # PIL Information
    library_name_en:             str=Field(default='', description="[Optional] Library Name in English")
    library_name_tc:             str=Field(default='', description="[Optional] Library Name in Traditional Chinese")
    category_name_en:            str=Field(default='', description="[Optional] Category Name in English")
    category_name_tc:            str=Field(default='', description="[Optional] Category Name in Traditional Chinese")
    title_name_en:               str=Field(default='', description="[Optional] Title Name in English")
    title_name_tc:               str=Field(default='', description="[Optional] Title Name in Traditional Chinese")
    item_type:                   str=Field(default='', description="[Optional] Item Type")
    item_url:                    str=Field(default='', description="[Optional] Item URL")
    item_status:                 str=Field(default='', description="[Optional] Item Status")
    document_id:                 str=Field(default='', description="[Optional] Document ID")
    file_name:                   str=Field(default='', description="[Optional] File Name")
    file_description:            str=Field(default='', description="[Optional] File Description")
    file_created_datetime:       datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] File Created DateTime")
    file_last_modified_datetime: datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] File Last Modified DateTime")
    group_id:                    List[str]=Field(default=[], description="[Optional] Group ID")
    file_sync_up_url:            str=Field(default='', description="[Optional] File Sync Up URL")
    library_id:                  str=Field(default='', description="[Optional] Library ID")
    category_id:                 str=Field(default='', description="[Optional] Category ID")
    reference_start_date:        datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Reference Start Date")
    reference_end_date:          datetime=Field(default_factory=lambda: datetime.strptime(SETTINGS.KNOW.DEFAULT_EFFECTIVE_TO, "%Y-%m-%d"), description="[Optional] Reference End Date")

    updated_by:                  str=Field(default='', description="[Optional] Updated By")
    retention_at:                datetime=Field(default_factory=lambda: datetime.strptime(SETTINGS.KNOW.DEFAULT_EFFECTIVE_TO, "%Y-%m-%d"), description="[Optional] Retention Date")
    pil_active_status:           bool=Field(default=True, description="[Optional] PIL Active Status") # active, inactive, deleted

    # Creator Information
    creator_id:                  str=Field(default='', description="[Optional] Creator ID")
    creator_name:                str=Field(default='', description="[Optional] Creator Name")
    approver_id:                 str=Field(default='', description="[Optional] Approver ID")
    approver_name:               str=Field(default='', description="[Optional] Approver Name")

    # Category Information
    knowledge_group:             str=Field(default='default', description="[Optional] Knowledge Group")
    knowledge_type:              str=Field(default='default', description="[Optional] Knowledge Type")
    knowledge_location:          str=Field(default='default', description="[Optional] Knowledge Location")
    storage_type:                str=Field(default='', description="[Optional] Storage Type") # Storage Type of Knowledge
    storage_type_origin:         str=Field(default='', description="[Optional] Original Storage Type") # Origin Storage Type of Knowledge
    storage_provider:            str=Field(default='', description="[Optional] Storage Provider of Knowledge") # Storage Provider of Knowledge
    storage_provider_origin:     str=Field(default='', description="[Optional] Original Storage Provider of Knowledge") # Origin Storage Provider of Knowledge
    storage_directory:           str=Field(default='', description="[Optional] Storage File Path / Url") # File Path / Url
    storage_directory_origin:    str=Field(default='', description="[Optional] Original Storage File Path / Url") # File Path / Url
    storage_secrets:             dict=Field(default=dict(), description="[Optional] Storage Secret") # Access Secrets
    storage_secrets_origin:      dict=Field(default=dict(), description="[Optional] Original Storage Secret") # Access Secrets

    # Control Information
    knowledge_status:            int=Field(default=1, description="[Optional] Knowledge Status") # 0: Inactive, 1: Active, 2: Deleted
    knowledge_permission:        int=Field(default=1, description="[Optional] Knowledge Permission") # 0: Public, 1: Private, 2: Restricted
    knowledge_management:        int=Field(default=10, description="[Optional] Knowledge Management") # 0: Read Only, 1: Read and Write, 2: Restricted

    # Configuration
    knowledge_vectorstorage:     str=Field(default='', description="[Optional] Vector Storage Type") # Vector Storage Type of Knowledge
    knowledge_vectorlocation:    str=Field(default='', description="[Optional] Vector Storage Location") # Vector Storage File Path / Url
    knowledge_vectorinfo:        dict=Field(default=dict(), description="[Optional] Vector Storage Information") # Vector Storage Information
    knowledge_graphstorage:      str=Field(default='', description="[Optional] Graph Storage Type") # Graph Storage Type of Knowledge
    knowledge_graphlocation:     str=Field(default='', description="[Optional] Graph Storage Location") # Graph Storage File Path / Url
    knowledge_graphinfo:         dict=Field(default=dict(), description="[Optional] Graph Storage Information") # Graph Storage Information
    knowledge_searchstorage:     dict=Field(default=dict(), description="[Optional] Search Storage Type") # Search Storage Type of Knowledge
    knowledge_searchinfo:        dict=Field(default=dict(), description="[Optional] Search Storage Information") # Search Storage Information
    knowledge_secrets:           dict=Field(default=dict(), description="[Optional] Knowledge Secret") # Access Secrets
    knowledge_record:            bool=Field(default=False, description="[Optional] Knowledge Record") # Knowledge Record
    knowledge_key:               str=Field(default='', description="[Optional] Knowledge Key") # Knowledge Key

    # Specification
    knowledge_confidence:        float=Field(default=-1.0, description="[Optional] Knowledge Confidence") # Knowledge Confidence
    knowledge_filename:          str=Field(default='', description="[Optional] Knowledge File Name") # Knowledge File Name
    knowledge_fileextension:     str=Field(default='', description="[Optional] Knowledge File Extension") # Knowledge File Extension
    knowledge_filesize:          float=Field(default=0.0, description="[Optional] Knowledge File Size") # Knowledge File Size
    knowledge_description:       str=Field(default='', description="[Optional] Knowledge Description") # Knowledge Description

    # Statistics
    processing_time:             float=Field(default=0.0, description="[Optional] Processing Time") # Processing Time
    total_input_tokens:          int=Field(default=0, description="[Optional] Total Input Tokens") # Total Input Tokens
    total_output_tokens:         int=Field(default=0, description="[Optional] Total Output Tokens") # Total Output Tokens
    total_tool_tokens:           int=Field(default=0, description="[Optional] Total Tool Tokens") # Total Tool Tokens

    # Dependices
    knowledgeinput_id:           str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Map to knowledgeinput_id in KnowledgeInputHub") # Map to knowledgeinput_id in KnowledgeInputHub
    prepknow_id:                 str=Field(default="", description="[Optional] Used Preprocessing Knowledge ID") # Used Preprocessing Knowledge ID

    # Tags
    knowledge_keywords:          list[str]=Field(default=[], description="[Optional] Knowledge Keywords") # Knowledge Keywords
    knowledge_searchstorages:    list[str]=Field(default=[], description="[Optional] Knowledge Search Storage") # Knowledge Search Storage
    knowledge_sources:           list[str]=Field(default=[], description="[Optional] Knowledge Source") # Knowledge Source
    knowledge_sourcetypes:       list[str]=Field(default=[], description="[Optional] Knowledge Source Type") # Knowledge Source Type # official, search engine, etc.
    knowledge_contenttypes:      list[str]=Field(default=[], description="[Optional] Knowledge Content Type") # Knowledge Content Type
    knowledge_cats:              list[str]=Field(default=[], description="[Optional] Knowledge Category") # Knowledge Category
    knowledge_languages:         list[str]=Field(default=[], description="[Optional] Knowledge Language") # Knowledge Language
    knowledge_tags:              list[str]=Field(default=[], description="[Optional] Knowledge Tags") # Knowledge Tags
    user_groups:                 list[str]=Field(default=[], description="[Optional] User Groups") # User Groups
    agent_groups:                list[str]=Field(default=[], description="[Optional] Agent Groups") # Agent Groups

    # Evaluation Results
    average_groundedness:        float=Field(default=0.0, description="[Optional] Average Groundedness") # Average Groundedness
    average_relevance:           float=Field(default=0.0, description="[Optional] Average Relevance") # Average Relevance
    average_retrieval:           float=Field(default=0.0, description="[Optional] Average Retrieval") # Average Retrieval
    average_similarity:          float=Field(default=0.0, description="[Optional] Average Similarity") # Average Similarity

    # Time Information
    knowledge_issue_date:        datetime=Field(default=None, description="[Optional] Knowledge Issue Date") # Knowledge Issue Date
    knowledge_effective_from:    datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Knowledge Effective From") # Knowledge Effective From
    knowledge_effective_to:      datetime=Field(default_factory=lambda: datetime.strptime(SETTINGS.KNOW.DEFAULT_EFFECTIVE_TO, "%Y-%m-%d"), description="[Optional] Knowledge Effective To") # Knowledge Effective To

    created_at:                  datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Created DateTime") # Created DateTime
    updated_at:                  datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Updated DateTime") # Updated DateTime

    @validator('group_id', pre=True)
    def validate_group_id(cls, value):
        if isinstance(value, str):
            return value.split(',')
        return value

class KnowledgeCreateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Knowledge")
    user_name:      str=Field(default="", description="[Optional] User Name for the Knowledge")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Knowledge")
    data:           KnowledgeCreate=Field(..., description="[Required] Knowledge Data", example=KnowledgeCreate())

class KnowledgeBatchCreateRequest(BaseModel):
    create_requests: list[KnowledgeCreateRequest]

# Knowledge CRUD
class KnowledgeUpdate(BaseModel):
    # Trace Information
    knowledge_id:                str | None = None
    knowledge_traceid:           str | None = None
    knowledge_name:              str | None = None
    knowledge_version:           int | None = None
    knowledge_ingestion_stage:   str | None = None
    knowledge_ingestion_reason:  str | None = None
    knowledge_processing_stage:  str | None = None
    knowledge_processing_reason: str | None = None
    batch_order:                 str | None = None

    # Creator Information
    creator_id:                  str | None = None
    creator_name:                str | None = None
    approver_id:                 str | None = None
    approver_name:               str | None = None

    # PIL Information
    library_name_en:             str | None = None
    library_name_tc:             str | None = None
    category_name_en:            str | None = None
    category_name_tc:            str | None = None
    title_name_en:               str | None = None  
    title_name_tc:               str | None = None
    item_type:                   str | None = None
    item_url:                    str | None = None
    item_status:                 str | None = None
    document_id:                 str | None = None
    file_name:                   str | None = None
    file_description:            str | None = None
    file_created_datetime:       datetime | None = None
    file_last_modified_datetime: datetime | None = None
    group_id:                    List[str] | None = None
    file_sync_up_url:            str | None = None
    library_id:                  str | None = None
    category_id:                 str | None = None
    reference_start_date:        datetime | None = None
    reference_end_date:          datetime | None = None

    updated_by:                  str | None = None
    retention_at:                datetime | None = None
    pil_active_status:           bool | None = None

    # Category Information
    knowledge_group:             str | None = None
    knowledge_type:              str | None = None
    knowledge_location:          str | None = None
    storage_type:                str | None = None
    storage_type_origin:         str | None = None
    storage_provider:            str | None = None
    storage_provider_origin:     str | None = None
    storage_directory:           str | None = None
    storage_directory_origin:    str | None = None
    storage_secrets:             dict | None = None
    storage_secrets_origin:      dict | None = None

    # Control Information
    knowledge_status:            int | None = None
    knowledge_permission:        int | None = None
    knowledge_management:        int | None = None

    # Configuration
    knowledge_vectorstorage:     str  | None = None
    knowledge_vectorlocation:    str  | None = None
    knowledge_vectorinfo:        dict | None = None
    knowledge_graphstorage:      str  | None = None
    knowledge_graphlocation:     str  | None = None
    knowledge_graphinfo:         dict | None = None
    knowledge_searchstorage:     dict | None = None
    knowledge_searchinfo:        dict | None = None
    knowledge_secrets:           dict | None = None
    knowledge_record:            bool | None = None
    knowledge_key:               str  | None = None

    # Specification
    knowledge_confidence:        float | None = None
    knowledge_filename:          str   | None = None
    knowledge_fileextension:     str   | None = None
    knowledge_filesize:          float | None = None
    knowledge_description:       str   | None = None

    # Statistics
    processing_time:             float | None = None
    total_input_tokens:          int   | None = None
    total_output_tokens:         int   | None = None
    total_tool_tokens:           int   | None = None

    # Dependices
    knowledgeinput_id:           str  | None = None
    prepknow_id:                 str  | None = None

    # Tags
    knowledge_keywords:          list[str] | None = None
    knowledge_searchstorages:    list[str] | None = None
    knowledge_sources:           list[str] | None = None
    knowledge_sourcetypes:       list[str] | None = None
    knowledge_contenttypes:      list[str] | None = None
    knowledge_cats:              list[str] | None = None
    knowledge_languages:         list[str] | None = None
    knowledge_tags:              list[str] | None = None
    user_groups:                 list[str] | None = None
    agent_groups:                list[str] | None = None

    # Evaluation Results
    average_groundedness:        float | None = None
    average_relevance:           float | None = None
    average_retrieval:           float | None = None
    average_similarity:          float | None = None

    # Time Information
    knowledge_issue_date:        datetime | None = None
    knowledge_effective_from:    datetime | None = None
    knowledge_effective_to:      datetime | None = None

    created_at:                  datetime | None = None
    updated_at:                  datetime | None = None


class KnowledgeUpdateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Knowledge")
    user_name:      str=Field(default="", description="[Optional] User Name for the Knowledge")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Knowledge")
    knowledge_id:   str=Field(..., description="[Required] Knowledge ID for the Update")
    update_data:    KnowledgeUpdate=Field(..., description="[Required] Knowledge Data for the Update", example=KnowledgeUpdate(
                                        knowledge_ingestion_stage="Ingested",
                                        knowledge_processing_stage="Ingest Done",
                                        library_name_en="Test Library",
                                        category_name_en="Test Category",
                                        title_name_en="Test Title",
                                        item_type="Test Type",
                                        item_url="https://example.com/test.pdf",
                                        item_status="Active",
                                        file_name="test.pdf",
                                        file_description="Test File Description",
                                        file_created_datetime=datetime.now(timezone.utc),
                                        file_last_modified_datetime=datetime.now(timezone.utc),
                                    ))
    overwrite:      bool=Field(default=True, description="[Optional] Overwrite Flag for the Update") # Overwrite Flag for the Update
    
class KnowledgeRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Knowledge")
    user_name:      str=Field(default="", description="[Optional] User Name for the Knowledge")
    knowledge_id:   str=Field(..., description="[Required] Knowledge ID for the Request")

class KnowledgeBatchRequest(BaseModel):
    batch_requests: list[KnowledgeRequest]

# System-level Access
class SecretKnowledge(BaseModel):
    # Trace Information
    knowledge_id:                str | None = None
    knowledge_traceid:           str | None = None
    knowledge_name:              str | None = None
    knowledge_version:           int | None = None
    knowledge_ingestion_stage:   str | None = None
    knowledge_ingestion_reason:  str | None = None
    knowledge_processing_stage:  str | None = None
    knowledge_processing_reason: str | None = None
    batch_order:                 str | None = None

    # Creator Information
    creator_id:                  str | None = None
    creator_name:                str | None = None
    approver_id:                 str | None = None
    approver_name:               str | None = None

    # PIL Information
    library_name_en:             str | None = None
    library_name_tc:             str | None = None
    category_name_en:            str | None = None
    category_name_tc:            str | None = None
    title_name_en:               str | None = None  
    title_name_tc:               str | None = None
    item_type:                   str | None = None
    item_url:                    str | None = None
    item_status:                 str | None = None
    document_id:                 str | None = None
    file_name:                   str | None = None
    file_description:            str | None = None
    file_created_datetime:       datetime | None = None
    file_last_modified_datetime: datetime | None = None
    group_id:                    List[str] | None = None
    file_sync_up_url:            str | None = None
    library_id:                  str | None = None
    category_id:                 str | None = None
    reference_start_date:        datetime | None = None
    reference_end_date:          datetime | None = None

    updated_by:                  str | None = None
    retention_at:                datetime | None = None
    pil_active_status:           bool | None = None

    # Category Information
    knowledge_group:             str | None = None
    knowledge_type:              str | None = None
    knowledge_location:          str | None = None
    storage_type:                str | None = None
    storage_type_origin:         str | None = None
    storage_provider:            str | None = None
    storage_provider_origin:     str | None = None
    storage_directory:           str | None = None
    storage_directory_origin:    str | None = None
    storage_secrets:             dict | None = None
    storage_secrets_origin:      dict | None = None

    # Control Information
    knowledge_status:            int | None = None
    knowledge_permission:        int | None = None
    knowledge_management:        int | None = None

    # Configuration
    knowledge_vectorstorage:     str  | None = None
    knowledge_vectorlocation:    str  | None = None
    knowledge_vectorinfo:        dict | None = None
    knowledge_graphstorage:      str  | None = None
    knowledge_graphlocation:     str  | None = None
    knowledge_graphinfo:         dict | None = None
    knowledge_searchstorage:     dict | None = None
    knowledge_searchinfo:        dict | None = None
    knowledge_secrets:           dict | None = None
    knowledge_record:            bool | None = None
    knowledge_key:               str  | None = None

    # Specification
    knowledge_confidence:        float | None = None
    knowledge_filename:          str   | None = None
    knowledge_fileextension:     str   | None = None
    knowledge_filesize:          float | None = None
    knowledge_description:       str   | None = None

    # Statistics
    processing_time:             float | None = None
    total_input_tokens:          int   | None = None
    total_output_tokens:         int   | None = None
    total_tool_tokens:           int   | None = None

    # Dependices
    knowledgeinput_id:           str  | None = None
    prepknow_id:                 str  | None = None

    # Tags
    knowledge_keywords:          list[str] | None = None
    knowledge_searchstorages:    list[str] | None = None
    knowledge_sources:           list[str] | None = None
    knowledge_sourcetypes:       list[str] | None = None
    knowledge_contenttypes:      list[str] | None = None
    knowledge_cats:              list[str] | None = None
    knowledge_languages:         list[str] | None = None
    knowledge_tags:              list[str] | None = None
    user_groups:                 list[str] | None = None
    agent_groups:                list[str] | None = None

    # Evaluation Results
    average_groundedness:        float | None = None
    average_relevance:           float | None = None
    average_retrieval:           float | None = None
    average_similarity:          float | None = None

    # Time Information
    knowledge_issue_date:        datetime | None = None
    knowledge_effective_from:    datetime | None = None
    knowledge_effective_to:      datetime | None = None

    created_at:                  datetime | None = None
    updated_at:                  datetime | None = None


"""
    Knowledge Filter
"""   
class KnowledgeStringFilter(BaseModel):
    knowledge_id_filter:              list[str] | None = None
    knowledge_traceid_filter:         list[str] | None = None
    knowledge_name_filter:            list[str] | None = None
    knowledge_ingestion_stage_filter: list[str] | None = None
    knowledge_ingestion_reason_filter:  list[str] | None = None
    knowledge_processing_stage_filter: list[str] | None = None
    knowledge_processing_reason_filter: list[str] | None = None
    batch_order_filter:               list[str] | None = None

    library_name_en_filter:           list[str] | None = None
    library_name_tc_filter:           list[str] | None = None
    category_name_en_filter:          list[str] | None = None
    category_name_tc_filter:          list[str] | None = None
    title_name_en_filter:             list[str] | None = None
    title_name_tc_filter:             list[str] | None = None
    item_type_filter:                 list[str] | None = None
    item_url_filter:                  list[str] | None = None
    item_status_filter:               list[str] | None = None
    document_id_filter:               list[str] | None = None
    file_name_filter:                 list[str] | None = None
    file_sync_up_url_filter:          list[str] | None = None
    library_id_filter:                list[str] | None = None
    category_id_filter:               list[str] | None = None

    updated_by_filter:                list[str] | None = None

    creator_id_filter:                list[str] | None = None
    creator_name_filter:              list[str] | None = None
    approver_id_filter:               list[str] | None = None
    approver_name_filter:             list[str] | None = None

    knowledge_group_filter:           list[str] | None = None
    knowledge_type_filter:            list[str] | None = None
    knowledge_location_filter:        list[str] | None = None
    storage_type_filter:              list[str] | None = None
    storage_type_origin_filter:       list[str] | None = None
    storage_provider_filter:          list[str] | None = None
    storage_provider_origin_filter:   list[str] | None = None
    storage_directory_filter:         list[str] | None = None
    storage_directory_origin_filter:  list[str] | None = None

    knowledge_vectorstorage_filter:   list[str] | None = None
    knowledge_vectorlocation_filter:  list[str] | None = None
    knowledge_graphstorage_filter:    list[str] | None = None
    knowledge_graphlocation_filter:   list[str] | None = None
    knowledge_key_filter:             list[str] | None = None

    knowledge_filename_filter:        list[str] | None = None
    knowledge_fileextension_filter:   list[str] | None = None

    knowledgeinput_id_filter:         list[str] | None = None
    prepknow_id_filter:               list[str] | None = None

class KnowledgeNumericFilter(BaseModel):
    knowledge_version_min:    int | None = None
    knowledge_version_max:    int | None = None

    knowledge_status_min:     int | None = None
    knowledge_status_max:     int | None = None 
    knowledge_permission_min: int | None = None
    knowledge_permission_max: int | None = None
    knowledge_management_min: int | None = None
    knowledge_management_max: int | None = None

    knowledge_confidence_min: float | None = None
    knowledge_confidence_max: float | None = None
    knowledge_filesize_min:   float | None = None
    knowledge_filesize_max:   float | None = None

    processing_time_min:      float | None = None
    processing_time_max:      float | None = None
    total_input_tokens_min:   int   | None = None
    total_input_tokens_max:   int   | None = None
    total_output_tokens_min:  int   | None = None
    total_output_tokens_max:  int   | None = None
    total_tool_tokens_min:    int   | None = None
    total_tool_tokens_max:    int   | None = None

    average_groundedness_min: float | None = None
    average_groundedness_max: float | None = None
    average_relevance_min:    float | None = None
    average_relevance_max:    float | None = None
    average_retrieval_min:    float | None = None
    average_retrieval_max:    float | None = None
    average_similarity_min:   float | None = None
    average_similarity_max:   float | None = None

class KnowledgeListFilter(BaseModel):
    group_id_or:                  list[str] | None = None
    group_id_and:                 list[str] | None = None
    knowledge_keywords_or:        list[str] | None = None
    knowledge_keywords_and:       list[str] | None = None    
    knowledge_searchstorages_or:  list[str] | None = None
    knowledge_searchstorages_and: list[str] | None = None
    knowledge_sources_or:         list[str] | None = None
    knowledge_sources_and:        list[str] | None = None
    knowledge_sourcetypes_or:     list[str] | None = None
    knowledge_sourcetypes_and:    list[str] | None = None
    knowledge_contenttypes_or:    list[str] | None = None
    knowledge_contenttypes_and:   list[str] | None = None
    knowledge_cats_or:            list[str] | None = None
    knowledge_cats_and:           list[str] | None = None
    knowledge_langauges_or:       list[str] | None = None
    knowledge_langauges_and:      list[str] | None = None
    knowledge_tags_or:            list[str] | None = None
    knowledge_tags_and:           list[str] | None = None
    user_groups_or:               list[str] | None = None
    user_groups_and:              list[str] | None = None
    agent_groups_or:              list[str] | None = None
    agent_groups_and:             list[str] | None = None


class KnowledgeDictionaryFilter(BaseModel):
    storage_secrets_or:          list[str] | None = None
    storage_secrets_and:         list[str] | None = None
    storage_secrets_origin_or:   list[str] | None = None
    storage_secrets_origin_and:  list[str] | None = None

    knowledge_vectorinfo_or:     list[str] | None = None
    knowledge_vectorinfo_and:    list[str] | None = None
    knowledge_graphinfo_or:      list[str] | None = None
    knowledge_graphinfo_and:     list[str] | None = None
    knowledge_searchstorage_or:  list[str] | None = None
    knowledge_searchstorage_and: list[str] | None = None
    knowledge_searchinfo_or:     list[str] | None = None
    knowledge_searchinfo_and:    list[str] | None = None
    knowledge_secrets_or:        list[str] | None = None
    knowledge_secrets_and:       list[str] | None = None

class KnowledgeBooleanFilter(BaseModel):
    pil_active_status_filter: bool | None = None

class KnowledgeDatetimeFilter(BaseModel):
    file_created_datetime_start:       datetime | None = None
    file_created_datetime_end:         datetime | None = None
    file_last_modified_datetime_start: datetime | None = None
    file_last_modified_datetime_end:   datetime | None = None
    reference_start_date_start:        datetime | None = None
    reference_start_date_end:          datetime | None = None
    reference_end_date_start:          datetime | None = None
    reference_end_date_end:            datetime | None = None

    retention_at:                      datetime | None = None

    knowledge_issue_date_start:        datetime  | None = None
    knowledge_issue_date_end:          datetime  | None = None
    knowledge_effective_from_start:    datetime  | None = None
    knowledge_effective_from_end:      datetime  | None = None
    knowledge_effective_to_start:      datetime  | None = None
    knowledge_effective_to_end:        datetime  | None = None

    created_at_start:                  datetime  | None = None
    created_at_end:                    datetime  | None = None
    updated_at_start:                  datetime  | None = None
    updated_at_end:                    datetime  | None = None

class KnowledgeByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class KnowledgeFilter(BaseModel):
    string_filter:     KnowledgeStringFilter     | None = None
    numeric_filter:    KnowledgeNumericFilter    | None = None
    list_filter:       KnowledgeListFilter       | None = None
    dictionary_filter: KnowledgeDictionaryFilter | None = None
    boolean_filter:    KnowledgeBooleanFilter    | None = None
    datetime_filter:   KnowledgeDatetimeFilter   | None = None
    byte_filter:       KnowledgeByteFilter       | None = None
    sorting:           dict={"knowledge_id": "asc"}
    filter_no:         int=-1


""" 
    Request and Resposne for System Access Knowledges
"""
class SystemKnowledgeRequest(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:         KnowledgeFilter=Field(..., description="[Required] Knowledge Filter", example=KnowledgeFilter(
                                        string_filter=KnowledgeStringFilter(
                                            knowledge_id_filter=["knowledge_id_1", "knowledge_id_2"]
                                        ),
                                        numeric_filter=KnowledgeNumericFilter(
                                            knowledge_status_min=1
                                        )
                                    ))  

    class Config:
        schema_extra = {
            "example": {
                "knowledge_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "numeric_filter": {
                        "knowledge_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemKnowledgeResponse(BaseModel):
    knowledge_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data:       list[SecretKnowledge]=Field(default=[], description="Filtered Knowledge Data", example=[SecretKnowledge(
                                        knowledge_id="knowledge_id_1",
                                        knowledge_traceid="knowledge_traceid_1",
                                        knowledge_name="knowledge_name_1",
                                        knowledge_version=1,
                                        knowledge_ingestion_stage="Ingested",
                                        knowledge_processing_stage="Ingest Done",
                                        library_name_en="Test Library",
                                        category_name_en="Test Category",
                                        title_name_en="Test Title",
                                        item_type="Test Type",
                                        item_url="https://example.com/test.pdf",
                                        item_status="Active",
                                        file_name="test.pdf",
                                        file_description="Test File Description",
                                        file_created_datetime=datetime.now(timezone.utc),
                                        file_last_modified_datetime=datetime.now(timezone.utc),
                                        group_id=["group_id_1", "group_id_2"],
                                        file_sync_up_url="https://example.com/test.pdf",
                                        library_id="library_id_1",
                                        category_id="category_id_1",
                                        reference_start_date=datetime.now(timezone.utc),
                                        reference_end_date=datetime.now(timezone.utc),
                                        updated_by="user_id_1",
                                        retention_at=datetime.now(timezone.utc),
                                        pil_active_status=True,
                                        knowledge_group="Test Group",
                                        knowledge_type="Test Type",
                                        knowledge_location="Test Location",
                                        storage_type="Test Storage Type",
                                        storage_type_origin="Test Storage Type Origin",
                                        storage_provider="Test Storage Provider",
                                        storage_provider_origin="Test Storage Provider Origin",
                                        storage_directory="Test Storage Directory",
                                        storage_directory_origin="Test Storage Directory Origin",
                                        storage_secrets={},
                                        storage_secrets_origin={},
                                        knowledge_status=1,
                                        knowledge_permission=1,
                                        knowledge_management=1,
                                        knowledge_vectorstorage="Test Vector Storage",
                                        knowledge_vectorlocation="Test Vector Location",
                                        knowledge_vectorinfo={},
                                        knowledge_graphstorage="Test Graph Storage",
                                        knowledge_graphlocation="Test Graph Location",
                                        knowledge_graphinfo={},
                                        knowledge_searchstorage={},
                                        knowledge_searchinfo={},
                                        knowledge_secrets={},
                                        knowledge_record=True,
                                        knowledge_key="knowledge_key_1",
                                        knowledge_confidence=0.9,
                                        knowledge_filename="test.pdf",
                                        knowledge_fileextension=".pdf",
                                        knowledge_filesize=1024.0,
                                        knowledge_description="Test Knowledge Description",
                                        processing_time=0.1,
                                        total_input_tokens=100,
                                        total_output_tokens=50,
                                        total_tool_tokens=10,
                                        knowledgeinput_id="knowledgeinput_id_1",
                                        prepknow_id="prepknow_id_1",
                                        knowledge_keywords=["keyword_1", "keyword_2"],
                                        knowledge_searchstorages=["searchstorage_1", "searchstorage_2"],
                                        knowledge_sources=["source_1", "source_2"],
                                        knowledge_sourcetypes=["sourcetype_1", "sourcetype_2"],
                                        knowledge_contenttypes=["contenttype_1", "contenttype_2"],
                                        knowledge_cats=["cat_1", "cat_2"],
                                        knowledge_languages=["language_1", "language_2"],
                                        knowledge_tags=["tag_1", "tag_2"],
                                        user_groups=["user_group_1", "user_group_2"],
                                        agent_groups=["agent_group_1", "agent_group_2"],
                                        average_groundedness=0.8,
                                        average_relevance=0.7,
                                        average_retrieval=0.6,
                                        average_similarity=0.5,
                                        knowledge_issue_date=datetime.now(timezone.utc),
                                        knowledge_effective_from=datetime.now(timezone.utc),
                                        knowledge_effective_to=datetime.now(timezone.utc),
                                        created_at=datetime.now(timezone.utc),
                                        updated_at=datetime.now(timezone.utc)
                                    )])
    data_count:          int=Field(default=0, description="Count of Filtered Knowledge Data", example=1)


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class KnowledgeBackupRequest(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:         KnowledgeFilter | None = None
    backup_config:       BackupConfig | None = None

class KnowledgeBackupListRequest(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:       BackupConfig | None = None

class KnowledgeBackupListResponse(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:          list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class KnowledgeRestoreRequest(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:      RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class KnowledgeImportRequest(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:           IOConfig | None = None
    backup:              bool=True

class KnowledgeExportRequest(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:         KnowledgeFilter | None = None
    io_config:           IOConfig | None = None
    include_datetime:    bool = True

    class Config:
        schema_extra = {
            "example": {
                "knowledge_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "numeric_filter": {
                        "knowledge_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "metadata"
                },
                "include_datetime": True
            }
        }

"""" KnowledgeServiceManager """
"""
    Request and Response for User Access Permitted Knowledges
"""
# User-level Access
class Knowledge(BaseModel):
    # Trace Information
    knowledge_id:                str | None = None
    knowledge_traceid:           str | None = None
    knowledge_name:              str | None = None
    knowledge_version:           int | None = None
    knowledge_ingestion_stage:   str | None = None
    knowledge_ingestion_reason:  str | None = None
    knowledge_processing_stage:  str | None = None
    knowledge_processing_reason: str | None = None
    batch_order:                 str | None = None

    # Creator Information
    creator_id:                  str | None = None
    creator_name:                str | None = None
    approver_id:                 str | None = None
    approver_name:               str | None = None

    # PIL Information
    library_name_en:             str | None = None
    library_name_tc:             str | None = None
    category_name_en:            str | None = None
    category_name_tc:            str | None = None
    title_name_en:               str | None = None  
    title_name_tc:               str | None = None
    item_type:                   str | None = None
    item_url:                    str | None = None
    item_status:                 str | None = None
    document_id:                 str | None = None
    file_name:                   str | None = None
    file_description:            str | None = None
    file_created_datetime:       datetime | None = None
    file_last_modified_datetime: datetime | None = None
    group_id:                    List[str] | None = None
    file_sync_up_url:            str | None = None
    library_id:                  str | None = None
    category_id:                 str | None = None
    reference_start_date:        datetime | None = None
    reference_end_date:          datetime | None = None

    updated_by:                  str | None = None
    retention_at:                datetime | None = None
    pil_active_status:           bool | None = None

    # Category Information
    knowledge_group:             str | None = None
    knowledge_type:              str | None = None
    knowledge_location:          str | None = None
    storage_type:                str | None = None
    storage_type_origin:         str | None = None
    storage_provider:            str | None = None
    storage_provider_origin:     str | None = None
    storage_directory:           str | None = None
    storage_directory_origin:    str | None = None
    storage_secrets:             dict | None = None
    storage_secrets_origin:      dict | None = None

    # Control Information
    knowledge_status:            int | None = None
    knowledge_permission:        int | None = None
    knowledge_management:        int | None = None

    # Configuration
    knowledge_vectorstorage:     str  | None = None
    knowledge_vectorlocation:    str  | None = None
    knowledge_vectorinfo:        dict | None = None
    knowledge_graphstorage:      str  | None = None
    knowledge_graphlocation:     str  | None = None
    knowledge_graphinfo:         dict | None = None
    knowledge_searchstorage:     dict | None = None
    knowledge_searchinfo:        dict | None = None
    knowledge_secrets:           dict | None = None
    knowledge_record:            bool | None = None
    knowledge_key:               str  | None = None

    # Specification
    knowledge_confidence:        float | None = None
    knowledge_filename:          str   | None = None
    knowledge_fileextension:     str   | None = None
    knowledge_filesize:          float | None = None
    knowledge_description:       str   | None = None

    # Statistics
    processing_time:             float | None = None
    total_input_tokens:          int   | None = None
    total_output_tokens:         int   | None = None
    total_tool_tokens:           int   | None = None

    # Dependices
    knowledgeinput_id:           str  | None = None
    prepknow_id:                 str  | None = None

    # Tags
    knowledge_keywords:          list[str] | None = None
    knowledge_searchstorages:    list[str] | None = None
    knowledge_sources:           list[str] | None = None
    knowledge_sourcetypes:       list[str] | None = None
    knowledge_contenttypes:      list[str] | None = None
    knowledge_cats:              list[str] | None = None
    knowledge_languages:         list[str] | None = None
    knowledge_tags:              list[str] | None = None
    user_groups:                 list[str] | None = None
    agent_groups:                list[str] | None = None

    # Evaluation Results
    average_groundedness:        float | None = None
    average_relevance:           float | None = None
    average_retrieval:           float | None = None
    average_similarity:          float | None = None

    # Time Information
    knowledge_issue_date:        datetime | None = None
    knowledge_effective_from:    datetime | None = None
    knowledge_effective_to:      datetime | None = None

    created_at:                  datetime | None = None
    updated_at:                  datetime | None = None
    
class UserKnowledgeRequest(BaseModel):
    knowledge_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:         KnowledgeFilter

class UserKnowledgeResponse(BaseModel):
    knowledge_requestid: str
    filtered_data:       list[Knowledge]=[]