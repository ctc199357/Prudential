
"""
    Metadata Data Manager
"""

"""
    Custom Config
"""
from ....settings import SETTINGS
from ..models.metadata_models import MetadataDB
from ..schemas import metadata as schema

DATA_UID               = "file_id"
DATA_OBJECT            = "Metadata"
COLLECTION_NAME        = SETTINGS.META.TABLE

DBClass                = MetadataDB

DataCreate             = schema.MetadataCreate
CreateRequest          = schema.MetadataCreateRequest
UpdateRequest          = schema.MetadataUpdateRequest
DropRequest            = schema.MetadataDropRequest
DataExportRequest      = schema.MetadataExportRequest
DataFilter             = schema.MetadataFilter
DataStringFilter       = schema.MetadataStringFilter
SystemDataRequest      = schema.SystemMetadataRequest
SystemDataResponse     = schema.SystemMetadataResponse

DEFAULT_EXPORT_CONFIG = schema.IOConfig(
    format=SETTINGS.EXPT.FORM,
    location=SETTINGS.EXPT.LOCA,
    name=SETTINGS.EXPT.NAME,
    host=SETTINGS.EXPT.HOST,
    port=SETTINGS.EXPT.PORT,
    user=SETTINGS.EXPT.USER,
    pswd=SETTINGS.EXPT.PSWD,
    table=SETTINGS.EXPT.REGISTRY_TABLE,
    rdir=SETTINGS.EXPT.RDIR,
    sdir=SETTINGS.EXPT.SDIR,
    file_rdir=SETTINGS.EXPT.FILE_RDIR,
    file_sdir=SETTINGS.EXPT.FILE_SDIR,
    file_name=SETTINGS.EXPT.FILE_NAME
)

from ....database.metadata.connections.metadata_connection import get_db_api, get_db_func

# API DB Session
if SETTINGS.BASE.APP_API == True:
    db_api = get_db_api
    default_api_call = True
else:
    db_api = None
    default_api_call = False

# Function DB Session
if SETTINGS.BASE.APP_FUNC == True:
    db_func = get_db_func
else:
    db_func = None
    
"""
    End of Custom Config
"""

import os
from mongoengine.queryset.visitor import Q
from datetime import datetime, timezone
from typing import Generator, Any
import inspect

import json
import csv
import uuid

from ....schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ....logger.log_handler import get_logger

logger = get_logger(__name__)

class DataManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            api_call: bool    = default_api_call,
            db_api:   Generator | None = db_api, 
            db_func:  Any | None = db_func
        ):
        self.api_call = api_call
        self.db_api   = db_api
        self.db_func  = db_func

    """
        General Operation
    """
    # Create
    def create(self, request: CreateRequest) -> Response:
        data = DataCreate(**request.data.__dict__)
        db_data = DBClass(**data.dict())

        try:
            if self.api_call == True:
                with self.db_api():
                    db_data.save()
                    db_data.reload()
            else:
                with self.db_func():
                    db_data.save()
                    db_data.reload()
            response = Response(status_code=201, detail=self.response_format.ok(f"Success : Registered {DATA_OBJECT} <{DATA_UID}: {getattr(data, DATA_UID)}>"))
            logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Registering {DATA_OBJECT} <{DATA_UID}: {getattr(data, DATA_UID)}>", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Registering {DATA_OBJECT} <{DATA_UID}: {getattr(data, DATA_UID)}>"))
            logger.error(response.detail)

        return response
    
    # Update
    def update(self, request: UpdateRequest) -> Response:
        
        # Retrieve data from database
        data_filter = DataFilter(
            string_filter=DataStringFilter(**{f"{DATA_UID}_filter": [getattr(request, DATA_UID)]}),
        )
        conditions, sorting, filter_no = self.filter_formatter(data_filter=data_filter)
        db_data, response              = self.query(conditions=conditions, sorting=sorting, filter_no=filter_no)

        # Check if data exists in database
        if not db_data:
            response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Updating {DATA_OBJECT} <{DATA_UID}: {getattr(request, DATA_UID)}>"))
            logger.error(response.detail)
            return response

        else:
            update_data = {key: value for key, value in request.update_data.__dict__.items() if value is not None}

            if not update_data:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid Update {DATA_OBJECT}"))
                logger.error(response.detail)
                return response

            new_data = DataCreate(**db_data.first().to_dict())
            new_data.__dict__.update(update_data)
            
            new_db_data = DBClass(**new_data.dict())
            
            try:
                old_id = str(uuid.uuid4())
                if self.api_call == True:
                    with self.db_api():
                        db_data.first().update(**{
                            f'set__{DATA_UID}':   old_id
                        })
                        
                        # Add new version
                        new_db_data.save()
                        new_db_data.reload()
                        
                        if request.overwrite == True:
                            DBClass.objects(**{DATA_UID: old_id}).first().delete()
                            
                        
                else:
                    old_id = str(uuid.uuid4())
                    with self.db_func() as db:
                        db_data.first().update(**{
                            f'set__{DATA_UID}':   old_id
                        })
                        
                        # Add new version
                        new_db_data.save()
                        new_db_data.reload()
                        
                        if request.overwrite == True:
                            DBClass.objects(**{DATA_UID: old_id}).first().delete()
                            

                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Updated {DATA_OBJECT} <{DATA_UID}: {getattr(new_data, DATA_UID)}>"))
                logger.info(response.detail)

            # Handle common exceptions that might occur
            except (BaseException, Exception) as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Updating {DATA_OBJECT} <{DATA_UID}: {getattr(new_data, DATA_UID)}>", str(e)))
                logger.error(response.detail)

            # Handle any other exceptions that might occur
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Updating {DATA_OBJECT} <{DATA_UID}: {getattr(new_data, DATA_UID)}>"))
                logger.error(response.detail)

        return response

    # Drop
    def drop(self, request: DropRequest) -> Response:
        try:
            # Retrieve data from database
            data_filter = DataFilter(
                string_filter=DataStringFilter(**{f"{DATA_UID}_filter": [getattr(request, DATA_UID)]})
            )
            conditions, sorting, filter_no = self.filter_formatter(data_filter=data_filter)
            db_data, response              = self.query(conditions=conditions, sorting=sorting, filter_no=filter_no)
            
            if db_data:
                if self.api_call == True:
                    with self.db_api():
                        DBClass.objects(**{DATA_UID: getattr(request, DATA_UID)}).delete()
                else:
                    with self.db_func() as db:
                        DBClass.objects(**{DATA_UID: getattr(request, DATA_UID)}).delete()
                        
                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Dropped {DATA_OBJECT} <{DATA_UID}: {getattr(request, DATA_UID)}>"))
                logger.info(response.detail)
            
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Dropping {DATA_OBJECT} <{DATA_UID}: {getattr(request, DATA_UID)}>"))
                logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Dropping {DATA_OBJECT} <{DATA_UID}: {getattr(request, DATA_UID)}>", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Dropping {DATA_OBJECT} <{DATA_UID}: {getattr(request, DATA_UID)}>"))
            logger.error(response.detail)

        return response

    def query_data_by_system(self, request: SystemDataRequest) -> tuple[SystemDataResponse, Response]:
        response_data = SystemDataResponse(**request.__dict__)

        if request.data_filter:
            data_filter = DataFilter(**request.data_filter.__dict__)
        else:
            data_filter = DataFilter()

        conditions, sorting, filter_no = self.filter_formatter(data_filter=data_filter)
        db_data, response = self.query(conditions=conditions, sorting=sorting, filter_no=filter_no)
        
        if db_data:
            response_data.__dict__.update(filtered_data=[DataCreate(**data.to_dict()) for data in db_data], data_count=len(db_data))
            response = Response(status_code=200, detail=self.response_format.ok("Success : Get Filtered Data from Metadata MongoDB"))
            logger.info(response.detail)
        return response_data, response

    def export_data_by_system(self, request: DataExportRequest) -> Response:
        # Get Data
        if request.data_filter:
            data_filter = DataFilter(**request.data_filter.__dict__)
        else:
            data_filter = DataFilter()

        conditions, sorting, filter_no = self.filter_formatter(data_filter=data_filter)
        db_data, response = self.query(conditions=conditions, sorting=sorting, filter_no=filter_no)

        if db_data:
            filtered_data = [DataCreate(**data.to_dict()).__dict__ for data in db_data]
            response = Response(status_code=200, detail=self.response_format.ok("Success : Get Filtered Data for System"))
        else:
            return response # Return No Data

        response = self.export_data(
            config=request.io_config, 
            data=filtered_data, 
            include_datetime=request.include_datetime
        )
        return response    

    # Perform Query
    def query(self, conditions: list | None = None, sorting: list | None = None, filter_no: int | None = None) -> tuple[list[DBClass] | None, Response]:
        db_data = None
        nested_conditions = None

        # If conditions are provided, combine them with AND logic
        if conditions:
            nested_conditions = conditions[0]
            for _condition in conditions[1:]:
                nested_conditions &= _condition

        try:
            if self.api_call == True:
                if nested_conditions:
                    if not filter_no or filter_no < 0:
                        db_data = DBClass.objects(nested_conditions).order_by(*sorting)
                    else:
                        db_data = DBClass.objects(nested_conditions).order_by(*sorting).limit(filter_no)
                else:
                    if not filter_no or filter_no < 0:
                        db_data = DBClass.objects().order_by(*sorting)
                    else:
                        db_data = DBClass.objects().order_by(*sorting).limit(filter_no)
            else:
                with self.db_func():
                    if nested_conditions:
                        if not filter_no or filter_no < 0:
                            db_data = DBClass.objects(nested_conditions).order_by(*sorting)
                        else:
                            db_data = DBClass.objects(nested_conditions).order_by(*sorting).limit(filter_no)
                    else:
                        if not filter_no or filter_no < 0:
                            db_data = DBClass.objects().order_by(*sorting)
                        else:
                            db_data = DBClass.objects().order_by(*sorting).limit(filter_no)
            
            if db_data:
                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Retrieved Filtered {DATA_OBJECT} from DB"))
            else:
                response = Response(status_code=200, detail=self.response_format.ok(f"Success : No Matched {DATA_OBJECT} from DB"))


        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Getting {DATA_OBJECT}", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Getting {DATA_OBJECT}"))
            logger.error(response.detail)

        return db_data, response

   # Export Data
    def export_data(self, config: schema.IOConfig | None, data: list, include_datetime: bool=True) -> Response:         
        
        # 1. Detect Export Configuration
        if config is None:
            config = DEFAULT_EXPORT_CONFIG.copy()
            response = Response(status_code=200, detail=self.response_format.ok("Info : Empty Export Configuration >>> Use System Default Export Configuration"))
            logger.info(response.detail)

        # 2.1. Init Export File
        if config.format.upper() in SETTINGS.EXPT.FILE_FORM:
            try:
                if include_datetime == True:
                    file_name = config.file_name + '_' + datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")
                file_name = '.'.join([file_name, config.format.lower()])

                if not config.file_sdir:
                    file_root = config.file_rdir
                else:
                    file_root = os.path.join(config.file_rdir, config.file_sdir)

                file_path = os.path.join(file_root, file_name)

            # Handle missing parameters
            except TypeError as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Missing Parameter Error : Exporting Data", str(e)))
                logger.error(response.detail)
                return response

            # Handle any other exceptions that might occur
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Exporting Data"))
                logger.error(response.detail)
                return response

            try:
                os.makedirs(file_root, exist_ok=True)
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Failed to Create Directory when Exporting Data"))
                logger.error(response.detail)
                return response
 
        # 2.3. Handle Unknown Format
        else:
            response = Response(status_code=500, detail=self.response_format.error("Data Export Error : Invalid Data Export Format"))
            logger.error(response.detail)       
            return response 

        # 3. Export Data
        # 3.1. Export to JSON
        if config.format.upper() == 'JSON':
            try:
                with open(file_path, 'w', encoding="utf-8") as json_file:
                    json.dump(data, json_file, cls=ComplexEncoder, ensure_ascii=False, indent=4)
            
                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Exported Data to <{file_path}>"))
                logger.info(response.detail)

            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Data Export Error : Failed to Export Data to <{file_path}>"))
                logger.error(response.detail)
            
        # 3.2. Export to CSV
        elif config.format.upper() == 'CSV':
            try:
                with open(file_path, 'w',  newline='', encoding="utf-8-sig") as csv_file:
                    fieldnames = data[0].keys()
                    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
                    writer.writeheader()    # Write the header
                    writer.writerows(data)  # Write the data
                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Exported Data to <{file_path}>"))
                logger.info(response.detail)

            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Data Export Error : Failed to Export Data to <{file_path}>"))
                logger.error(response.detail)      
        else:
            response = Response(status_code=500, detail=self.response_format.error("Data Export Error : Invalid Data Export Format"))
            logger.error(response.detail)       

        return response


    # Filter Formatter
    def filter_formatter(self, data_filter: DataFilter) -> tuple[list, list, int]:
        conditions = []
        sorting    = []

        # Parsing conditions
        # String Filter
        if data_filter.string_filter is not None:
            string_suffix = '_filter'
            for key, value in data_filter.string_filter.__dict__.items():
                if value is not None:
                    column_name = key.split(string_suffix)[0]
                    try:
                        conditions.append(Q(**{f"{column_name}__in": value}))
                    except AttributeError as e:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for StringFilter must be <key_filter>", str(e)))
                        logger.error(response.detail)
                    except Exception:
                        response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in StringFilter"))
                        logger.error(response.detail)                    

        # Dictionary Filter
        if data_filter.dictionary_filter is not None:
            or_suffix  = '_or'
            and_suffix = '_and'
            for key, value in data_filter.dictionary_filter.__dict__.items():
                if value is not None:
                    if or_suffix in key:
                        column_name = key.split(or_suffix)[0]
                        try:
                            _conditions = [Q(**{f"attribute.{_key}__exists": True}) for _key in value]
                            if _conditions:
                                nested_conditions = _conditions[0]
                                for _condition in _conditions:
                                    nested_conditions |= _condition
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for DictionaryFilter must be <key_or> or <key_and>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in DictionaryFilter"))
                            logger.error(response.detail)     

                    elif and_suffix in key:
                        column_name = key.split(and_suffix)[0]
                        try:
                            _conditions = [Q(**{f"attribute.{_key}__exists": True}) for _key in value]
                            if _conditions:
                                nested_conditions = _conditions[0]
                                for _condition in _conditions:
                                    nested_conditions &= _condition
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for DictionaryFilter must be <key_or> or <key_and>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in DictionaryFilter"))
                            logger.error(response.detail)

                    else:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute Suffix for ListFilter must be Either _or or _and"))
                        logger.error(response.detail)

        # Datetime Filter
        if data_filter.datetime_filter is not None:
            start_suffix = '_start'
            end_suffix   = '_end'
            
            for key, value in data_filter.datetime_filter.__dict__.items():
                if value is not None:
                    if start_suffix in key:
                        column_name = key.split(start_suffix)[0]
                        try:
                            conditions.append(Q(**{f"{column_name}__gte": value}))
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for DatetimeFilter must be <key_start> or <key_end>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in DatetimeFilter"))
                            logger.error(response.detail)              

                    if end_suffix in key:
                        column_name = key.split(end_suffix)[0]
                        try:
                            conditions.append(Q(**{f"{column_name}__lte": value}))
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for DatetimeFilter must be <key_start> or <key_end>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in DatetimeFilter"))
                            logger.error(response.detail)    

                    else:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute Suffix for DatetimeFilter must be Either _start or _end"))
                        logger.error(response.detail)

        # Define sorting order
        for col, direction in data_filter.sorting.items():
            column = getattr(DBClass, col, None)  # Returns None if col is not found
            if column is not None:
                if direction.lower() == "desc":
                    sorting.append(f"-{col}")
                else:
                    sorting.append(f"+{col}")
        
        filter_no = data_filter.filter_no

        return conditions, sorting, filter_no