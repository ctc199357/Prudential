from mongoengine import connect, disconnect
from pymongo.errors import ServerSelectionTimeoutError

import urllib.parse
from contextlib import contextmanager

from ....settings import SETTINGS

from ....logger.log_handler import get_logger

logger = get_logger(__name__)

if SETTINGS.META.FORM.upper() == "MODB":
    from mongoengine import connect, disconnect
    from pymongo.errors import ServerSelectionTimeoutError
    from ..models.metadata_models import MetadataDB

    # Access Database Settings
    DB_URL = '{user}:{pswd}@{host}:{port}/?{other}'.format(
        host=urllib.parse.quote_plus(SETTINGS.META.HOST),  # DB host
        port=urllib.parse.quote_plus(SETTINGS.META.PORT),  # DB port
        other=SETTINGS.META.CONFIG.get("OTHER", ""),  # DB name
        user=urllib.parse.quote_plus(SETTINGS.META.USER),  # DB user
        pswd=urllib.parse.quote_plus(SETTINGS.META.PSWD)   # DB pswd
    )
        
    DATABASE_URL = f"mongodb://{DB_URL}"

    # Test DB Connection
    try:
        connect(SETTINGS.META.NAME, host=DATABASE_URL, alias=SETTINGS.META.NAME)
        logger.info(f"Connected : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.META.NAME}> Database")

    except ServerSelectionTimeoutError:
        err_msg = f"DB Connection Timeout Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.META.NAME}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)

    # Handle any other exceptions that might occur
    except:
        err_msg = f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.META.NAME}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)

    # DB via Function Call
    @contextmanager
    def get_db_func():
        try:
            session = MetadataDB._get_db().client.start_session()
            session.start_transaction()
            yield session
            session.commit_transaction()

        except Exception as e:
            session.abort_transaction()  # Abort the transaction on error
            raise e
        
        finally:
            session.end_session()

    # DB via API Call
    def get_db_api():
        try:
            session = MetadataDB._get_db().client.start_session()
            session.start_transaction()
            yield session
            session.commit_transaction()

        except Exception as e:
            session.abort_transaction()  # Abort the transaction on error
            raise e
        
        finally:
            session.end_session()