from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone

"""
    Metadata Information
"""
class AdditionalInfo(BaseModel):
    sync_by:                     str=Field(default='pil', description="[Optional] Sync By") # Sync By
    sync_dt:                     datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Reference Start Date")

class MetadataCreate(BaseModel):
    file_id:                     str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] File ID")

    library_id:                  str=Field(default='', description="[Optional] Library ID") # Library ID
    library_en_nm:               str=Field(default='', description="Library English Name") # Library English Name
    library_tc_nm:               str=Field(default='', description="[Optional] Library Traditional Chinese Name") # Library Traditional Chinese Name

    category_id:                 str=Field(default='', description="[Optional] Category ID") # Category ID
    category_en_nm:              str=Field(default='', description="Category English Name") # Category English Name
    category_tc_nm:              str=Field(default='', description="[Optional] Category Traditional Chinese Name") # Category Traditional Chinese Name

    title_nm_en:                 str=Field(default='', description="[Optional] Title English Name") # Title English Name
    title_nm_tc:                 str=Field(default='', description="[Optional] Title Traditional Chinese Name") # Title Traditional Chinese Name

    item_type:                   str=Field(default='', description="[Optional] Item Type") # Item Type
    item_url:                    str=Field(default='', description="[Optional] Item URL") # Item URL
    item_status:                 str=Field(default='', description="[Optional] Item Status") # Item Status

    document_id:                 str=Field(default='', description="Document ID") # Document ID

    file_nm:                     str=Field(default='', description="File Name") # File Name
    file_desc:                   str=Field(default='', description="[Optional] File Description") # File Description

    file_created_dt:             datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] File Created Date")
    file_lastmodified_dt:        datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] File Last Modified Date")
    file_lastmodified_author_email: str=Field(default='', description="[Optional] File Last Modified Author Email")
    file_lastmodified_author_nm: str=Field(default='', description="[Optional] File Last Modified Author Name")

    access_group:                list[str]=Field(default=[], description="[Optional] Access Group") # Access Group

    file_sync_url_from:          str=Field(default='', description="[Optional] File Sync URL from") # File Sync URL from

    file_launch_dt:              datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] File Launch Date")
    file_expiry_eff_dt:          datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] File Expiry Effective Date")
    file_archive_dt:             datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] File Archive Date")

    file_sync_url_to:            str=Field(default='', description="[Optional] File Sync URL to") # File Sync URL to
    file_type:                   str=Field(default='', description="[Optional] File Type") # File Type

    additional_info:             AdditionalInfo=Field(default=AdditionalInfo(), description="[Optional] Additional Information") # Additional Information

class MetadataUpdate(BaseModel):
    file_id:                     str | None = None

    library_id:                  str | None = None
    library_en_nm:               str | None = None
    library_tc_nm:               str | None = None

    category_id:                 str | None = None
    category_en_nm:              str | None = None
    category_tc_nm:              str | None = None

    title_nm_en:                 str | None = None
    title_nm_tc:                 str | None = None

    item_type:                   str | None = None
    item_url:                    str | None = None
    item_status:                 str | None = None

    document_id:                 str | None = None

    file_nm:                     str | None = None
    file_desc:                   str | None = None

    file_created_dt:             datetime | None = None
    file_lastmodified_dt:        datetime | None = None
    file_lastmodified_author_email: str | None = None
    file_lastmodified_author_nm: str | None = None

    access_group:                list[str] | None = None

    file_sync_url_from:          str | None = None

    file_launch_dt:              datetime | None = None
    file_expiry_eff_dt:          datetime | None = None
    file_archive_dt:             datetime | None = None

    file_sync_url_to:            str | None = None
    file_type:                   str | None = None

    additional_info:             AdditionalInfo | None = None

"""
    Metadata Filter
"""   
class MetadataDictionaryFilter(BaseModel):
    library_id_or:         list[str] | None = None
    library_id_and:        list[str] | None = None
    library_en_nm_or:      list[str] | None = None
    library_en_nm_and:     list[str] | None = None
    library_tc_nm_or:      list[str] | None = None
    library_tc_nm_and:     list[str] | None = None
    category_id_or:        list[str] | None = None
    category_id_and:       list[str] | None = None
    category_en_nm_or:     list[str] | None = None
    category_en_nm_and:    list[str] | None = None
    category_tc_nm_or:     list[str] | None = None
    category_tc_nm_and:    list[str] | None = None
    document_id_or:        list[str] | None = None
    document_id_and:       list[str] | None = None
    file_nm_or:            list[str] | None = None
    file_nm_and:           list[str] | None = None

class MetadataStringFilter(BaseModel):
    file_id_filter:        list[str] | None = None

    library_id_filter:     list[str] | None = None
    library_en_nm_filter:  list[str] | None = None
    library_tc_nm_filter:  list[str] | None = None

    category_id_filter:    list[str] | None = None
    category_en_nm_filter: list[str] | None = None
    category_tc_nm_filter: list[str] | None = None

    title_nm_en_filter:    list[str] | None = None
    title_nm_tc_filter:    list[str] | None = None

    item_type_filter:      list[str] | None = None
    item_url_filter:       list[str] | None = None
    item_status_filter:    list[str] | None = None

    document_id_filter:    list[str] | None = None

    file_nm_filter:        list[str] | None = None
    file_desc_filter:      list[str] | None = None

    file_lastmodified_author_email_filter: list[str] | None = None
    file_lastmodified_author_nm_filter: list[str] | None = None

    file_sync_url_from_filter:          list[str] | None = None
    file_sync_url_to_filter:            list[str] | None = None
    file_type_filter:                   list[str] | None = None

class MetadataDatetimeFilter(BaseModel):
    file_created_datetime_start:       datetime | None = None
    file_created_datetime_end:         datetime | None = None
    file_last_modified_datetime_start: datetime | None = None
    file_last_modified_datetime_end:   datetime | None = None

    file_launch_dt_start:              datetime | None = None
    file_launch_dt_end:                datetime | None = None
    file_expiry_eff_dt_start:          datetime | None = None
    file_expiry_eff_dt_end:            datetime | None = None
    file_archive_dt_start:             datetime | None = None
    file_archive_dt_end:               datetime | None = None

class MetadataFilter(BaseModel):
    string_filter:       MetadataStringFilter | None = None
    dictionary_filter:   MetadataDictionaryFilter | None = None
    datetime_filter:     MetadataDatetimeFilter | None = None
    filter_no:           int=-1
    sorting:             dict={"file_id": "asc"}

"""
    Query Request
"""
class SystemMetadataRequest(BaseModel):
    metadata_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:        MetadataFilter=Field(default=None, description="[Optional] Metadata Filter", example=MetadataFilter(
                                                string_filter=MetadataStringFilter(
                                                    file_id_filter=["file_id_1", "file_id_2"]
                                                )
                                            ))  

"""
    Query Response
"""
class SystemMetadataResponse(BaseModel):
    metadata_requestid: str = Field(..., description="Unique ID for the Request")
    filtered_data:      list[MetadataCreate] = Field(default=[], description="Filtered Metadata Data", example=[MetadataCreate(
                                        file_id="file_id_1",
                                        library_id="library_id_1",
                                        library_en_nm="Library Name",
                                        library_tc_nm="Library Name",
                                        category_id="category_id_1",
                                        category_en_nm="Category Name",
                                        category_tc_nm="Category Name",
                                        title_nm_en="Title Name",
                                        title_nm_tc="Title Name",
                                        item_type="Item Type",
                                        item_url="Item URL",
                                        item_status="Item Status",
                                        document_id="Document ID",
                                        file_nm="File Name",
                                        file_desc="File Description",
                                        file_created_datetime=datetime.now(timezone.utc),
                                        file_last_modified_datetime=datetime.now(timezone.utc),
                                        file_lastmodified_author_email="Email",
                                        file_lastmodified_author_nm="Name",
                                        file_sync_url_from="Sync URL",
                                        file_sync_url_to="Sync URL",
                                        file_type="File Type",
                                        additional_info=AdditionalInfo(
                                            sync_by="Sync By",
                                            sync_dt=datetime.now(timezone.utc)
                                        )
                                    )])
    data_count:         int = Field(default=0, description="Count of Filtered Metadata", example=1)

"""
    Data Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

"""
    Export Request
"""
class MetadataExportRequest(BaseModel):
    metadata_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        MetadataFilter | None = None
    io_config:          IOConfig | None = None
    include_datetime:   bool = True


"""
    Create, Update, Drop Request
"""
class MetadataDropRequest(BaseModel):
    metadata_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    file_id:            str=Field(..., description="[Required] File ID for the Request")

class MetadataCreateRequest(BaseModel):
    metadata_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data:               MetadataCreate=Field(..., description="[Required] Metadata Data", example=MetadataCreate())

class MetadataUpdateRequest(BaseModel):
    metadata_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    file_id:            str=Field(..., description="[Required] File ID for the Update")
    update_data:        MetadataUpdate=Field(..., description="[Required] Metadata Data", example=MetadataUpdate())
    overwrite:          bool=Field(default=True, description="[Optional] Overwrite Flag for the Update") # Overwrite Flag for the Update