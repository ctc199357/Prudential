from datetime import datetime, timezone

from ....settings import SETTINGS

if SETTINGS.DATB.FORM.upper() in ["MODB"]:
    from mongoengine import *

    class AdditionalInfo(EmbeddedDocument):
        sync_by                     = StringField(default="manual", choices=("manual", "pil"))
        sync_dt                     = DateTimeField(default=datetime.now(timezone.utc))

    class MetadataDB(Document):

        file_id                     = StringField(unique = True, required = True)

        library_id                  = StringField(default = "", required = True,  description = "id for PIL library")
        library_en_nm               = StringField(default = "")
        library_tc_nm               = StringField(default = "")

        category_id                 = StringField(default = "", required = True)
        category_en_nm              = StringField(default = "")
        category_tc_nm              = StringField(default = "")

        title_nm_en                 = StringField(default = "")
        title_nm_tc                 = StringField(default = "")

        item_type                   = StringField(default = "", description = "PIL item type, like attachment, item, etc.")
        item_url                    = StringField(default = "", desccription = "the item's url in PIL")
        item_status                 = StringField(default = "", description = "item status in PIL")

        document_id                 = StringField(default = "")

        file_nm                     = StringField(default = "", required = True, description = "the file name, like CIM claim process.pdf")
        file_desc                   = StringField(default = "")

        file_created_dt             = DateTimeField(default = datetime(1900,1, 1))
        file_lastmodified_dt        = DateTimeField(default = datetime(1900,1, 1))
        file_lastmodified_author_email = StringField(default = "")
        file_lastmodified_author_nm = StringField(default = "")

        access_group                = ListField(StringField(), default = [])

        file_sync_url_from          = URLField(required = True)

        file_launch_dt              = DateTimeField(default = datetime(1900, 1, 1))
        file_expiry_eff_dt          = DateTimeField(default = datetime(1900, 1, 1))
        file_archive_dt             = DateTimeField(default = datetime(1900, 1, 1))

        file_sync_url_to            = URLField(required = True)
        file_type                   = StringField(default = "")

        additional_info             = EmbeddedDocumentField(AdditionalInfo, default=AdditionalInfo)

        meta = {
            "collection": SETTINGS.META.TABLE,
            "db_alias": SETTINGS.META.NAME,
            'indexes': [
                'file_id',
                'library_id',
                'category_id',
                'document_id',
                'file_nm'
            ]
        }

        def to_dict(self):
            return {**self.to_mongo().to_dict()}