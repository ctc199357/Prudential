import os
import urllib.parse
from contextlib import contextmanager

from ....database.vector.models.io_models import vb_ex_schema, vb_ex_schema_index_params

from ....settings import SETTINGS
from ....logger.log_handler import get_logger

logger = get_logger(__name__)

if SETTINGS.VTEX.FORM.upper() == "AISEARCH":
    from azure.core.exceptions import ResourceNotFoundError
    from azure.core.credentials import AzureKeyCredential
    from azure.search.documents import SearchClient
    from azure.search.documents.indexes import SearchIndexClient
    from azure.search.documents.indexes.models import SearchIndex, SimpleField, SearchableField
    import azure.search.documents.indexes.models._edm as edm
    from azure.search.documents.indexes.models import SearchResourceEncryptionKey

    API_KEY          = SETTINGS.VTEX.PSWD
    INDEX_NAME       = SETTINGS.VTEX.TABLE
    ENCRYPTION_CONFIG = SETTINGS.VTEX.CONFIG.get("encryption_config", None)
    
    def init_ex_index(
        index_name:             str=INDEX_NAME,
        vb_schema:              list=vb_ex_schema,
        vb_schema_index_params: dict=vb_ex_schema_index_params
    ):

        # Create Search Index
        if ENCRYPTION_CONFIG:
            #encrytion_config = {"key_name": "ai-search-key", "key_version": "5da730552ec4405f9dbce6cfb2f363ae", "vault_uri": "https://kvahklifedevaz2z5oxk5001.vault.azure.net"}
            encryption_key = SearchResourceEncryptionKey(**ENCRYPTION_CONFIG)
            ex_index = SearchIndex(
                name           = index_name, 
                fields         = vb_schema,
                vector_search  = vb_schema_index_params, 
                encryption_key = encryption_key
            )
        else:
            ex_index = SearchIndex(
                name   = index_name, 
                fields = vb_schema,
                vector_search = vb_schema_index_params
            )
            
        # Test DB Connection
        try:
            # Init Schema
            ex_index_client = SearchIndexClient(    
                endpoint=SETTINGS.VTEX.HOST,
                credential=AzureKeyCredential(API_KEY)
            )
            
            try:
                ex_index_client.get_index(index_name)
            except:
                ex_index_client.create_or_update_index(ex_index)

            logger.info(f"Connected : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.VTEX.NAME}> Vector Export Index")
        # Handle any operational errors that might occur
        except Exception as e:  
            err_msg = f"Connection Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.VTEX.NAME}> Vector Export Database"
            logger.error(err_msg)
            raise Exception(err_msg)
        
        # Handle any other exceptions that might occur
        except:
            err_msg = f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.VTEX.NAME}> Vector Export Database"
            logger.error(err_msg)
            raise Exception(err_msg)

    # DB via Function Call
    @contextmanager
    def get_ex_vb_func(index_name: str=INDEX_NAME):
        try:
            # Init VB Client
            vb_client = SearchClient(
                endpoint   = SETTINGS.VTEX.HOST,
                index_name = index_name,
                credential = AzureKeyCredential(API_KEY)
            )
            yield vb_client
        except Exception as e:
            logger.error(f"Failed in Initializing Connection to Vector Export Database via Function Call --- {str(e)}")
            raise e
            
    # DB via API Call
    def get_ex_vb_api(index_name: str=INDEX_NAME):
        try:
            # Init VB Client
            vb_client = SearchClient(
                endpoint   = SETTINGS.VTEX.HOST,
                index_name = index_name,
                credential = AzureKeyCredential(API_KEY)
            )
            return vb_client
        except Exception as e:
            logger.error(f"Failed in Initializing Connection to Vector Export Database via Function Call --- {str(e)}")
            raise e

else:
    err_msg = f"Unknown DB Error : <{SETTINGS.VTEX.NAME}> Export Database"
    logger.error(err_msg)
    raise Exception(err_msg)