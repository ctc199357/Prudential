from pydantic import BaseModel
from typing import List

class TableInfo(BaseModel):
    table_name:     str=''
    data_count:     int=-1

class VBTableInfoResponse(BaseModel):
    total_table_count: int=-1
    total_data_count:  int=-1
    table_info:        List[TableInfo]=[]

class VBTableRenameRequest(BaseModel):
    org_name: str
    new_name: str


"""
    DB Connection
"""
class BackupDatabaseConfiguration(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

"""
    Import/Export DB Connection
"""
class IODatabaseConfiguration(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None