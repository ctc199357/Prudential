from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone
from typing import Any

from ....settings import SETTINGS

""""
    Vector General Operation
"""

class VectorCreate(BaseModel):
    # Trace Information
    data_id:        str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Trace ID for the Vector")
    data_version:   int=Field(default=1, description="[Optional] Version Number for the Vector")    

    # Category Information
    data_type:      str=Field(default='', description="Data Type - text, title, image, table, document") # TEXT, TITLE, IMAGE, TABLE, DOCUMENT, etc.
    content_type:   str=Field(default='default', description="Content Type - default, image2text, ocr") # TEXT, IMAGE, TABLE, etc.
    data_url:       str=Field(default='', description="Data URL - URL for the Data (Image / Talbe)") # URL for the Data

    # Control Information
    data_status:    int=Field(default=1, description="Data Status - 0: Inactive, 1: Active") # Data Status - 0: Created, 1: Processed, 2: Error

    # Specification
    raw_data:       str=Field(default='', description="Raw Data in Plaintext") # Original Data
    processed_data: list[float]=Field(default=[], description="Processed Data in Vector") # Processed Data in Vector
    data_dimension: int=Field(default=-1, description="Data Dimension - Number of Dimensions in the Vector") # Data Dimension - Number of Dimensions in the Vector
    data_length:    int=Field(default=0, description="Data Length - Length of the Raw Text") # Data Length - Length of the Data

    coord_x1:       float=Field(default=-1.0, description="X1 Coordinate - X1 Coordinate of the Data") # X1 Coordinate - X1 Coordinate of the Data
    coord_x2:       float=Field(default=-1.0, description="X2 Coordinate - X2 Coordinate of the Data") # X2 Coordinate - X2 Coordinate of the Data
    coord_y1:       float=Field(default=-1.0, description="Y1 Coordinate - Y1 Coordinate of the Data") # Y1 Coordinate - Y1 Coordinate of the Data
    coord_y2:       float=Field(default=-1.0, description="Y2 Coordinate - Y2 Coordinate of the Data") # Y2 Coordinate - Y2 Coordinate of the Data

    page_start:     int=Field(default=-1, description="Page Start - Page Start Number") # Page Start - Page Start Number
    page_end:       int=Field(default=-1, description="Page End - Page End Number") # Page End - Page End Number
    line_start:     int=Field(default=-1, description="Line Start - Line Start Number") # Line Start - Line Start Number
    line_end:       int=Field(default=-1, description="Line End - Line End Number") # Line End - Line End Number
    seq_no:         int=Field(default=-1, description="Sequence Number - Sequence Number of the Data in Document Parsing") # Sequence Number - Sequence Number of the Data

    # Dependent
    knowledge_id:   str=Field(default='', description="Knowledge ID - ID of the Knowledge") # Knowledge ID - ID of the Knowledge
    node_id:        str=Field(default='', description="Node ID - ID of the Node in Graph") # Node ID - ID of the Node
    node_type:      str=Field(default='', description="Node Type - Type of the Node in Graph") # Node Type - Type of the Node

    # Tags
    data_languages: list[str]=Field(default=[], description="Data Languages - List of Languages in the Data") # Data Languages - List of Languages in the Data
    data_keywords:  list[str]=Field(default=[], description="Data Keywords - List of Keywords in the Data") # Data Keywords - List of Keywords in the Data
    data_tags:      list[str]=Field(default=[], description="Data Tags - List of Tags in the Data") # Data Tags - List of Tags in the Data

    # Time Information
    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Created At - Creation Time of the Data")
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Updated At - Last Update Time of the Data") # Updated At - Last Update Time of the Data

class VectorCreateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Vector")
    user_name:      str=Field(default="", description="[Optional] User Name for the Vector")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Vector")
    data:           VectorCreate=Field(..., description="Vector Data - VectorCreate Object", example=VectorCreate(
                        data_id="12345",
                        data_traceid="67890",
                        data_version=1,
                        data_type="image",
                        content_type="image2text",
                        data_url="http://example.com/data",
                        data_status=1,
                        raw_data="This is a sample text.",
                        processed_data=[0.1, 0.2, 0.3],
                        data_dimension=3,
                        data_length=20,
                        coord_x1=0.0,
                        coord_x2=1.0,
                        coord_y1=0.0,
                        coord_y2=1.0,
                        page_start=1,
                        page_end=1,
                        line_start=1,
                        line_end=1,
                        seq_no=1,
                        knowledge_id="knowledge_123",
                        node_id="node_123",
                        node_type="node_type_123",
                        data_languages=["en", "fr"],
                        data_keywords=["keyword1", "keyword2"],
                        data_tags=["tag1", "tag2"],
                        created_at=datetime.now(timezone.utc),
                        updated_at=datetime.now(timezone.utc)
                    )
                )
    prepmedia_config: dict=Field(default=SETTINGS.VTDB.PREPMEIDA_CONFIG, description="[Optional] Preprocessing Media Configuration - Configuration for Preprocessing Media")


class VectorBatchCreateRequest(BaseModel):
    create_requests: list[VectorCreateRequest]

# Vector CRUD
class VectorUpdate(BaseModel):
    # Trace Information
    data_id:        str | None = None
    data_traceid:   str | None = None
    data_version:   int | None = None

    # Category Information
    data_type:      str | None = None
    content_type:   str | None = None
    data_url:       str | None = None

    # Control Information
    data_status:    int | None = None

    # Specification
    raw_data:       str | None = None
    processed_data: list[float] | None = None
    data_dimension: int | None = None
    data_length:    int | None = None

    coord_x1:       float | None = None
    coord_x2:       float | None = None
    coord_y1:       float | None = None
    coord_y2:       float | None = None
    seq_no:         int | None = None

    page_start:     int | None = None
    page_end:       int | None = None
    line_start:     int | None = None
    line_end:       int | None = None

    # Dependent
    knowledge_id:   str | None = None
    node_id:        str | None = None
    node_type:      str | None = None

    # Tags
    data_languages: list[str] | None = None
    data_keywords:  list[str] | None = None
    data_tags:      list[str] | None = None

    # Time Information
    created_at:     datetime | None = None
    updated_at:     datetime | None = None

class VectorUpdateRequest(BaseModel):
    user_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:          str=Field(default="", description="[Optional] User ID for the Vector")
    user_name:        str=Field(default="", description="[Optional] User Name for the Vector")
    is_admin:         bool=Field(default=False, description="[Optional] Is Admin Flag for the Vector")
    data_id:          str=Field(..., description="Data ID - ID of the Data to be Updated")
    update_data:      VectorUpdate=Field(..., description="Update Data - VectorUpdate Object", example=VectorUpdate(
                                        raw_data="125")
                                    )
    prepmedia_config: dict=Field(default=SETTINGS.VTDB.PREPMEIDA_CONFIG, description="[Optional] Preprocessing Media Configuration - Configuration for Preprocessing Media")
    overwrite:        bool=Field(default=True, description="[Optional] Overwrite Flag - Flag to Overwrite the Existing Data")
    
class VectorRequest(BaseModel):
    user_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:          str=Field(default="", description="[Optional] User ID for the Vector")
    user_name:        str=Field(default="", description="[Optional] User Name for the Vector")
    data_id:          str=Field(..., description="Data ID - ID of the Data to be Used")

class VectorBatchRequest(BaseModel):
    vector_requests: list[VectorRequest]


# System-level Access
class SecretVector(BaseModel):
    # Trace Information
    data_id:        str | None = None
    data_traceid:   str | None = None
    data_version:   int | None = None

    # Category Information
    data_type:      str | None = None
    content_type:   str | None = None
    data_url:       str | None = None

    # Control Information
    data_status:    int | None = None

    # Specification
    raw_data:       str | None = None
    processed_data: list[float] | None = None
    data_dimension: int | None = None
    data_length:    int | None = None

    coord_x1:       float | None = None
    coord_x2:       float | None = None
    coord_y1:       float | None = None
    coord_y2:       float | None = None

    page_start:     int | None = None
    page_end:       int | None = None
    line_start:     int | None = None
    line_end:       int | None = None
    seq_no:         int | None = None

    # Dependent
    knowledge_id:   str | None = None
    node_id:        str | None = None
    node_type:      str | None = None

    # Tags
    data_languages: list[str] | None = None
    data_keywords:  list[str] | None = None
    data_tags:      list[str] | None = None

    # Time Information
    created_at:     datetime | None = None
    updated_at:     datetime | None = None

"""
    Vector Filter
"""   
class VectorStringFilter(BaseModel):
    data_id_filter:        list[str] | None = None
    data_traceid_filter:   list[str] | None = None

    data_type_filter:      list[str] | None = None
    content_type_filter:   list[str] | None = None
    data_url_filter:       list[str] | None = None

    raw_data_filter:       list[str] | None = None

    knowledge_id_filter:   list[str] | None = None
    node_id_filter:        list[str] | None = None
    node_type_filter:      list[str] | None = None


class VectorNumericFilter(BaseModel):
    data_version_min:   int | None = None
    data_version_max:   int | None = None

    data_status_min:    int | None = None
    data_status_max:    int | None = None 

    data_dimension_min: int | None = None
    data_dimension_max: int | None = None
    data_length_min:    int | None = None
    data_length_max:    int | None = None

    coord_x1_min:       float | None = None
    coord_x1_max:       float | None = None
    coord_x2_min:       float | None = None
    coord_x2_max:       float | None = None
    coord_y1_min:       float | None = None
    coord_y1_max:       float | None = None
    coord_y2_min:       float | None = None
    coord_y2_max:       float | None = None

    page_start_min:     int | None = None
    page_start_max:     int | None = None
    page_end_min:       int | None = None
    page_end_max:       int | None = None
    line_start_min:     int | None = None
    line_start_max:     int | None = None
    line_end_min:       int | None = None
    line_end_max:       int | None = None
    seq_no_min:         int | None = None
    seq_no_max:         int | None = None

class VectorListFilter(BaseModel):
    data_languages_or:  list[str] | None = None
    data_languages_and: list[str] | None = None
    data_keywords_or:   list[str] | None = None
    data_keywords_and:  list[str] | None = None
    data_tags_or:       list[str] | None = None
    data_tags_and:      list[str] | None = None

class VectorDictionaryFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None

class VectorBooleanFilter(BaseModel):
    not_used_filter: bool | None = None

class VectorDatetimeFilter(BaseModel):
    created_at_start: datetime  | None = None
    created_at_end:   datetime  | None = None
    updated_at_start: datetime  | None = None
    updated_at_end:   datetime  | None = None

class VectorByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class VectorFilter(BaseModel):
    string_filter:     VectorStringFilter     | None = None
    numeric_filter:    VectorNumericFilter    | None = None
    list_filter:       VectorListFilter       | None = None
    dictionary_filter: VectorDictionaryFilter | None = None
    boolean_filter:    VectorBooleanFilter    | None = None
    datetime_filter:   VectorDatetimeFilter   | None = None
    byte_filter:       VectorByteFilter       | None = None
    sorting:           dict={"data_id": "asc", "updated_at": "desc"}
    batch_index:       int=1
    batch_size:        int=-1

class VectorFilterResult(BaseModel):
    filtered_vectors: list[SecretVector]=[]
    batch_index:      int=1
    batch_size:       int=-1
    vector_count:     int=0
    batch_count:      int=0

""" 
    Request and Resposne for System Access Vectors
"""
class SystemVectorRequest(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    vector_filter:    VectorFilter=Field(..., description="Vector Filter - VectorFilter Object", example=VectorFilter(
                                                string_filter=VectorStringFilter(
                                                    data_id_filter=["12345", "67890"]
                                                ),
                                                numeric_filter=VectorNumericFilter(
                                                    data_status_min=1
                                                )
                                            )
                                        )   

    class Config:
        schema_extra = {
            "example": {
                "vector_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "vector_filter": {
                    "numeric_filter": {
                        "data_status_min": 0
                    },
                    "sorting": {
                        "data_id": "asc", 
                        "updated_at": "desc"
                    },
                    "batch_index": 1,
                    "batch_size": 100
                }
            }
        }

class SystemVectorResponse(BaseModel):
    vector_requestid: str=Field(..., description="Vector Request ID - Unique ID for the Request Request")
    filtered_vectors: list[SecretVector]=Field(default=[], description="Filtered Vectors - List of Filtered Vectors", example=[
                                                SecretVector(
                                                    data_id="12345",
                                                    data_traceid="67890",
                                                    data_version=1,
                                                    data_type="image",
                                                    content_type="image2text",
                                                    data_url="http://example.com/data",
                                                    data_status=1,
                                                    raw_data="This is a sample text.",
                                                    processed_data=[0.1, 0.2, 0.3],
                                                    data_dimension=3,
                                                    data_length=20,
                                                    coord_x1=0.0,
                                                    coord_x2=1.0,
                                                    coord_y1=0.0,
                                                    coord_y2=1.0,
                                                    page_start=1,
                                                    page_end=1,
                                                    line_start=1,
                                                    line_end=1,
                                                    seq_no=1,
                                                    knowledge_id="knowledge_123",
                                                    node_id="node_123",
                                                    node_type="node_type_123",
                                                    data_languages=["en", "fr"],
                                                    data_keywords=["keyword1", "keyword2"],
                                                    data_tags=["tag1", "tag2"],
                                                    created_at=datetime.now(timezone.utc),
                                                    updated_at=datetime.now(timezone.utc)
                                                )
                                            ]
                                        )
    vector_no:        int=Field(default=0, description="Vector Number - Number of Filtered Vectors", example=1)


"""
    Data Backup / Restore Configuration
"""
class BackupConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None
    limit:    int | None = None

class VectorBackupRequest(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    vector_filter:    VectorFilter | None = None
    backup_config:            BackupConfig | None = None

class VectorBackupListRequest(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    backup_config:            BackupConfig | None = None

class VectorBackupListResponse(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    table_list:               list[str]=[]

class RestoreConfig(BaseModel):
    format:   str | None = None
    location: str | None = None
    name:     str | None = None
    host:     str | None = None
    port:     str | None = None
    user:     str | None = None
    pswd:     str | None = None
    table:    str | None = None
    rdir:     str | None = None
    sdir:     str | None = None

class VectorRestoreRequest(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    restore_config:           RestoreConfig | None = None


"""
    Data Import/Export Configuration
"""
class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

class VectorImportRequest(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    io_config:                IOConfig | None = None
    backup:                   bool=True

class VectorExportRequest(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    vector_filter:    VectorFilter | None = None
    io_config:        IOConfig | None = None
    include_datetime: bool = True

    class Config:
        schema_extra = {
            "example": {
                "vector_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "vector_filter": {
                    "numeric_filter": {
                        "data_status_min": 0
                    },
                    "sorting": {
                        "data_id": "asc", 
                        "updated_at": "desc"
                    },
                    "batch_index": -1,
                    "batch_size": 1000
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "vector"
                },
                "include_datetime": False
            }
        }


"""" VectorServiceManager """
"""
    Request and Response for User Access Permitted Vectors
"""
# User-level Access
class Vector(BaseModel):
    # Trace Information
    data_id:        str | None = None
    data_traceid:   str | None = None
    data_version:   int | None = None

    # Category Information
    data_type:      str | None = None
    content_type:   str | None = None
    data_url:       str | None = None

    # Control Information
    data_status:    int | None = None

    # Specification
    raw_data:       str | None = None
    processed_data: list[float] | None = None
    data_dimension: int | None = None
    data_length:    int | None = None

    coord_x1:       float | None = None
    coord_x2:       float | None = None
    coord_y1:       float | None = None
    coord_y2:       float | None = None

    page_start:     int | None = None
    page_end:       int | None = None
    line_start:     int | None = None
    line_end:       int | None = None
    seq_no:         int | None = None

    # Dependent
    knowledge_id:   str | None = None
    node_id:        str | None = None
    node_type:      str | None = None

    # Tags
    data_languages: list[str] | None = None
    data_keywords:  list[str] | None = None
    data_tags:      list[str] | None = None

    # Time Information
    created_at:     datetime | None = None
    updated_at:     datetime | None = None

    
class UserVectorRequest(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    vector_filter:    VectorFilter

class UserVectorResponse(BaseModel):
    vector_requestid: str
    filtered_vectors: list[Vector]=[]

"""
    Partitioning
"""
class PartitionRequest(BaseModel):
    vector_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    vector_filter:    VectorFilter
    field_name:       str

class PartitionResponse(BaseModel):
    vector_requestid: str
    partitions:       list[Any]=[]