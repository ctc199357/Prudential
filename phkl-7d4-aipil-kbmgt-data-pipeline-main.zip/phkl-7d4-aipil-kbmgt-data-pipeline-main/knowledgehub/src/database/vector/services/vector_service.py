from datetime import datetime, timezone
import inspect

from typing import Any, Generator

from ....settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.database import (
    TableInfo,
    VBTableInfoResponse,
    VBTableRenameRequest,
    BackupDatabaseConfiguration,
    IODatabaseConfiguration
)

from ....logger.log_handler import get_logger

logger = get_logger(__name__)

# Init Manager Mapping
manager_map = {}
if SETTINGS.VTDB.FORM.upper() == "AISEARCH":
    from ..services.vb_aisearch_service import AISearchManager
    manager_map["AISEARCH"] = AISearchManager

class VBManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            vb_form: str=SETTINGS.VTDB.FORM,
            vb_name: str=SETTINGS.VTDB.TABLE,
            vb_host: str=SETTINGS.VTDB.HOST,
            vb_key:  str=SETTINGS.VTDB.PSWD
        ):
        self.vb_form = vb_form
        self.vb_name = vb_name
        self.vb_host = vb_host
        self.vb_key  = vb_key

        self.manager = manager_map.get(self.vb_form.upper(), None)

    def get_primary_vb_info(self) -> tuple[VBTableInfoResponse, Response]:
        response_data = VBTableInfoResponse()

        try:
            response_data, response = self.manager(
                vb_name = self.vb_name,
                vb_host = self.vb_host,
                vb_key  = self.vb_key
            ).get_primary_vb_info()

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encounter Unexpected Error in Vector Service Managment"))
            logger.error(response.detail)
                
        return response_data, response

    def get_vb_table_info(self) -> tuple[VBTableInfoResponse, Response]:
        response_data = VBTableInfoResponse()

        try:
            response_data, response = self.manager(
                vb_name = self.vb_name,
                vb_host = self.vb_host,
                vb_key  = self.vb_key
            ).get_vb_table_info()

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encounter Unexpected Error in Vector Service Managment"))
            logger.error(response.detail)
                
        return response_data, response


    def drop_table(self, table_name: str) -> Response:
        
        try:
            response = self.manager(
                vb_name = self.vb_name,
                vb_host = self.vb_host,
                vb_key  = self.vb_key
            ).drop_table(table_name=table_name)

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encounter Unexpected Error in Vector Service Managment"))
            logger.error(response.detail)
            
        return response