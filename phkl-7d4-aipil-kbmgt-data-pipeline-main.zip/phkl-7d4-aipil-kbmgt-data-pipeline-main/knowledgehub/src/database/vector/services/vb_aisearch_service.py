from datetime import datetime, timezone
import inspect

from typing import Generator

from azure.core.exceptions import ResourceNotFoundError
from azure.search.documents.indexes import SearchIndexClient
from azure.core.credentials import AzureKeyCredential


from ....settings import SETTINGS

from ....utils import delete_blob_folder

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.database import (
    TableInfo,
    VBTableInfoResponse,
    VBTableRenameRequest,
    BackupDatabaseConfiguration,
    IODatabaseConfiguration
)

from ....logger.log_handler import get_logger

logger = get_logger(__name__)


class AISearchManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            vb_name: str=SETTINGS.VTDB.TABLE,
            vb_host: str=SETTINGS.VTDB.HOST,
            vb_key:  str=SETTINGS.VTDB.PSWD
        ):
        self.vb_name = vb_name
        self.vb_host = vb_host
        self.vb_key  = vb_key

    def get_primary_vb_info(self) -> tuple[VBTableInfoResponse, Response]:
        response_data = VBTableInfoResponse()

        try:
            index_client = SearchIndexClient(    
                endpoint=SETTINGS.VTDB.HOST,
                credential=AzureKeyCredential(self.vb_key)
            )

            table_info = [
                TableInfo(
                    table_name=self.vb_name,
                    data_count=index_client.get_index_statistics(self.vb_name).get('document_count', 0)
                )
            ]
            
            response_data = VBTableInfoResponse(
                total_table_count = len(table_info),
                total_data_count  = sum([info.data_count for info in table_info]),
                table_info        = table_info
            )

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Got VB Table Info"))

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"VB Unexpected Error : <{self.vb_name}> Database"))
            logger.error(response.detail)
            return response_data, response
        
        return response_data, response



    def get_vb_table_info(self) -> tuple[VBTableInfoResponse, Response]:
        response_data = VBTableInfoResponse()

        try:
            index_client = SearchIndexClient(    
                endpoint=SETTINGS.VTDB.HOST,
                credential=AzureKeyCredential(self.vb_key)
            )

            indexes = index_client.list_index_names()

            if not indexes:
                response_data = VBTableInfoResponse(
                    total_table_count = 0,
                    total_data_count  = 0
                )
            else:
                table_info = [
                    TableInfo(
                        table_name=index,
                        data_count=index_client.get_index_statistics(index).get('document_count', 0)
                    )
                    for index in indexes
                ]
                
                response_data = VBTableInfoResponse(
                    total_table_count = len(table_info),
                    total_data_count  = sum([info.data_count for info in table_info]),
                    table_info        = table_info
                )

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Got VB Table Info"))

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"VB Unexpected Error : <{self.vb_name}> Database"))
            logger.error(response.detail)
            return response_data, response
        
        return response_data, response


    def drop_table(self, table_name: str) -> Response:
        
        try:
            index_client = SearchIndexClient(    
                endpoint=SETTINGS.VTDB.HOST,
                credential=AzureKeyCredential(self.vb_key)
            )
            index_client.delete_index(table_name)
            response = Response(status_code=200, detail=self.response_format.ok(f"VB Drop Success : <{SETTINGS.BASE.APP_NAME}> Completed Dropping Data"))
            
        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"VB Unexpected Error : <{self.vb_name}> Database"))
            logger.error(response.detail)
            return response
        
        # Delete old index files and folder on Azure Blob Storage.
        try:
            blob_folder_path = f"{SETTINGS.BLOB.VECTOR_FOLDER_NAME}/{self.vb_name}/" # Make sure to include the trailing slash
            delete_blob_folder(blob_folder_path=blob_folder_path)

            # TODO: retrieve all data, and delete each image blob file if not data_url
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"VB Unexpected Error : <{self.vb_name}> Database"))
            logger.error(response.detail)
            return response

        return response