import os
from datetime import datetime, timezone
import shutil
import uuid
import inspect
import math
import httpx

from typing import Generator

import json
import csv
from azure.core.exceptions import ResourceNotFoundError
from ....settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient
from azure.storage.blob import BlobClient, BlobServiceClient, ContentSettings
import requests

from ..schemas.vector import(
    VectorCreate,
    VectorCreateRequest, 
    VectorBatchCreateRequest,
    VectorUpdateRequest, 
    VectorRequest,
    VectorBatchRequest,
    Vector, 
    SecretVector,
    VectorFilter,
    UserVectorRequest,
    UserVectorResponse,
    SystemVectorRequest,
    SystemVectorResponse,
    BackupConfig,
    RestoreConfig,
    VectorBackupRequest,
    VectorBackupListRequest,
    VectorBackupListResponse,
    VectorRestoreRequest,
    IOConfig,
    VectorImportRequest,
    VectorExportRequest,
    VectorFilterResult,
    PartitionRequest,
    PartitionResponse
)

from ..schemas.utils import (
    PrepMediaPipelineRequest,
    PrepMediaPipelineResponse,
    KnowDataObject
)

from ....utils import (
    upload_to_blob,
    check_blob_file_exists,
    delete_blob_file,
    delete_blob_file_by_url
)

from ..services import request_exec_prepmedia
from ....services import init_preprocessing_temp_storage

from ....database.vector.connections.vector_connection import get_vb_func, get_vb_api
from ....database.vector.connections.io_connection import get_ex_vb_func, get_ex_vb_api, init_ex_index

from openai import AzureOpenAI
import time

# API DB Session
if SETTINGS.BASE.APP_API == True:
    vb_api = get_vb_api()
    default_api_call = True
else:
    vb_api = None
    default_api_call = False

# Function DB Session
if SETTINGS.BASE.APP_FUNC == True:
    vb_func = get_vb_func
else:
    vb_func = None

from ....logger.log_handler import get_logger

logger = get_logger(__name__)


class AISearchDataManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    blob_url_prefix = f"https://{SETTINGS.BLOB.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BLOB.CONTAINER_NAME}/"

    # default_backup_config = BackupConfig(
    #     format=SETTINGS.BKUP.FORM,
    #     location=SETTINGS.BKUP.LOCA,
    #     name=SETTINGS.BKUP.NAME,
    #     host=SETTINGS.BKUP.HOST,
    #     port=SETTINGS.BKUP.PORT,
    #     user=SETTINGS.BKUP.USER,
    #     pswd=SETTINGS.BKUP.PSWD,
    #     table=SETTINGS.BKUP.TABLE,
    #     rdir=SETTINGS.BKUP.RDIR,
    #     sdir=SETTINGS.BKUP.SDIR,
    #     limit=SETTINGS.BKUP.LIMIT
    # )

    default_export_config = IOConfig(
        format=SETTINGS.VTEX.FORM,
        location=SETTINGS.VTEX.LOCA,
        name=SETTINGS.VTEX.NAME,
        host=SETTINGS.VTEX.HOST,
        port=SETTINGS.VTEX.PORT,
        user=SETTINGS.VTEX.USER,
        pswd=SETTINGS.VTEX.PSWD,
        table=SETTINGS.VTEX.TABLE,
        rdir=SETTINGS.VTEX.RDIR,
        sdir=SETTINGS.VTEX.SDIR,
        file_rdir=SETTINGS.VTEX.FILE_RDIR,
        file_sdir=SETTINGS.VTEX.FILE_SDIR,
        file_name=SETTINGS.VTEX.FILE_NAME
    )

    def __init__(
            self, 
            api_call:        bool | None = default_api_call,
            vb_api:          SearchClient | None = vb_api, 
            vb_func:         Generator    | None = vb_func, 
            vector_storage:  str='AISEARCH', 
            vector_location: str='azure', 
            vector_config:   dict={},
        ):
        self.api_call        = api_call
        self.vb_api          = vb_api
        self.vb_func         = vb_func
        self.vector_storage  = vector_storage
        self.vector_location = vector_location
        self.vector_config   = vector_config

    def create_data_check(self, requests: list[VectorCreateRequest]) -> tuple[list[VectorCreate], Response]:
        create_data = []

        for request in requests:
            data = request.data   

            # Handle Image
            if data.data_url and data.data_type.lower() == 'image' and not data.processed_data:
                if request.prepmedia_config.get("image", None):
                    _prepmedia_config = request.prepmedia_config.get("image", None)
                else:
                    _prepmedia_config = SETTINGS.VTDB.PREPMEIDA_CONFIG.get("image", None)

                if not _prepmedia_config:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid PrepMedia Config for Updating Image Content"))
                    logger.error(response.detail)
                    return create_data, response
                
                knowdataobject = KnowDataObject(
                    data_url  = data.data_url,
                    data_type = 'IMAGE'
                )
                
                prepmedia_request = PrepMediaPipelineRequest(
                    prepmedia_id = _prepmedia_config,
                    prepmedia_input  = [knowdataobject]
                )
                response_data, response = self.preprocess_prepmedia(request=prepmedia_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return create_data, response
                
                if not response_data.prepmedia_output:
                    response = Response(status_code=500, detail=self.response_format.error(f"Preprocessing Error : Invalid PrepMedia Output for Updating Image Content"))
                    logger.error(response.detail)
                    return create_data, response

                for _data in response_data.prepmedia_output:
                    if (data.content_type.lower() == _data.content_type.lower()): # IMAGE may have two outputs returned (image2text/ocr)
                        vector_data = VectorCreate(**data.__dict__)
                        
                        if not data.data_keywords:
                            vector_data.data_keywords = _data.data_keywords

                        if not data.data_languages:
                            vector_data.data_languages = _data.data_languages

                        vector_data.__dict__.update(
                            **{
                                "processed_data": _data.processed_data,
                                "data_dimension": _data.data_dimension,
                                "data_length":    _data.data_length
                            }
                        )
                        
                        create_data.append(vector_data)
            
            # Handle Table
            elif data.data_url and data.data_type.lower() == 'table' and not data.processed_data:
                if request.prepmedia_config.get("table", None):
                    _prepmedia_config = request.prepmedia_config.get("table", None)
                else:
                    _prepmedia_config = SETTINGS.VTDB.PREPMEIDA_CONFIG.get("table", None)

                if not _prepmedia_config:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid PrepMedia Config for Updating Table Content"))
                    logger.error(response.detail)
                    return create_data, response
                
                knowdataobject = KnowDataObject(
                    data_url  = data.data_url,
                    data_type = 'TABLE',
                    raw_data = data.raw_data
                )
                
                prepmedia_request = PrepMediaPipelineRequest(
                    prepmedia_id = _prepmedia_config,
                    prepmedia_input  = [knowdataobject]
                )
                response_data, response = self.preprocess_prepmedia(request=prepmedia_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return create_data, response
                
                if not response_data.prepmedia_output:
                    response = Response(status_code=500, detail=self.response_format.error(f"Preprocessing Error : Invalid PrepMedia Output for Updating Table Content"))
                    logger.error(response.detail)
                    return create_data, response

                for _data in response_data.prepmedia_output:
                    vector_data = VectorCreate(**data.__dict__)
                    
                    if not data.data_keywords:
                        vector_data.data_keywords = _data.data_keywords

                    if not data.data_languages:
                        vector_data.data_languages = _data.data_languages

                    vector_data.__dict__.update(
                        **{
                            "processed_data": _data.processed_data,
                            "data_dimension": _data.data_dimension,
                            "data_length":    _data.data_length
                        }
                    )
                    
                    create_data.append(vector_data)
            
            # Handle Text / Document
            elif data.raw_data and not data.processed_data:
                if request.prepmedia_config.get("text", None):
                    _prepmedia_config = request.prepmedia_config.get("text", None)
                else:
                    _prepmedia_config = SETTINGS.VTDB.PREPMEIDA_CONFIG.get("text", None)

                if not _prepmedia_config:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid PrepMedia Config for Updating Raw Content"))
                    logger.error(response.detail)
                    return create_data, response
                
                knowdataobject = KnowDataObject(
                    raw_data  = data.raw_data,
                    data_type = 'TEXT'
                )
                prepmedia_request = PrepMediaPipelineRequest(
                    prepmedia_id = _prepmedia_config,
                    prepmedia_input  = [knowdataobject]
                )
                response_data, response = self.preprocess_prepmedia(request=prepmedia_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return create_data, response
                
                if not response_data.prepmedia_output:
                    response = Response(status_code=500, detail=self.response_format.error(f"Preprocessing Error : Invalid PrepMedia Output for Updating Text Content"))
                    logger.error(response.detail)
                    return create_data, response

                for _data in response_data.prepmedia_output:
                    vector_data = VectorCreate(**data.__dict__)
                    
                    if not data.data_keywords:
                        vector_data.data_keywords = _data.data_keywords

                    if not data.data_languages:
                        vector_data.data_languages = _data.data_languages

                    vector_data.__dict__.update(
                        **{
                            "processed_data": _data.processed_data,
                            "data_dimension": _data.data_dimension,
                            "data_length":    _data.data_length
                        }
                    )
                    
                    create_data.append(vector_data)
            
            else:
                create_data.append(data)
        
        response = self.clear_preprocessing_temp_storage()
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return create_data, response
        
        response = Response(status_code=200, detail=self.response_format.ok(f"Success: All Data Checking Passed"))
        return create_data, response


    """
        Data-level General Operation
    """
    # Create
    def create(
            self, 
            request: VectorCreateRequest
        ) -> Response:
        
        # # Validate parameters with creator role
        # response = self.verify_vector_content(is_admin=request.is_admin, data=request.data)
        # if response:
        #     return response

        create_data, response = self.create_data_check(requests=[request])
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response

        try:
            entities = [{key: value  for key, value in _data.__dict__.items()} for _data in create_data]
            if self.api_call == True:
                self.vb_api.upload_documents(
                    documents = entities
                )
            else:
                with self.vb_func() as vb:
                    vb.upload_documents(
                    documents = entities
                )
            response = Response(status_code=201, detail=self.response_format.ok(f"Success : Registered Vector <data_id: {create_data[0].data_id}>"))
            logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Registering Vector <data_id: {create_data[0].data_id}>", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Registering Vector <data_id: {create_data[0].data_id}>"))
            logger.error(response.detail)
            return response

        # Backup all records to Azure Blob Storage
        response = self.backup_data_to_blob(data=create_data)

        return response

    # Batch Create
    def batch_create(
            self, 
            request: VectorBatchCreateRequest
        ) -> Response:
        
        _data_list = []
        admin_list = []

        # for _request in request.create_requests:
        #     if isinstance(_request.data, VectorCreate):
        #         _data_list.append(_request.data)
        #         admin_list.append(_request.is_admin)
        #     elif isinstance(_request.data, dict):
        #         _data_list.append(VectorCreate(**_request.data))
        #         admin_list.append(_request.is_admin)
        #     else:
        #         logger.error(f"Invalid Data Type for <{_request.data}>")

        # # Validate parameters with creator role
        # # for is_admin, data in zip(admin_list, _data_list):
        # #     response = self.verify_vector_content(is_admin=is_admin, data=data)
        # #     if response:
        # #         return response

        vb_data_batch, response = self.create_data_check(requests=request.create_requests)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response

        if not vb_data_batch:
            response = Response(status_code=404, detail=self.response_format.error("Unfound Data Batch for Creation"))
            return response

        try:
            entities = [{key: value  for key, value in data.__dict__.items()} for data in vb_data_batch]
            if self.api_call == True:
                self.vb_api.upload_documents(
                    documents = entities
                )
            else:
                with self.vb_func() as vb:
                    vb.upload_documents(
                    documents = entities
                )
            response = Response(status_code=201, detail=self.response_format.ok(f"Success : Batch Registered All <{len(request.create_requests)}> Vectors"))
            logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Batch Registering Vector", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Batch Registering Vector"))
            logger.error(response.detail)
            return response

        # Backup all records to Azure Blob Storage
        response = self.backup_data_to_blob(data=vb_data_batch)
        
        return response
    

    def update(
            self, 
            request: VectorUpdateRequest
        ) -> Response:
        
        # Retrieve data from database
        db_data = self.get_data_by_data_id(
            id     = request.data_id,
            active = False
        )

        # Check if data exists in database
        if not db_data:
            response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Updating Vector Data <data_id: {request.data_id}>"))
            logger.error(response.detail)
            return response

        # Handle Image
        if request.update_data.data_url:
            if request.prepmedia_config.get("image", None):
                _prepmedia_config = request.prepmedia_config.get("image", None)
            else:
                _prepmedia_config = SETTINGS.VTDB.PREPMEIDA_CONFIG.get("image", None)

            if not _prepmedia_config:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid PrepMedia Config for Updating Image Content"))
                logger.error(response.detail)
                return response
            
            knowdataobject = KnowDataObject(
                data_url  = request.update_data.data_url,
                data_type = 'IMAGE'
            )
            
            prepmedia_request = PrepMediaPipelineRequest(
                prepmedia_id = _prepmedia_config,
                prepmedia_input  = [knowdataobject]
            )

            response_data, response = self.preprocess_prepmedia(request=prepmedia_request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response
            
            outputs = [_output for _output in response_data.prepmedia_output if _output.content_type.upper() == db_data.get("content_type", "").upper()]

            if not outputs:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid Content Type for Updating Image Content"))
                logger.error(response.detail)
            else:
                prepmedia_output = outputs[0]

            # Update Keywords if not Specified Keywords
            if not request.update_data.data_keywords:
                request.update_data.data_keywords = prepmedia_output.data_keywords
            if not request.update_data.data_languages:
                request.update_data.data_languages = prepmedia_output.data_languages

            request.update_data.__dict__.update(
                **{
                    "raw_data":       prepmedia_output.raw_data,
                    "processed_data": prepmedia_output.processed_data,
                    "data_dimension": prepmedia_output.data_dimension,
                    "data_length":    prepmedia_output.data_length
                }
            )

        # Handle Text
        elif request.update_data.raw_data and not request.update_data.processed_data:
            if request.prepmedia_config.get("text", None):
                _prepmedia_config = request.prepmedia_config.get("text", None)
            else:
                _prepmedia_config = SETTINGS.VTDB.PREPMEIDA_CONFIG.get("text", None)

            if not _prepmedia_config:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid PrepMedia Config for Updating Raw Content"))
                logger.error(response.detail)
                return response
            
            knowdataobject = KnowDataObject(
                raw_data  = request.update_data.raw_data,
                data_type = 'TEXT'
            )
            prepmedia_request = PrepMediaPipelineRequest(
                prepmedia_id = _prepmedia_config,
                prepmedia_input  = [knowdataobject]
            )
            response_data, response = self.preprocess_prepmedia(request=prepmedia_request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response
            
            # Update Keywords if not Specified Keywords
            if not request.update_data.data_keywords:
                request.update_data.data_keywords =  response_data.prepmedia_output[0].data_keywords
            if not request.update_data.data_languages:
                request.update_data.data_languages =  response_data.prepmedia_output[0].data_languages

            request.update_data.__dict__.update(
                **{
                    "processed_data":  response_data.prepmedia_output[0].processed_data,
                    "data_dimension":  response_data.prepmedia_output[0].data_dimension,
                    "data_length":     response_data.prepmedia_output[0].data_length
                }
            )

            request.update_data.processed_data = response_data.prepmedia_output[0].processed_data

        # Parse Update Data        
        update_data = {key: value for key, value in request.update_data.__dict__.items() if value is not None}

        if not update_data:
            response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid Update Vector Data"))
            logger.error(response.detail)
            return response

        new_data = db_data.copy()
        new_data.update(update_data)
        if "data_version" not in update_data.keys():
            new_data["data_version"] += 1
        new_data["updated_at"] = datetime.now(timezone.utc)

        old_data = db_data.copy()
        old_data["data_id"]     = str(uuid.uuid4())
        old_data["data_status"] = 0
        old_data["updated_at"]  = datetime.now(timezone.utc)
        
        if request.overwrite == False:
            update_db_data = [old_data, new_data]
        else:
            update_db_data = [new_data]
        
        try:
            if self.api_call == True:
                self.vb_api.merge_or_upload_documents(documents=update_db_data)
            else:
                with self.vb_func() as vb:
                    vb.merge_or_upload_documents(documents=update_db_data)       

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Updated Vector <data_id: {new_data['data_id']}>"))
            logger.info(response.detail)

        # Handle Unfound errors
        except ResourceNotFoundError as e:
            response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Data are not Found in Vector DB <data_id: {new_data['data_id']}>", str(e)))
            logger.error(response.detail)
            return response

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Updating Data <data_id: {new_data['data_id']}>", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Updating  Data <data_id: {new_data['data_id']}"))
            logger.error(response.detail)
            return response
        
        # backup new data to blob storage
        response = self.backup_data_to_blob(data=[VectorCreate(**new_data)])
        
        return response

    # Activate
    def activate(
            self, 
            request: VectorRequest
        ) -> Response:
        try:
            db_data = self.get_data_by_data_id(
                id       = request.data_id,
                active   = False
            )

            if db_data:
                db_data["data_status"] = 1
                db_data["updated_at"]  = datetime.now(timezone.utc)

                if self.api_call == True:
                    self.vb_api.merge_or_upload_documents(documents=db_data)
                else:
                    with self.vb_func() as vb:
                        vb.merge_or_upload_documents(documents=db_data)      

                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Activated Data <data_id: {request.data_id}>"))
                logger.info(response.detail)
                
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Activating Data <data_id: {request.data_id}>"))
                logger.error(response.detail)
                return response

        # Handle Unfound errors
        except ResourceNotFoundError as e:
            response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Data are not Found in Vector DB <data_id: {request.data_id}>", str(e)))
            logger.error(response.detail)
            return response

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Updating Data <data_id: {request.data_id}>", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Updating  Data <data_id: {request.data_id}"))
            logger.error(response.detail)
            return response

        # Backup all records to Azure Blob Storage
        response = self.backup_data_to_blob(data=[VectorCreate(**db_data)])

        return response

    # Batch Activate
    def batch_activate(
            self, 
            request: VectorBatchRequest
        ) -> Response:
        update_data = []
        try:
            for data in request.vector_requests:
                db_data = self.get_data_by_data_id(
                    id     = data.data_id,
                    active = False
                )

                # Check if data exists
                if db_data:
                    db_data["data_status"] = 1
                    db_data["updated_at"]  = datetime.now(timezone.utc)
                    update_data.append(db_data)
                
                else:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Activating Vector <data_id: {data.data_id}>"))
                    logger.error(response.detail)
                    return response

            if not update_data:
                response = Response(status_code=404, detail=self.response_format.error("Unfound error : Failed to Load Conditions for Batch Activation"))
                logger.error(response.detail)
                return response
            
            # Update status
            if self.api_call == True:
                self.vb_api.merge_or_upload_documents(documents=update_data)
            else:
                with self.vb_func() as vb:
                    vb.merge_or_upload_documents(documents=update_data)    

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Batch Activated <{len(request.vector_requests)}> Vectors"))
            logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Batch Activating Vector", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Batch Activating Vector"))
            logger.error(response.detail)
            return response

        # Backup all records to Azure Blob Storage
        update_data = [VectorCreate(**_data) for _data in update_data]
        response = self.backup_data_to_blob(data=update_data)

        return response


    # Deactivate
    def deactivate(
            self, 
            request: VectorRequest
        ) -> Response:
        try:
            db_data = self.get_data_by_data_id(
                id      = request.data_id, 
                active  = True
            )

            if db_data:
                db_data["data_status"] = 0
                db_data["updated_at"]  = datetime.now(timezone.utc)

                if self.api_call == True:
                    self.vb_api.merge_or_upload_documents(documents=db_data)
                else:
                    with self.vb_func() as vb:
                        vb.merge_or_upload_documents(documents=db_data)      

                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Deactivated Vector <data_id: {request.data_id}>"))
                logger.info(response.detail)
            
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Deactivating Vector <data_id: {request.data_id}>"))
                logger.error(response.detail)
                return response

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Deactivating Vector <data_id: {request.data_id}>", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Deactivating Vector <data_id: {request.data_id}>"))
            logger.error(response.detail)
            return response

        # Backup all records to Azure Blob Storage
        response = self.backup_data_to_blob(data=[VectorCreate(**db_data)])

        return response


    # Batch Deactivate
    def batch_deactivate(
            self, 
            request: VectorBatchRequest
        ) -> Response:
        update_data = []
        try:
            for data in request.vector_requests:
                db_data = self.get_data_by_data_id(
                    id     = data.data_id,
                    active = True
                )

                # Check if data exists
                if db_data:
                    db_data["data_status"] = 0
                    db_data["updated_at"]  = datetime.now(timezone.utc)
                    update_data.append(db_data)
                
                else:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Deactivating Vector <data_id: {data.data_id}>"))
                    logger.error(response.detail)
                    return response

            if not update_data:
                response = Response(status_code=404, detail=self.response_format.error("Unfound error : Failed to Load Conditions for Batch Deactivation"))
                logger.error(response.detail)
                return response
            
            # Update status
            if self.api_call == True:
                self.vb_api.merge_or_upload_documents(documents=update_data)
            else:
                with self.vb_func() as vb:
                    vb.merge_or_upload_documents(documents=update_data)    

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Batch Deactivated <{len(request.vector_requests)}> Vectors"))
            logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Batch Deactivating Vector", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Batch Deactivating Vector"))
            logger.error(response.detail)
            return response

        # Backup all records to Azure Blob Storage
        update_data = [VectorCreate(**_data) for _data in update_data]
        response = self.backup_data_to_blob(data=update_data)

        return response


    # Delete
    def delete(self, request: VectorRequest) -> Response:
        response = self.deactivate(request=request)
    
    # Batch Delete
    def batch_delete(self, request: VectorRequest) -> Response:
        response = self.batch_deactivate(request=request)
        return response

    # Drop
    def drop(self, request: VectorRequest) -> Response:
        try:
            db_data = self.get_data_by_data_id(
                id     = request.data_id,
                active = False
            )

            if db_data:
                conditions = [{"data_id": db_data["data_id"]}]
                if self.api_call:
                   self.vb_api.delete_documents(documents=conditions)
                else:
                    with self.vb_func() as vb:
                       vb.delete_documents(documents=conditions)

                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Dropped Vector <data_id: {request.data_id}>"))
                logger.info(response.detail)
            
            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Dropping Vector <data_id: {request.data_id}>"))
                logger.error(response.detail)
                return response

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Dropping Vector <data_id: {request.data_id}>", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Dropping Vector <data_id: {request.data_id}>"))
            logger.error(response.detail)
            return response

        # Delete data on Azure Blob Storage. 
        response = self.delete_data_from_blob(data=[VectorCreate(**db_data)])

        return response

    # Batch Drop
    def batch_drop(self, request: VectorBatchRequest) -> Response:
        update_data = []
        drop_data = []
        try:
            for data in request.vector_requests:
                db_data = self.get_data_by_data_id(
                    id      = data.data_id, 
                    active  = False
                )

                # Check if data exists
                if db_data:
                    update_data.append({"data_id": db_data["data_id"]})
                    drop_data.append(VectorCreate(**db_data))
                else:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Dropping Vector <data_id: {data.data_id}>"))
                    logger.error(response.detail)
                    return response

            if not update_data:
                response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Dropping Vector <data_id: {data.data_id}>"))
                logger.error(response.detail)
                return response

            # Delete data
            if self.api_call == True:
                self.vb_api.delete_documents(documents=update_data)
            else:
                with self.vb_func() as vb:
                    vb.delete_documents(documents=update_data)  

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Batch Dropped <{len(request.vector_requests)}> Vector"))
            logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Batch Dropping Vector", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Batch Dropping Vector"))
            logger.error(response.detail)
            return response

        # Delete data on Azure Blob Storage. 
        response = self.delete_data_from_blob(data=drop_data)

        return response


    """
        System Operation
    """
    def drop_inactive_by_system(self) -> Response:
        conditions = []
        filter_query = 'data_status eq 0'
        try:
            if self.api_call == True:
                results = self.vb_api.search(search_text="*", filter=filter_query)
            else:
                with self.vb_func() as vb:
                    results = vb.search(search_text="*", filter=filter_query)
        
            if results:
                conditions = [{"data_id": data_id} for data_id in list(results)]

            if self.api_call:
               self.vb_api.delete_documents(documents=conditions)
            else:
                with self.vb_func() as vb:
                   vb.delete_documents(documents=conditions)
        
        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Dropping Inactive Vectors", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Dropping Inactive Vectors"))
            logger.error(response.detail)
            return response

        # Delete data on Azure Blob Storage. 
        drop_data = [VectorCreate(**_data) for _data in conditions]
        response = self.delete_data_from_blob(data=drop_data)

        return response

    # System Query Data
    def query_data_by_system(self, request: SystemVectorRequest) -> tuple[SystemVectorResponse, Response]:
        response_data = SystemVectorResponse(**request.__dict__)

        if request.vector_filter:
            data_filter = VectorFilter(**request.vector_filter.__dict__)
        else:
            data_filter = VectorFilter()

        conditions, sorting, batch_index, batch_size = self.filter_formatter(data_filter=data_filter)
        filter_result, response = self.query_with_conditions(conditions=conditions, sorting=sorting, batch_index=batch_index, batch_size=batch_size)
    
        response_data.__dict__.update(filtered_vectors=filter_result.filtered_vectors, vector_no=filter_result.vector_count)
        response = Response(status_code=200, detail=self.response_format.ok("Success : Get Filtered Data for System"))
    
        return response_data, response

    # System Export Data
    def export_data_by_system(self, request: VectorExportRequest) -> Response:

        logger.info("Processing : Exporting Data")

        # Use default export configuration if none provided
        config = request.io_config
        if config is None:
            config = self.default_export_config.copy()
            logger.info("Using default export configuration")

        if config.format.upper() in SETTINGS.VTEX.DB_FORM: # Valid DB
            if config.format.upper() == "AISEARCH":
                try:
                    init_ex_index(index_name=config.table)
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Init Index for Data Export", str(e)))
                    logger.error(response.detail)
                    return response

        # response_data, response = self.partition_data_by_field(
        #     request = PartitionRequest(
        #         vector_filter=data_filter,
        #         field_name="knowledge_id"
        #     )
        # )

        # Get Data
        if request.vector_filter:
            data_filter = VectorFilter(**request.vector_filter.__dict__)
        else:
            data_filter = VectorFilter(batch_index=-1)

        conditions, sorting, batch_index, batch_size = self.filter_formatter(data_filter=data_filter)
        filter_query = ' and '.join(conditions)

        try:
            logger.info("Processing : Identifying Partitions for Export")
            if self.api_call == True:
                search_results = self.vb_api.search(
                    search_text="*", 
                    filter=filter_query,
                    select="knowledge_id",
                    facets=["knowledge_id,count:0"],
                    top=0
                )


            else:
                with self.vb_func() as vb:
                    search_results = vb.search(
                        search_text="*", 
                        filter=filter_query,
                        select="knowledge_id",
                        facets=["knowledge_id,count:0"],
                        top=0
                    )
            
            knowledge_ids = [facet['value'] for facet in search_results.get_facets().get("knowledge_id", [])]

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Getting Vectors", str(e)))
            logger.error(response.detail)
            return response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Getting Vectors"))
            logger.error(response.detail)  
            return response

        logger.info(f"Detected <{len(knowledge_ids)}> Partitions")
        for knowledge_index, knowledge_id in enumerate(knowledge_ids, start=1):
            logger.info(f"Processing : Exporting <{knowledge_index} / {len(knowledge_ids)}> Partition")

            # Detect Number of Batches
            _conditions = conditions.copy()
            _conditions.append(f"knowledge_id eq \'{knowledge_id}\'")
            filtered_result, response = self.query_with_conditions(
                conditions=_conditions,
                sorting=sorting,
                batch_index=-1,
                batch_size=batch_size
            )

            logger.info(f"Detected <{filtered_result.vector_count}> Data and Divided into <{filtered_result.batch_count}> Batches. Each Batch Contains <{filtered_result.batch_size}> Data")
            if request.vector_filter.batch_index <= 0:
                range_start = 1
                range_end   = filtered_result.batch_count + 1
            else:
                range_start = request.vector_filter.batch_index
                range_end   = request.vector_filter.batch_index + 1

            for _i, _batch_index in enumerate(range(range_start, range_end), start=1):
                logger.info(f"Export In Progress : Processing <{_i} / {len(range(range_start, range_end))}> Batch for <{knowledge_index} / {len(knowledge_ids)}> Partition")
                batch_filtered_result, response = self.query_with_conditions(
                    conditions=_conditions, 
                    sorting=sorting, 
                    batch_index=_batch_index, 
                    batch_size=batch_size
                )

                data = [VectorCreate(**_data.__dict__).__dict__ for _data in batch_filtered_result.filtered_vectors]
                
                # # Hot Fix
                # for _data in data:
                #     if "售富" in _data.raw_data:
                #         _data.raw_data.replace("售富", "雋富")
                #         _data.processed_data = []
                #         for keyword in _data.data_keywords:
                #             keyword.replace("售富", "雋富")

                # create_data = self.create_data_check(requests=[VectorCreateRequest(data=_data) for _data in data])
                # data = [_data.__dict__ for _data in create_data]

                # # Setup Azure Text Analytics client for language detection
                # text_analytics_client = None
                # try:
                #     AZURE_ANALYTICS_ENDPOINT = "https://azure-cog-806082.cognitiveservices.azure.com/"
                #     AZURE_ANALYTICS_KEY = "2324a3a4dfd84e0a8f7d9e32536d7d50" 
                   
                #     text_analytics_client = TextAnalyticsClient(
                #         endpoint=AZURE_ANALYTICS_ENDPOINT,
                #         credential=AzureKeyCredential(AZURE_ANALYTICS_KEY)
                #     )
                #     logger.info("Azure Text Analytics client successfully configured with hardcoded values")
                # except Exception as e:
                #     logger.error(f"Failed to initialize Azure Text Analytics client: {str(e)}. Using default language 'en'.")
               
                # # Process data in batches for language detection
                # if text_analytics_client:
                #     batch_size = 10
                #     for i in range(0, len(data), batch_size):
                #         batch_data = []
                #         batch_indices = []
                       
                #         # Prepare batch data for language detection
                #         for j, item in enumerate(data[i:i+batch_size]):
                #             if 'raw_data' in item and item['raw_data']:
                #                 batch_data.append(item['raw_data'])
                #                 batch_indices.append(i+j)
                       
                #         if batch_data:
                #             # Detect language for batch
                #             language_response = text_analytics_client.detect_language(documents=batch_data)
                           
                #             # Update language information for each item
                #             for idx, doc_idx in enumerate(batch_indices):
                #                 if idx < len(language_response):
                #                     lang_result = language_response[idx]
                #                     languages = []
                                   
                #                     if not hasattr(lang_result, 'is_error') or not lang_result.is_error:
                #                         if hasattr(lang_result, 'primary_language') and hasattr(lang_result.primary_language, 'iso6391_name'):
                #                             detected_primary_lang = lang_result.primary_language.iso6391_name
                #                             if detected_primary_lang == 'zh_cht' or detected_primary_lang == 'zh_chs':
                #                                 primary_language = detected_primary_lang
                #                             else:
                #                                 primary_language = 'en'
                                           
                #                             languages.append(primary_language)
                                           
                #                             if hasattr(lang_result, 'detected_languages'):
                #                                 for lang in lang_result.detected_languages:
                #                                     if hasattr(lang, 'iso6391_name'):
                #                                         detected_lang = lang.iso6391_name
                #                                         if detected_lang != detected_primary_lang:
                #                                             if detected_lang == 'zh_cht' or detected_lang == 'zh_chs':
                #                                                 secondary_language = detected_lang
                #                                             elif detected_lang != primary_language:
                #                                                 secondary_language = 'en'
                #                                             else:
                #                                                 continue
                                                           
                #                                             if secondary_language not in languages:
                #                                                 languages.append(secondary_language)
                #                                     else:
                #                                         languages = ['en']  # Default if structure not as expected
                #                         else:
                #                             languages = ['en']  # Default to English if error
                                       
                #                     data[doc_idx]['data_languages'] = languages
               
                # lang_stats = {}
                # for item in data:
                #     if 'data_languages' in item and item['data_languages']:
                #         for lang in item['data_languages']:
                #             lang_stats[lang] = lang_stats.get(lang, 0) + 1
                              
                # # Ensure processed_data is not null for any item (Azure AI Search requirement)
                # for item in data:
                #     # Check if processed_data exists and is not null
                #     if 'processed_data' not in item or item['processed_data'] is None:
                #         # Set default empty array for processed_data
                #         item['processed_data'] = []
                   
                #     # Ensure processed_data is a list/array
                #     if not isinstance(item['processed_data'], list):
                #         item['processed_data'] = [float(item['processed_data'])] if isinstance(item['processed_data'], (int, float)) else []
               
                # # # Proceed with export after language detection and data validation

                # Handle file-based exports (JSON, CSV)
                if config.format.upper() in SETTINGS.VTEX.FILE_FORM:
                    try:
                        file_name = config.file_name + f'_partition-{knowledge_id}' + f'_batch-{_batch_index}'
                        if request.include_datetime:
                            file_name += '_' + datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")
                        file_name += '.' + config.format.lower()
                        file_root = os.path.join(config.file_rdir, config.file_sdir) if config.file_sdir else config.file_rdir
                        file_path = os.path.join(file_root, file_name)
                        os.makedirs(file_root, exist_ok=True)
                    except Exception as e:
                        response = Response(
                            status_code=500,
                            detail=self.response_format.error("Error preparing file path", str(e))
                        )
                        logger.error(response.detail)
                        return response

                # 2.2. Init Export DB
                elif config.format.upper() in SETTINGS.VTEX.DB_FORM:
                    try:
                        if request.include_datetime == True:
                            config.table = config.table + '_' + datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")
                    
                    # Handle missing parameters
                    except TypeError as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Missing Parameter Error : Exporting Data", str(e)))
                        logger.error(response.detail)
                        return response

                    # Handle any other exceptions that might occur
                    except:
                        response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Exporting Data"))
                        logger.error(response.detail)
                        return response

                # 3. Export Data
                # 3.1. Export to JSON
                if config.format.upper() == 'JSON':
                    try:
                        with open(file_path, 'w', encoding="utf-8") as json_file:
                            json.dump(data, json_file, cls=ComplexEncoder, ensure_ascii=False, indent=4)
                    
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : Exported Data to <{file_path}>"))
                        logger.info(response.detail)

                    except:
                        response = Response(status_code=500, detail=self.response_format.error(f"Data Export Error : Failed to Export Data to <{file_path}>"))
                        logger.error(response.detail)
                    
                # 3.2. Export to CSV
                elif config.format.upper() == 'CSV':
                    try:
                        with open(file_path, 'w',  newline='', encoding="utf-8-sig") as csv_file:
                            fieldnames = data[0].keys()
                            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
                            writer.writeheader()    # Write the header
                            writer.writerows(data)  # Write the data
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : Exported Data to <{file_path}>"))
                        logger.info(response.detail)

                    except:
                        response = Response(status_code=500, detail=self.response_format.error(f"Data Export Error : Failed to Export Data to <{file_path}>"))
                        logger.error(response.detail)

                # 3.3. Export to DB
                elif config.format.upper() in SETTINGS.VTEX.DB_FORM: # Valid DB
                    
                    if config.format.upper() == "AISEARCH":
                        try:
                            # Backup to Export Blob
                            new_data = [VectorCreate(**_data) for _data in data]
                            new_data, response = self.backup_all_data_to_export_blob(vector_data=new_data)
                            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                                return response

                            # Update the data url list
                            for _data, _new_data in zip(data, new_data):
                                _data["data_url"] = _new_data.data_url

                            if self.api_call == True:
                                get_ex_vb_api(index_name=config.table).upload_documents(
                                    documents = data
                                )

                            else:
                                with get_ex_vb_func(index_name=config.table) as vb:
                                    vb.upload_documents(
                                    documents = data
                                )
                            
                            response = Response(status_code=201, detail=self.response_format.ok(f"Success : Exporting All <{len(data)}> Vectors"))
                            logger.info(response.detail)

                        # Handle common exceptions that might occur
                        except (BaseException, Exception) as e:
                            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Export Vectors <{config.table}>", str(e)))
                            logger.error(response.detail)
                            return response

                        # Handle any other exceptions that might occur
                        except:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Export Vectors <{config.table}>"))
                            logger.error(response.detail)    
                            return response
                            
                    else:
                        response = Response(status_code=500, detail=self.response_format.error("Data Export Error : Unknown Export DB"))
                        logger.error(response.detail)       
                        return response            

                # Handle unsupported formats
                else:
                    response = Response(
                        status_code=500,
                        detail=self.response_format.error(f"Unsupported export format: {config.format}")
                    )
                    logger.error(response.detail)
                    return response

        return response


    """
        User Operation
    """
    def query_data_by_user(self, request: UserVectorRequest) -> tuple[UserVectorResponse, Response]:
        response_data = UserVectorResponse(**request.__dict__)

        data_filter = VectorFilter(**request.vector_filter.__dict__)
        conditions, sorting, batch_index, batch_size = self.filter_formatter(data_filter=data_filter)

        if not conditions:
            response = Response(status_code=500, detail=self.response_format.error(f"Missing Filter Error : Filter cannot be All Empty"))
            logger.error(response.detail)
            return response_data, response

        else:
            filter_result, response = self.query_with_conditions(
                conditions=conditions, 
                sorting=sorting, 
                batch_index=batch_index, 
                batch_size=batch_size
            )
    
        response_data.__dict__.update(filtered_vectors=[Vector(**data.__dict__) for data in filter_result.filtered_vectors], vector_no=filter_result.vector_count)
        response = Response(status_code=200, detail=self.response_format.ok("Success : Get Filtered Data for User"))
    
        return response_data, response

    """
        Class Operation
    """
    def partition_data_by_field(self, request: PartitionRequest) -> tuple[PartitionResponse, Response]:
        response_data = PartitionResponse(**request.__dict__)
        partitions = []

        # Get Data
        if request.vector_filter:
            data_filter = VectorFilter(**request.vector_filter.__dict__)
        else:
            data_filter = VectorFilter(batch_index=-1)

        conditions, sorting, batch_index, batch_size = self.filter_formatter(data_filter=data_filter)
        filter_query = ' and '.join(conditions)

        try:
            logger.info("Processing : Identifying Partitions for Export")
            if self.api_call == True:
                search_results = self.vb_api.search(
                    search_text="*", 
                    # filter=filter_query,
                    select=request.field_name,
                    facets=[f"{request.field_name},count:0"],
                    top=0
                )

            else:
                with self.vb_func() as vb:
                    search_results = vb.search(
                        search_text="*", 
                        filter=filter_query,
                        select=request.field_name,
                        facets=[f"{request.field_name},count:0"],
                        top=0
                    )
            
            partitions = [facet['value'] for facet in search_results.get_facets().get(request.field_name, [])]
            response   = Response(status_code=200, detail=self.response_format.ok(f"Partition Completed : <{SETTINGS.BASE.APP_NAME}> Identified <{len(partitions)}> Partitions for Vector DB"))

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Getting Vectors", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Getting Vectors"))
            logger.error(response.detail)  
        
        response_data.partitions = partitions

        return response_data, response


    def get_data_by_data_id(self, id: str=None, active: bool=True) -> dict:
        if id:
            if self.api_call == True:
                db_data = self.vb_api.get_document(key=id)
            else:
                with self.vb_func() as vb:
                    db_data = vb.get_document(key=id)
        else:
            return {}
        
        return db_data

    # Perform Query
    def query_with_conditions(
            self, 
            conditions: list, 
            sorting: list, 
            batch_index: int, 
            batch_size: int
        ) -> tuple[VectorFilterResult, Response]:

        response_data = VectorFilterResult(batch_index=batch_index)

        filter_query = ''
        sort_query   = ''

        if not conditions:
            response = Response(status_code=500, detail=self.response_format.error("Condition Filter Error : Condition Filter is Empty"))
            logger.error(response.detail)
            return response_data, response
        else:
            filter_query = ' and '.join(conditions)

        if sorting:
            sort_query = ', '.join(sorting)

        try:
            if self.api_call == True:
                response_data.vector_count = self.vb_api.search(search_text=None, filter=filter_query, include_total_count=True).get_count()
                response= Response(status_code=200, detail=self.response_format.ok(f"Got Vector Data Count"))

                if batch_size < 0:
                    response_data.batch_size = response_data.vector_count
                else:
                    response_data.batch_size = batch_size

                if response_data.vector_count <= 0:
                    return response_data, response
                
                response_data.batch_count = math.ceil(response_data.vector_count / response_data.batch_size)

                if response_data.batch_index > response_data.batch_count:
                    response = Response(status_code=500, detail=self.response_format.error(f"Batch Index Out of Range : Vector Filter Batch Index <{response_data.batch_index}> Exceeded Batch Count <{response_data.batch_count}>"))
                    logger.error(response.detail)
                    return response_data, response
                
                elif response_data.batch_index <= 0:
                    response = Response(status_code=200, detail=self.response_format.ok("Batch Index <= 0 : Return Statistics Only"))
                    logger.info(response.detail)
                    return response_data, response
                
                else:
                    results = self.vb_api.search(
                            search_text="*", 
                            filter=filter_query,
                            order_by=sort_query,
                            top=response_data.batch_size,
                            skip=(batch_index-1) * batch_size
                        )

            else:
                with self.vb_func() as vb:
                    response_data.vector_count = vb.search(search_text=None, filter=filter_query, include_total_count=True).get_count()
                    response= Response(status_code=200, detail=self.response_format.ok(f"Got Vector Data Count"))

                    if batch_size < 0:
                        response_data.batch_size = response_data.vector_count
                    else:
                        response_data.batch_size = batch_size
                    
                    if response_data.vector_count <= 0:
                        return response_data, response
                    
                    response_data.batch_count = math.ceil(response_data.vector_count / response_data.batch_size)

                    if response_data.batch_index > response_data.batch_count:
                        response = Response(status_code=500, detail=self.response_format.error(f"Batch Index Out of Range : Vector Filter Batch Index <{response_data.batch_index}> Exceeded Batch Count <{response_data.batch_count}>"))
                        return response_data, response
                    
                    elif response_data.batch_index <= 0:
                        response = Response(status_code=200, detail=self.response_format.ok("Batch Index <= 0 : Return Statistics Only"))
                        return response_data, response
                    
                    else:
                        results = vb.search(
                                search_text="*", 
                                filter=filter_query,
                                order_by=sort_query,
                                top=response_data.batch_size,
                                skip=(batch_index-1) * batch_size
                            )

            if results:
                response = Response(status_code=200, detail=self.response_format.ok("Success : Retrieved Filtered Vectors from DB"))
                response_data.filtered_vectors = [SecretVector(**_result) for _result in list(results)]
            else:
                response = Response(status_code=200, detail=self.response_format.ok("Success : No Matched Vectors from DB"))

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Getting Vectors", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Getting Vectors"))
            logger.error(response.detail)

        return response_data, response

    # Filter Formatter
    def filter_formatter(self, data_filter: VectorFilter) -> tuple[list, list, int, int]:

        def filter_by_byte(column_name: str, entity_filter: list[str]) -> list:
            conditions = []

            try:
                pass
                # column = getattr(db_model, column_name)
            except AttributeError as e:
                response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for ByteFilter must be <key_filter>", str(e)))
                logger.error(response.detail)
                return conditions
            except Exception:
                response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in ByteFilter"))
                logger.error(response.detail)       
                return conditions
            
            # _encoded_values = []
            # for value in entity_filter:
            #     encoded_value, response = CryptoServiceManager(api_call=False).encode_content(content=value)
            #     if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            #         logger.error(response.detail)
            #         return conditions
            #     _encoded_values.append(encoded_value)

            # conditions = [Q(**{f"{column_name}__in": encoded_value})]
            
            return conditions

        conditions = []
        sorting    = []

        # Parsing conditions

        # String Filter
        if data_filter.string_filter is not None:
            string_suffix = '_filter'
            for key, value in data_filter.string_filter.__dict__.items():
                if value is not None:
                    column_name = key.split(string_suffix)[0]
                    try:
                        _conditions   = [f"{column_name} eq \'{_value}\'" for _value in value]
                        condition_str = " or ".join(_conditions)
                        conditions.append(condition_str)
                    except AttributeError as e:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for StringFilter must be <key_filter>", str(e)))
                        logger.error(response.detail)
                    except Exception:
                        response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in StringFilter"))
                        logger.error(response.detail)                    


        # Numeric Filter
        if data_filter.numeric_filter is not None:
            min_suffix = '_min'
            max_suffix = '_max'
            for key, value in data_filter.numeric_filter.__dict__.items():
                if value is not None:
                    if min_suffix in key:
                        column_name = key.split(min_suffix)[0]
                        try:
                            conditions.append(f"{column_name} ge {value}")
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for NumericFilter must be <key_min> or <key_max>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in NumericFilter"))
                            logger.error(response.detail)              

                    elif max_suffix in key:
                        column_name = key.split(max_suffix)[0]
                        try:
                            conditions.append(f"{column_name} le {value}")
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for NumericFilter must be <key_min> or <key_max>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in NumericFilter"))
                            logger.error(response.detail)    

                    else:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute Suffix for NumericFilter must be Either _min or _max"))
                        logger.error(response.detail)


        # List Filter
        if data_filter.list_filter is not None:
            or_suffix  = '_or'
            and_suffix = '_and'
            for key, value in data_filter.list_filter.__dict__.items():
                if value is not None:
                    if or_suffix in key:
                        column_name   = key.split(or_suffix)[0]
                        _conditions   = [f"c eq \'{_value}\'" for _value in value]
                        _nested_conditions = ' or '.join(_conditions)
                        condition_str = f"{column_name}/any(c: {_nested_conditions})"
                        conditions.append(condition_str)
                        
                    elif and_suffix in key:
                        column_name = key.split(and_suffix)[0]
                        _conditions   = [f"c eq \'{_value}\'" for _value in value]
                        _nested_conditions = ' and '.join(_conditions)
                        condition_str = f"{column_name}/aall(c: {_nested_conditions})"
                        conditions.append(condition_str)

                    else:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute Suffix for ListFilter must be Either _or or _and"))
                        logger.error(response.detail)


        # Dictionary Filter
        if data_filter.dictionary_filter is not None:
            or_suffix  = '_or'
            and_suffix = '_and'
            for key, value in data_filter.dictionary_filter.__dict__.items():
                if value is not None:
                    if or_suffix in key:
                        column_name = key.split(or_suffix)[0]
                        try:
                            # _conditions = [Q(**{f"attribute.{_key}__exists": True}) for _key in value]
                            # if _conditions:
                            #     nested_conditions = _conditions[0]
                            #     for _condition in _conditions:
                            #         nested_conditions |= _condition
                            pass
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for DictionaryFilter must be <key_or> or <key_and>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in DictionaryFilter"))
                            logger.error(response.detail)     

                    elif and_suffix in key:
                        column_name = key.split(and_suffix)[0]
                        try:
                            # _conditions = [Q(**{f"attribute.{_key}__exists": True}) for _key in value]
                            # if _conditions:
                            #     nested_conditions = _conditions[0]
                            #     for _condition in _conditions:
                            #         nested_conditions &= _condition
                            pass
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for DictionaryFilter must be <key_or> or <key_and>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in DictionaryFilter"))
                            logger.error(response.detail)

                    else:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute Suffix for ListFilter must be Either _or or _and"))
                        logger.error(response.detail)


        # Boolean Filter
        if data_filter.boolean_filter is not None:
            boolean_suffix = '_filter'
            
            for key, value in data_filter.boolean_filter.__dict__.items():
                if value is not None:
                    column_name = key.split(boolean_suffix)[0]
                    try:
                        conditions.append(f"{column_name} eq true")
                    except AttributeError as e:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for BooleanFilter must be <key_filter>", str(e)))
                        logger.error(response.detail)
                    except Exception:
                        response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in BooleanFilter"))
                        logger.error(response.detail)    


        # Datetime Filter
        if data_filter.datetime_filter is not None:
            start_suffix = '_start'
            end_suffix   = '_end'
            
            for key, value in data_filter.datetime_filter.__dict__.items():
                if value is not None:
                    if start_suffix in key:
                        column_name = key.split(start_suffix)[0]
                        try:
                            conditions.append(f"{column_name} ge {value}")
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for DatetimeFilter must be <key_start> or <key_end>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in DatetimeFilter"))
                            logger.error(response.detail)      

                    if end_suffix in key:
                        column_name = key.split(end_suffix)[0]
                        try:
                            conditions.append(f"{column_name} le {value}")
                        except AttributeError as e:
                            response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute for DatetimeFilter must be <key_start> or <key_end>", str(e)))
                            logger.error(response.detail)
                        except Exception:
                            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Unexpected Error during Parsing Attribute <{column_name}> in DatetimeFilter"))
                            logger.error(response.detail)    

                    else:
                        response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute Suffix for DatetimeFilter must be Either _start or _end"))
                        logger.error(response.detail)

        # Byte Filter
        if data_filter.byte_filter is not None:
            byte_suffix = '_filter'
            
            for key, value in data_filter.byte_filter.__dict__.items():
                if value is not None:
                    column_name = key.split(byte_suffix)[0]
                    pass
                    # _conditions = filter_by_byte(db_model=KnowledgeDB, column_name=column_name, entity_filter=value)
                    # if _conditions:
                    #     conditions += _conditions

                    # else:
                    #     response = Response(status_code=404, detail=self.response_format.error(f"Attribute Error : Unrecognized Attribute <{column_name}>. The Attribute Suffix for ByteFilter must be _filter"))
                    #     logger.error(response.detail)

        # Define sorting order
        sorting = []
        for col, direction in data_filter.sorting.items():
            if direction.lower() == "desc":
                sorting.append(f"{col} desc")
            else:
                sorting.append(f"{col} asc")

        batch_index = data_filter.batch_index

        batch_size  = data_filter.batch_size

        return conditions, sorting, batch_index, batch_size

    def export_data(self, config: IOConfig | None, data: list, include_datetime: bool = True) -> Response:
          
            # Use default export configuration if none provided
            if config is None:
                config = self.default_export_config.copy()
                response = Response(status_code=200, detail=self.response_format.ok("Info : Empty Export Configuration >>> Use System Default Export Configuration"))
                logger.info(response.detail)

            # Handle file-based exports (JSON, CSV)
            if config.format.upper() in SETTINGS.VTEX.FILE_FORM:
                try:
                    file_name = config.file_name
                    if include_datetime:
                        file_name += '_' + datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")
                    file_name += '.' + config.format.lower()
                    file_root = os.path.join(config.file_rdir, config.file_sdir) if config.file_sdir else config.file_rdir
                    file_path = os.path.join(file_root, file_name)
                    os.makedirs(file_root, exist_ok=True)
                except Exception as e:
                    response = Response(
                        status_code=500,
                        detail=self.response_format.error("Error preparing file path", str(e))
                    )
                    logger.error(response.detail)
                    return response

            # 2.2. Init Export DB
            elif config.format.upper() in SETTINGS.VTEX.DB_FORM:
                try:
                    if include_datetime == True:
                        config.table = config.table + '_' + datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")
                
                # Handle missing parameters
                except TypeError as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Missing Parameter Error : Exporting Data", str(e)))
                    logger.error(response.detail)
                    return response

                # Handle any other exceptions that might occur
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Exporting Data"))
                    logger.error(response.detail)
                    return response
    
            # 3. Export Data
            # 3.1. Export to JSON
            if config.format.upper() == 'JSON':
                try:
                    with open(file_path, 'w', encoding="utf-8") as json_file:
                        json.dump(data, json_file, cls=ComplexEncoder, ensure_ascii=False, indent=4)
                
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : Exported Data to <{file_path}>"))
                    logger.info(response.detail)

                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"Data Export Error : Failed to Export Data to <{file_path}>"))
                    logger.error(response.detail)
                
            # 3.2. Export to CSV
            elif config.format.upper() == 'CSV':
                try:
                    with open(file_path, 'w',  newline='', encoding="utf-8-sig") as csv_file:
                        fieldnames = data[0].keys()
                        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
                        writer.writeheader()    # Write the header
                        writer.writerows(data)  # Write the data
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : Exported Data to <{file_path}>"))
                    logger.info(response.detail)

                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"Data Export Error : Failed to Export Data to <{file_path}>"))
                    logger.error(response.detail)

            # 3.3. Export to DB
            elif config.format.upper() in SETTINGS.VTEX.DB_FORM: # Valid DB
                
                if config.format.upper() == "AISEARCH":
                    try:
                        total_data_count = len(data)
                        batch_count = math.ceil(total_data_count / SETTINGS.VTEX.BATCH_SIZE)
                        logger.info(f"Exporting Data : Detected <{total_data_count}> Data. Divided into <{batch_count}> Batches with <{SETTINGS.VTEX.BATCH_SIZE}> Each for Processing")

                        for batch_index, i in enumerate(range(0, total_data_count, SETTINGS.VTEX.BATCH_SIZE), start=1):
                            logger.info(f"Exporting Data to Export DB : <{batch_index} / {batch_count}> Batch")
                            entities = data[i : i + SETTINGS.VTEX.BATCH_SIZE]

                            if self.api_call == True:
                                self.vb_api.upload_documents(
                                    documents = entities
                                )

                            else:
                                with self.vb_func() as vb:
                                    vb.upload_documents(
                                    documents = entities
                                )
                            
                            logger.info(f"[Data Export Batch <{batch_index}>] Success")

                        response = Response(status_code=201, detail=self.response_format.ok(f"Success : Exporting All <{len(data)}> Vectors"))
                        logger.info(response.detail)

                    # Handle common exceptions that might occur
                    except (BaseException, Exception) as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Export Vectors", str(e)))
                        logger.error(response.detail)

                    # Handle any other exceptions that might occur
                    except:
                        response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Export Vectors"))
                        logger.error(response.detail)    
                        
                else:
                    response = Response(status_code=500, detail=self.response_format.error("Data Export Error : Unknown Export DB"))
                    logger.error(response.detail)       
                    return response            

            # Handle unsupported formats
            else:
                response = Response(
                    status_code=500,
                    detail=self.response_format.error(f"Unsupported export format: {config.format}")
                )
                logger.error(response.detail)
                return response

            return response

    def backup_data_to_blob(self, data: list[VectorCreate], index: str = SETTINGS.VTDB.TABLE) -> Response:
        try:
            for _data in data:
                # Save data to json file
                local_dir = os.path.join(os.getcwd(), f"{index}")
                local_path = os.path.join(local_dir, f"{_data.data_id}.json")
                
                # Check if file exists, if yes, delete it
                if os.path.exists(local_path):
                    os.remove(local_path)
                
                os.makedirs(local_dir, exist_ok=True)
                
                # Save VectorCreate object to json file
                with open(local_path, 'w', encoding="utf-8") as json_file:
                    json.dump(_data.dict(), json_file, cls=ComplexEncoder, ensure_ascii=False, indent=4)
                
                blob_path = f"{SETTINGS.BLOB.VECTOR_FOLDER_NAME}/{index}/{_data.data_id}.json"

                # Upload the new blob file
                upload_to_blob(local_path=local_path, blob_path=blob_path, content_type="application/json")

                # Delete the local file
                if os.path.exists(local_path):
                    os.remove(local_path)

            response = Response(status_code=200, detail=self.response_format.ok("Success : Added Data to Blob"))
            logger.info(response.detail)

        except Exception as e:
            if os.path.exists(local_path):
                os.remove(local_path)

            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Add Data to Blob", str(e)))
            logger.error(response.detail)

        return response
    
    def backup_all_data_to_export_blob(self, vector_data: list[VectorCreate]) -> tuple[list[VectorCreate], Response]:
        local_dir = os.path.join(os.getcwd(), "temp_blob_files")

        try:
            for _data in vector_data:
                # Save data to json file
                local_path = os.path.join(local_dir, f"{_data.data_id}.json")
                
                # Check if file exists, if yes, delete it
                if os.path.exists(local_path):
                    os.remove(local_path)

                os.makedirs(local_dir, exist_ok=True)
                
                # Save VectorCreate object to json file
                with open(local_path, 'w', encoding="utf-8") as json_file:
                    json.dump(_data.dict(), json_file, cls=ComplexEncoder, ensure_ascii=False, indent=4)
        
                # Upload the new blob file to Export blob
                blob_path = f"{SETTINGS.BBEX.VECTOR_FOLDER_NAME}/{SETTINGS.VTEX.NAME}/{_data.data_id}.json"
                blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BBEX.CONNECTION_STRING)
                blob_client = blob_service_client.get_blob_client(container=SETTINGS.BBEX.CONTAINER_NAME, blob=blob_path)
                content_settings = ContentSettings(content_type="application/json")

                with open(local_path, "rb") as data:
                    blob_client.upload_blob(data, overwrite=True, content_settings=content_settings)

                logger.info(f"Uploaded {local_path} to blob storage as {blob_client.url}")

                # Upload the image from Current blob to Export blob
                if _data.data_url and _data.data_url.startswith(self.blob_url_prefix):
                    # Download data_url from Current blob to local
                    current_blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
                    current_blob_client = BlobClient.from_blob_url(
                        _data.data_url,
                        credential=current_blob_service_client.credential
                    )
                    if current_blob_client.exists():
                        image_local_path = os.path.join(local_dir, _data.data_url.split("/")[-1])
                        # Check if file exists, if yes, delete it
                        if os.path.exists(image_local_path):
                            os.remove(image_local_path)
                        with open(image_local_path, "wb") as file:
                            file.write(current_blob_client.download_blob().readall())

                        # Upload the image to Export blob
                        blob_path = current_blob_client.blob_name
                        export_blob_client = blob_service_client.get_blob_client(container=SETTINGS.BBEX.CONTAINER_NAME, blob=blob_path)
                        content_settings = ContentSettings(content_type="image/jpeg")

                        with open(image_local_path, "rb") as data:
                            export_blob_client.upload_blob(data, overwrite=True, content_settings=content_settings)

                        _data.__dict__.update(
                            data_url = str(export_blob_client.url)
                        )
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Added Data to Blob"))
            logger.info(response.detail)
        
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Failed to Upload Data to Blob", str(e)))
            logger.error(response.detail)
            return vector_data, response
        
        try:
            if os.path.exists(local_dir):
                shutil.rmtree(local_dir)
        except Exception as e:
            logger.error(f"Error deleting directory {local_dir}: {str(e)}")

        return vector_data, response

    def delete_data_from_blob(self, data: list[VectorCreate]) -> Response:
        try:
            for _data in data:
                blob_path = f"{SETTINGS.BLOB.VECTOR_FOLDER_NAME}/{SETTINGS.VTDB.TABLE}/{_data.data_id}.json"

                if check_blob_file_exists(blob_path=blob_path):
                    delete_blob_file(blob=blob_path)

                if _data.data_url and _data.data_url.startswith(self.blob_url_prefix):
                    delete_blob_file_by_url(blob_url=_data.data_url)

            response = Response(status_code=200, detail=self.response_format.ok("Success : Deleted Data from Blob"))
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Delete Data from Blob", str(e)))
            logger.error(response.detail)

        return response

    def preprocess_prepmedia(self, request: PrepMediaPipelineRequest) -> tuple[PrepMediaPipelineResponse, Response]:
        response_data = PrepMediaPipelineResponse(**request.__dict__)

        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.PREP.HOST}:{SETTINGS.PREP.PORT}/{SETTINGS.PREP.REQUEST_PREPMEDIA_API}"
                payload = request.json()
                response_data, response = self.api_call_static(data=payload, service="KnowledgeHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                response_data = PrepMediaPipelineResponse(**response_data)
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response_data = response_data.json()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Prepmedia Preprocessing via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                try:
                    response_data = request_exec_prepmedia(request=request, api_call=False)
                    response_data = PrepMediaPipelineResponse(**response_data.__dict__)
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Prepmedia Preprocessing via Function Call"))
                    logger.info(response.detail)
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Complete Knowledge Preprocessing via Function Call", str(e)))
                    logger.error(response.detail)
            
        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing Prepmedia", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing Prepmedia"))
            logger.error(response.detail)

        return response_data, response

    def clear_preprocessing_temp_storage(self) -> Response:
        try:
            if SETTINGS.BASE.APP_FUNC == True:
                try:
                    init_preprocessing_temp_storage()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Cleared Preprocessing Temp Storage via Function Call"))
                    logger.info(response.detail)
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Clear Preprocessing Temp Storage via Function Call", str(e)))
                    logger.error(response.detail)
                
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Clear Preprocessing Temp Storage but <APP_FUNC> is False"))
                logger.error(response.detail)
        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Clearing Preprocessing Temp Storage", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Clearing Preprocessing Temp Storage"))
            logger.error(response.detail)

        return response

    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response