from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from datetime import datetime, timezone
from typing import Any
import inspect
import pytz

from ..schemas.format import ResponseFormatter, Response


# scheduler.add_job(time_trigger_pipeline_job, 'interval', seconds=SETTINGS.JOB.PIPELINE_SCAN_SEC, args=[JOB_RELATIONSHIP_PIPELINE])
# scheduler.add_job(time_trigger_pipeline_job, 'interval', seconds=SETTINGS.JOB.PIPELINE_SCAN_SEC, args=[JOB_VECTOR_MIGRATION_EXPORT_PIPEILNE])


from ..settings import SETTINGS

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

scheduler = BackgroundScheduler({'apscheduler.job_defaults.max_instances': SETTINGS.BASE.APP_JOB_WORKERS})

class SchedulerService:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def init_background_scheduler(self) -> Any:
        logger.info(f"Init <{SETTINGS.BASE.APP_NAME}> Scheduler")
        scheduler = BackgroundScheduler({'apscheduler.job_defaults.max_instances': SETTINGS.SCH.MAX_INSTNACE})
        
        # Weekly Jobs
        if SETTINGS.SCH.CLEAR_EVALUATION_JOB_ENABLE and SETTINGS.BASE.APP_FUNC == True:
            from ..services import clear_pipeline_job as clear_evaluation_pipeline_job
            for _job_type, _job_stage in zip(SETTINGS.SCH.CLEAR_EVALUATION_JOB_TYPE, SETTINGS.SCH.CLEAR_EVALUATION_JOB_STAGE):
                scheduler.add_job(
                    clear_evaluation_pipeline_job, 
                    CronTrigger(
                        day_of_week = SETTINGS.SCH.CLEAR_EVALUATION_JOB_WEEDAY, 
                        hour        = SETTINGS.SCH.CLEAR_EVALUATION_JOB_HOUR,
                        minute      = SETTINGS.SCH.CLEAR_EVALUATION_JOB_MIN,
                        timezone    = pytz.utc
                    ),
                    args        = [_job_type, _job_stage], 
                    id          = f'WEEKLY-EVAL-{_job_type}'
                )
                logger.info(f"<{SETTINGS.BASE.APP_NAME}> Added Time-Triggering Evaluation Job <{_job_type}>")

        if SETTINGS.SCH.CLEAR_KNOWLEDGE_JOB_ENABLE:
            from ..routers.request_pipeline import clear_pipeline_job as clear_knowledge_pipeline_job
            for _job_type, _job_stage in zip(SETTINGS.SCH.CLEAR_KNOWLEDGE_JOB_TYPE, SETTINGS.SCH.CLEAR_KNOWLEDGE_JOB_STAGE):
                scheduler.add_job(
                    clear_knowledge_pipeline_job, 
                    CronTrigger(
                        day_of_week = SETTINGS.SCH.CLEAR_KNOWLEDGE_JOB_WEEDAY, 
                        hour        = SETTINGS.SCH.CLEAR_KNOWLEDGE_JOB_HOUR,
                        minute      = SETTINGS.SCH.CLEAR_KNOWLEDGE_JOB_MIN,
                        timezone    = pytz.utc
                    ),
                    args        = [_job_type, _job_stage], 
                    id          = f'WEEKLY-KNOW-{_job_type}'
                )
                logger.info(f"<{SETTINGS.BASE.APP_NAME}> Added Time-Triggering Knowledge Job <{_job_type}>")

        # Daily Jobs


        # Adding Scheduler Jobs
        if SETTINGS.SCH.EVALUATION_JOB_ENABLE and SETTINGS.BASE.APP_FUNC == True:
            from ..services import time_trigger_pipeline_job as evaluation_pipeline_job
            for job_type in SETTINGS.SCH.EVALUATION_JOB_TYPE:
                scheduler.add_job(evaluation_pipeline_job, 'interval', seconds=SETTINGS.SCH.EVALUATION_JOB_SCAN_SEC, args=[job_type], id=job_type)
                logger.info(f"<{SETTINGS.BASE.APP_NAME}> Added Time-Triggering Evaluation Job <{job_type}>")

        if SETTINGS.SCH.KNOWLEDGE_JOB_ENABLE:
            from ..routers.request_pipeline import time_trigger_pipeline_job as knowledge_pipeline_job
            for job_type in SETTINGS.SCH.KNOWLEDGE_JOB_TYPE:
                scheduler.add_job(knowledge_pipeline_job, 'interval', seconds=SETTINGS.SCH.KNOWLEDGE_JOB_SCAN_SEC, args=[job_type], id=job_type)
                logger.info(f"<{SETTINGS.BASE.APP_NAME}> Added Time-Triggering Knowledge Job <{job_type}>")

        return scheduler