from pydantic import BaseModel
from uuid import UUID
from datetime import datetime, timezone
import json

from ..database.registry.schemas.database import TableInfo as DBInfo
from ..database.vector.schemas.database import TableInfo as VBInfo
from ..database.graph.schemas.database import GBGraphInfoResponse as GBInfo

class Health(BaseModel):
    app_name:          str
    status_code:       int=200
    api_call:          str='ACTIVE'
    function_call:     str='ACTIVE'
    primary_db:        str='ONLINE'
    primary_db_reason: str='In Service'
    primary_db_info:   DBInfo=DBInfo()
    primary_vb:        str='Online'
    primary_vb_info:   VBInfo=VBInfo()
    primary_vb_reason: str='In Service'
    primary_gb:        str='Online'
    primary_gb_info:   GBInfo=GBInfo()
    primary_gb_reason: str='In Service'