from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone
from fastapi import UploadFile
from typing import List, Any, Dict, Optional, Literal

from ..schemas.knowledge import KnowledgeFilter
from ..schemas.evaluation import SeedQnAFilter, QnAFilter, EvaluationFilter

from ..schemas.vector import *

from ..schemas.graph import GraphFilter

from ..migration.migration_db.schemas.migration import (
    DBConfig,
    BatchMigrateRequest as DBBatchMigrateRequest
)

from ..migration.migration_vb.schemas.migration import (
    InitMigrationTableRequest as VBInitMigrationRequest,
    BatchMigrateRequest as VBBatchMigrateRequest
)

from ..migration.migration_blob.schemas.migration import (
    BlobConfig,
    FileConfig,
    BatchMigrateRequest as BlobMigrationRequest
)

from ..migration.migration_gb.schemas.migration import (
    DBConfig as GBConfig,
    BatchMigrateRequest as GBBatchMigrateRequest
)

class DBMigrationExportRequest(BaseModel):
    migration_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    db_config:            Optional[DBConfig]=DBConfig()
    migration_type:       Literal["knowledge", "seed_qna", "qna", "evaluation", "keyword_mapping", "metadata"]
    meta:                 dict
    uid_field:            str=''    
    data_filter:          dict = None
    action:               str=Field(default="INSERT", description="INSERT, UPSERT, DROP")
    
    method:               Literal["DB", "API"]
    include_datetime:     bool = False

    class Config:
        schema_extra = {
            "example": {
                "migration_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "db_config": {
                    "db_url": "",
                    "db_name": "database_name"
                },
                "migration_type": "knowledge",
                "meta": {
                    "collection": "collection_name"
                },
                "uid_field": "knowledge_id",
                "data_filter": {
                    "numeric_filter": {
                        "knowledge_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "method": "DB",
                "include_datetime": False
            }
        }

class VBMigrationExportRequest(BaseModel):
    migration_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    vb_config:            VBInitMigrationRequest
    uid_field:            str=''    
    vector_filter:        VectorFilter | None = None
    action:               str=Field(default="INSERT", description="INSERT, UPSERT, DROP")
    preprocessing:        bool=Field(default=False, description="Performing Preprocessing for Data")
    preprocessing_config: dict=Field(default=dict(), description="Preprocessing Strategy")
    
    method:               Literal["DB", "API"]
    include_datetime:     bool = False

    class Config:
        schema_extra = {
            "example": {
                "migration_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "vb_config": {
                    "table_name": "vector-export"
                },
                "uid_field": "data_id",
                "vector_filter": {
                    "numeric_filter": {
                        "data_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    },
                    "batch_index": -1,
                    "batch_size": 1500
                },
                "method": "DB",
                "include_datetime": False
            }
        }


class BlobMigrationExportRequest(BaseModel):
    migration_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    migration_type:      Literal["knowledge", "metadata"]
    blob_config:         BlobConfig
    action:              str=Field(default="INSERT", description="INSERT, UPSERT, DROP")
    vector_filter:       VectorFilter | None = None
    data_filter:         dict = None
    data_types:          list[str]=Field(default=["IMAGE", "JSON", "PDF"], description="IMAGE, JSON, PDF")
    table_name:          str=Field(..., description="Index Name of AI Search")

    method:               Literal["DB", "API"]

    class Config:
        schema_extra = {
            "example": {
                "migration_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "migration_type": "knowledge",
                "blob_config": {
                    "connection_string": "",
                    "container_name": "container_name",
                },
                "action": "INSERT",
                "vector_filter": {
                    "numeric_filter": {
                        "data_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    },
                    "batch_index": -1,
                    "batch_size": 1500
                },
                "data_filter": {
                    "numeric_filter": {
                        "knowledge_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "data_types": ["IMAGE", "JSON", "PDF"],
                "table_name": "export vb index name",
                "method": "API",
                "include_datetime": False
            }
        }


class GBMigrationExportRequest(BaseModel):
    migration_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    db_config:           Optional[DBConfig]=DBConfig()
    container_name:      str=SETTINGS.GPDB.CONTAINER
    partition_key:       str=SETTINGS.GPDB.PARTITION_KEY
    throughput:          int=SETTINGS.GPDB.CONTAINER_THROUGHPUT
    knowledge_id:        str=''
    node_uid_field:      str=Field(default='node_id', description="Field Name of Node UID")
    node_label_field:    str=Field(default='node_type', description="Field Name of Node Label")
    edge_uid_field:      str=Field(default='edge_id', description="Field Name of Edge UID")
    edge_label_field:    str=Field(default='edge_type', description="Field Name of Edge Label")
    edge_source_field:   str=Field(default='source_node_id', description="Field Name of Edge Source")
    edge_target_field:   str=Field(default='target_node_id', description="Field Name of Edge Target")
    action:              str=Field(default="INSERT", description="INSERT, UPSERT, DROP")
    
    method:              Literal["DB", "API"]
    include_datetime:    bool = True

    class Config:
        schema_extra = {
            "example": {
                "migration_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "db_config": {
                    "table_name": "graph-export"
                },
                "container_name": SETTINGS.GPDB.CONTAINER,
                "partition_key": SETTINGS.GPDB.PARTITION_KEY,
                "throughput": SETTINGS.GPDB.CONTAINER_THROUGHPUT,
                "knowledge_id": "knowledge_id",
                "node_uid_field": "node_id",
                "node_label_field": "node_type",
                "edge_uid_field": "edge_id",
                "edge_label_field": "edge_type",
                "edge_source_field": "source_node_id",
                "edge_target_field": "target_node_id",
                "method": "API",
                "include_datetime": False
            }
        }
