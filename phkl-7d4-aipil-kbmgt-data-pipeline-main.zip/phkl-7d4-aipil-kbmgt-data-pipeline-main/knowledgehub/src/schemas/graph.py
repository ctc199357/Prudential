from pydantic import BaseModel, Field 
import uuid
from datetime import datetime, timezone
from fastapi import UploadFile
from typing import List, Any, Dict, Optional

from ..database.graph.schemas.graph import *

"""
    Knowledge-level Graph Operation
"""
class KnowledgeGraphDBInfo(BaseModel):
    knowledge_graphstorage:  str=''
    knowledge_graphlocation: str=''
    knowledge_graphinfo:     dict=dict()

class KnowledgeGraphCreateRequest(BaseModel):
    create_request: GraphCreateRequest

class KnowledgeGraphCreateResponse(BaseModel):
    knowledge_graphstorage:  str=''
    knowledge_graphlocation: str=''
    knowledge_graphinfo:     dict=dict()

class KnowledgeGraphUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=True
    knowledge_id:   str
    update_request: GraphCreateRequest
    overwrite:      bool=True

class KnowledgeGraphUpdateResponse(BaseModel):
    knowledge_id:            str
    knowledge_graphstorage:  str=''
    knowledge_graphlocation: str=''
    knowledge_graphinfo:     dict=dict()
    updated_graph_count:     int=-1

class KnowledgeGraphRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str | None = None
    user_name:      str | None = None
    knowledge_id:   str

class KnowledgeGraphBatchRequest(BaseModel):
    graph_requests: list[KnowledgeGraphRequest]

class KnowledgeGraphReadResponse(BaseModel):
    knowledge_id:  str
    filtered_data: SecretGraph=SecretGraph()
    node_count:    int=0
    edge_count:    int=0