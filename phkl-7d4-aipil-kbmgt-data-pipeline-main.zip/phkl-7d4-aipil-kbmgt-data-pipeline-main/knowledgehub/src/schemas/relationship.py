from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone, timedelta
from fastapi import UploadFile

from ..job.schemas.job import JobCreate

from ..settings import SETTINGS

"""
    Knowledge Relationship Extraction Operation
"""
class KnowledgeRelationshipRequest(BaseModel):
    knowledge_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_id:              str | None = None
    user_requestid:       str | None = None
    
    knowledge_ids:        list[str]=[]
    
    # Preprocessing Info
    prepmedia_id:         str=SETTINGS.PREP.PREPMEDIA_RELATIONSHIP_NAME
    custom_config:        dict=dict()
    resume_pipeline:      bool=False
    encrypt_knowledge:    str='default'
    get_full_chain:       bool=False

    # Time Information
    knowledge_request_at: datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class KnowledgeRelationshipObject(BaseModel):
    knowledge_sequence: int=1
    knowledge_code:     str=SETTINGS.KNOW.STATUS_CODE.get("FAIL", "500")
    knowledge_reason:   str='DEFAULT'

    knowledge_id:       str='Undefined'

class KnowledgeRelationshipResponse(BaseModel):
    knowledge_requestid:         str
    
    # Results
    knowledge_success_objects:   list[KnowledgeRelationshipObject]=[]
    knowledge_fail_objects:      list[KnowledgeRelationshipObject]=[]

    # Statistics
    knowledge_total_no:          int=0
    knowledge_success_no:        int=0
    knowledge_fail_no:           int=0
    knowledge_relationship_time: float=0.0

    # Time Information
    knowledge_response_at:       datetime | None = None

class KnowledgeRelationshipPipeline(BaseModel):
    knowledge_requestid:         str=Field(default_factory=lambda: str(uuid.uuid4()))

    # Results
    knowledge_success_objects:   list[KnowledgeRelationshipObject]=[]
    knowledge_fail_objects:      list[KnowledgeRelationshipObject]=[]

    # Statistics
    knowledge_total_no:          int=0
    knowledge_success_no:        int=0
    knowledge_fail_no:           int=0
    knowledge_relationship_time: float=0.0

    # Time Information
    request_at:                  datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    response_at:                 datetime | None = None