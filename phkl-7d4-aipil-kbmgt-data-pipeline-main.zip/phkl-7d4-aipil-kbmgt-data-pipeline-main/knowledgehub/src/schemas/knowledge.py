from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone, timedelta
from fastapi import UploadFile

from ..database.registry.schemas.knowledge import *

from ..schemas.utils import KnowledgeInputIngestObject

from ..settings import SETTINGS

"""
    Knowledge Ingestion Operation
"""
class KnowledgeIngestRequest(BaseModel):
    knowledge_requestid:    str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_id:                str | None = None
    user_requestid:         str | None = None
    
    # Request Info
    knowledge_creates:      list[KnowledgeCreate]=Field(default=[], description="Knowledge Ingest List", example=[
        {
            "storage_directory_origin": "blob url of the document"
        }
    ])
    
    # Preprocessing Info
    prepknow_id:            str=Field('test_prepknow_1', description="[Optional] Preprocessing Knowledge ID")
    custom_config:          dict=dict()
    resume_pipeline:        bool=False
    encrypt_knowledge:      str='default'
    get_full_chain:         bool=False

    # Time Information
    knowledge_request_at:   datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class KnowledgeIngestObject(BaseModel):
    knowledge_sequence:       int=1
    knowledge_code:           str=SETTINGS.KNOW.STATUS_CODE.get("FAIL", "500")
    knowledge_reason:         str='DEFAULT'

    knowledge_id:             str='Undefined'
    knowledge_name:           str=''
    storage_directory_origin: str=''
    knowledge_filename:       str=''
    knowledge_fileextension:  str=''

class KnowledgeIngestResponse(BaseModel):
    knowledge_requestid:            str=Field(..., description="Knowledge Request ID")
    
    # Results
    knowledge_success_objects:      list[KnowledgeIngestObject]=Field(default=[], description="Knowledge Success Objects", example=[
        {
            "knowledge_sequence": 1,
            "knowledge_code": "200",
            "knowledge_reason": "Success",
            "knowledge_id": "1234567890abcdef",
            "knowledge_name": "example_knowledge",
            "storage_directory_origin": "/path/to/origin",
            "knowledge_filename": "example_file.txt",
            "knowledge_fileextension": ".txt"
        }
    ])
    knowledge_fail_objects:         list[KnowledgeIngestObject]=Field(default=[], description="Knowledge Fail Objects")

    # Statistics
    knowledge_total_no:             int=Field(0, description="Total Number of Knowledge")
    knowledge_success_no:           int=Field(0, description="Total Number of Knowledge Success")
    knowledge_fail_no:              int=Field(0, description="Total Number of Knowledge Fail")
    knowledge_ingest_time:          float=Field(0.0, description="Knowledge Ingest Time")

    # Time Information
    knowledge_response_at:          datetime=Field(default=None, description="Knowledge Response Time")

class KnowledgeIngestPipeline(BaseModel):
    knowledge_requestid:            str=Field(default_factory=lambda: str(uuid.uuid4()))

    # Results
    knowledgeinput_success_objects: list[KnowledgeInputIngestObject]=[]
    knowledgeinput_fail_objects:    list[KnowledgeInputIngestObject]=[]

    knowledge_success_objects:      list[KnowledgeIngestObject]=[]
    knowledge_fail_objects:         list[KnowledgeIngestObject]=[]

    # Statistics
    knowledgeinput_total_no:        int=0
    knowledgeinput_success_no:      int=0
    knowledgeinput_fail_no:         int=0
    knowledgeinput_ingest_time:     float=0.0
    knowledge_total_no:             int=0
    knowledge_success_no:           int=0
    knowledge_fail_no:              int=0
    knowledge_ingest_time:          float=0.0

    # Time Information
    request_at:                     datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    response_at:                    datetime | None = None

"""
    Knowledge Automatic Ingestion Operation
"""
class KnowledgeAutoIngestRequest(BaseModel):
    knowledge_requestid:    str=Field(default_factory=lambda: str(uuid.uuid4()), description="Knowledge Request ID")
    user_id:                str=Field(default='', description="User ID")
    user_requestid:         str=Field(default='', description="User Request ID")
    
    # Preprocessing Info
    batch_order:            str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S"), description="Batch Name") # single if not batch, otherwise timestamp
    batch_size:             int=Field(10, description="Batch Size") # execute all if batch_size <= 0
    prepknow_id:            str=Field('test_prepknow_1', description="[Optional] Preprocessing Knowledge ID")
    custom_config:          dict=Field(default={}, description="Custom Configuration")
    resume_pipeline:        bool=Field(False, description="Resume Pipeline")
    encrypt_knowledge:      str=Field(default='default', description="Encrypt Knowledge")
    get_full_chain:         bool=Field(False, description="Get Full Chain")

    # Time Information
    knowledge_request_at:   datetime=Field(default_factory=datetime.now, description="Knowledge Request Time")

"""
    Knowledge Update Ingestion Operation
"""
class KnowledgeUpdateIngestRequest(BaseModel):
    knowledge_requestid:    str=Field(default_factory=lambda: str(uuid.uuid4()), description="Knowledge Request ID")
    user_id:                str=Field(default='', description="User ID")
    user_requestid:         str=Field(default='', description="User Request ID")
    
    knowledge_updates:       list[KnowledgeUpdate]=Field(default=[], description="Knowledge Update List", example=[
        {
            "library_id": "example_library",
            "category_id": "example_category",
            "document_id": "example_document_id",
            "file_name": "example_file.txt"
        }
    ])

    # Preprocessing Info
    prepknow_id:            str=Field('test_prepknow_1', description="[Optional] Preprocessing Knowledge ID")
    custom_config:          dict=Field(default={}, description="Custom Configuration")
    resume_pipeline:        bool=Field(False, description="Resume Pipeline")
    encrypt_knowledge:      str=Field(default='default', description="Encrypt Knowledge")
    get_full_chain:         bool=Field(False, description="Get Full Chain")

    # Time Information
    knowledge_request_at:   datetime=Field(default_factory=datetime.now, description="Knowledge Request Time")




# # Mock Usage
# class KnowledgeAutoIngestRequest(BaseModel):
#     knowledge_requestid:    str=Field(default_factory=lambda: str(uuid.uuid4()), description="Knowledge Request ID")
#     # user_id:                str=Field(default='', description="User ID")
#     # user_requestid:         str=Field(default='', description="User Request ID")
    
#     # Preprocessing Info
#     batch_order:            str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S"), description="Batch Name") # single if not batch, otherwise timestamp
#     batch_size:             int=Field(default=10, description="Batch Size")
#     # prepknow_id:            str=Field(default='', description="[Optional] Preprocessing Knowledge ID")
#     # custom_config:          dict=Field(default={}, description="Custom Configuration")
#     # resume_pipeline:        bool=Field(default=False, description="Resume Pipeline")
#     # encrypt_knowledge:      str=Field(default='default', description="Encrypt Knowledge")
#     # get_full_chain:         bool=Field(default=False, description="Get Full Chain")

#     # Time Information
#     knowledge_request_at:   datetime=Field(default_factory=datetime.now, description="Knowledge Request Time")

#     class Config:
#         schema_extra = {
#             "example": {
#                 "knowledge_requestid": "123e4567-e89b-12d3-a456-426614174000",
#                 "batch_order": "2023-04-30-12-00-00",
#                 "batch_size": 10,
#                 "prepknow_id": "prep_001",
#                 "knowledge_request_at": "2023-04-30T12:00:00Z"
#             }
#         }

# # Mock Usage
# class KnowledgeIngestResponse(BaseModel):
#     knowledge_requestid:            str=Field(..., description="Knowledge Request ID")
    
#     # Results
#     knowledge_success_objects:      list[KnowledgeIngestObject]=Field(default=[], description="Knowledge Success Objects")
#     knowledge_fail_objects:         list[KnowledgeIngestObject]=Field(default=[], description="Knowledge Fail Objects")

#     # Statistics
#     knowledge_total_no:             int=Field(0, description="Total Number of Knowledge")
#     knowledge_success_no:           int=Field(0, description="Total Number of Knowledge Success")
#     knowledge_fail_no:              int=Field(0, description="Total Number of Knowledge Fail")
#     knowledge_ingest_time:          float=Field(0.0, description="Knowledge Ingest Time")

#     # Time Information
#     knowledge_response_at:          datetime=Field(default=None, description="Knowledge Response Time")

#     class Config:
#         schema_extra = {
#             "example": {
#                 "knowledge_requestid": "123e4567-e89b-12d3-a456-426614174000",
#                 "knowledge_success_objects": [
#                     {
#                         "knowledge_sequence": 1,
#                         "knowledge_code": "200",
#                         "knowledge_reason": "Success",
#                         "knowledge_id": "233e4567-e89b-12d3-a456-426614174888",
#                         "knowledge_name": "example_knowledge",
#                         "storage_directory_origin": "blob_path",
#                         "knowledge_filename": "example_file.pdf",
#                         "knowledge_fileextension": ".pdf"
#                     }
#                 ],
#                 "knowledge_fail_objects": [],
#                 "knowledge_total_no": 1,
#                 "knowledge_success_no": 1,
#                 "knowledge_fail_no": 0,
#                 "knowledge_ingest_time": 0.123,
#                 "knowledge_response_at": "2023-04-30T12:00:00Z"
#             }
#         }
"""
    PIL Sync Operation
"""
class PilSyncRequest(BaseModel):
    pil_requestid:          str=Field(default_factory=lambda: str(uuid.uuid4()), description="PIL Request ID")
    pil_metadata_path:      str=Field(default='', description="Sharepoint path of the PIL csv")

class PilSyncMetadataObject(BaseModel):
    metadata_sequece:       int=1
    metadata_code:           str=SETTINGS.KNOW.STATUS_CODE.get("FAIL", "500")
    metadata_reason:         str='DEFAULT'

    file_id:                     str=''
    library_id:                  str=''
    library_name_en:             str=''
    category_id:                 str=''
    category_name_en:            str=''
    document_id:                 str=''
    file_name:                   str=''
    file_sync_url_from:          str=''

class PilSyncMetadataResult(BaseModel):
    metadata_success_objects:      list[PilSyncMetadataObject]=Field(default=[], description="Metadata Success Objects", example=[
        {
            "metadata_sequence": 1,
            "metadata_code": "200",
            "metadata_reason": "Success",
            "file_id": "1234567890abcdef",
            "library_id": "1234567890abcdef",
            "category_id": "1234567890abcdef",
            "document_id": "1234567890abcdef",
            "file_name": "example_file.txt",
            "file_sync_url_from": "/path/to/origin"
        }
    ])
    metadata_fail_objects:         list[PilSyncMetadataObject]=Field(default=[], description="Metadata Fail Objects")

    # Statistics
    metadata_total_no:             int=Field(0, description="Total Number of Metadata")
    metadata_success_no:           int=Field(0, description="Total Number of Metadata Success")
    metadata_fail_no:              int=Field(0, description="Total Number of Metadata Fail")

class PilSyncResponse(BaseModel):
    pil_requestid:                  str=Field(default_factory=lambda: str(uuid.uuid4()), description="PIL Request ID")
    
    # Results
    pil_update_result:              PilSyncMetadataResult=Field(default=None, description="PIL Update Result")
    pil_create_result:              PilSyncMetadataResult=Field(default=None, description="PIL Create Result")
    pil_delete_result:              PilSyncMetadataResult=Field(default=None, description="PIL Delete Result")
    pil_sync_status:                str = Field(
        default='',
        description="PIL Sync Status: display error message if synchronization failed or success message if synchronization is done"
    )

    # Time Information
    pil_response_at:                datetime=Field(default=None, description="PIL Response Time")
