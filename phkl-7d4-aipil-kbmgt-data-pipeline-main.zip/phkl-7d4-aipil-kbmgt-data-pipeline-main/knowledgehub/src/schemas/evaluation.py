from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone
from fastapi import UploadFile
from typing import List, Any, Dict, Optional, Literal

class IOConfig(BaseModel):
    format:           str | None = None
    location:         str | None = None
    name:             str | None = None
    host:             str | None = None
    port:             str | None = None
    user:             str | None = None
    pswd:             str | None = None
    table:            str | None = None
    rdir:             str | None = None
    sdir:             str | None = None
    file_rdir:        str | None = None
    file_sdir:        str | None = None
    file_name:        str | None = None

"""
    Job
"""
""" 
    Request and Resposne for System Access Jobs
"""
"""
    Job Filter
"""   
class JobStringFilter(BaseModel):
    job_id_filter:       list[str] | None = None
    knowledge_id_filter: list[str] | None = None
    
    job_type_filter:     list[str] | None = None
    job_pipeline_filter: list[str] | None = None
    job_stage_filter:    list[str] | None = None
    job_reason_filter:   list[str] | None = None


class JobNumericFilter(BaseModel):
    job_status_min:  int | None = None
    job_status_max:  int | None = None 
    job_version_min: int | None = None
    job_version_max: int | None = None

class JobListFilter(BaseModel):
    not_used_filter_or:  list[str] | None = None
    not_used_filter_and: list[str] | None = None

class JobDictionaryFilter(BaseModel):
    not_used_filter_or:  list[str] | None = None
    not_used_filter_and: list[str] | None = None

class JobBooleanFilter(BaseModel):
    job_success_filter:  bool | None = None
    job_complete_filter: bool | None = None

class JobDatetimeFilter(BaseModel):
    created_at_start: datetime  | None = None
    created_at_end:   datetime  | None = None
    updated_at_start: datetime  | None = None
    updated_at_end:   datetime  | None = None

class JobByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class JobFilter(BaseModel):
    string_filter:     JobStringFilter     | None = None
    numeric_filter:    JobNumericFilter    | None = None
    list_filter:       JobListFilter       | None = None
    dictionary_filter: JobDictionaryFilter | None = None
    boolean_filter:    JobBooleanFilter    | None = None
    datetime_filter:   JobDatetimeFilter   | None = None
    byte_filter:       JobByteFilter       | None = None
    sorting:           dict={"job_id": "asc"}
    filter_no:         int=-1

# System-level Access
class SecretJob(BaseModel):
    # Trace Information
    job_id:       str | None = None
    job_status:   int | None = None
    job_version:  int | None = None
    knowledge_id: str | None = None

    # Specification
    job_type:     str | None = None
    job_success:  bool | None = None
    job_complete: bool | None = None
    job_stage:    str | None = None
    job_reason:   str | None = None

    # Time Information
    created_at:   datetime | None = None
    updated_at:   datetime | None = None

class SystemJobRequest(BaseModel):
    job_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:   JobFilter=Field(..., description="[Required] Job Filter")  

    class Config:
        schema_extra = {
            "example": {
                "job_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "numeric_filter": {
                        "job_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemJobResponse(BaseModel):
    job_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data: list[SecretJob]=Field(default=[], description="Filtered Job Data")
    data_count:    int=Field(default=0, description="Count of Filtered Job Data", example=1)

"""
    Seed QnA
"""
""" 
    Seed QnA Generation Request and Response
"""
class SeedQnASyncRequest(BaseModel):
    qna_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()), description="Unique ID for the QnA request")
    qna_sync_origin: str=Field(default='', description="Origin of the QnA sync, LOCAL, BLOB")
    qna_sync_path:   str=Field(default='', description="Path for QnA sync")
    batch_order:     str=Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d-%H-%M-%S")) # single if not batch, otherwise timestamp
    request_at:      datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="Request time in UTC format")

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "bcbf6b6c-1d4b-4c8f-bd7b-2c7d8c8a2a7f",
                "qna_sync_path": "/path/to/qna/sync/Full List of FAQ for AI-PIL_ by Library.xlsx",
                "request_at": "2023-10-01T12:00:00Z"
            }
        }

class SeedQnASyncResponse(BaseModel):
    qna_requestid: str=Field(..., description="Unique ID for the QnA request")
    succeess_flag: bool=Field(default=False, description="Success flag for the QnA sync")
    reason:        str=Field(default='UNKNOWN', description="Reason for the success or failure of the QnA sync")
    response_at:   datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="Response time in UTC format")

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "bcbf6b6c-1d4b-4c8f-bd7b-2c7d8c8a2a7f",
                "succeess_flag": True,
                "reason": "SUCCESS",
                "response_at": "2023-10-01T12:00:00Z"
            }
        }

class SeedQnACreate(BaseModel):
    # Trace Information
    seed_qna_id:                str=Field(default_factory=lambda: str(uuid.uuid4()))
    seed_qna_traceid:           str=Field(default_factory=lambda: str(uuid.uuid4()))
    seed_qna_version:           int=1
    batch_order:                str=Field(default_factory=lambda: datetime.now().strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp
    knowledge_id:               str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_version:          int=1
    library_name_en:            str=''

    # Creator Information
    creator_id:                 str=''
    creator_name:               str=''
    approver_id:                str='system'
    approver_name:              str='system'

    # Control Information
    seed_qna_status:            int=1
    seed_qna_permission:        int=1  # qna access level
    seed_qna_management:        int=10 # qna management level

    # SeedQnA Information
    qna_query:                  str=''
    qna_response:               str=''
    qna_citations:              list[str]=[]
    qna_query_language:         str=''
    qna_response_language:      str=''

    # Tags
    seed_qna_tags:              list[str]=[]
    
    # Time Information
    created_at:                 datetime=Field(default_factory=datetime.now)
    updated_at:                 datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "seed_qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "seed_qna_traceid": "a7bcf831-a33e-4f4b-939d-5ad26c128542",
                "seed_qna_version": 1,
                "batch_order": "2023-04-30-12-00-00",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "knowledge_version": 1,
                "library_name_en": "MPF",
                "creator_id": "creator_001",
                "creator_name": "John Doe",
                "approver_id": "system",
                "approver_name": "system",
                "seed_qna_status": 1,
                "seed_qna_permission": 1,
                "seed_qna_management": 10,
                "qna_query": "What is the capital of France?",
                "qna_response": "The capital of France is Paris.",
                "qna_citations": [
                    {
                        "document": {
                            "knowledge_id": "doc123",
                            "knowledge_languages": ["en"],
                            "document_name": "Sample Document",
                            "hyperlink": "https://example.com/sample-document",
                            "last_update_date": "2023-04-30",
                            "pil_reference_number": "PIL12345",
                            "translation": "ORIGINAL"
                        },
                        "citations": [
                            {
                                "data_id": "cite456",
                                "knowledge_id": "doc123",
                                "content": "This is a sample citation content.",
                                "source_type": "text",
                                "image_table_link": "https://example.com/citation-image.jpg",
                                "page_start": 1,
                                "page_end": 1,
                                "langauage": "en",
                                "score": 0.85
                            }
                        ]
                    }
                ],
                "qna_query_language": "en",
                "qna_response_language": "en",
                "seed_qna_tags": []
            }
        }

# System-level Access
class SecretSeedQnA(BaseModel):
    # Trace Information
    seed_qna_id:                str | None = None
    seed_qna_traceid:           str | None = None
    seed_qna_version:           int | None = None
    batch_order:                str | None = None
    knowledge_id:               str | None = None
    knowledge_version:          int | None = None
    library_name_en:            str | None = None

    # Creator Information
    creator_id:                 str | None = None
    creator_name:               str | None = None
    approver_id:                str | None = None
    approver_name:              str | None = None

    # Control Information
    seed_qna_status:            int | None = None
    seed_qna_permission:        int | None = None  # qna access level
    seed_qna_management:        int | None = None # qna management level

    # SeedQnA Information
    qna_query:                  str | None = None
    qna_response:               str | None = None
    qna_citations:              list[str] | None = None
    qna_query_language:         str | None = None
    qna_response_language:      str | None = None

    # Tags
    seed_qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:                 datetime | None = None
    updated_at:                 datetime | None = None


"""
    SeedQnA Filter
"""   
class SeedQnAStringFilter(BaseModel):
    seed_qna_id_filter:                list[str] | None = None
    seed_qna_traceid_filter:           list[str] | None = None    
    batch_order_filter:                list[str] | None = None
    knowledge_id_filter:               list[str] | None = None
    library_name_en_filter:            list[str] | None = None

    creator_id_filter:                 list[str] | None = None
    creator_name_filter:               list[str] | None = None
    approver_id_filter:                list[str] | None = None
    approver_name_filter:              list[str] | None = None

    qna_query_filter:                  list[str] | None = None
    qna_response_filter:               list[str] | None = None
    qna_query_language_filter:         list[str] | None = None
    qna_response_language_filter:      list[str] | None = None

class SeedQnANumericFilter(BaseModel):
    seed_qna_version_min:    int | None = None
    seed_qna_version_max:    int | None = None
    knowledge_version_min:   int | None = None
    knowledge_version_max:   int | None = None  

    seed_qna_status_min:     int | None = None
    seed_qna_status_max:     int | None = None 
    seed_qna_permission_min: int | None = None
    seed_qna_permission_max: int | None = None
    seed_qna_management_min: int | None = None
    seed_qna_management_max: int | None = None

class SeedQnAListFilter(BaseModel):
    seed_qna_tags_or:  list[str] | None = None
    seed_qna_tags_and: list[str] | None = None    

class SeedQnADictionaryFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None

class SeedQnABooleanFilter(BaseModel):
    not_used_filter: bool | None = None

class SeedQnADatetimeFilter(BaseModel):
    created_at_start:                  datetime  | None = None
    created_at_end:                    datetime  | None = None
    updated_at_start:                  datetime  | None = None
    updated_at_end:                    datetime  | None = None

class SeedQnAByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class SeedQnAFilter(BaseModel):
    string_filter:     SeedQnAStringFilter     | None = None
    numeric_filter:    SeedQnANumericFilter    | None = None
    list_filter:       SeedQnAListFilter       | None = None
    dictionary_filter: SeedQnADictionaryFilter | None = None
    boolean_filter:    SeedQnABooleanFilter    | None = None
    datetime_filter:   SeedQnADatetimeFilter   | None = None
    byte_filter:       SeedQnAByteFilter       | None = None
    sorting:           dict={"seed_qna_id": "asc"}
    filter_no:         int=-1

class SystemSeedQnARequest(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:        SeedQnAFilter=Field(..., description="[Required] SeedQnA Filter", example=SeedQnAFilter(
                                    string_filter=SeedQnAStringFilter(
                                        qna_id_filter=["seed_qna_id_1"]
                                    ),
                                    numeric_filter=SeedQnANumericFilter(
                                        qna_status_min=1
                                    )
                                ))  

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "seed_qna_id_filter": ["seed_qna_id_1"],
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemSeedQnAResponse(BaseModel):
    seed_qna_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data:      list[SecretSeedQnA]=Field(default=[], description="Filtered SeedQnA Data")
    data_count:         int=Field(default=0, description="Count of Filtered SeedQnA Data", example=1)

class SeedQnAExportRequest(BaseModel):
    seed_qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:        SeedQnAFilter | None = None
    io_config:          IOConfig | None = None
    include_datetime:   bool = True

    class Config:
        schema_extra = {
            "example": {
                "seed_qna_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "qna"
                },
                "include_datetime": True
            }
        }

"""
    QnA CRUD
"""
class RawDocumentObject(BaseModel):
    knowledge_id:         str=Field(default="UNKNOWN", description="knowledge_id of the document")
    knowledge_languages:  list[str]=Field(default=[], description="Languages of the document")
    document_name:        str=Field(default="UNKNOWN", description="Name of the document")
    hyperlink:            str=Field(default="UNKNOWN", description="Hyperlink of the document")
    last_update_date:     str=Field(default="UNKNOWN", description="Last update date of the document")
    pil_reference_number: str=Field(default="UNKNOWN", description="PIL reference number of the document")
    translation:          str=Field(default='ORIGINAL', description="Translation notes of the citation")
    
class RawCitationObject(BaseModel):
    data_id:              str=Field(default="", description="data_id of the citation")
    knowledge_id:         str=Field(default="", description="knowledge_id of the document")
    content:              str=Field(default="", description="Content of the citation")
    source_type:          str=Field(default="UNKNOWN", description="Source type of the citation, e.g., text, image, table")
    image_table_link:     str=Field(default="", description="Image or table URL of the citation")
    page_start:           int=Field(default="UNKNOWN", description="Page start of the citation")
    page_end:             int=Field(default="UNKNOWN", description="Page end of the citation")
    langauage:            str=Field(default="en", description="Langauge of the citation")
    score:                float=Field(default=0.0, description="Retrieval Scoring")

class RawRetrievalObject(BaseModel):
    document:  RawDocumentObject=Field(default=RawDocumentObject(), description="List of DocumentObjects")
    citations: list[RawCitationObject]=Field(default=[], description="List of CitationObjects")

class QnACreate(BaseModel):
    # Trace Information
    qna_id:                str=Field(default_factory=lambda: str(uuid.uuid4()))
    qna_traceid:           str=Field(default_factory=lambda: str(uuid.uuid4()))
    qna_version:           int=1
    seed_qna_id:           str=''
    seed_qna_version:      int=1
    batch_order:           str=Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d-%H-%M-%S")) # single if not batch, otherwise timestamp
    knowledge_id:          str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_version:     int=1
    document_name:         str=''

    # Creator Information
    creator_id:            str=''
    creator_name:          str=''
    approver_id:           str='system'
    approver_name:         str='system'

    # Control Information
    qna_status:            int=1
    qna_permission:        int=1  # qna access level
    qna_management:        int=10 # qna management level

    # QnA Information
    qna_query:             str=''
    qna_response:          str=''
    qna_citations:         list[str]=[]
    qna_data_ids:          list[str]=[]
    qna_query_language:    str=''
    qna_response_language: str=''

    # Tags
    qna_tags:              list[str]=[]
    
    # Time Information
    created_at:            datetime=Field(default_factory=datetime.now)
    updated_at:            datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "qna_traceid": "a7bcf831-a33e-4f4b-939d-5ad26c128542",
                "qna_version": 1,
                "seed_qna_id": "",
                "seed_qna_version": 1,
                "batch_order": "20230430120000",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "knowledge_version": 1,
                "document_name": "Sample Document",
                "creator_id": "creator_001",
                "creator_name": "John Doe",
                "approver_id": "system",
                "approver_name": "system",
                "qna_status": 1,
                "qna_permission": 1,
                "qna_management": 10,
                "qna_query": "What is the capital of France?",
                "qna_response": "The capital of France is Paris.",
                "qna_citations": [],
                "qna_query_language": "en",
                "qna_response_language": "en",
                "qna_tags": []
            }
        }

class QnACreateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    data:           QnACreate

class QnABatchCreateRequest(BaseModel):
    create_requests: list[QnACreateRequest]

# QnA CRUD
class QnAUpdate(BaseModel):
    # Trace Information
    qna_id:                str | None = None
    qna_traceid:           str | None = None
    qna_version:           int | None = None
    seed_qna_id:           str | None = None
    seed_qna_version:      int | None = None
    batch_order:           str | None = None
    knowledge_id:          str | None = None
    knowledge_version:     int | None = None
    document_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None
    approver_id:           str | None = None
    approver_name:         str | None = None

    # Control Information
    qna_status:            int | None = None
    qna_permission:        int | None = None  # qna access level
    qna_management:        int | None = None # qna management level

    # QnA Information
    qna_query:             str | None = None
    qna_response:          str | None = None
    qna_citations:         list[str] | None = None
    qna_data_ids:          list[str] | None = None
    qna_query_language:    str | None = None
    qna_response_language: str | None = None

    # Tags
    qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "batch_order": "single",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "qna_query": "What is the capital of UK?",
                "qna_response": "The capital of UK is London.",
                "qna_citations": []
            }
        }

class QnAUpdateRequest(BaseModel):
    user_requestid: str | None = None
    user_id:        str=''
    user_name:      str=''
    is_admin:       bool=False
    qna_id:         str | None = None
    update_data:    QnAUpdate=QnAUpdate()
    overwrite:      bool = True

    class Config:
        schema_extra = {
            "example": {
                "qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "update_data": {
                    "batch_order": "single",
                    "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                    "qna_query": "What is the capital of UK?",
                    "qna_response": "The capital of UK is London.",
                    "qna_citations": []
                }
            }
        }
    
class QnARequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the QnA")
    user_name:      str=Field(default="", description="[Optional] User Name for the QnA")
    qna_id:         str=Field(..., description="[Required] QnA ID for the Request")

    class Config:
        schema_extra = {
            "example": {
                "qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541"
            }
        }

class QnAPair(BaseModel):
    qna_id:                str=Field(default_factory=lambda: str(uuid.uuid4()))
    seed_qna_id:           str=''
    knowledge_id:          str=''
    qna_query:             str=''
    qna_response:          str=''
    qna_citations:         list[RawRetrievalObject]=[]
    qna_query_language:    Literal['en', 'zh']='en'
    qna_response_language: Literal['en', 'zh']='en'

class QnAGenerationRequest(BaseModel):
    generation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    batch_order:          str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")) # single if not batch, otherwise timestamp
    
    knowledge_id:         str=''
    category_name_en:     str=''
    
    data_input:           list[QnAPair]=[]
    unit_generation_num:  int=5
    
    save_to_db:           bool=False
    request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class QnAGenerationResponse(BaseModel):
    generation_requestid: str
    batch_order:          str
    knowledge_id:         str

    success_objects:      list[QnACreate]=[]
    fail_objects:         list[QnACreate]=[]
    
    total_qna_count:      int=0
    success_qna_count:    int=0
    fail_qna_count:       int=0

    generation_time:      float=0.0
    total_input_tokens:   int=-1
    total_output_tokens:  int=-1
    total_tool_tokens:    int=-1
    
    response_at:          datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

# System-level Access
class SecretQnA(BaseModel):
    # Trace Information
    qna_id:                str | None = None
    qna_traceid:           str | None = None
    qna_version:           int | None = None
    seed_qna_id:           str | None = None
    seed_qna_version:      int | None = None
    batch_order:           str | None = None
    knowledge_id:          str | None = None
    knowledge_version:     int | None = None
    document_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None
    approver_id:           str | None = None
    approver_name:         str | None = None

    # Control Information
    qna_status:            int | None = None
    qna_permission:        int | None = None  # qna access level
    qna_management:        int | None = None  # qna management level

    # QnA Information
    qna_query:             str | None = None
    qna_response:          str | None = None
    qna_citations:         list[str] | None = None
    qna_data_ids:          list[str] | None = None
    qna_query_language:    str | None = None
    qna_response_language: str | None = None

    # Tags
    qna_tags:              list[str] | None = None
    
    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None


"""
    QnA Filter
"""   
class QnAStringFilter(BaseModel):
    qna_id_filter:                list[str] | None = None
    qna_traceid_filter:           list[str] | None = None    
    seed_qna_id_filter:           list[str] | None = None
    batch_order_filter:           list[str] | None = None
    knowledge_id_filter:          list[str] | None = None

    creator_id_filter:            list[str] | None = None
    creator_name_filter:          list[str] | None = None
    approver_id_filter:           list[str] | None = None
    approver_name_filter:         list[str] | None = None

    qna_query_filter:             list[str] | None = None
    qna_response_filter:          list[str] | None = None
    qna_query_language_filter:    list[str] | None = None
    qna_response_language_filter: list[str] | None = None

class QnANumericFilter(BaseModel):
    qna_version_min:       int | None = None
    qna_version_max:       int | None = None
    seed_qna_version_min:  int | None = None
    seed_qna_version_max:  int | None = None
    knowledge_version_min: int | None = None
    knowledge_version_max: int | None = None

    qna_status_min:        int | None = None
    qna_status_max:        int | None = None 
    qna_permission_min:    int | None = None
    qna_permission_max:    int | None = None
    qna_management_min:    int | None = None
    qna_management_max:    int | None = None

class QnAListFilter(BaseModel):
    qna_tags_or:  list[str] | None = None
    qna_tags_and: list[str] | None = None    

class QnADictionaryFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None

class QnABooleanFilter(BaseModel):
    not_used_filter: bool | None = None

class QnADatetimeFilter(BaseModel):
    created_at_start:                  datetime  | None = None
    created_at_end:                    datetime  | None = None
    updated_at_start:                  datetime  | None = None
    updated_at_end:                    datetime  | None = None

class QnAByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class QnAFilter(BaseModel):
    string_filter:     QnAStringFilter     | None = None
    numeric_filter:    QnANumericFilter    | None = None
    list_filter:       QnAListFilter       | None = None
    dictionary_filter: QnADictionaryFilter | None = None
    boolean_filter:    QnABooleanFilter    | None = None
    datetime_filter:   QnADatetimeFilter   | None = None
    byte_filter:       QnAByteFilter       | None = None
    sorting:           dict={"qna_id": "asc"}
    filter_no:         int=-1

class SystemQnARequest(BaseModel):
    qna_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:   QnAFilter=Field(..., description="[Required] QnA Filter", example=QnAFilter(
                                    string_filter=QnAStringFilter(
                                        qna_id_filter=["qna_id_1"]
                                    ),
                                    numeric_filter=QnANumericFilter(
                                        qna_status_min=1
                                    )
                                ))  

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemQnAResponse(BaseModel):
    qna_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data: list[SecretQnA]=Field(default=[], description="Filtered QnA Data")
    data_count:    int=Field(default=0, description="Count of Filtered QnA Data", example=1)


class QnAExportRequest(BaseModel):
    qna_requestid:    str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:      QnAFilter | None = None
    io_config:        IOConfig | None = None
    include_datetime: bool = True

    class Config:
        schema_extra = {
            "example": {
                "qna_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "qna"
                },
                "include_datetime": True
            }
        }

"""
    Evaluation Pipeline Request
"""
class JobCreate(BaseModel):
    # Trace Information
    job_id:       str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Job ID")
    job_status:   int=Field(default=1, description="[Optional] Job Status")
    job_version:  int=Field(default=1, description="[Optional] Job Version")
    knowledge_id: str=Field(default='', description="[Optional] Knowledge ID")

    # Specification
    job_type:     str=Field(default='', description="[Optional] Job Type")
    job_success:  bool=Field(default=False, description="Job Success Flag")
    job_complete: bool=Field(default=False, description="Job Complete Flag")
    job_stage:    str=Field(default='', description="Job Stage")
    job_reason:   str=Field(default='', description="Job Fail Reason")

    # Time Information
    created_at:   datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Created DateTime") # Created DateTime
    updated_at:   datetime=Field(default_factory=lambda: datetime.now(timezone.utc), description="[Optional] Updated DateTime") # Updated DateTime

class EvaluationCreate(BaseModel):
    # Trace Information
    evaluation_id:            str=Field(default_factory=lambda: str(uuid.uuid4()))
    evaluation_traceid:       str=Field(default_factory=lambda: str(uuid.uuid4()))
    evaluation_version:       int=1
    batch_order:              str=Field(default_factory=lambda: datetime.now().strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp
    knowledge_id:             str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_version:        int=1
    document_name:            str=''

    # Control Information
    evaluation_status:        int=1
    evaluation_permission:    int=1  # evaluation access level
    evaluation_management:    int=10 # evaluation management level
    
    # Evaluation Information
    qna_id:                   str=''
    qna_query:                str=''
    qna_response:             str=''
    qna_citations:            list[str]=[]
    qna_data_ids:             list[str]=[]
    qna_query_language:       str=''
    qna_response_language:    str=''

    actual_response:          str=''
    actual_citations:         list[str]=[]
    actual_data_ids:          list[str]=[]
    actual_language:          str=''

    # Evaluation Matrix
    similarity:               int=-1
    relevance:                int=-1
    groundedness:             int=-1
    retrieval:                int=-1
    input_tokens:             int=-1   # Inference Input Tokens
    output_tokens:            int=-1   # Inference Output Tokens
    tool_tokens:              int=-1   # Inference Tool Tokens
    response_time:            float=-1 # Inference Response Time

    # Statistics
    evaluation_code:          str='SUCCESS'
    evaluation_time:          float=0.0

    # Tags
    evaluation_tags:          list[str]=[]
    
    # Time Information
    created_at:               datetime=Field(default_factory=datetime.now)
    updated_at:               datetime | None = None

    class Config:
        schema_extra = {
            "example": {
                "evaluation_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "evaluation_traceid": "a7bcf831-a33e-4f4b-939d-5ad26c128542",
                "evaluation_version": 1,
                "batch_order": "20230430120000",
                "knowledge_id": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "knowledge_version": 1,
                "document_name": "Sample Document",
                "evaluation_status": 1,
                "evaluation_permission": 1,
                "evaluation_management": 10,
                "qna_id": "9e7cb831-a33e-4f4b-939d-5ad26c128541",
                "qna_query": "What is the capital of France?",
                "qna_response": "The capital of France is Paris.",
                "qna_citations": [
                    {
                        "document": {
                            "knowledge_id": "doc123",
                            "knowledge_languages": ["en"],
                            "document_name": "Sample Document",
                            "hyperlink": "https://example.com/sample-document",
                            "last_update_date": "2023-04-30",
                            "pil_reference_number": "PIL12345",
                            "translation": "ORIGINAL"
                        },
                        "citations": [
                            {
                                "data_id": "cite456",
                                "knowledge_id": "doc123",
                                "content": "This is a sample citation content.",
                                "source_type": "text",
                                "image_table_link": "https://example.com/citation-image.jpg",
                                "page_start": 1,
                                "page_end": 1,
                                "langauage": "en",
                                "score": 0.85
                            }
                        ]
                    }
                ],
                "qna_query_language": "en",
                "qna_response_language": "en",
                "actual_response": "The capital of France is Paris.",
                "actual_citations": [],
                "actual_language": "en",
                "similarity": 5,
                "relevance": 4,
                "groundedness": 3,
                "retrieval": 2,
                "input_tokens": 10,
                "output_tokens": 15,
                "tool_tokens": 5,
                "response_time": 0.123,
                "evaluation_code": "SUCCESS",
                "evaluation_time": 1.5,
                "evaluation_tags": [],
                "created_at": "2023-04-30T12:00:00Z",
                "updated_at": "2023-04-30T12:00:00Z"
            }
        }


class EvaluationPipelineRequest(BaseModel):
    knowledge_ids: list[str]=Field(..., description="List of Knowledge IDs for Evaluation")
    process:       Literal["QNA_GENERATION", 
                        "EVALUATION", 
                        "ONBOARD", 
                        "UPDATE_QNA",
                        "UPDATE_DOCUMENT",
                        "AUTO", 
                        "FULL"]=Field(..., description="Next process of Onboarding (QNA_GENERATION for Generating QNA, EVALUTATION for Eexcuting Onboarding)")
    batch_order:   str=Field(default_factory=lambda: datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")) # single if not batch, otherwise timestamp

    class Config:
        schema_extra = {
            "example": {
                "knowledge_ids": ["knowledge_id_1", "knowledge_id_2", "knowledge_id_3"],
                "process": "QNA_GENERATION"
            }
        }

class EvaluationPipelineResponse(BaseModel):
    pipeline_info: list[JobCreate]=Field(default=[], description="List of PipelineResult Indicating SUCCESS or FAIL")

# System-level Access
class SecretEvaluation(BaseModel):
    # Trace Information
    evaluation_id:            str | None = None
    evaluation_traceid:       str | None = None
    evaluation_version:       int | None = None
    batch_order:              str | None = None
    knowledge_id:             str | None = None
    knowledge_version:        int | None = None
    document_name:            str | None = None

    # Control Information
    evaluation_status:        int | None = None
    evaluation_permission:    int | None = None  # evaluation access level
    evaluation_management:    int | None = None
    
    # Evaluation Information
    qna_id:                   str | None = None
    qna_query:                str | None = None
    qna_response:             str | None = None
    qna_citations:            list[str] | None = None
    qna_data_ids:             list[str] | None = None
    qna_query_language:       str | None = None
    qna_response_language:    str | None = None

    actual_response:          str | None = None
    actual_citations:         list[str] | None = None
    actual_data_ids:          list[str] | None = None
    actual_language:          str | None = None

    # Evaluation Matrix
    similarity:               int | None = None
    relevance:                int | None = None
    groundedness:             int | None = None
    retrieval:                int | None = None
    input_tokens:             int | None = None   # Inference Input Tokens
    output_tokens:            int | None = None   # Inference Output Tokens
    tool_tokens:              int | None = None   # Inference Tool Tokens
    response_time:            float | None = None # Inference Response Time

    # Statistics
    evaluation_code:          str | None = None
    evaluation_time:          float | None = None

    # Tags
    evaluation_tags:          list[str] | None = None
    
    # Time Information
    created_at:               datetime | None = None
    updated_at:               datetime | None = None

"""
    Evaluation Filter
"""   
class EvaluationStringFilter(BaseModel):
    evaluation_id_filter:         list[str] | None = None
    evaluation_traceid_filter:    list[str] | None = None    
    batch_order_filter:           list[str] | None = None
    knowledge_id_filter:          list[str] | None = None

    qna_query_filter:             list[str] | None = None
    qna_response_filter:          list[str] | None = None
    qna_query_language_filter:    list[str] | None = None
    qna_response_language_filter: list[str] | None = None

    actual_response_filter:       list[str] | None = None
    actual_language_filter:       list[str] | None = None

    evaluation_code_filter:       list[str] | None = None
    
class EvaluationNumericFilter(BaseModel):
    evaluation_version_min:    int | None = None
    evaluation_version_max:    int | None = None
    knowledge_version_min:     int | None = None
    knowledge_version_max:     int | None = None

    evaluation_status_min:     int | None = None
    evaluation_status_max:     int | None = None 
    evaluation_permission_min: int | None = None
    evaluation_permission_max: int | None = None
    evaluation_management_min: int | None = None
    evaluation_management_max: int | None = None

    similarity_min:            int | None = None
    similarity_max:            int | None = None 
    relevance_min:             int | None = None
    relevance_max:             int | None = None
    groundedness_min:          int | None = None
    groundedness_max:          int | None = None

    retrieval_min:             int | None = None
    retrieval_max:             int | None = None 
    input_tokens_min:          int | None = None
    input_tokens_max:          int | None = None
    output_tokens_min:         int | None = None
    output_tokens_max:         int | None = None

    tool_tokens_min:           int | None = None
    tool_tokens_max:           int | None = None
    response_time_min:         int | None = None
    response_time_max:         int | None = None

    evaluation_time_min:       int | None = None
    evaluation_time_max:       int | None = None

class EvaluationListFilter(BaseModel):
    evaluation_tags_or:  list[str] | None = None
    evaluation_tags_and: list[str] | None = None    

class EvaluationDictionaryFilter(BaseModel):
    not_used_or:  list[str] | None = None
    not_used_and: list[str] | None = None

class EvaluationBooleanFilter(BaseModel):
    not_used_filter: bool | None = None

class EvaluationDatetimeFilter(BaseModel):
    created_at_start:                  datetime  | None = None
    created_at_end:                    datetime  | None = None
    updated_at_start:                  datetime  | None = None
    updated_at_end:                    datetime  | None = None

class EvaluationByteFilter(BaseModel):
    not_used_filter: list[bytes] | None = None

class EvaluationFilter(BaseModel):
    string_filter:     EvaluationStringFilter     | None = None
    numeric_filter:    EvaluationNumericFilter    | None = None
    list_filter:       EvaluationListFilter       | None = None
    dictionary_filter: EvaluationDictionaryFilter | None = None
    boolean_filter:    EvaluationBooleanFilter    | None = None
    datetime_filter:   EvaluationDatetimeFilter   | None = None
    byte_filter:       EvaluationByteFilter       | None = None
    sorting:           dict={"evaluation_id": "asc"}
    filter_no:         int=-1

class SystemEvaluationRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_filter:   EvaluationFilter=Field(..., description="[Required] Evaluation Filter", example=EvaluationFilter(
                                    string_filter=EvaluationStringFilter(
                                        evaluation_id_filter=["evaluation_id_1"]
                                    ),
                                    numeric_filter=EvaluationNumericFilter(
                                        evaluation_status_min=1
                                    )
                                ))  

    class Config:
        schema_extra = {
            "example": {
                "evaluation_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "numeric_filter": {
                        "evaluation_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                }
            }
        }

class SystemEvaluationResponse(BaseModel):
    evaluation_requestid: str=Field(..., description="Unique ID for the Request")
    filtered_data: list[SecretEvaluation]=Field(default=[], description="Filtered Evaluation Data")
    data_count:    int=Field(default=0, description="Count of Filtered Evaluation Data", example=1)


class EvaluationExportRequest(BaseModel):
    evaluation_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_filter:          EvaluationFilter | None = None
    io_config:            IOConfig | None = None
    include_datetime:     bool = True

    class Config:
        schema_extra = {
            "example": {
                "evaluation_requestid": "2c9e1f7e-8f6c-4c6b-8d7c-b5e4ed7e8e3a",
                "data_filter": {
                    "string_filter": {
                        "knowledge_id_filter": ["knowledge_id"]
                    },
                    "numeric_filter": {
                        "evaluation_status_min": 0
                    },
                    "sorting": {
                        "updated_at": "desc"
                    }
                },
                "io_config": {
                    "format": "csv",
                    "location": "local",
                    "file_rdir": "your path",
                    "file_sdir": "output",
                    "file_name": "evaluation"
                },
                "include_datetime": True
            }
        }
