from fastapi import APIRouter, status
from typing import Any

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..schemas.format import Response

from ..schemas.evaluation import (
    SeedQnASyncRequest,
    SeedQnASyncResponse,
    QnACreateRequest,
    QnAUpdateRequest,
    QnARequest,
    QnAGenerationRequest,
    QnAGenerationResponse,
    EvaluationPipelineRequest,
    EvaluationPipelineResponse,
    SeedQnAExportRequest,
    QnAExportRequest,
    EvaluationExportRequest,
    SystemJobRequest,
    SystemJobResponse,
    SystemSeedQnARequest,
    SystemSeedQnAResponse,
    SystemQnARequest,
    SystemQnAResponse,
    SystemEvaluationRequest,
    SystemEvaluationResponse
)

from ..services.evaluation_service import EvaluationServiceManager

router = APIRouter(tags=["Request-Evaluation"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


if SETTINGS.BASE.APP_FUNC == True:
    
    @router.post("/request/evaluation/pipeline", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=EvaluationPipelineResponse)
    def request_evaluation_pipeline(request: EvaluationPipelineRequest) -> EvaluationPipelineResponse:
        request = EvaluationPipelineRequest(**request.__dict__)
        response_data, response = EvaluationServiceManager(api_call=default_api_call).execute_pipeline(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response_data

    @router.post("/evaluation/job/query", status_code=status.HTTP_200_OK, response_model=SystemJobResponse)
    def request_evaluation_pipeline(request: SystemJobRequest) -> SystemJobResponse:
        request = SystemJobRequest(**request.__dict__)
        response_data, response = EvaluationServiceManager(api_call=default_api_call).query_job(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response_data

    @router.post("/general/qna/single/create", status_code=status.HTTP_201_CREATED)
    def general_create_qna(request: QnACreateRequest) -> Response:
        request  = QnACreateRequest(**request.__dict__)
        response = EvaluationServiceManager(api_call=default_api_call).create_qna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response

    @router.patch("/general/qna/single/update", status_code=status.HTTP_200_OK)
    def general_update_qna(request: QnAUpdateRequest) -> Response:
        request  = QnAUpdateRequest(**request.__dict__)
        response = EvaluationServiceManager(api_call=default_api_call).update_qna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response

    @router.delete("/general/qna/single/drop", status_code=status.HTTP_200_OK)
    def general_drop_qna(request: QnARequest) -> Response:
        request  = QnARequest(**request.__dict__)
        response = EvaluationServiceManager(api_call=default_api_call).drop_qna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response

    @router.post("/request/qna/knowledge/generation", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
    def request_generate_knowledge_qna(request: QnAGenerationRequest) -> QnAGenerationResponse:
        request  = QnAGenerationRequest(**request.__dict__)
        response_data, response = EvaluationServiceManager(api_call=default_api_call).generate_knowledge_qna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response_data

    @router.post("/request/seed_qna/sync", status_code=status.HTTP_201_CREATED)
    def request_sync_seed_qna(request: SeedQnASyncRequest) -> SeedQnASyncResponse:
        request  = SeedQnASyncRequest(**request.__dict__)
        response_data, response = EvaluationServiceManager(api_call=default_api_call).sync_seed_qna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response_data

    @router.post("/system/seedqna/query", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=SystemSeedQnAResponse)
    def system_query_seedqna(request: SystemSeedQnARequest) -> SystemSeedQnAResponse:
        request  = SystemSeedQnARequest(**request.__dict__)
        response_data, response = EvaluationServiceManager(api_call=default_api_call).query_seedqna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response_data

    @router.post("/system/qna/query", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=SystemQnAResponse)
    def system_query_qna(request: SystemQnARequest) -> SystemQnAResponse:
        request  = SystemQnARequest(**request.__dict__)
        response_data, response = EvaluationServiceManager(api_call=default_api_call).query_qna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response_data

    @router.post("/system/evaluation/query", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=SystemEvaluationResponse)
    def system_query_evaluation(request: SystemEvaluationRequest) -> SystemEvaluationResponse:
        request  = SystemEvaluationRequest(**request.__dict__)
        response_data, response = EvaluationServiceManager(api_call=default_api_call).query_evaluation(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response_data


    @router.post("/io/seedqna/export", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
    def system_export_seedqna(request: SeedQnAExportRequest) -> Response:
        request = SeedQnAExportRequest(**request.__dict__)
        response = EvaluationServiceManager(api_call=default_api_call).export_seed_qna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response

    @router.post("/io/qna/export", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
    def system_export_qna(request: QnAExportRequest) -> Response:
        request = QnAExportRequest(**request.__dict__)
        response = EvaluationServiceManager(api_call=default_api_call).export_qna(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response
    
    @router.post("/io/evaluation/export", status_code=status.HTTP_200_OK)
    def system_export_evaluation(request: EvaluationExportRequest) -> Response:
        request = EvaluationExportRequest(**request.__dict__)
        response = EvaluationServiceManager(api_call=default_api_call).export_evaluation(request=request)
        router_response_handler(response=response, api_call=default_api_call)
        return response