from fastapi import APIRouter, status
from typing import Any

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..services.knowledge_service import KnowledgeIngestManager
from ..schemas.knowledge import (
    KnowledgeAutoIngestRequest,
    KnowledgeIngestRequest,
    KnowledgeIngestResponse,
    KnowledgeUpdateIngestRequest,
    PilSyncRequest,
    PilSyncResponse
)

router = APIRouter(tags=["Request"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

@router.post("/request/knowledge/ingest", status_code=status.HTTP_200_OK, response_model=KnowledgeIngestResponse)
def request_knowledge_ingest(request: KnowledgeIngestRequest, api_call: bool=default_api_call) -> KnowledgeIngestResponse:
    request = KnowledgeIngestRequest(**request.__dict__)
    response_knowledge, response = KnowledgeIngestManager(api_call=False).knowledge_ingest_pipeline(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_knowledge

@router.post("/request/knowledge/auto_ingest", status_code=status.HTTP_200_OK, response_model=KnowledgeIngestResponse)
def request_knowledge_auto_ingest(request: KnowledgeAutoIngestRequest, api_call: bool = default_api_call) -> KnowledgeIngestResponse:
    request = KnowledgeAutoIngestRequest(**request.__dict__)
    response_knowledge, response = KnowledgeIngestManager(api_call=False).knowledge_auto_ingest_pipeline(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_knowledge

@router.post("/request/knowledge/update_ingest", status_code=status.HTTP_200_OK, response_model=KnowledgeIngestResponse)
def request_knowledge_update_ingest(request: KnowledgeUpdateIngestRequest, api_call: bool = default_api_call) -> KnowledgeIngestResponse:
    request = KnowledgeUpdateIngestRequest(**request.__dict__)
    response_knowledge, response = KnowledgeIngestManager(api_call=False).knowledge_update_ingest_pipeline(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_knowledge

@router.post("/request/knowledge/pil_sync", status_code=status.HTTP_200_OK, response_model=PilSyncResponse)
def request_pil_sync(request: PilSyncRequest, api_call: bool = default_api_call) -> PilSyncResponse:
    request = PilSyncRequest(**request.__dict__)
    response_knowledge, response = KnowledgeIngestManager(api_call=False).pil_sync_pipeline(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_knowledge

# @router.get("/request/knowledge/csv-read", status_code=status.HTTP_200_OK, response_model=list[KnowledgeCreate])
# def read_pil_metadata_from_file(
#     file_path: str,
#     db_api: Any=db_api,
#     api_call: bool = default_api_call
# ) -> list[KnowledgeCreate]:
#         knowledge_manager = KnowledgeIngestManager(db_api=db_api, api_call=api_call)
#         knowledge_data = knowledge_manager.read_pil_metadata_from_file(file_path=file_path)
#         return knowledge_data

# @router.post("/request/relationship/generate", status_code=status.HTTP_200_OK, response_model=RelationshipExtractResponse)
# def request_relationship_ingest(request: RelationshipExtractRequest, vb_api: Session = vb_api, api_call: bool = default_api_call) -> RelationshipExtractResponse:
#     request = ListDataByKnowledgeReRequest(knowledge_id=request.knowledge_id)
#     response_data, vector_response = AISearchDataManager(vb_api=vb_api, vb_func=vb_func, api_call=api_call).list_by_knowledge_id(request=request)
#     data_input = []
#     for data in response_data.results:
#         knowledge = KnowDataObject(**data.__dict__)
#         data_input.append(knowledge)
#     relationship_request = RelationshipExtractRequest(data_input=data_input)
#     response_relationship, response = KnowledgeIngestManager(db_api=db_api, vb_api=vb_api, gb_api=gb_api, api_call=api_call).preprocess_relationship(request=relationship_request)
#     router_response_handler(response=response, api_call=api_call)
#     return response_relationship


# @router.post("/retrieve", status_code=status.HTTP_200_OK, response_model=VectorRetrieveOutput)
# def retrieve_chunks_endpoint(request: VectorRetrieveInput, vb_api: Session = vb_api, api_call: bool = default_api_call) -> VectorRetrieveOutput:
#     request  = VectorRetrieveInput(**request.__dict__)
#     response_data, response = VectorServiceManager(vb_api=vb_api, vb_func=vb_func, api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).retrieve(request=request)
#     router_response_handler(response=response, api_call=api_call)
#     return response_data


# @router.post("/vector/keyword_search", status_code=status.HTTP_200_OK, response_model=list[str])
# def keyword_search_endpoint(
#     keywords: list[str],
#     vb_api: Session = vb_api,
#     api_call: bool = default_api_call
# ) -> list[str]:
#     if not keywords:
#         return []
#     knowledge_ids = VectorServiceManager(
#         vb_api=vb_api,
#         vb_func=vb_func,
#         api_call=api_call,
#         vector_storage=SETTINGS.VTDB.FORM,
#         vector_location=SETTINGS.VTDB.LOCA,
#         vector_config=SETTINGS.VTDB.CONFIG
#     ).keyword_search(keywords=keywords)

#     return knowledge_ids