from fastapi import APIRouter, Depends, status
from typing import Any

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..services.relationship_service import RelationshipServiceManager

from ..schemas.format import Response

from ..schemas.relationship import (
    KnowledgeRelationshipRequest,
    KnowledgeRelationshipResponse
)

from ..services.graph_service import (
    KnowledgeGraphCreateRequest,
    KnowledgeGraphCreateResponse,
    KnowledgeGraphRequest,
    KnowledgeGraphReadResponse,
    KnowledgeGraphUpdateRequest,
    KnowledgeGraphUpdateResponse,
    KnowledgeGraphDBInfo,
    GraphServiceManager
)

router = APIRouter(tags=["Request-Graph"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


@router.post("/request/knowledge/extract_relationship", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=KnowledgeRelationshipResponse)
def request_knowledge_extract_relationship(request: KnowledgeRelationshipRequest) -> KnowledgeRelationshipResponse:
    request = KnowledgeRelationshipRequest(**request.__dict__)
    response_knowledge, response = RelationshipServiceManager(api_call=False).knowledge_relationship_pipeline(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_knowledge


@router.post("/request/graph/knowledge/single/create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED, response_model=KnowledgeGraphCreateResponse)
def general_create_knowledge_graph(request: KnowledgeGraphCreateRequest) -> KnowledgeGraphCreateResponse:
    request  = KnowledgeGraphCreateRequest(**request.__dict__)
    response_data, response = GraphServiceManager(api_call=False, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).create_knowledge(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/request/graph/knowledge/single/read", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=KnowledgeGraphReadResponse)
def general_read_knowledge_graph(request: KnowledgeGraphRequest) -> KnowledgeGraphReadResponse:
    request  = KnowledgeGraphRequest(**request.__dict__)
    response_data, response = GraphServiceManager(api_call=False, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).read_knowledge(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/request/graph/knowledge/single/update", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED, response_model=KnowledgeGraphUpdateResponse)
def general_update_knowledge_graph(request: KnowledgeGraphUpdateRequest) -> KnowledgeGraphUpdateResponse:
    request  = KnowledgeGraphUpdateRequest(**request.__dict__)
    response_data, response = GraphServiceManager(api_call=False, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).update_knowledge(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/request/graph/knowledge/single/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_drop_knowledge_graph(request: KnowledgeGraphRequest) -> Response:
    request  = KnowledgeGraphRequest(**request.__dict__)
    response = GraphServiceManager(api_call=default_api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).drop_knowledge(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.get("/request/graph/gb_info/{knowledge_id}", status_code=status.HTTP_200_OK, response_model=KnowledgeGraphDBInfo)
def request_gb_info(knowledge_id: str) -> KnowledgeGraphDBInfo:
    response_data, response = GraphServiceManager(api_call=False, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).get_knowledge_gb_info(knowledge_id=knowledge_id)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

