from fastapi import APIRouter, status

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..services.embedding_service import (
    EmbeddingServiceManager,
    EmbeddingRequest,
    EmbeddingResponse
)

from ..schemas.format import Response

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

"""
    Knowledge Vector Management
"""
def request_query_embedding(request: EmbeddingRequest, api_call: bool = default_api_call) -> EmbeddingResponse:
    request = EmbeddingRequest(**request.__dict__)
    response_data, response = EmbeddingServiceManager(api_call=api_call).text_embedding(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data
