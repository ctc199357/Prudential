from fastapi import APIRouter, Depends, status
from typing import Any

import asyncio

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..services.pipeline_service import (
    JobManager, 
    JOB_RELATIONSHIP_PIPELINE,
    JOB_PROCESSING,
    JOB_SUCCESS,
    KnowledgeExportRequest,
    VBMigrationExportRequest,
    GBMigrationExportRequest,
    DBMigrationExportRequest,
    BlobMigrationExportRequest
)

from ..schemas.job import PipelineResponse

from ..schemas.relationship import (
    KnowledgeRelationshipRequest
)

from ..schemas.knowledge import (
    KnowledgeAutoIngestRequest,
    KnowledgeIngestRequest,
    KnowledgeUpdateIngestRequest,
    PilSyncRequest
)


router = APIRouter(tags=["Request-Pipeline"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


@router.get("/pipeline/job/time_trigger/{job_type}", status_code=status.HTTP_200_OK)
def time_trigger_pipeline_job(job_type: str=JOB_RELATIONSHIP_PIPELINE):
    asyncio.run(JobManager(api_call=default_api_call).time_trigger_job(job_type=job_type))

@router.get("/pipeline/job/reset/{job_type}/{job_stage}", status_code=status.HTTP_200_OK)
async def reset_pipeline_job(job_type: str='ALL', job_stage: str=JOB_PROCESSING):
    await JobManager(api_call=False).reset_job(job_type=job_type, job_stage=job_stage)

@router.get("/pipeline/job/clear/{job_type}/{job_stage}", status_code=status.HTTP_200_OK)
def clear_pipeline_job(job_type: str='ALL', job_stage: str=JOB_SUCCESS):
    JobManager(api_call=False).clear_job(job_type=job_type, job_stage=job_stage)


@router.post("/pipeline/job/relationship", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
def request_execute_relationship_pipeline(request: KnowledgeRelationshipRequest) -> PipelineResponse:
    request = KnowledgeRelationshipRequest(**request.__dict__)
    response_data, response = JobManager(api_call=default_api_call).create_relationship_job(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/pipeline/job/ingest", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
async def request_knowledge_ingest_pipeline(request: KnowledgeIngestRequest) -> PipelineResponse:
    request = KnowledgeIngestRequest(**request.__dict__)
    response_knowledge, response = await JobManager(api_call=default_api_call).create_knowledge_ingest(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_knowledge

@router.post("/pipeline/job/auto_ingest", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
async def request_knowledge_auto_ingest(request: KnowledgeAutoIngestRequest) -> PipelineResponse:
    request = KnowledgeAutoIngestRequest(**request.__dict__)
    response_knowledge, response = await JobManager(api_call=default_api_call).create_knowledge_auto_ingest(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_knowledge

@router.post("/pipeline/job/update_ingest", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
async def request_knowledge_update_ingest(request: KnowledgeUpdateIngestRequest) -> PipelineResponse:
    request = KnowledgeUpdateIngestRequest(**request.__dict__)
    response_knowledge, response = await JobManager(api_call=default_api_call).create_knowledge_update_ingest(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_knowledge

@router.post("/pipeline/job/pil_sync", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
async def request_pil_sync(request: PilSyncRequest) -> PipelineResponse:
    request = PilSyncRequest(**request.__dict__)
    response_knowledge, response = await JobManager(api_call=default_api_call).create_pil_sync(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_knowledge

@router.post("/pipeline/job/knowledge_export", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
async def request_knowledge_export(request: KnowledgeExportRequest) -> PipelineResponse:
    request = KnowledgeExportRequest(**request.__dict__)
    response_data, response = await JobManager(api_call=default_api_call).create_knowledge_export_job(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/pipeline/job/db_migration_export", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
async def request_db_migration_export(request: DBMigrationExportRequest) -> PipelineResponse:
    request = DBMigrationExportRequest(**request.__dict__)
    response_data, response = await JobManager(api_call=default_api_call).create_db_migration_export_job(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/pipeline/job/vb_migration_export", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
def request_vb_migration_export(request: VBMigrationExportRequest) -> PipelineResponse:
    request = VBMigrationExportRequest(**request.__dict__)
    response_data, response = JobManager(api_call=default_api_call).create_vb_migration_export_job(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/pipeline/job/gb_migration_export", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
def request_gb_migration_export(request: GBMigrationExportRequest) -> PipelineResponse:
    request = GBMigrationExportRequest(**request.__dict__)
    response_data, response = JobManager(api_call=default_api_call).create_gb_migration_export_job(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/pipeline/job/blob_migration_export", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
async def request_blob_migration_export(request: BlobMigrationExportRequest) -> PipelineResponse:
    request = BlobMigrationExportRequest(**request.__dict__)
    response_data, response = await JobManager(api_call=default_api_call).create_blob_migration_export_job(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/pipeline/job/auto/relationship", status_code=status.HTTP_200_OK, response_model=PipelineResponse)
def request_auto_relationship_pipeline(request: KnowledgeRelationshipRequest) -> PipelineResponse:
    request = KnowledgeRelationshipRequest(**request.__dict__)
    response_data, response = JobManager(api_call=default_api_call).auto_relationship_job(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data