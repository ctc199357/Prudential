from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks

from ..settings import SETTINGS

from ..schemas.health import Health
from ..services.health_service import HealthService

router = APIRouter(tags=["Health"])

@router.get("/", status_code=200)
def index():
    """
    For health check

    :return:
    """
    return {"message": "Welcome to api service!"}

# Auto Job
@router.get("/health", status_code=status.HTTP_200_OK, response_model=Health)
async def health_check() -> Health:
    response_health = HealthService().health_check()
    return response_health


