from fastapi import APIRouter, status

from ...settings import SETTINGS
from ...utils import router_response_handler


from ...database.vector.services.vector_data import (
    VectorDataManager,
    VectorExportRequest
)


from ...schemas.format import Response

router = APIRouter(tags=["Vector-IO"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    vb_api = None
    default_api_call = False

@router.post("/system/vector/export", status_code=status.HTTP_200_OK)
def system_export_vector(request: VectorExportRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorExportRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response