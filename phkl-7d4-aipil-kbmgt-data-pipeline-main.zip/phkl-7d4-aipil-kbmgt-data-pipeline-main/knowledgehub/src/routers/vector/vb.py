from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.vector.services.vector_service import (
        VBManager,
        VBTableInfoResponse
    )

router = APIRouter(tags=["Vector-DB"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

""" VB """
@router.get("/vb/vector/primary/status", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=VBTableInfoResponse)
def vb_primary_status() -> VBTableInfoResponse:
    response_data, response = VBManager().get_primary_vb_info()
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.get("/vb/vector/index/list", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=VBTableInfoResponse)
def vb_table_list() -> VBTableInfoResponse:
    response_data, response = VBManager().get_vb_table_info()
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.delete("/vb/vector/index/drop/{index_name}", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=Response)
def vb_table_drop(index_name: str) -> Response:
    response = VBManager().drop_table(table_name=index_name)
    router_response_handler(response=response, api_call=default_api_call)
    return response