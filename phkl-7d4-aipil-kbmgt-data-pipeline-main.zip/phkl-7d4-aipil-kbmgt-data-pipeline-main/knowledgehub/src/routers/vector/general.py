from fastapi import APIRouter, status

from ...settings import SETTINGS
from ...utils import router_response_handler

from ...database.vector.services.vector_data import (
    VectorDataManager,
    VectorCreateRequest, 
    VectorUpdateRequest,
    VectorBatchCreateRequest,
    VectorRequest,
    VectorBatchRequest
)

from ...schemas.format import Response

router = APIRouter(tags=["Vector-General"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


"""
    Vector Database Management
"""
@router.post("/general/vector/single/create", status_code=status.HTTP_201_CREATED)
def general_create_vector(request: VectorCreateRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorCreateRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/batch/create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_batch_create_vector(request: VectorBatchCreateRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorBatchCreateRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/single/update", status_code=status.HTTP_201_CREATED)
def general_update_vector(request: VectorUpdateRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorUpdateRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/single/activate", status_code=status.HTTP_200_OK)
def general_activate_vector(request: VectorRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/batch/activate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_activate_vector(request: VectorBatchRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorBatchRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/single/deactivate", status_code=status.HTTP_200_OK)
def general_deactivate_vector(request: VectorRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/batch/deactivate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_deactivate_vector(request: VectorBatchRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorBatchRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/single/delete", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_delete_vector(request: VectorRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/batch/delete", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_delete_vector(request: VectorBatchRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorBatchRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/single/drop", status_code=status.HTTP_200_OK)
def general_drop_vector(request: VectorRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/vector/batch/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_drop_vector(request: VectorBatchRequest, api_call: bool = default_api_call) -> Response:
    request  = VectorBatchRequest(**request.__dict__)
    response = VectorDataManager(api_call=api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response