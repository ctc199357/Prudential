from fastapi import APIRouter

from ..settings import SETTINGS

from .health  import router as health_router

from .request import router as request_router

from .request_pipeline import router as requet_pipeline_router

from .job import router as job_router

from .request_evaluation import router as request_evaluation_router

from .request_graph import router as request_graph_router

from .request_migration import router as request_migration_router

from .request_sync import router as request_sync_router

from .registry.general import router as general_router
from .registry.user    import router as user_router
from .registry.system  import router as system_router
from .registry.io      import router as io_router
from .registry.db      import router as db_router

from .vector.general import router as vector_general_router
from .vector.user    import router as vector_user_router
from .vector.system  import router as vector_system_router
from .vector.io      import router as vector_io_router
from .vector.vb      import router as vb_router

from .graph.general import router as graph_general_router
from .graph.user    import router as graph_user_router
from .graph.system  import router as graph_system_router
from .graph.io      import router as graph_io_router
from .graph.gb      import router as gb_router

from .metadata.general import router as metadata_general_rounter
from .metadata.io      import router as metadata_io_router
from .metadata.system  import router as metadata_system_router

router = APIRouter()

# @router.get("/", status_code=200)
# def index():
#     """
#     For health check

#     :return:
#     """
#     return {"domain": ""}

api_routers = [
    health_router,
    request_router,
    requet_pipeline_router,
    job_router,
    request_evaluation_router,
    request_migration_router,
    request_sync_router,
    general_router,
    system_router,
    io_router,
    user_router,
    vector_general_router,
    vector_system_router,
    vector_io_router,
    vector_user_router,
    request_graph_router,
    graph_general_router,
    graph_system_router,
    graph_io_router,
    graph_user_router,
    metadata_general_rounter,
    metadata_system_router,
    metadata_io_router,
    db_router,
    vb_router,
    gb_router
]

for api_router in api_routers:
    router.include_router(api_router, prefix=SETTINGS.BASE.ENDPOINT_PREFIX)