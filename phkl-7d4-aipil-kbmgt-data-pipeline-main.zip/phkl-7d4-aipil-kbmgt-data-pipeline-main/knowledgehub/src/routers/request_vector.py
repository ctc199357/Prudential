from fastapi import APIRouter, status

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..schemas.vector import (
    KnowledgeVectorCreateRequest,
    KnowledgeVectorCreateResponse,
    KnowledgeVectorRequest,
    KnowledgeVectorUpdateRequest,
    KnowledgeVectorUpdateResponse,
    KnowledgeVectorReadResponse,
    VectorSearchRequest,
    VectorSearchResponse
)

from ..schemas.format import Response

from ..services.vector_service import VectorServiceManager

router = APIRouter(tags=["Request-Vector"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

"""
    Knowledge Vector Management
"""
@router.post("/general/vector/knowledge/single/create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED, response_model=KnowledgeVectorCreateResponse)
def general_create_knowledge_vector(request: KnowledgeVectorCreateRequest) -> KnowledgeVectorCreateResponse:
    request  = KnowledgeVectorCreateRequest(**request.__dict__)
    response_data, response = VectorServiceManager(api_call=default_api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).create_knowledge(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/general/vector/knowledge/single/read", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=KnowledgeVectorReadResponse)
def general_read_knowledge_vector(request: KnowledgeVectorRequest) -> KnowledgeVectorReadResponse:
    request  = KnowledgeVectorRequest(**request.__dict__)
    response_data, response = VectorServiceManager(api_call=default_api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).read_knowledge(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/general/vector/knowledge/single/update", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED, response_model=KnowledgeVectorUpdateResponse)
def general_update_knowledge_vector(request: KnowledgeVectorUpdateRequest) -> KnowledgeVectorUpdateResponse:
    request  = KnowledgeVectorUpdateRequest(**request.__dict__)
    response_data, response = VectorServiceManager(api_call=default_api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).update_knowledge(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.post("/general/vector/knowledge/single/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_drop_knowledge_vector(request: KnowledgeVectorRequest) -> Response:
    request  = KnowledgeVectorRequest(**request.__dict__)
    response = VectorServiceManager(api_call=default_api_call, vector_storage=SETTINGS.VTDB.FORM, vector_location=SETTINGS.VTDB.LOCA, vector_config=SETTINGS.VTDB.CONFIG).drop_knowledge(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

def request_vector_search(request: VectorSearchRequest, api_call: bool=default_api_call) -> VectorSearchResponse:
    request = VectorSearchRequest(**request.__dict__)
    response_data, response = VectorServiceManager(api_call=api_call).search_by_vector(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data
