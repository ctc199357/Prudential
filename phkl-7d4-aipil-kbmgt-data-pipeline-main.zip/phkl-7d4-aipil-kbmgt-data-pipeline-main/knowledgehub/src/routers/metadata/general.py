from fastapi import APIRouter, status

from ...settings import SETTINGS
from ...utils import router_response_handler

from ...schemas.format import Response

from ...database.metadata.services.metadata_data import (
    DataManager as MetadataDataManager,
    CreateRequest as MetadataCreateRequest, 
    UpdateRequest as MetadataUpdateRequest,
    DropRequest as MetadataDropRequest
)

router = APIRouter(tags=["Metadata-General"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


"""
    Metadata Data Management
"""
@router.post("/general/metadata/single/create", status_code=status.HTTP_201_CREATED)
def general_create_metadata(request: MetadataCreateRequest, api_call: bool = default_api_call) -> Response:
    request = MetadataCreateRequest(**request.__dict__)
    response = MetadataDataManager(api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/metadata/single/update", status_code=status.HTTP_200_OK)
def general_update_metadata(request: MetadataUpdateRequest, api_call: bool = default_api_call) -> Response:
    request = MetadataUpdateRequest(**request.__dict__)
    response = MetadataDataManager(api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/metadata/single/drop", status_code=status.HTTP_200_OK)
def general_drop_metadata(request: MetadataDropRequest, api_call: bool = default_api_call) -> Response:
    request = MetadataDropRequest(**request.__dict__)
    response = MetadataDataManager(api_call=api_call).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response