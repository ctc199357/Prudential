from fastapi import APIRouter, status

from ...settings import SETTINGS
from ...utils import router_response_handler

from ...schemas.format import Response

from ...database.metadata.services.metadata_data import (
    DataManager as MetadataDataManager,
    DataExportRequest as MetadataExportRequest
)

router = APIRouter(tags=["Metadata-IO"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False



@router.post("/io/metadata/export", status_code=status.HTTP_200_OK)
def io_export_metadata(request: MetadataExportRequest, api_call: bool = default_api_call) -> Response:
    request  = MetadataExportRequest(**request.__dict__)
    response = MetadataDataManager(api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response
