from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.graph.services.gb_service import (
        GBManager,
        GBGraphInfoResponse
    )

router = APIRouter(tags=["Graph-DB"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

""" GB """
@router.get("/gb/graph/primary/status", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=GBGraphInfoResponse)
def gb_primary_status() -> GBGraphInfoResponse:
    response_data, response = GBManager().get_primary_gb_info()
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.get("/gb/graph/container/status/{container_name}", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=GBGraphInfoResponse)
def gb_graph_status(container_name: str) -> GBGraphInfoResponse:
    response_data, response = GBManager().get_gb_graph_info(graph_name=container_name)
    router_response_handler(response=response, api_call=default_api_call)
    return response_data

@router.delete("/gb/graph/container/drop/{container_name}", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=Response)
def gb_graph_drop(container_name: str) -> Response:
    response = GBManager().drop_graph(graph_name=container_name)
    router_response_handler(response=response, api_call=default_api_call)
    return response