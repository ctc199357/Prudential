from fastapi import APIRouter, status

from ...settings import SETTINGS
from ...utils import router_response_handler


from ...database.graph.services.graph_data import (
    DataManager as GraphDataManager,
    SystemDataRequest as SystemGraphRequest,
    SystemDataResponse as SystemGraphResponse,
    DataExportRequest as GraphExportRequest
)


from ...schemas.format import Response

router = APIRouter(tags=["Graph-IO"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    vb_api = None
    default_api_call = False

@router.post("/system/graph/export", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def system_export_graph(request: GraphExportRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphExportRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response