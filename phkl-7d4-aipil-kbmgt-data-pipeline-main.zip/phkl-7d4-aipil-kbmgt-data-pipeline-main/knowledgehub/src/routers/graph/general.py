from fastapi import APIRouter, status
from typing import Any

from ...settings import SETTINGS
from ...utils import router_response_handler

from ...database.graph.services.graph_data import (
    DataManager as GraphDataManager,
    CreateRequest as GraphCreateRequest,
    UpdateRequest as GraphUpdateRequest,
    BatchCreateRequest as GraphBatchCreateRequest,
    CommonRequest as GraphRequest,
    BatchCommonRequest as GraphBatchRequest
)

from ...schemas.format import Response

router = APIRouter(tags=["Graph-General"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


"""
    Graph Database Management
"""
@router.post("/general/graph/single/create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_create_graph(request: GraphCreateRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphCreateRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/batch/create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_batch_create_graph(request: GraphBatchCreateRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphBatchCreateRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/single/update", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_update_graph(request: GraphUpdateRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphUpdateRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/single/activate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_activate_graph(request: GraphRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/batch/activate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_activate_graph(request: GraphBatchRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphBatchRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/single/deactivate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_deactivate_graph(request: GraphRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/batch/deactivate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_deactivate_graph(request: GraphBatchRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphBatchRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/single/delete", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_delete_graph(request: GraphRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/batch/delete", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_delete_graph(request: GraphBatchRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphBatchRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/single/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_drop_graph(request: GraphRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/batch/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_drop_graph(request: GraphBatchRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphBatchRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/graph/condition/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_condition_drop_graph(request: GraphUpdateRequest, api_call: bool = default_api_call) -> Response:
    request  = GraphUpdateRequest(**request.__dict__)
    response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).condition_drop_node(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response