from fastapi import APIRouter, status

from ...settings import SETTINGS
from ...utils import router_response_handler

from ...database.graph.services.graph_data import (
    DataManager as GraphDataManager,
    UserDataRequest as UserGraphRequest,
    UserDataResponse as UserGraphResponse
)

from ...schemas.format import Response

router = APIRouter(tags=["Graph-User"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


@router.post("/user/graph/query", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=UserGraphResponse)
def user_query_knowledge(request: UserGraphRequest, api_call: bool = default_api_call) -> UserGraphResponse:
    request = UserGraphRequest(**request.__dict__)
    response_data, response = GraphDataManager(api_call=api_call, graph_storage=SETTINGS.GPDB.FORM, graph_location=SETTINGS.GPDB.LOCA, graph_config=SETTINGS.GPDB.CONFIG).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data
