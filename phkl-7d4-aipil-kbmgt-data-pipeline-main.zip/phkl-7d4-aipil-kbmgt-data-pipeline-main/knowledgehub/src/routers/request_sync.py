from fastapi import APIRouter, Depends, status
from typing import Any

import asyncio

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..services.sync_service import (
    SyncServiceManager,
    SeedQnASyncRequest,
    SeedQnASyncResponse,
    PilSyncResponse,
)

from ..schemas.format import Response

router = APIRouter(tags=["Request-Sync"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

def sync_access_from_file(file_path: str, batch_order: str) -> Response:
    response = SyncServiceManager().sync_pil_access_from_file(file_path=file_path, batch_order=batch_order)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.get("/sync/pil_access", status_code=status.HTTP_200_OK)
def sync_pil_access() -> Response:
    response = SyncServiceManager().sync_pil_access()
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.get("/sync/seed_qna", status_code=status.HTTP_200_OK)
def sync_seed_qna() -> Response:
    response = SyncServiceManager().sync_seed_qna()    
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.get("/sync/pil_metadata", status_code=status.HTTP_200_OK)
def sync_pil_metadata() -> PilSyncResponse:
    response_data, response = SyncServiceManager().sync_pil_metadata()
    router_response_handler(response=response, api_call=default_api_call)
    return response_data