from fastapi import APIRouter, status, File, UploadFile, Form, Depends
from typing import List
import json

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..migration.migration_db.services.db_data import (
    DBManager as DBMigrationManager,
    BatchMigrateRequest as DBBatchMigrateRequest
)

from ..migration.migration_vb.services.vb_data import (
    VBManager as VBMigrationManager,
    BatchMigrateRequest as VBBatchMigrateRequest,
    InitMigrationTableRequest as VBInitMigrationRequest
)

from ..migration.migration_blob.services.blob_data import (
    BlobManager as BlobMigrationManager,
    BatchMigrateRequest as BlobBatchMigrateRequest,
    BlobConfig,
    FileConfig
)

from ..schemas.migration import (
    DBMigrationExportRequest,
    VBMigrationExportRequest,
    BlobMigrationExportRequest,
    GBMigrationExportRequest
)

from ..migration.migration_gb.services.gb_data import (
    GBManager as GBMigrationManager,
    BatchMigrateRequest as GBBatchMigrateRequest,
    DBConfig as GBConfig
)

from ..schemas.format import Response

from ..services.migration_service import MigrationManager

router = APIRouter(tags=["Request-Migration"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

"""
Form Object helper function
"""

# Dependency to parse form fields into the model
def parse_blob_batch_migrate_request(
    blob_batch_migrate_request: str = Form('{"blob_config": {"connection_string": "", "container_name": ""}, "data": {"blob_path": "", "blob_url": "", "file_type": ""}, "action": "INSERT"}')
) -> BlobBatchMigrateRequest:
    json_dict = json.loads(blob_batch_migrate_request)
    return BlobBatchMigrateRequest(**json_dict)

"""
    Migration Management
"""
@router.post("/migration/db/import", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def migrate_db_import(request: DBBatchMigrateRequest) -> Response:
    request  = DBBatchMigrateRequest(**request.__dict__)
    response = DBMigrationManager().batch_migrate(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.post("/migration/vb/import", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def migrate_vb_import(request: VBBatchMigrateRequest) -> Response:
    request  = VBBatchMigrateRequest(**request.__dict__)
    response = VBMigrationManager().batch_migrate(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.post("/migration/blob/import", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
async def migrate_blob_import(request: BlobBatchMigrateRequest = Depends(parse_blob_batch_migrate_request),
                        file: UploadFile = File(None)) -> Response:
    response = await BlobMigrationManager().batch_migrate(request=request, file=file)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.post("/migration/vb/init", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def migrate_vb_init(request: VBInitMigrationRequest) -> Response:
    request  = VBInitMigrationRequest(**request.__dict__)
    response = VBMigrationManager().init_table(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.post("/migration/gb/import", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def migrate_gb_import(request: GBBatchMigrateRequest) -> Response:
    request  = GBBatchMigrateRequest(**request.__dict__)
    response = GBMigrationManager().batch_migrate(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.post("/migration/gb/init", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def migrate_gb_init(request: GBConfig) -> Response:
    request  = GBConfig(**request.__dict__)
    response = GBMigrationManager().init_gb(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response


@router.post("/migration/db/export", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def migrate_db_export(request: DBMigrationExportRequest) -> Response:
    request  = DBMigrationExportRequest(**request.__dict__)
    response = MigrationManager(api_call=default_api_call).export_db_by_partition(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.post("/migration/vb/export", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def migrate_vb_export(request: VBMigrationExportRequest) -> Response:
    request  = VBMigrationExportRequest(**request.__dict__)
    response = MigrationManager(api_call=default_api_call).export_vb_by_partition(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.post("/migration/blob/export", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
async def migrate_blob_export(request: BlobMigrationExportRequest) -> Response:
    request  = BlobMigrationExportRequest(**request.__dict__)
    response = await MigrationManager(api_call=default_api_call).export_blob_by_partition(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response

@router.post("/migration/gb/export", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def migrate_gb_export(request: GBMigrationExportRequest) -> Response:
    request  = GBMigrationExportRequest(**request.__dict__)
    response = MigrationManager(api_call=default_api_call).export_gb_by_partition(request=request)
    router_response_handler(response=response, api_call=default_api_call)
    return response
