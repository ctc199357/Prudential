from fastapi import APIRouter, Depends, status
from typing import Any

import asyncio

from ..settings import SETTINGS
from ..utils import router_response_handler

from ..scheduler.scheduler_service import (
    SchedulerService
)

router = APIRouter(tags=["Request-Scheduler"])

def request_init_background_scheduler() -> Any:
    scheduler= SchedulerService.init_background_scheduler()
    return scheduler
