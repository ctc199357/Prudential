from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.knowledge_data import (
        DataManager as KnowledgeDataManager,
        UserDataRequest as UserKnowledgeRequest, 
        UserDataResponse as UserKnowledgeResponse,
    )


router = APIRouter(tags=["Registry-User"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


""" Knowledge """
@router.post("/user/knowledge/query", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=UserKnowledgeResponse)
def user_query_knowledge(request: UserKnowledgeRequest, api_call: bool=default_api_call) -> UserKnowledgeResponse:
    request = UserKnowledgeRequest(**request.__dict__)
    response_data, response = KnowledgeDataManager(api_call=api_call).query_data_by_user(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

