from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.knowledge_data import (
        DataManager as KnowledgeDataManager,
        DataBackupRequest as KnowledgeBackupRequest, 
        DataBackupListRequest as KnowledgeBackupListRequest,
        DataBackupListResponse as KnowledgeBackupListResponse,
        DBRestoreRequest as KnowledgeRestoreRequest,
        DataImportRequest as KnowledgeImportRequest,
        DataExportRequest as KnowledgeExportRequest,
    )


router = APIRouter(tags=["Registry-IO"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

""" Knowledge """
@router.post("/io/knowledge/export", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def system_export_knowledge(request: KnowledgeExportRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeExportRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).export_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/knowledge/import", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def system_import_knowledge(request: KnowledgeImportRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeImportRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).import_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/knowledge/backup", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def system_backup_knowledge(request: KnowledgeBackupRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeBackupRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).backup_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/io/knowledge/backup/list", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=KnowledgeBackupListResponse)
def system_backup_list_knowledge(request: KnowledgeBackupListRequest, api_call: bool=default_api_call) -> KnowledgeBackupListResponse:
    request = KnowledgeBackupListRequest(**request.__dict__)
    response_table, response = KnowledgeDataManager(api_call=api_call).list_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_table

@router.post("/io/knowledge/restore/backup", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def system_restore_backup_knowledge(request: KnowledgeRestoreRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeRestoreRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).restore_backup_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response