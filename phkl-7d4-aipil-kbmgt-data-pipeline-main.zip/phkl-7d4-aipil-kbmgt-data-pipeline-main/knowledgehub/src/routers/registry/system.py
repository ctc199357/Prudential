from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.knowledge_data import (
        DataManager as KnowledgeDataManager,
        SystemDataRequest as SystemKnowledgeRequest, 
        SystemDataResponse as SystemKnowledgeResponse,
    )

from ...database.registry.services.access_data import (
        DataManager as AccessDataManager,
        SystemDataRequest as SystemAccessRequest, 
        SystemDataResponse as SystemAccessResponse,
    )

from ...database.registry.services.keyword_mapping import(
    DataManager as KMDataManager,
    SystemDataRequest as SystemKMRequest, 
    SystemDataResponse as SystemKMResponse,
    CreateRequest as CreateRequest,
    UpdateRequest as UpdateRequest,
    CommonRequest as KMRequest,

    SystemKeywordMappingFuncReponse as SystemKeywordMappingFuncReponse,
    SystemKeywordMappingFuncRequest as SystemKeywordMappingFuncRequest

)

router = APIRouter(tags=["Registry-System"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

""" Knowledge """
@router.post("/system/knowledge/query", status_code=status.HTTP_200_OK, response_model=SystemKnowledgeResponse)
def system_query_knowledge(request: SystemKnowledgeRequest, api_call: bool=default_api_call) -> SystemKnowledgeResponse:
    request = SystemKnowledgeRequest(**request.__dict__)
    response_data, response = KnowledgeDataManager(api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/knowledge/drop/inactive", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def system_drop_inactive_knowledge(api_call: bool=default_api_call) -> Response:
    response = KnowledgeDataManager(api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response

""" Access """
@router.post("/system/access/query", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=SystemAccessResponse)
def system_query_access(request: SystemAccessRequest, api_call: bool=default_api_call) -> SystemAccessResponse:
    request = SystemAccessRequest(**request.__dict__)
    response_data, response = AccessDataManager(api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data

@router.delete("/system/access/drop/inactive", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def system_drop_inactive_access(api_call: bool=default_api_call) -> Response:
    response = AccessDataManager(api_call=api_call).drop_inactive_by_system()
    router_response_handler(response=response, api_call=api_call)
    return response

""" Keyword Mapping """
@router.post("/request/system_query_keyword_mapping", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=SystemKMResponse)
def system_query_keyword_mapping(request: SystemKMRequest, api_call: bool = default_api_call) -> SystemKMResponse:
    request = SystemKMRequest(**request.__dict__)
    response_data, response = KMDataManager(api_call=api_call).query_data_by_system(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response_data


# @router.post("/request/get_keyword_mappings_with_string", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=SystemKeywordMappingFuncReponse)
# def get_keyword_mappings_with_string(request:SystemKeywordMappingFuncRequest, api_call: bool = default_api_call) -> SystemKeywordMappingFuncReponse:
#     request = SystemKeywordMappingFuncRequest(**request.__dict__)

#     response_data, response = KMDataManager(api_call=api_call).get_keyword_mappings_with_string(request=request)
#     router_response_handler(response=response, api_call=api_call)
#     return response_data

# @router.post("/request/keyword_mappings_create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=Any)
# def keyword_mappings_create(request: CreateRequest, api_call: bool = default_api_call) -> Any:
#     request = CreateRequest(**request.__dict__)
#     response_data, response = KMDataManager(api_call=api_call).create(request=request)
#     return response_data

# @router.post("/request/keyword_mappings_update", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=Any)
# def keyword_mappings_update(request: UpdateRequest, api_call: bool = default_api_call) -> Any:
#     request = UpdateRequest(**request.__dict__)
#     response_data, response = KMDataManager(api_call=api_call).update(request=request)
#     return response_data


# @router.post("/request/keyword_mappings_del", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK, response_model=Any)
# def keyword_mappings_del(request: KMRequest, api_call: bool = default_api_call) -> Any:
#     request = KMRequest(**request.__dict__)
#     response_data, response = KMDataManager(api_call=api_call).delete(request=request)
#     return response_data