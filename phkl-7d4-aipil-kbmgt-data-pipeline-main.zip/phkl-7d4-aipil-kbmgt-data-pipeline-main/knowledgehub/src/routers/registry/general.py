from fastapi import APIRouter, Depends, status
from typing import Any

from ...settings import SETTINGS
from ...schemas.format import Response
from ...utils import router_response_handler

from ...database.registry.services.knowledge_data import (
        DataManager as KnowledgeDataManager,
        CreateRequest as KnowledgeCreateRequest, 
        BatchCreateRequest as KnowledgeBatchCreateRequest,
        UpdateRequest as KnowledgeUpdateRequest, 
        CommonRequest as KnowledgeRequest,
        BatchCommonRequest as KnowledgeBatchRequest,
    )

from ...database.registry.services.access_data import (
        DataManager as AccessDataManager,
        CreateRequest as AccessCreateRequest, 
        BatchCreateRequest as AccessBatchCreateRequest,
        UpdateRequest as AccessUpdateRequest, 
        CommonRequest as AccessRequest,
        BatchCommonRequest as AccessBatchRequest,
    )

router = APIRouter(tags=["Registry-General"])

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


"""
    Knowledge Data Management
"""
@router.post("/general/knowledge/single/create", status_code=status.HTTP_201_CREATED)
def general_create_knowledge(request: KnowledgeCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeCreateRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledge/single/upsert", status_code=status.HTTP_201_CREATED)
def general_upsert_knowledge(request: KnowledgeCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeCreateRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).upsert(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/knowledge/single/update", status_code=status.HTTP_200_OK)
def general_update_knowledge(request: KnowledgeUpdateRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeUpdateRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledge/single/delete", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_delete_knowledge(request: KnowledgeRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledge/single/drop", status_code=status.HTTP_200_OK)
def general_drop_knowledge(request: KnowledgeRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).force_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledge/single/activate", status_code=status.HTTP_200_OK)
def general_activate_knowledge(request: KnowledgeRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledge/single/deactivate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_deactivate_knowledge(request: KnowledgeRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledge/batch/create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_batch_create_knowledge(request: KnowledgeBatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeBatchCreateRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledge/batch/upsert", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_batch_upsert_knowledge(request: KnowledgeBatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeBatchCreateRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).batch_upsert(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledge/batch/delete", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_delete_knowledge(request: KnowledgeBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeBatchRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/knowledge/batch/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_drop_knowledge(request: KnowledgeBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeBatchRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledge/batch/activate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_activate_knowledge(request: KnowledgeBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeBatchRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/knowledge/batch/deactivate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_deactivate_knowledge(request: KnowledgeBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = KnowledgeBatchRequest(**request.__dict__)
    response = KnowledgeDataManager(api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response


"""
    Access Data Management
"""
@router.post("/general/access/single/create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_create_access(request: AccessCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessCreateRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/access/single/upsert", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_upsert_access(request: AccessCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessCreateRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).upsert(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.patch("/general/access/single/update", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_update_access(request: AccessUpdateRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessUpdateRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).update(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/access/single/delete", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_delete_access(request: AccessRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/access/single/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_drop_access(request: AccessRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).force_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/access/single/activate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_activate_access(request: AccessRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/access/single/deactivate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_deactivate_access(request: AccessRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/access/batch/create", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_batch_create_access(request: AccessBatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessBatchCreateRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).batch_create(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/access/batch/upsert", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_201_CREATED)
def general_batch_upsert_access(request: AccessBatchCreateRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessBatchCreateRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).batch_upsert(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/access/batch/delete", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_delete_access(request: AccessBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessBatchRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).batch_delete(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.delete("/general/access/batch/drop", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_drop_access(request: AccessBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessBatchRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).batch_drop(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/access/batch/activate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_activate_access(request: AccessBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessBatchRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).batch_activate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response

@router.post("/general/access/batch/deactivate", include_in_schema=not(SETTINGS.BASE.APP_PRODUCTION), status_code=status.HTTP_200_OK)
def general_batch_deactivate_access(request: AccessBatchRequest, api_call: bool=default_api_call) -> Response:
    request  = AccessBatchRequest(**request.__dict__)
    response = AccessDataManager(api_call=api_call).batch_deactivate(request=request)
    router_response_handler(response=response, api_call=api_call)
    return response