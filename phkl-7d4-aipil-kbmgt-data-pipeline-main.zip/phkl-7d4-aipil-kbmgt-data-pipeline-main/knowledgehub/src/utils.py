import os

import re

from datetime import datetime, timezone

from fastapi import HTTPException

from .settings import SETTINGS

from .schemas.format import Response

from azure.storage.blob import BlobClient, BlobServiceClient, ContentSettings

from .logger.log_handler import get_logger

logger = get_logger(__name__)

# Router Response Handler
def router_response_handler(response: Response, api_call: bool):
    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
        if api_call == True:
            raise HTTPException(status_code=response.status_code, detail=response.detail)
        else:
            raise Exception(response.detail)

def upload_to_blob(local_path: str, blob_path: str, content_type: str) -> str:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob_path)
        content_settings = ContentSettings(content_type=content_type)

        with open(local_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True, content_settings=content_settings)

        logger.info(f"Uploaded {local_path} to blob storage as {blob_path}")

        return blob_client.url 
    except Exception as e:
        logger.error(f"Failed to upload {local_path} to blob storage: {str(e)}")
        raise

def delete_blob_file(blob: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob)
        blob_client.delete_blob()
        logger.info(f"Deleted {blob} on blob storage")
    except Exception as e:
        logger.error(f"Failed to delete {blob} on blob storage: {str(e)}")
        raise

def delete_blob_folder(blob_folder_path: str):
    try:
        # Set up blob service client
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(SETTINGS.BLOB.CONTAINER_NAME)
        # List all blobs in the directory
        blobs_list = container_client.list_blobs(name_starts_with=blob_folder_path)

        # Download each blob file
        for blob in blobs_list:
            blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob.name)
            blob_client.delete_blob()
            logger.info(f"Deleted {blob.name} on blob storage")

    except Exception as e:
        logger.error(f"Failed to delete {blob_folder_path} on blob storage: {str(e)}")
        raise

def delete_blob_file_by_url(blob_url: str):
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        
        blob_client = BlobClient.from_blob_url(
            blob_url,
            credential=blob_service_client.credential
        )
        if blob_client.exists():
            blob_client.delete_blob()
            logger.info(f"Deleted {blob_url} on blob storage")
        else:
            logger.info(f"No blob found for {blob_url}")
    except Exception as e:
        logger.error(f"Failed to delete {blob_url} on blob storage: {str(e)}")
        raise

def download_from_blob_by_url(blob_file_url: str, local_path: str):
    try:
        # Initialize blob service client
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        
        blob_client = BlobClient.from_blob_url(
            blob_file_url,
            credential=blob_service_client.credential
        )
        # Download the blob
        with open(local_path, "wb") as file:
            file.write(blob_client.download_blob().readall())

        logger.info(f"Downloaded blob from {blob_file_url} to {local_path}")
    except Exception as e:
        logger.error(f"Failed to download {blob_file_url} from blob storage: {str(e)}")
        raise

def check_and_download_blob_by_url(blob_file_url: str, local_path: str) -> bool:
    try:
        # Initialize blob service client
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        
        blob_client = BlobClient.from_blob_url(
            blob_file_url,
            credential=blob_service_client.credential
        )
        if blob_client.exists():
            # Download the blob
            with open(local_path, "wb") as file:
                file.write(blob_client.download_blob().readall())

            logger.info(f"Downloaded blob from {blob_file_url} to {local_path}")
            return True
        else:
            logger.info(f"No Blob Found for {blob_file_url}")
            return False
    except Exception as e:
        logger.error(f"Failed to download {blob_file_url} from blob storage: {str(e)}")
        raise

def ensure_blob_url(blob_input: str) -> str:
    try:
        blob_url_pattern = r"^https?://[a-z0-9]+\.blob\.core\.windows\.net/[a-z0-9-]+/.+$"

        if re.match(blob_url_pattern, blob_input):
            return blob_input  # Already a valid blob URL
    
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob_input)
        return blob_client.url
    except Exception as e:
        logger.error(f"Failed to get blob url for {blob_input}: {str(e)}")
        raise

def check_blob_file_exists(blob_path: str) -> bool:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob_path)
        return blob_client.exists()
    except Exception as e:
        logger.error(f"Failed to check if {blob_path} exists on blob storage: {str(e)}")
        raise

def get_blob_path(blob_url: str) -> str:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        blob_client = BlobClient.from_blob_url(
            blob_url,
            credential=blob_service_client.credential
        )
        return blob_client.blob_name
    except Exception as e:
        logger.error(f"Failed to get blob path for {blob_url}: {str(e)}")
        raise

def list_blob(folder_name: str, container: str=SETTINGS.BLOB.CONTAINER_NAME) -> list:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(container)
        blob_list = container_client.list_blobs(name_starts_with=folder_name)
        return blob_list
        
    except Exception as e:
        logger.error(f"Failed to get blob list for {container}/{folder_name}: {str(e)}")
        raise


def get_sync_blob(folder_name: str, date_str: str, file_name: str, container: str=SETTINGS.BLOB.CONTAINER_NAME) -> str:
    
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(container)
        blob_list = container_client.list_blobs(name_starts_with=folder_name)

        # Filter for folders that match the current date
        latest_folder = None
        sync_file = None

        for blob in blob_list:
            folder_name_part = blob.name[len(folder_name):len(folder_name) + 14]  # Extract YYYYMMDDHHMMSS
            if folder_name_part.startswith(date_str):
                latest_folder = blob.name
                break
            
        if latest_folder:
            file_list = container_client.list_blobs(name_starts_with=latest_folder)
            for file in file_list:
                if file.name.endswith(file_name):
                    sync_file = file.name
                    break
        
        return sync_file
        
    except Exception as e:
        logger.error(f"Failed to get blob list for {container}/{folder_name}: {str(e)}")
        raise


def check_sync_blob(folder_name: str, date_str: str, file_name: str, container: str=SETTINGS.BLOB.CONTAINER_NAME) -> tuple[str, str]:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(container)
        blob_list = container_client.list_blobs(name_starts_with=folder_name)

        # Filter for folders that match the current date
        sync_file = None
        sync_file_url       = ""
        sync_file_timestamp = ""

        for blob in blob_list:

            if file_name in blob.name:
                sync_file_timestamp = blob.name[len(folder_name):len(folder_name) + 14]  # Extract YYYYMMDDHHMMSS
                if int(sync_file_timestamp) > int(date_str):
                    sync_file = blob.name
                break

        if sync_file:
            blob_client = blob_service_client.get_blob_client(container=container, blob=sync_file)
            sync_file_url = blob_client.url

        return sync_file_url, sync_file_timestamp
        
    except Exception as e:
        logger.error(f"Failed to get blob list for {container}/{folder_name}: {str(e)}")
        raise e
    
def get_sync_blob_url(folder_name: str, file_name: str, container: str=SETTINGS.BLOB.CONTAINER_NAME) -> str:
    try:
        blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(container)
        blob_list = container_client.list_blobs(name_starts_with=folder_name)
        sync_file = None

        max_date = int("19000101000000")
        for blob in blob_list:
            if blob.name.endswith(file_name):
                datetime_part = blob.name[len(folder_name):len(folder_name) + 14]  # Extract YYYYMMDDHHMMSS
                if int(datetime_part) > max_date:
                    max_date = int(datetime_part)
                    sync_file = blob.name

        if sync_file:
            blob_client = blob_service_client.get_blob_client(container=container, blob=sync_file)
            return blob_client.url
        else:
            return None
        
    except Exception as e:
        logger.error(f"Failed to get blob list for {container}/{folder_name}: {str(e)}")
        raise
