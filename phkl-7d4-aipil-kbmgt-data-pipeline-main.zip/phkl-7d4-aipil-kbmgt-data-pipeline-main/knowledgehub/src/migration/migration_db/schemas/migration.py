from pydantic import BaseModel, Field, validator
from typing import List, Optional, Union, Any
import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS

class DBConfig(BaseModel):
    db_url:  Optional[str]=Field(default='', description="DB Connection URL")
    db_name: Optional[str]=Field(default='', description="DB Name")

class BatchMigrateRequest(BaseModel):
    db_config: DBConfig=Field(defualt=DBConfig(), description="DB Connection Config")
    meta:      dict=Field(..., description="DynamicDocument Meta - collection and indexes")
    uid_field: str=Field(default='id', description="Field Name of Data UID")
    data:      List[dict]=Field(..., description="List of Input Data")
    action:    str=Field(default="INSERT", description="INSERT, UPSERT, DROP")