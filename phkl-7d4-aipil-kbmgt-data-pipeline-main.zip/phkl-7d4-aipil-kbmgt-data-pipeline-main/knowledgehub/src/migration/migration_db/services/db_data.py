"""
    DB Service Manager
"""
import urllib.parse
from mongoengine import connect, disconnect, NotUniqueError, DynamicDocument
from pymongo.errors import ServerSelectionTimeoutError
from contextlib import contextmanager
from azure.storage.blob import BlobClient, BlobServiceClient

import time
from datetime import datetime, timezone
import inspect

from ....settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.migration import (
    BatchMigrateRequest
)

from ....logger.log_handler import get_logger

logger = get_logger(__name__)

    
if SETTINGS.DATB.LOCA.lower() == "azure":
    # Access Database Settings
    DB_URL = '{user}:{pswd}@{host}:{port}/?{other}'.format(
        host=urllib.parse.quote_plus(SETTINGS.DATB.HOST),  # DB host
        port=urllib.parse.quote_plus(SETTINGS.DATB.PORT),  # DB port
        other=SETTINGS.DATB.CONFIG.get("OTHER", ""),  # DB name
        user=urllib.parse.quote_plus(SETTINGS.DATB.USER),  # DB user
        pswd=urllib.parse.quote_plus(SETTINGS.DATB.PSWD)   # DB pswd
    )

elif SETTINGS.DATB.LOCA.lower() == "server":
    
    # Access Database Settings
    if SETTINGS.DATB.USER and SETTINGS.DATB.PSWD:
        DB_URL = '{user}:{pswd}@{host}:{port}/{name}'.format(
            host=urllib.parse.quote_plus(SETTINGS.DATB.HOST),  # DB host
            port=urllib.parse.quote_plus(SETTINGS.DATB.PORT),  # DB port
            name=urllib.parse.quote_plus(SETTINGS.DATB.NAME),  # DB name
            user=urllib.parse.quote_plus(SETTINGS.DATB.USER),  # DB user
            pswd=urllib.parse.quote_plus(SETTINGS.DATB.PSWD)   # DB pswd
        )
    
    else:
        DB_URL = '{host}:{port}/{name}'.format(
            host=urllib.parse.quote_plus(SETTINGS.DATB.HOST),  # DB host
            port=urllib.parse.quote_plus(SETTINGS.DATB.PORT),  # DB port
            name=urllib.parse.quote_plus(SETTINGS.DATB.NAME)   # DB name
        )

DATABASE_URL = f"mongodb://{DB_URL}"
DB_ALIAS_PREFIX = f"dynamic-"

def connect_to_db(db_name: str=SETTINGS.DATB.NAME, db_url: str=DATABASE_URL):
    # Test DB Connection
    try:
        connect(db_name, alias=f"{DB_ALIAS_PREFIX}{db_name}", host=db_url)
        logger.info(f"Connected : <{SETTINGS.BASE.APP_NAME}> <{db_name}> Database")

    except ServerSelectionTimeoutError:
        err_msg = f"DB Connection Timeout Error : <{SETTINGS.BASE.APP_NAME}> <{db_name}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)
    
    # Handle any other exceptions that might occur
    except:
        err_msg = f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> <{db_name}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)


class DBManager:
    blob_url_prefix = f"https://{SETTINGS.BLOB.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BLOB.CONTAINER_NAME}/"
    metadata_blob_url_prefix = f"https://{SETTINGS.BLOB.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BLOB.METADATA_CONTAINER_NAME}/"
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    @contextmanager
    def get_db(
        self,
        db_meta: dict,
        db_name: str=SETTINGS.DATB.NAME, 
        db_url:  str=DATABASE_URL
    ):

        class DynamicDB(DynamicDocument):
            meta = db_meta | {'db_alias': f"{DB_ALIAS_PREFIX}{db_name}"}

            def to_dict(self):
                return {**self.to_mongo().to_dict()}
        
        try:
            connect(db_name, alias=f"{DB_ALIAS_PREFIX}{db_name}", host=db_url)
            client = DynamicDB._get_db().client
            with client.start_session() as session:
                session.start_transaction()
                try:
                    yield DynamicDB, session  # Yield the class for document operations
                    session.commit_transaction()
                except Exception as e:
                    session.abort_transaction()
                    raise e
                finally:
                    session.end_session()

        except Exception as e:
            raise e

        # finally:
        #     disconnect(f"{DB_ALIAS_PREFIX}{db_name}")

    def batch_migrate(self, request: BatchMigrateRequest) -> Response:
        logger.info("Starting Data Migration")

        if not request.meta.get("collection", ""):
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Collection Name", str(e)))
            logger.error(response.detail)
            return response 
        
        db_name = request.db_config.db_name if request.db_config.db_name else SETTINGS.DATB.NAME
        db_url  = request.db_config.db_url  if request.db_config.db_url else DATABASE_URL

        for _data in request.data:
            # Knowledge Blob Url Conversion
            if _data.get("storage_directory"):
                _data["storage_directory"] = self.get_new_blob_url(blob_url=_data["storage_directory"], migration_type="knowledge")
            if _data.get("storage_directory_origin"):
                _data["storage_directory_origin"] = self.get_new_blob_url(blob_url=_data["storage_directory_origin"], migration_type="knowledge")
            # Metadata Blob Url Conversion
            if _data.get("file_sync_url_to"):
                _data["file_sync_url_to"] = self.get_new_blob_url(blob_url=_data["file_sync_url_to"], migration_type="metadata")
            if _data.get("file_sync_url_from"):
                _data["file_sync_url_from"] = self.get_new_blob_url(blob_url=_data["file_sync_url_from"], migration_type="metadata")

        try:
            with self.get_db(db_meta=request.meta, db_name=db_name, db_url=db_url) as (DynamicDB, session):
                if request.action.upper() == "INSERT":
                    for _data in request.data:
                        db_data = DynamicDB(**_data)
                        db_data.save()
                        time.sleep(SETTINGS.DATB.CREATE_WAIT_SEC)

                elif request.action.upper() == "UPSERT":
                    for _data in request.data:
                        DynamicDB.objects(**{request.uid_field: _data.get(request.uid_field)}).update_one(
                            **{f"set__{key}": value for key, value in _data.items()},
                            upsert=True
                        )
                        time.sleep(SETTINGS.DATB.CREATE_WAIT_SEC)
                
                elif request.action.upper() == "DROP":
                    for _data in request.data:
                        DynamicDB.objects(**{request.uid_field: _data.get(request.uid_field)}).delete()
                        time.sleep(SETTINGS.DATB.CREATE_WAIT_SEC)
                        
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Migration Fail : Unknown Migration Action"))
                    return response
                
                response = Response(status_code=201, detail=self.response_format.ok(f"Success : {request.action} Data"))
                logger.info(response.detail)

        except NotUniqueError as e:
            response = Response(status_code=400, detail=self.response_format.error(
                f"Migration Error: <{SETTINGS.BASE.APP_NAME}> Duplicate Key Error", str(e)))
            logger.error(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Failed to Connect DB", str(e)))
            logger.error(response.detail)
            
        return response
    
    
    def get_new_blob_url(self, blob_url: str, migration_type: str) -> str:
        new_blob_url = ""
        try:
            blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
            blob_client = BlobClient.from_blob_url(
                blob_url,
                credential=blob_service_client.credential
            )
            blob_path = blob_client.blob_name
            if migration_type == "metadata":
                new_blob_url = f"{self.metadata_blob_url_prefix}{blob_path}"
            else:
                new_blob_url = f"{self.blob_url_prefix}{blob_path}"

            logger.debug(f"Success : Replace Data Url from {blob_url} to {new_blob_url}")
        except Exception as e:
            new_blob_url = blob_url # Reset
            logger.error(f"Unexpected Error : Replace Blob Data Url | {str(e)}")
            
        return new_blob_url