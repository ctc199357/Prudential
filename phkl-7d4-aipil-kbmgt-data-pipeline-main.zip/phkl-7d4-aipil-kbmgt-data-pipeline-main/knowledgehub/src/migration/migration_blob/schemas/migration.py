from pydantic import BaseModel, Field, validator
from typing import List, Optional, Union, Any, Literal
import uuid
from datetime import datetime, timezone

from ....settings import SETTINGS

class BlobConfig(BaseModel):
    connection_string:  Optional[str]=Field(default='', description="DB Connection URL")
    container_name:     Optional[str]=Field(default='', description="DB Name")

class FileConfig(BaseModel):
    blob_path:      Optional[str]=Field(default='', description="Blob Path for INSERT, UPSERT")
    blob_url:       Optional[str]=Field(default='', description="Blob URL for DROP")
    file_type:      Optional[str]=Field(default='', description="File type (jpeg, json, or pdf)")

class BatchMigrateRequest(BaseModel):
    blob_config: BlobConfig
    data:        FileConfig=Field(..., description="Blob Local File Path and Blob Path for INSERT, UPSERT; List of Blob URL for DROP")
    action:      str=Field(default="INSERT", description="INSERT, UPSERT, DROP")
