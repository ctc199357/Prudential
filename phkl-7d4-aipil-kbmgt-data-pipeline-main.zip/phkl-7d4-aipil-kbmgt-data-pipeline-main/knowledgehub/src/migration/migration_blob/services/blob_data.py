"""
    Blob Service Manager
"""
import mimetypes
import os
import inspect

from datetime import datetime, timezone
from azure.storage.blob import BlobClient, BlobServiceClient, ContentSettings

from ....settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.migration import (
    FileConfig,
    BlobConfig,
    BatchMigrateRequest
)

from fastapi import UploadFile, File
from typing import List

from ....logger.log_handler import get_logger

logger = get_logger(__name__)

VALID_CONTENT_TYPE = {
    'json': 'application/json',
    'jpeg': 'image/jpeg',
    'pdf': 'application/pdf',
    'csv': 'text/csv',
    'xls': 'application/vnd.ms-excel',
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'doc': 'application/msword',
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
}

class BlobManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    
    async def batch_migrate(self, request: BatchMigrateRequest, file: UploadFile = File(None)) -> Response:
        logger.info("Starting Blob Migration")

        blob_config, response = self.data_check(request, file)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response
        
        try:
            if request.action.upper() == "INSERT":
                response = await self.upload_blob(file=file, file_type=request.data.file_type, blob_path=request.data.blob_path, blob_config=blob_config)

            elif request.action.upper() == "UPSERT":
                response = await self.upload_blob(file=file, file_type=request.data.file_type, blob_path=request.data.blob_path, blob_config=blob_config)
            
            elif request.action.upper() == "DROP":
                response = self.delete_blob(blob_url=request.data.blob_url, blob_config=blob_config)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"Migration Fail : Unknown Migration Action"))
                return response
            
            response = Response(status_code=201, detail=self.response_format.ok(f"Success : {request.action} Blob"))
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Failed to Migrate Blob", str(e)))
            logger.error(response.detail)
            
        return response
    
    def data_check(self, request: BatchMigrateRequest, file: UploadFile = File(None)) -> tuple[BlobConfig, Response]:
        blob_config = BlobConfig()
        blob_connection_string = request.blob_config.connection_string if request.blob_config.connection_string else SETTINGS.BLOB.CONNECTION_STRING
        blob_container_name = request.blob_config.container_name  if request.blob_config.container_name else SETTINGS.BLOB.CONTAINER_NAME

        blob_config.__dict__.update(
            connection_string=blob_connection_string,
            container_name=blob_container_name
        )

        if not blob_connection_string or not blob_container_name:
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Missing Blob Connection String or Container Name"))
            logger.error(response.detail)
            return blob_config, response

        if not request.data:
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Missing Data"))
            logger.error(response.detail)
            return blob_config, response
        
        if request.action != "DROP":
            if not file: 
                response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Missing File"))
                logger.error(response.detail)
                return blob_config, response
            else:
                if file.content_type not in VALID_CONTENT_TYPE.values():
                    response = Response(status_code=400, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Unsupported File Type"))
                    logger.error(response.detail)
                    return blob_config, response
        
        response = Response(status_code=200, detail=self.response_format.ok(f"Success : {request.action} Blob"))
        return blob_config, response

    async def upload_blob(self, file: UploadFile, file_type: str, blob_path: str, blob_config: BlobConfig) -> Response:
        try:
            content_type = VALID_CONTENT_TYPE.get(file_type.lower(), 'application/octet-stream')

            blob_service_client = BlobServiceClient.from_connection_string(blob_config.connection_string)
            blob_client = blob_service_client.get_blob_client(container=blob_config.container_name, blob=blob_path)
            content_settings = ContentSettings(content_type=content_type)

            # Read the file contents
            file_data = await file.read()

            blob_client.upload_blob(file_data, overwrite=True, content_settings=content_settings)

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Uploaded {file.filename} to blob storage as {blob_path}"))
            logger.info(response.detail)
            return response
        
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Failed to Upload Blob", str(e)))
            logger.error(response.detail)
            return response
            
    def delete_blob(self, blob_url: str, blob_config: BlobConfig) -> Response:
        try:
            blob_service_client = BlobServiceClient.from_connection_string(blob_config.connection_string)
            blob_client = BlobClient.from_blob_url(
                blob_url,
                credential=blob_service_client.credential
            )
            if blob_client.exists():
                blob_client.delete_blob()
                response = Response(status_code=200, detail=self.response_format.ok(f"Success : Deleted {blob_url}"))
                return response
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Failed to Delete Blob", str(e)))
            logger.error(response.detail)
            return response
            
            
            
