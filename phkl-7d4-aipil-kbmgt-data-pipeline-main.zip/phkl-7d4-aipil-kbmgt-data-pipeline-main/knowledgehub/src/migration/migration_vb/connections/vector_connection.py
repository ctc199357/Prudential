from contextlib import contextmanager
import copy

from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents import SearchClient
from azure.search.documents.indexes.models import SearchIndex
from azure.search.documents.indexes.models import SearchResourceEncryptionKey

from ....settings import SETTINGS

from ....logger.log_handler import get_logger
logger = get_logger(__name__)

API_KEY           = SETTINGS.VTDB.PSWD
ENCRYPTION_CONFIG = SETTINGS.VTDB.CONFIG.get("encryption_config", None)

def init_migrate_table(
        index_name: str,
        vb_schema: list,
        vb_schema_index_params: dict
    ):

    vb_schema_index_params = copy.deepcopy(vb_schema_index_params)

    # Create Search Index
    if ENCRYPTION_CONFIG:
        encryption_key = SearchResourceEncryptionKey(**ENCRYPTION_CONFIG)
        search_index = SearchIndex(
            name           = index_name, 
            fields         = vb_schema,
            vector_search  = vb_schema_index_params, 
            encryption_key = encryption_key
        )
    else:
        search_index = SearchIndex(
            name          = index_name, 
            fields        = vb_schema,
            vector_search = vb_schema_index_params
        )
        
    # Test DB Connection
    try:
        # Init Schema
        search_index_client = SearchIndexClient(    
            endpoint=SETTINGS.VTDB.HOST,
            credential=AzureKeyCredential(API_KEY)
        )
        
        try:
            search_index_client.get_index(index_name)
        except:
            search_index_client.create_or_update_index(search_index)

        logger.info(f"Connected : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.VTEX.NAME}> Vector Migration Index")
    # Handle any operational errors that might occur
    except Exception as e:  
        err_msg = f"Connection Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.VTEX.NAME}> Vector Migration Database --- {str(e)}"
        logger.error(err_msg)
        raise Exception(err_msg)
    
    # Handle any other exceptions that might occur
    except:
        err_msg = f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.VTEX.NAME}> Vector Migration Database"
        logger.error(err_msg)
        raise Exception(err_msg)

@contextmanager
def get_vb(index_name: str):
    try:
        vb_client = SearchClient(
            endpoint   = SETTINGS.VTDB.HOST,
            index_name = index_name,
            credential = AzureKeyCredential(API_KEY)
        )
        yield vb_client
    except Exception as e:
        logger.error(f"Failed in Initializing Connection to Vector Database --- {str(e)}")
        raise e