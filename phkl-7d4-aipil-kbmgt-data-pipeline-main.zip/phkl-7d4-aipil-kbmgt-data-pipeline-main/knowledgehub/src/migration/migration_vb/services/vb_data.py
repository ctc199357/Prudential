import os
import inspect

import json
import shutil
from azure.storage.blob import BlobServiceClient, ContentSettings

from ....settings import SETTINGS
from ....services import init_preprocessing_temp_storage
from ....utils import (
    get_blob_path
)

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.migration import(
    InitMigrationTableRequest,
    BatchMigrateRequest
)

from ..schemas.utils import (
    PrepMediaPipelineRequest,
    PrepMediaPipelineResponse,
    KnowDataObject,
    VectorCreateRequest,
    VectorCreate
)

from ..services import request_exec_prepmedia

from ....migration.migration_vb.connections.vector_connection import init_migrate_table, get_vb
from ....migration.migration_vb.models.vector_models import vb_schema, vb_schema_index_params


from ....logger.log_handler import get_logger

logger = get_logger(__name__)


class VBManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    blob_url_prefix = f"https://{SETTINGS.BLOB.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BLOB.CONTAINER_NAME}/"

    def init_table(self, request: InitMigrationTableRequest) -> Response:
        schema = request.vb_schema if request.vb_schema else vb_schema
        schema_index_params = request.vb_schema_index_params if request.vb_schema_index_params else vb_schema_index_params
        
        try:
            init_migrate_table(
                index_name=request.table_name,
                vb_schema=schema,
                vb_schema_index_params=schema_index_params
            )
            response = Response(status_code=201, detail=self.response_format.ok(f"Success : Init Migration Index"))
            logger.info(response.detail)
            return response

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error("Failed to Init Migration Index", str(e)))
            logger.error(response.detail)
            return response

    def batch_migrate(self, request: BatchMigrateRequest) -> Response:
        logger.info("Starting Data Migration")

        if request.preprocessing == True and request.action.upper() != "DROP":
            try:
                request = self.data_check(request=request)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error("Failed to Perform Data Check before Migration", e))
                logger.error(response.detail)
                return response

        migrate_data = request.data

        if request.action.upper() != "DROP":
            migrate_data = self.update_data(data=migrate_data)
            response = self.upload_data_to_blob(data=migrate_data, index=request.table_name)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response

        try:
            with get_vb(index_name=request.table_name) as vb:
                if request.action.upper() == "INSERT": # create
                    vb.upload_documents(documents=migrate_data)

                elif request.action.upper() == "UPSERT": # update
                    vb.merge_or_upload_documents(documents=migrate_data)
                
                elif request.action.upper() == "DROP":
                    for _data in request.data:                 
                        conditions = [{request.uid_field: _data.get(request.uid_field)}]
                        vb.delete_documents(documents=conditions)

                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Migration Fail : Unknown Migration Action"))
                    return response
                
                response = Response(status_code=201, detail=self.response_format.ok(f"Success : {request.action} Data"))
                logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Failed to Connect VB", str(e)))
            logger.error(response.detail)
            
        return response
    
    def data_check(self, request: BatchMigrateRequest) -> BatchMigrateRequest:
        requests = []
        # Check if data has sufficient information
        for _data in request.data:
            requests.append(VectorCreateRequest(
                data = VectorCreate(
                    **_data
                ),
                prepmedia_config = request.preprocessing_config
            ))
        
        checked_data, response = self.create_data_check(requests=requests)

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            raise Exception(response.detail)
        
        if not checked_data:
            err_msg = f"Migration Error : <{SETTINGS.BASE.APP_NAME}> No Data Found in Request Data"
            logger.error(err_msg)
            raise Exception(err_msg)

        request.__dict__.update(
            data = [_data.__dict__ for _data in checked_data]
        )

        return request
    
    def upload_data_to_blob(self, data: list[dict], index) -> Response:
        vector_creates = [VectorCreate(**_data) for _data in data]
        try:
            for _data in vector_creates:
                # Save data to json file
                local_dir = os.path.join(os.getcwd(), f"{index}")
                local_path = os.path.join(local_dir, f"{_data.data_id}.json")
                
                # Check if file exists, if yes, delete it
                if os.path.exists(local_path):
                    os.remove(local_path)
                
                os.makedirs(local_dir, exist_ok=True)
                
                # Save VectorCreate object to json file
                with open(local_path, 'w', encoding="utf-8") as json_file:
                    json.dump(_data.dict(), json_file, cls=ComplexEncoder, ensure_ascii=False, indent=4)
                
                blob_path = f"{SETTINGS.BLOB.VECTOR_FOLDER_NAME}/{index}/{_data.data_id}.json"

                # Upload the new blob file
                blob_service_client = BlobServiceClient.from_connection_string(SETTINGS.BLOB.CONNECTION_STRING)
                blob_client = blob_service_client.get_blob_client(container=SETTINGS.BLOB.CONTAINER_NAME, blob=blob_path)
                content_settings = ContentSettings(content_type='application/json')

                with open(local_path, "rb") as data:
                    blob_client.upload_blob(data, overwrite=True, content_settings=content_settings)

                logger.info(f"Uploaded {local_path} to blob storage as {blob_path}")

                # Delete the local file
                if os.path.exists(local_path):
                    os.remove(local_path)

            response = Response(status_code=200, detail=self.response_format.ok("Success : Added Data to Blob"))
            logger.info(response.detail)

        except Exception as e:
            try:
                if os.path.exists(local_dir):
                    shutil.rmtree(local_dir)
            except Exception as e:
                logger.error(f"Error cleaning up temporary directory {local_dir}: {str(e)}")

            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Add Data to Blob", str(e)))
            logger.error(response.detail)

        return response
    

    def update_data(self, data: list[dict]) -> list[dict]:
        vector_create = [VectorCreate(**_data) for _data in data]
        
        # Update data url to new blob url
        for _data in vector_create:
            if _data.data_url:
                _data.__dict__.update(
                    data_url = self.get_new_blob_url(_data.data_url)
                )
        
        return_data = [_data.__dict__ for _data in vector_create]
        return return_data

    def create_data_check(self, requests: list[VectorCreateRequest]) -> tuple[list[VectorCreate], Response]:
        create_data = []

        for request in requests:
            data = request.data   

            # Handle Image
            if data.data_url and data.data_type.lower() == 'image' and not data.processed_data:
                if request.prepmedia_config.get("image", None):
                    _prepmedia_config = request.prepmedia_config.get("image", None)
                else:
                    _prepmedia_config = SETTINGS.VTDB.PREPMEIDA_CONFIG.get("image", None)

                if not _prepmedia_config:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid PrepMedia Config for Updating Image Content"))
                    logger.error(response.detail)
                    return create_data, response
                
                knowdataobject = KnowDataObject(
                    data_url  = data.data_url,
                    data_type = 'IMAGE'
                )
                
                prepmedia_request = PrepMediaPipelineRequest(
                    prepmedia_id = _prepmedia_config,
                    prepmedia_input  = [knowdataobject]
                )
                response_data, response = self.preprocess_prepmedia(request=prepmedia_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return create_data, response
                
                if not response_data.prepmedia_output:
                    response = Response(status_code=500, detail=self.response_format.error(f"Preprocessing Error : Invalid PrepMedia Output for Updating Image Content"))
                    logger.error(response.detail)
                    return create_data, response

                for _data in response_data.prepmedia_output:
                    if (data.content_type.lower() == _data.content_type.lower()): # IMAGE may have two outputs returned (image2text/ocr)
                        vector_data = VectorCreate(**data.__dict__)
                        
                        if not data.data_keywords:
                            vector_data.data_keywords = _data.data_keywords

                        if not data.data_languages:
                            vector_data.data_languages = _data.data_languages

                        vector_data.__dict__.update(
                            **{
                                "processed_data": _data.processed_data,
                                "data_dimension": _data.data_dimension,
                                "data_length":    _data.data_length
                            }
                        )
                        
                        create_data.append(vector_data)
            
            # Handle Table
            elif data.data_url and data.data_type.lower() == 'table' and not data.processed_data:
                if request.prepmedia_config.get("table", None):
                    _prepmedia_config = request.prepmedia_config.get("table", None)
                else:
                    _prepmedia_config = SETTINGS.VTDB.PREPMEIDA_CONFIG.get("table", None)

                if not _prepmedia_config:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid PrepMedia Config for Updating Table Content"))
                    logger.error(response.detail)
                    return create_data, response
                
                knowdataobject = KnowDataObject(
                    data_url  = data.data_url,
                    data_type = 'TABLE',
                    raw_data = data.raw_data
                )
                
                prepmedia_request = PrepMediaPipelineRequest(
                    prepmedia_id = _prepmedia_config,
                    prepmedia_input  = [knowdataobject]
                )
                response_data, response = self.preprocess_prepmedia(request=prepmedia_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return create_data, response
                
                if not response_data.prepmedia_output:
                    response = Response(status_code=500, detail=self.response_format.error(f"Preprocessing Error : Invalid PrepMedia Output for Updating Table Content"))
                    logger.error(response.detail)
                    return create_data, response

                for _data in response_data.prepmedia_output:
                    vector_data = VectorCreate(**data.__dict__)
                    
                    if not data.data_keywords:
                        vector_data.data_keywords = _data.data_keywords

                    if not data.data_languages:
                        vector_data.data_languages = _data.data_languages

                    vector_data.__dict__.update(
                        **{
                            "processed_data": _data.processed_data,
                            "data_dimension": _data.data_dimension,
                            "data_length":    _data.data_length
                        }
                    )
                    
                    create_data.append(vector_data)
            
            # Handle Text / Document
            elif data.raw_data and not data.processed_data:
                if request.prepmedia_config.get("text", None):
                    _prepmedia_config = request.prepmedia_config.get("text", None)
                else:
                    _prepmedia_config = SETTINGS.VTDB.PREPMEIDA_CONFIG.get("text", None)

                if not _prepmedia_config:
                    response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : Invalid PrepMedia Config for Updating Raw Content"))
                    logger.error(response.detail)
                    return create_data, response
                
                knowdataobject = KnowDataObject(
                    raw_data  = data.raw_data,
                    data_type = 'TEXT'
                )
                prepmedia_request = PrepMediaPipelineRequest(
                    prepmedia_id = _prepmedia_config,
                    prepmedia_input  = [knowdataobject]
                )
                response_data, response = self.preprocess_prepmedia(request=prepmedia_request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    return create_data, response
                
                if not response_data.prepmedia_output:
                    response = Response(status_code=500, detail=self.response_format.error(f"Preprocessing Error : Invalid PrepMedia Output for Updating Text Content"))
                    logger.error(response.detail)
                    return create_data, response

                for _data in response_data.prepmedia_output:
                    vector_data = VectorCreate(**data.__dict__)
                    
                    if not data.data_keywords:
                        vector_data.data_keywords = _data.data_keywords

                    if not data.data_languages:
                        vector_data.data_languages = _data.data_languages

                    vector_data.__dict__.update(
                        **{
                            "processed_data": _data.processed_data,
                            "data_dimension": _data.data_dimension,
                            "data_length":    _data.data_length
                        }
                    )
                    
                    create_data.append(vector_data)
            
            else:
                create_data.append(data)
        
        response = self.clear_preprocessing_temp_storage()
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return create_data, response

        response = Response(status_code=200, detail=self.response_format.ok(f"Success: All Data Checking Passed"))
        return create_data, response
    
    
    def clear_preprocessing_temp_storage(self) -> Response:
        try:
            if SETTINGS.BASE.APP_FUNC == True:
                try:
                    init_preprocessing_temp_storage()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Cleared Preprocessing Temp Storage via Function Call"))
                    logger.info(response.detail)
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Clear Preprocessing Temp Storage via Function Call", str(e)))
                    logger.error(response.detail)
                
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Clear Preprocessing Temp Storage but <APP_FUNC> is False"))
                logger.error(response.detail)
        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Clearing Preprocessing Temp Storage", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Clearing Preprocessing Temp Storage"))
            logger.error(response.detail)

        return response

    def get_new_blob_url(self, blob_url: str) -> str:
        new_blob_url = ""
        try:
            blob_path = get_blob_path(blob_url=blob_url)
            new_blob_url = f"{self.blob_url_prefix}{blob_path}"

            logger.info(f"Success : Replace Data Url from {blob_url} to {new_blob_url}")
        except Exception as e:
            new_blob_url = blob_url # Reset
            logger.error(f"Unexpected Error : Replace Blob Data Url | {str(e)}")
            
        return new_blob_url

    def preprocess_prepmedia(self, request: PrepMediaPipelineRequest) -> tuple[PrepMediaPipelineResponse, Response]:
        response_data = PrepMediaPipelineResponse(**request.__dict__)
        try:
            if SETTINGS.BASE.APP_FUNC == True:
                try:  
                    response_data = request_exec_prepmedia(request=request, api_call=False)
                    response_data = PrepMediaPipelineResponse(**response_data.__dict__)
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Prepmedia Preprocessing via Function Call"))
                    logger.info(response.detail)
                # Handle common exceptions that might occur
                except (BaseException, Exception) as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Complete Knowledge Preprocessing via Function Call", str(e)))
                    logger.error(response.detail)

                # Handle any other exceptions that might occur
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing Prepmedia"))
                    logger.error(response.detail)
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Clear Preprocessing Temp Storage but <APP_FUNC> is False"))
                logger.error(response.detail)
                # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing Prepmedia", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing Prepmedia"))
            logger.error(response.detail)
            
        return response_data, response