from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone
from ....settings import SETTINGS

"""
    Request and Response of PrepKnowPipeline
"""
class KnowDataObject(BaseModel):
    # Trace Information
    data_id:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_version:   int=1

    # Category Information
    data_type:      str='' # TEXT, TITLE, IMAGE, TABLE, DOCUMENT, etc.
    content_type:   str='default' # default, image-to-text, OCR
    data_url:       str='' # Image URL, Table URL

    # Control Information
    data_status:    int=1

    # Specification
    raw_data:       str='' # Raw Text, Image Description, Text on Image, etc.
    processed_data: list[float]=[] # vector
    data_dimension: int=-1
    data_length:    int=0

    coord_x1:       float=-1.0
    coord_x2:       float=-1.0
    coord_y1:       float=-1.0
    coord_y2:       float=-1.0

    page_start:     int=-1
    page_end:       int=-1
    line_start:     int=-1
    line_end:       int=-1
    seq_no:         int=-1

    # Dependent
    knowledge_id:   str='' # Map to Original Knowledge
    node_id:        str=''
    node_type:      str=''

    # Tags
    data_languages: list[str]=[]
    data_keywords:  list[str]=[]
    data_tags:      list[str]=[]

    # Time Information
    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class EdgeCreate(BaseModel):
    edge_id:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    edge_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    edge_version:   int=1
    edge_status:    int=1

    updated_by:     str='system'

    source_node_id: str
    target_node_id: str
    edge_type:      str
    edge_cluster:   str='default'
    edge_category:  str='default'
    edge_name:      str=''
    edge_strength:  float=-1.0

    edge_tags:      list[str]=[]

    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class NodeCreate(BaseModel):
    # Trace Information
    node_id:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    node_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    node_version:   int=1
    node_status:    int=1
    
    # Control Information
    updated_by:     str='system'

    # Specification
    node_sequence:  int=-1
    node_type:      str='chunk'
    node_cluster:   str='default'
    node_category:  str='default'
    node_name:      str=''

    # Statistics
    node_indegree:  int=0
    node_outdegree: int=0

    # Chunkg Trace Information
    data_id:        str=''
    data_traceid:   str=''
    data_version:   int=1

    # Chunk Category Information
    data_type:      str='' # TEXT, IMAGE, TABLE, DOCUMENT, etc.
    content_type:   str=''

    # Chunk Tags
    data_languages: list[str]=[]
    data_keywords:  list[str]=[]

    # Dependent
    knowledge_id:   str='' # Map to Original Knowledge

    # Tags
    node_tags:      list[str]=[]

    # Time Information
    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class KnowGraphObject(BaseModel):
    nodes: list[NodeCreate]=[]
    edges: list[EdgeCreate]=[]


class KnowRelationshipObject(BaseModel):
    # Trace Information
    data_id:       str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    data_version:   int=1

    # Category Information
    data_type:      str='' # TEXT, IMAGE, TABLE, DOCUMENT, etc.

    # Control Information
    data_status:    int=1

    # Dependent
    knowledge_id:   str='' # Map to Original Knowledge
    node_id:        str=''
    node_type:      str=''
    node_name:      str=''

    # Relation
    relationship:    list[dict]=[] # [{target: str, relationship: str}]

    # Time Information
    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# System-level Access
class SecretPrepKnow(BaseModel):
    # Trace Information
    prepknow_id:           str | None = None
    prepknow_traceid:      str | None = None
    prepknow_version:      int | None = None
    prepknow_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None

    # Category Information
    prepknow_group:        str | None = None
    prepknow_type:         str | None = None
    prepknow_location:     str | None = None

    # Control Information
    prepknow_status:       int | None = None
    prepknow_permission:   int | None = None
    prepknow_management:   int | None = None

    # Configuration
    prepknow_layout_func:  dict | None = None
    prepknow_parameters:   dict | None = None
    prepknow_secrets:      dict | None = None
    prepknow_inputs:       dict | None = None
    prepknow_outputs:      dict | None = None
    prepknow_retry:        dict | None = None
    prepknow_termination:  dict | None = None
    prepknow_key:          str  | None = None
    prepknow_timeout:      int  | None = None    
    input_format:          str  | None = None
    output_format:         str  | None = None

    # Dependent
    prepmedia_selection:   str  | None = None
    prepmedia_ids:         dict | None = None

    # Specification
    prepknow_complexity:   int  | None = None
    prepknow_use_gpu:      bool | None = None
    prepknow_instance_num: int  | None = None
    prepknow_description:  str  | None = None

    # Tags
    input_types:           dict | None = None
    output_types:          dict | None = None
    prepknow_languages:    list[str] | None = None
    prepknow_tags:         list[str] | None = None
    user_groups:           list[str] | None = None
    agent_groups:          list[str] | None = None

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None

class PrepKnowInput(BaseModel):
    # Trace Information
    knowledge_id:             str=Field(default_factory=lambda: str(uuid.uuid4()))
    knowledge_name:           str=''

    # Creator Information
    creator_id:               str=''
    creator_name:             str=''

    # Category Information
    storage_type:             str='' # Storage Type of Knowledge
    storage_provider:         str='' # Storage Provider of Knowledge
    storage_directory:        str='' # File Path / Url
    storage_secrets:          dict=dict() # Access Secrets

    # Configuration
    knowledge_vectorstorage:  str=''
    knowledge_vectorlocation: str=''
    knowledge_vectorinfo:     dict=dict()
    knowledge_searchstorage:  dict=dict()
    knowledge_searchinfo:     dict=dict()
    knowledge_secrets:        dict=dict()

    # Specification
    knowledge_description:    str=''

class SecretPrepMedia(BaseModel):
    # Trace Information
    prepmedia_id:           str | None = None
    prepmedia_traceid:      str | None = None
    prepmedia_version:      int | None = None
    prepmedia_name:         str | None = None

    # Creator Information
    creator_id:             str | None = None
    creator_name:           str | None = None

    # Category Information
    prepmedia_group:        str | None = None
    prepmedia_type:         str | None = None
    prepmedia_location:     str | None = None

    # Control Information
    prepmedia_status:       int | None = None
    prepmedia_permission:   int | None = None
    prepmedia_management:   int | None = None

    # Configuration
    prepmedia_parameters:   dict | None = None
    prepmedia_secrets:      dict | None = None
    prepmedia_inputs:       dict | None = None
    prepmedia_outputs:      dict | None = None
    prepmedia_retry:        dict | None = None
    prepmedia_termination:  dict | None = None
    prepmedia_key:          str  | None = None
    prepmedia_timeout:      int  | None = None
    input_format:           str  | None = None
    output_format:          str  | None = None

    # Dependent
    preptool_selection:     str  | None = None
    preptool_ids:           dict | None = None

    # Specification
    prepmedia_complexity:   int  | None = None
    prepmedia_use_gpu:      bool | None = None
    prepmedia_instance_num: int  | None = None
    prepmedia_info:         dict | None = None
    prepmedia_description:  str  | None = None

    # Tags
    input_types:            dict | None = None
    output_types:           dict | None = None
    prepmedia_languages:    list[str] | None = None
    prepmedia_tags:         list[str] | None = None
    user_groups:            list[str] | None = None
    agent_groups:           list[str] | None = None

    # Time Information
    created_at:             datetime | None = None
    updated_at:             datetime | None = None

class SecretPrepTool(BaseModel):
    # Trace Information
    preptool_id:           str | None = None
    preptool_traceid:      str | None = None
    preptool_version:      int | None = None
    preptool_name:         str | None = None

    # Creator Information
    creator_id:            str | None = None
    creator_name:          str | None = None

    # Category Information
    preptool_group:        str | None = None
    preptool_type:         str | None = None
    preptool_location:     str | None = None

    # Control Information
    preptool_permission:   int | None = None
    preptool_management:   int | None = None
    preptool_status:       int | None = None

    # Configuration
    preptool_host:         str  | None = None
    preptool_port:         str  | None = None
    preptool_api:          str  | None = None
    preptool_engine:       str  | None = None
    preptool_base:         str  | None = None
    preptool_model:        str  | None = None
    preptool_parameters:   dict | None = None
    preptool_secrets:      dict | None = None
    preptool_inputs:       dict | None = None
    preptool_outputs:      dict | None = None
    preptool_environment:  str  | None = None
    preptool_retry:        dict | None = None
    preptool_termination:  dict | None = None
    preptool_key:          str  | None = None
    preptool_timeout:      int  | None = None
    input_format:          str  | None = None
    output_format:         str  | None = None

    # Specification
    preptool_complexity:   int  | None = None
    preptool_use_gpu:      bool | None = None
    preptool_instance_num: int  | None = None
    preptool_info:         dict | None = None
    preptool_description:  str  | None = None

    # Tags
    input_types:           dict | None = None
    output_types:          dict | None = None
    preptool_languages:    list[str] | None = None
    preptool_tags:         list[str] | None = None
    user_groups:           list[str] | None = None
    agent_groups:          list[str] | None = None

    # Time Information
    created_at:            datetime | None = None
    updated_at:            datetime | None = None

class PrepKnowCustomConfiguration(BaseModel):
    # Override Stored Configuration
    prepknow:             SecretPrepKnow  | None = None
    prepmedia:            SecretPrepMedia | None = None
    preptool:             SecretPrepTool  | None = None
    encrypt_knowledge:    str  | None = None

class PrepKnowOutput(BaseModel):
    know_data: list[KnowDataObject]=[]
    
class PrepToolMetric(BaseModel):
    preptool_id:               str='custom'
    preptool_requestid:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    preptool_pipeline_id:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    preptool_pipeline_traceid: str=Field(default_factory=lambda: str(uuid.uuid4()))

    preptool_code:             str=''
    preptool_reason:           str='DEFAULT'

    # PrepTool Metrics
    preptool_time:             float=0.0
    preptool_input_tokens:     int=0
    preptool_output_tokens:    int=0
    preptool_tool_tokens:      int=0
    preptool_config:           dict=dict()

    preptool_request_at:       datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    preptool_response_at:      datetime | None = None


class PrepMediaMetric(BaseModel):
    prepmedia_id:               str='custom'
    prepmedia_requestid:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepmedia_pipeline_id:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepmedia_pipeline_traceid: str=Field(default_factory=lambda: str(uuid.uuid4()))
    
    prepmedia_code:             str=''
    prepmedia_reason:           str='FAIL'

    # PrepMedia Metrics
    prepmedia_request_at:       datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    prepmedia_response_at:      datetime | None = None
    prepmedia_turn_no:          int=1
    prepmedia_retry_no:         int=0
    prepmedia_time:             float=0.0

    total_input_tokens:         int=0
    total_output_tokens:        int=0
    total_tool_tokens:          int=0

    # PrepMdia Metrics
    preptool_metrics:           list[PrepToolMetric]=[]

class PrepKnowMetric(BaseModel):
    prepknow_requestid:        str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_traceid:          str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_id:               str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_pipeline_id:      str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_pipeline_traceid: str=Field(default_factory=lambda: str(uuid.uuid4()))

    prepknow_code:             str=''
    prepknow_reason:           str='FAIL'

    # PrepKnow Metrics
    prepknow_request_at:       datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    prepknow_response_at:      datetime | None = None
    prepknow_turn_no:          int=1
    prepknow_retry_no:         int=0
    prepknow_time:             float=0.0
    
    prepknow_input_tokens:     int=0
    prepknow_output_tokens:    int=0
    prepknow_tool_tokens:      int=0

    # PrepMedia Metrics
    prepmedia_metrics:         list[PrepMediaMetric]=[]

class PrepKnowPipelineRecord(BaseModel):
    prepknow_pipeline_termination: bool=True
    prepknow_pipeline_code:        str=''
    prepknow_pipeline_completion:  bool=False
    prepknow_pipeline_reason:      str='DEFAULT'

    prepknow_output:               PrepKnowOutput=PrepKnowOutput()
    prepknow_metric:               PrepKnowMetric=PrepKnowMetric()
    
    request_at:                    datetime | None = None
    response_at:                   datetime | None = None

class PrepKnowPipelineRequest(BaseModel):
    prepknow_requestid:   str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_requestid:       str | None = None
    user_id:              str | None = None

    prepknow_pipeline_id: str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_id:          str=''
    prepknow_input:       PrepKnowInput
    custom_config:        PrepKnowCustomConfiguration | None = None
    resume_pipeline:      bool=False

    prepknow:             SecretPrepKnow | None = None # If prepknow is None, will init prepknow from prepknow_id
    
    encrypt_knowledge:    str='default'
    get_full_chain:       bool=False

    request_at:           datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PrepKnowPipelineResponse(BaseModel):
    prepknow_requestid:           str
    user_requestid:               str | None = None
    user_id:                      str | None = None

    prepknow_pipeline_id:         str=Field(default_factory=lambda: str(uuid.uuid4()))
    prepknow_id:                  str=Field(default_factory=lambda: str(uuid.uuid4()))

    prepknow_pipeline_code:       str=''
    prepknow_pipeline_reason:     str='DEFAULT'
    
    prepknow_pipeline_output:     PrepKnowPipelineRecord=PrepKnowPipelineRecord()

    prepknow_chain:               list[PrepKnowPipelineRecord]=[]  

    # Overall Pipeline Statistics
    prepmedias_total_turn_no:     int=0
    prepmedias_total_retry_no:    int=0
    prepknow_total_input_tokens:  int=0
    prepknow_total_output_tokens: int=0
    prepknow_total_tool_tokens:   int=0
    prepknow_total_turn_no:       int=1  
    prepknow_total_retry_no:      int=0
    prepknow_total_time:          float=0.0

    request_at:                   datetime
    response_at:                  datetime | None = None

"""
    Request and Response of PrepMediaPipeline
"""
class PrepKnowMedia(BaseModel):
    prepmedia: SecretPrepMedia
    preptools: list[SecretPrepTool]=[]

class PrepMediaCustomConfiguration(BaseModel):
    pass

class PrepMediaPipelineRequest(BaseModel):
    prepmedia_requestid:  str=Field(default_factory=lambda: str(uuid.uuid4()))
    user_requestid:       str | None = None
    user_id:              str | None = None

    prepmedia_id:         str=''
    prepmedia_input:      list[KnowDataObject]=[]
    custom_config:        PrepMediaCustomConfiguration | None = None
    resume_pipeline:      bool=False

    prepknow_media:       PrepKnowMedia | None = None
    encrypt_knowledge:    str='default'
    
    request_at:           datetime=Field(default_factory=lambda: datetime.now(timezone.utc))

class PrepMediaPipelineResponse(BaseModel):
    prepmedia_requestid:           str

    prepknow_termination:          bool=False
    prepmedia_pipeline_code:       str=''
    prepmedia_pipeline_reason:     str='DEFAULT'
    prepmedia_output:              list[KnowDataObject]=[]
    prepmedia_relationship:        KnowGraphObject=KnowGraphObject()

    prepmedia_turn_no:             int=1
    prepmedia_retry_no:            int=0
    prepmedia_total_time:          float=0.0
    prepmedia_total_input_tokens:  int=0
    prepmedia_total_output_tokens: int=0
    prepmedia_total_tool_tokens:   int=0

    prepmedia_metrics:             list[PrepMediaMetric]=[]
    
    request_at:                    datetime=Field(default_factory=lambda: datetime.now(timezone.utc))
    response_at:                   datetime | None = None


""""
    Vector General Operation
"""

class VectorCreate(BaseModel):
    # Trace Information
    data_id:        str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    data_traceid:   str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Trace ID for the Vector")
    data_version:   int=Field(default=1, description="[Optional] Version Number for the Vector")    

    # Category Information
    data_type:      str=Field(default='', description="Data Type - text, title, image, table, document") # TEXT, TITLE, IMAGE, TABLE, DOCUMENT, etc.
    content_type:   str=Field(default='default', description="Content Type - default, image2text, ocr") # TEXT, IMAGE, TABLE, etc.
    data_url:       str=Field(default='', description="Data URL - URL for the Data (Image / Talbe)") # URL for the Data

    # Control Information
    data_status:    int=Field(default=1, description="Data Status - 0: Inactive, 1: Active") # Data Status - 0: Created, 1: Processed, 2: Error

    # Specification
    raw_data:       str=Field(default='', description="Raw Data in Plaintext") # Original Data
    processed_data: list[float]=Field(default=[], description="Processed Data in Vector") # Processed Data in Vector
    data_dimension: int=Field(default=-1, description="Data Dimension - Number of Dimensions in the Vector") # Data Dimension - Number of Dimensions in the Vector
    data_length:    int=Field(default=0, description="Data Length - Length of the Raw Text") # Data Length - Length of the Data

    coord_x1:       float=Field(default=-1.0, description="X1 Coordinate - X1 Coordinate of the Data") # X1 Coordinate - X1 Coordinate of the Data
    coord_x2:       float=Field(default=-1.0, description="X2 Coordinate - X2 Coordinate of the Data") # X2 Coordinate - X2 Coordinate of the Data
    coord_y1:       float=Field(default=-1.0, description="Y1 Coordinate - Y1 Coordinate of the Data") # Y1 Coordinate - Y1 Coordinate of the Data
    coord_y2:       float=Field(default=-1.0, description="Y2 Coordinate - Y2 Coordinate of the Data") # Y2 Coordinate - Y2 Coordinate of the Data

    page_start:     int=Field(default=-1, description="Page Start - Page Start Number") # Page Start - Page Start Number
    page_end:       int=Field(default=-1, description="Page End - Page End Number") # Page End - Page End Number
    line_start:     int=Field(default=-1, description="Line Start - Line Start Number") # Line Start - Line Start Number
    line_end:       int=Field(default=-1, description="Line End - Line End Number") # Line End - Line End Number
    seq_no:         int=Field(default=-1, description="Sequence Number - Sequence Number of the Data in Document Parsing") # Sequence Number - Sequence Number of the Data

    # Dependent
    knowledge_id:   str=Field(default='', description="Knowledge ID - ID of the Knowledge") # Knowledge ID - ID of the Knowledge
    node_id:        str=Field(default='', description="Node ID - ID of the Node in Graph") # Node ID - ID of the Node
    node_type:      str=Field(default='', description="Node Type - Type of the Node in Graph") # Node Type - Type of the Node

    # Tags
    data_languages: list[str]=Field(default=[], description="Data Languages - List of Languages in the Data") # Data Languages - List of Languages in the Data
    data_keywords:  list[str]=Field(default=[], description="Data Keywords - List of Keywords in the Data") # Data Keywords - List of Keywords in the Data
    data_tags:      list[str]=Field(default=[], description="Data Tags - List of Tags in the Data") # Data Tags - List of Tags in the Data

    # Time Information
    created_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Created At - Creation Time of the Data")
    updated_at:     datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Updated At - Last Update Time of the Data") # Updated At - Last Update Time of the Data

class VectorCreateRequest(BaseModel):
    user_requestid: str=Field(default_factory=lambda: str(uuid.uuid4()), description="[Optional] Unique ID for the Request")
    user_id:        str=Field(default="", description="[Optional] User ID for the Vector")
    user_name:      str=Field(default="", description="[Optional] User Name for the Vector")
    is_admin:       bool=Field(default=False, description="[Optional] Is Admin Flag for the Vector")
    data:           VectorCreate=Field(..., description="Vector Data - VectorCreate Object", example=VectorCreate(
                        data_id="12345",
                        data_traceid="67890",
                        data_version=1,
                        data_type="image",
                        content_type="image2text",
                        data_url="http://example.com/data",
                        data_status=1,
                        raw_data="This is a sample text.",
                        processed_data=[0.1, 0.2, 0.3],
                        data_dimension=3,
                        data_length=20,
                        coord_x1=0.0,
                        coord_x2=1.0,
                        coord_y1=0.0,
                        coord_y2=1.0,
                        page_start=1,
                        page_end=1,
                        line_start=1,
                        line_end=1,
                        seq_no=1,
                        knowledge_id="knowledge_123",
                        node_id="node_123",
                        node_type="node_type_123",
                        data_languages=["en", "fr"],
                        data_keywords=["keyword1", "keyword2"],
                        data_tags=["tag1", "tag2"],
                        created_at=datetime.now(timezone.utc),
                        updated_at=datetime.now(timezone.utc)
                    )
                )
    prepmedia_config: dict=Field(default=SETTINGS.VTDB.PREPMEIDA_CONFIG, description="[Optional] Preprocessing Media Configuration - Configuration for Preprocessing Media")
