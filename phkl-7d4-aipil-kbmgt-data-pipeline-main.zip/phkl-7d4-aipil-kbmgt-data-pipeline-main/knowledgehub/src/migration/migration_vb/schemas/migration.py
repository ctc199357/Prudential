from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone
from typing import List, Any, Optional

from ....settings import SETTINGS

class InitMigrationTableRequest(BaseModel):
    table_name:             str=Field(..., description="Index Name of AI Search")
    vb_schema:              Optional[List[Any]]=Field(default=[], description="Schema for AI Search")
    vb_schema_index_params: Optional[dict]=Field(default=dict(), description="Schema Index Parameters for AI Search")

class BatchMigrateRequest(BaseModel):
    table_name:           str=Field(..., description="Index Name of AI Search")
    uid_field:            str=Field(default='id', description="Field Name of Data UID")
    data:                 List[dict]=Field(..., description="List of Input Data")
    action:               str=Field(default="INSERT", description="INSERT, UPSERT, DROP")
    preprocessing:        bool=Field(default=False, description="Performing Preprocessing for Data")
    preprocessing_config: dict=Field(default=dict(), description="Preprocessing Strategy")
