import sys
import asyncio
import urllib.parse
from contextlib import contextmanager

from azure.cosmos import CosmosClient
import azure.cosmos.cosmos_client as cosmos_client
import azure.cosmos.exceptions as exceptions
from gremlin_python.driver import client, serializer

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())


from ....settings import SETTINGS

from ....logger.log_handler import get_logger

logger = get_logger(__name__)


DB_URL = '{host}:{port}/'.format(
        host=urllib.parse.quote_plus(SETTINGS.GPDB.HOST),
        port=urllib.parse.quote_plus(SETTINGS.GPDB.PORT)
    )

DATABASE_URL = f"wss://{DB_URL}"

def init_migrate_gb(
        gb_name: str=SETTINGS.GPEX.NAME
    ):
    try:
        client_conn = CosmosClient(SETTINGS.GPDB.ENDPOINT, SETTINGS.GPDB.PSWD)
        gb_client   = client_conn.create_database_if_not_exists(id = gb_name)
        logger.info(f"DB Connected : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.GPDB.NAME}> Migration Graph DB")

    except exceptions.CosmosResourceExistsError:
        logger.info(f"DB Found and Connected : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.GPDB.NAME}> Migration Graph DB Connected")

    except exceptions.CosmosHttpResponseError as e:
        err_msg = f"DB Connection Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.GPDB.NAME}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)

    # Handle any other exceptions that might occur
    except:
        err_msg = f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> <{SETTINGS.GPDB.NAME}> Database"
        logger.error(err_msg)
        raise Exception(err_msg)

# DB via API Call
def create_gb_client(db_name: str=SETTINGS.GPEX.NAME):
    try:
        client_conn = CosmosClient(SETTINGS.GPDB.ENDPOINT, SETTINGS.GPDB.PSWD)
        gb_client = client_conn.get_database_client(db_name)
        return gb_client
    except Exception as e:
        logger.error(str(e))
        raise e

@contextmanager
def get_gb(container_name: str, gb_name=SETTINGS.GPEX.NAME):
    try:
        gremlin_client = client.Client(
            url=DATABASE_URL,
            traversal_source="g",
            username=f"/dbs/{gb_name}/colls/{container_name}",
            password=SETTINGS.GPDB.PSWD,
            message_serializer=serializer.GraphSONSerializersV2d0()
        )
        yield gremlin_client
    except Exception as e:
        logger.error(str(e))
        raise e
        
    finally:
        gremlin_client.close()