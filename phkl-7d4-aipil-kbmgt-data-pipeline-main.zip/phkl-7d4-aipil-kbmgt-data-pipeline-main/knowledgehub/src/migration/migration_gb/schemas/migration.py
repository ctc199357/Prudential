from pydantic import BaseModel, Field
import uuid
from datetime import datetime, timezone
from typing import List, Any, Optional

from ....settings import SETTINGS

class DBConfig(BaseModel):
    db_url:  Optional[str]=Field(default='', description="DB Connection URL")
    db_name: Optional[str]=Field(default='', description="DB Name")

class BatchMigrateRequest(BaseModel):
    db_config:         DBConfig=Field(defualt=DBConfig(), description="DB Connection Config")
    container_name:    str=Field(default=SETTINGS.GPDB.CONTAINER, description="Container Name")
    partition_key:     str=Field(default=SETTINGS.GPDB.PARTITION_KEY, description="Graph Partition")
    throughput:        int=Field(default=SETTINGS.GPDB.CONTAINER_THROUGHPUT, description="Container Throughput")
    graph_uid_field:   str=Field(default="knowledge_id", description="Partition UID Field Name")
    graph_uid_value:   str=Field(..., description="Paritition Value for Dropping Nodes")
    node_uid_field:    str=Field(default='node_id', description="Field Name of Node UID")
    node_label_field:  str=Field(default='node_type', description="Field Name of Node Label")
    edge_uid_field:    str=Field(default='edge_id', description="Field Name of Edge UID")
    edge_label_field:  str=Field(default='edge_type', description="Field Name of Edge Label")
    edge_source_field: str=Field(default='source_node_id', description="Field Name of Edge Source")
    edge_target_field: str=Field(default='target_node_id', description="Field Name of Edge Target")
    data:              dict=Field(..., description="List of Input Data")
    action:            str=Field(default="INSERT", description="INSERT, UPSERT, DROP")
