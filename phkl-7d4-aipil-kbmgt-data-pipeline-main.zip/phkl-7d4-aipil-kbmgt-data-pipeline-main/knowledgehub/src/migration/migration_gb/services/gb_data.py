import os
from datetime import datetime, timezone
import uuid
import inspect
import math
import time
import httpx

from azure.cosmos import PartitionKey, exceptions

from ....settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.migration import(
    DBConfig,
    BatchMigrateRequest
)

from ....migration.migration_gb.connections.graph_connection import init_migrate_gb, get_gb, create_gb_client, DATABASE_URL

GRAPH_PARTITION_KEY   = SETTINGS.GPDB.PARTITION_KEY

from ....logger.log_handler import get_logger

logger = get_logger(__name__)


class GBManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def init_gb(self, request: DBConfig) -> Response:
        db_url   = request.db_url if request.db_url else DATABASE_URL
        db_nanme = request.db_name if request.db_name else SETTINGS.GPDB.NAME
        
        try:
            init_migrate_gb(gb_name=db_nanme)
            response = Response(status_code=201, detail=self.response_format.ok(f"Success : Init Migration GraphDB"))
            logger.info(response.detail)
            return response

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error("Failed to Init Migration GraphDB", str(e)))
            logger.error(response.detail)
            return response

    def drop_container(self, container_name: str) -> Response:
        try:
            gb_client = create_gb_client()
            gb_client.get_container_client(container_name)
            gb_client.delete_container(container_name)
            response = Response(status_code=200, detail=self.response_format.ok(f"Graph Cotaniner <{container_name}> Dropped Successfully"))
            logger.info(response.detail)
        
        except exceptions.CosmosResourceNotFoundError:
            response = Response(status_code=200, detail=self.response_format.ok(f"Graph Cotaniner <{container_name}> Does Not Exist. No Actions have been Taken"))
            logger.info(response.detail)
        
        return response

    def condition_drop_node(self, container: str, knowledge_id: str) -> Response:
        if not knowledge_id:
            response = Response(status_code=404, detail=self.response_format.error(f"Condition Drop Error : <{SETTINGS.BASE.APP_NAME}> Found Invalid Drop Input"))
            return response
        
        message  = f"g.V().has(\'knowledge_id\', {knowledge_id}).drop()"
        bindings = dict()

        try:
            if self.api_call == True:
                with self.gb_api(container) as gremlin_client:
                    gremlin_client.submit(
                        message=message,
                        bindings=bindings,
                    )
                    time.sleep(SETTINGS.GPDB.CREATE_WAIT_SEC)

            else:
                with self.gb_func(container) as gremlin_client:
                    gremlin_client.submit(
                        message=message,
                        bindings=bindings,
                    )
                    time.sleep(SETTINGS.GPDB.CREATE_WAIT_SEC) 
            
            response = Response(status_code=200, detail=self.response_format.ok(f"Condition Drop Completed : <{SETTINGS.BASE.APP_NAME}> Dropping Node Completed"))
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Condition Drop Error : <{SETTINGS.BASE.APP_NAME}> Dropping Node Failed"))
        
        return response

    def batch_migrate(self, request: BatchMigrateRequest) -> Response:

        logger.info("Starting Data Migration")
        db_name = request.db_config.db_name if request.db_config.db_name else SETTINGS.GPDB.NAME

        try:
            gb_client = create_gb_client(db_name=db_name)
            gb_client.create_container_if_not_exists(
                id=request.container_name,
                partition_key=PartitionKey(path=f"/{request.partition_key}"),
                offer_throughput=request.throughput
            )            

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error("Failed to Init Container before Migration"))
            logger.error(response.detail)
            return response

        try:
            with get_gb(container_name=request.container_name, gb_name=db_name) as gremlin_client:

                if request.action.upper() in ["DROP", "UPSERT"]:
                    try:
                        message  = f"g.V().has(\'{request.graph_uid_field}\', {request.graph_uid_value}).drop()"
                        bindings = dict()
                        
                        gremlin_client.submit(
                            message=message,
                            bindings=bindings,
                        )
                        response = Response(status_code=200, detail=self.response_format.ok(f"Graph Cotaniner <{request.container_name}> Dropped Successfully"))
                        
                        if request.action.upper() == "DROP":
                            return response

                    except exceptions.CosmosResourceNotFoundError:
                        response = Response(status_code=200, detail=self.response_format.ok(f"Graph Cotaniner <{request.container_name}> Does Not Exist. No Actions have been Taken"))
                        logger.info(response.detail)
                        return response

                if request.action.upper() in ["INSERT", "UPSERT"]:

                    if request.data.get("nodes", []):
                        for node in request.data.get("nodes"):
                            message, bindings = self.add_node_formatter(
                                node_id_field    = request.node_uid_field,
                                node_label_field = request.node_label_field,
                                node             = node
                            )
                            gremlin_client.submit(
                                message=message,
                                bindings=bindings,
                            )
                            time.sleep(SETTINGS.GPDB.CREATE_WAIT_SEC)

                    if request.data.get("edges", []):
                        for edge in request.data.get("edges"):
                            message, bindings = self.add_edge_formatter(
                                partition_key     = request.graph_uid_value,
                                edge_id_field     = request.edge_uid_field,
                                edge_label_field  = request.edge_label_field,
                                edge_source_field = request.edge_source_field,
                                edge_target_field = request.edge_target_field,
                                edge              = edge
                            )
                            gremlin_client.submit(
                                message=message,
                                bindings=bindings,
                            )
                            time.sleep(SETTINGS.GPDB.CREATE_WAIT_SEC)
                    
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Migration Fail : Unknown Migration Action"))
                    return response
                
                response = Response(status_code=201, detail=self.response_format.ok(f"Success : {request.action} Data"))
                logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Migration Error : <{SETTINGS.BASE.APP_NAME}> Failed to Connect VB", str(e)))
            logger.error(response.detail)
            
        return response
    
    def add_node_formatter(
            self, 
            node_id_field: str, 
            node_label_field: str, 
            node: dict
        ) -> tuple[str, dict]:

        property_list = []
        message  = ""
        bindings = dict()
    
        node_dict  = node
        node_label = node_dict.pop(node_label_field, "unknown")

        for _key, _value in node_dict.items():
            prop_key = f"prop_{_key}"
            property_list.append(f".property(\'{_key}\', {prop_key})")
            bindings[prop_key] = self.value_converter_to_db(_value)

        property_list.append(f".property(\'id\', prop_{node_id_field})")

        message = f"g.addV(\'{node_label}\')" + "".join(property_list)
        
        return message, bindings

    def add_edge_formatter(
            self, 
            partition_key: str,
            edge_id_field: str, 
            edge_label_field: str, 
            edge_source_field: str,
            edge_target_field: str,
            edge: dict
        ) -> tuple[str, dict]:

        property_list = []
        message  = ""
        bindings = dict()   

        edge_dict  = edge
        edge_label = edge_dict.pop(edge_label_field, "unknown")

        for _key, _value in edge_dict.items():
            prop_key = f"prop_{_key}"
            property_list.append(f".property(\'{_key}\', {prop_key})")
            bindings[prop_key] = self.value_converter_to_db(_value)

        property_list.append(f".property(\'id\', prop_{edge_id_field})")

        message = (
            f"g.V([prop_partition_key, prop_{edge_source_field}])"
            f".addE(prop_{edge_label_field})"
            f".to(g.V([prop_partition_key, prop_{edge_target_field}]))"
        )
        message += "".join(property_list)
        
        bindings.update(
            {
                f"prop_partition_key":       partition_key,
                f"prop_{edge_source_field}": edge.get(edge_source_field),
                f"prop_{edge_target_field}": edge.get(edge_target_field),
                f"prop_{edge_label_field}":  edge_label
            }
        )
        return message, bindings


    def value_converter_to_db(self, value):
        if isinstance(value, datetime):
            return value.isoformat()
        elif isinstance(value, list):
            return str(value)
        else:
            return value