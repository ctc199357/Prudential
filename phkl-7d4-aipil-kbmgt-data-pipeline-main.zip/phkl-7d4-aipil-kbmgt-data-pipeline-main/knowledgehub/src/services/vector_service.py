import inspect

from azure.search.documents.models import VectorizedQuery 

from typing import Any, Generator

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.vector import (
    KnowledgeVectorUpdateRequest,
    KnowledgeVectorCreateRequest,
    KnowledgeVectorCreateResponse,
    KnowledgeVectorUpdateRequest,
    KnowledgeVectorUpdateResponse,
    KnowledgeVectorRequest,
    KnowledgeVectorReadResponse,
    VectorSearchRequest,
    VectorSearchResponse,
    VectorData
)

from ..database.vector.connections.vector_connection import get_vb_func, get_vb_api
from ..database.vector.models.vector_models import vb_schema

# API DB Session
if SETTINGS.BASE.APP_API == True:
    vb_api = get_vb_api()
    default_api_call = True
else:
    vb_api = None
    default_api_call = False

# Function DB Session
if SETTINGS.BASE.APP_FUNC == True:
    vb_func = get_vb_func
else:
    vb_func = None


from ..logger.log_handler import get_logger

logger = get_logger(__name__)

# Init Manager Mapping
manager_map = {}
if SETTINGS.VTDB.FORM.upper() == "AISEARCH":
    from ..services.vb_aisearch_service import AISearchServiceManager
    manager_map["AISEARCH"] = AISearchServiceManager


class VectorServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            api_call:        bool | None = default_api_call,
            vb_api:          Any | None = vb_api, 
            vb_func:         Generator | None = vb_func, 
            vector_storage:  str=SETTINGS.VTDB.FORM, 
            vector_location: str=SETTINGS.VTDB.LOCA, 
            vector_config:   dict=SETTINGS.VTDB.CONFIG,
        ):
        self.api_call        = api_call
        self.vb_api          = vb_api
        self.vb_func         = vb_func
        self.vector_storage  = vector_storage
        self.vector_location = vector_location
        self.vector_config   = vector_config

        self.manager = manager_map.get(self.vector_storage.upper(), None)

    # Create Knowledge
    def create_knowledge(self, request: KnowledgeVectorCreateRequest) -> tuple[KnowledgeVectorCreateResponse, Response]:
        response_data = KnowledgeVectorCreateResponse()
        
        try:
            response_data, response = self.manager(
                vb_api          = self.vb_api, 
                vb_func         = self.vb_func, 
                api_call        = self.api_call,
                vector_storage  = self.vector_storage,
                vector_location = self.vector_location,
                vector_config   = self.vector_config
            ).create_knowledge(request=request)

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encounter Unexpected Error in Vector Data Managment"))

        return response_data, response

    # Read Knowledge
    def read_knowledge(self, request: KnowledgeVectorRequest) -> tuple[KnowledgeVectorReadResponse, Response]:
        response_data = KnowledgeVectorReadResponse(**request.__dict__)
        
        try:
            response_data, response = self.manager(
                vb_api          = self.vb_api, 
                vb_func         = self.vb_func, 
                api_call        = self.api_call,
                vector_storage  = self.vector_storage,
                vector_location = self.vector_location,
                vector_config   = self.vector_config
            ).read_knowledge(request=request)

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encounter Unexpected Error in Vector Data Managment"))

        return response_data, response

    # Update Knowledge
    def update_knowledge(self, request: KnowledgeVectorUpdateRequest) -> tuple[KnowledgeVectorUpdateResponse, Response]:
        response_data = KnowledgeVectorUpdateResponse(**request.__dict__)
    
        try:
            response_data, response = self.manager(
                vb_api          = self.vb_api, 
                vb_func         = self.vb_func, 
                api_call        = self.api_call,
                vector_storage  = self.vector_storage,
                vector_location = self.vector_location,
                vector_config   = self.vector_config
            ).update_knowledge(request=request)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encounter Unexpected Error in Vector Data Managment", str(e)))

        return response_data, response
    
    # Drop Knowledge
    def drop_knowledge(self, request: KnowledgeVectorRequest) -> Response:   
        try:
            response = self.manager(
                vb_api          = self.vb_api, 
                vb_func         = self.vb_func, 
                api_call        = self.api_call,
                vector_storage  = self.vector_storage,
                vector_location = self.vector_location,
                vector_config   = self.vector_config
            ).drop_knowledge(request=request)

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encounter Unexpected Error in Vector Data Managment"))

        return response
    

    def search_by_vector(self, request: VectorSearchRequest) -> tuple[VectorSearchResponse, Response]:
        logger.info(f"Processing : <{SETTINGS.BASE.APP_NAME}> Starts Vector Search")

        response_vector = VectorSearchResponse(**request.__dict__)
        if not request.processed_query:
            response = Response(status_code=200, detail=self.response_format.ok(f"Vector Search Completed : <{SETTINGS.BASE.APP_NAME}> No Vectors Provided"))
            return response_vector, response

        if request.search_method.lower() == 'hybrid':
            retrieved_vectors, response = self.hybrid_search(request=request)

        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_vector, response

        response_vector.__dict__.update(
            retrieved_data         = retrieved_vectors,
            vector_retrieval_count = len(retrieved_vectors),
        )

        return response_vector, response
    
    def hybrid_search(self, request: VectorSearchRequest) -> tuple[list[VectorData], Response]:
        vector_data = []

        if not request.search_config:
            request.search_config = {"knn": {"knn": 50, "top_k": "50"}}

        data_length_min = 10
        if len(request.query) <= data_length_min:
            data_length_max = len(request.query) * 3
            filter_parts = [ f"data_length gt {data_length_max}"]
        else:
            filter_parts = []
        
        if request.knowledge_ids:
            knowledge_filter = " or ".join([f"knowledge_id eq '{_knowledge_id}'" for _knowledge_id in request.knowledge_ids])
            filter_parts.append(f"({knowledge_filter})")
        
        if request.data_ids:
            data_filter = " or ".join([f"data_id eq '{_data_id}'" for _data_id in request.data_ids])
            filter_parts.append(f"({data_filter})") 
        
        filter_parts.append("data_type ne 'DOCUMENT'")

        filter_str = " and ".join(filter_parts)
        selected_fields = [field.name for field in vb_schema if field.name != "processed_data"]

        try:
            if request.search_config.get("knn"):
                search_config = request.search_config.get("knn")
                vector_query = VectorizedQuery(
                    vector=request.processed_query,
                    k_nearest_neighbors=search_config.get("knn"),
                    fields="processed_data"
                )

                if self.api_call:
                    results = self.vb_api.search(
                        search_text    = request.query,
                        vector_queries = [vector_query],
                        select         = selected_fields,
                        top            = search_config.get("top_k", "50"),
                        filter         = filter_str,
                        # query_type     = "semantic",
                        # SemanticConfiguration   = "my-semantic-config",
                        # scoring_profile         = "boostLongDocs"
                    )

                else:
                    with self.vb_func() as vb:
                        results = vb.search(
                            search_text    = request.query,
                            vector_queries = [vector_query],
                            select         = selected_fields,
                            top            = search_config.get("top_k", "50"),
                            filter         = filter_str,
                            # query_type     = "semantic",
                            # SemanticConfiguration   = "my-semantic-config",
                            # scoring_profile         = "boostLongDocs"
                        )

                #for _results in results:
                #   if _result.get(data_type) == "TITLE":
                #       seq_no =  _result.get(data_type)+1
                #       kid    =  _result.get(knowledge_id)
                #       next_results = vb.search(
                        #     
                        #     
                        #     select         = selected_fields,
                        #    
                        #     filter         = "seq_no eq {seq_no} and knowledeg_id eq {knowledge_id}"
                        # )
                        
                        # result.append(next_results)
                        # result.delete(_results)

                ##
                                # Collect initial results into a list
                initial_results = list(results)

                # Process results to handle TITLEs
                for result in initial_results:
                    if result.get('data_type') != 'TITLE':
                        vector_data.append(VectorData(**result, score=result.get("@search.score", 0.0)))
                    else:
 
                        # Handle TITLE: find the next non-TITLE with same knowledge_id
                        knowledge_id = result.get('knowledge_id')
                        seq_no = result.get('seq_no') + 1  # Increment sequence number
                        score = result.get("@search.score", 0.0)  # Preserve the original score
                        max_attempts = 3  # Prevent infinite loops

                        for _ in range(max_attempts):
                            if self.api_call:
                                next_results = self.vb_api.search(
                                    select=selected_fields,
                                    filter=f"knowledge_id eq '{knowledge_id}' and seq_no eq {seq_no}"
                                ) 
                            else:
                                with self.vb_func() as vb:
                                    next_results = vb.search(
                                    select=selected_fields,
                                    filter=f"knowledge_id eq '{knowledge_id}' and seq_no eq {seq_no}"
                                ) 
                            next_result_list = list(next_results)
                            if next_result_list:
                                next_item = next_result_list[0]
                                if next_item.get('data_type') != 'TITLE':
                                    # Found a non-TITLE, append it with the original score
                                    vector_data.append(VectorData(**next_item, score=score))
                                    break
                                else:
                                    # Still a TITLE, increment seq_no and continue
                                    seq_no += 1
                            else:
                                # No next item found, stop searching
                                break
                        else:
                            # Max attempts reached without finding a non-TITLE
                            logger.warning(
                                f"Could not find non-TITLE item after {max_attempts} attempts "
                                f"for knowledge_id {knowledge_id} starting from seq_no {result['seq_no']}"
                            )
                response = Response(status_code=200, detail=self.response_format.ok(f"Vector Search Success : <{SETTINGS.BASE.APP_NAME}> Completed Hybrid Search. Retrieved <{len(vector_data)}> Vectors"))
                logger.info(response.detail)

            else:
                response = Response(status_code=404, detail=self.response_format.error(f"Hybrid Search Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Unknown Hybrid Search Configuration"))
                logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Encounterd Common Error during Hybrid Search", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Encounterd Unexpected Error during Hybrid Search", str(e)))
            logger.error(response.detail)

        return vector_data, response