"""
    Knowledge Ingestion Stage
"""

PENDING_TO_INGEST = "Pending to Ingest"
INGESTING = "Ingesting"
INGESTED_FOR_REVIEW = "Ingested for Review"

from datetime import datetime, timedelta, timezone
import time
import inspect
import httpx
import os
import uuid
import shutil
import io

import csv

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.evaluation import (
    SeedQnASyncRequest,
    SeedQnASyncResponse,
    SystemSeedQnARequest,
    SeedQnAFilter,
    SeedQnANumericFilter
)

from ..database.registry.schemas.access import (
    AccessFilter,
    AccessNumericFilter,
    SystemAccessRequest
)

from ..routers.registry.general import (
    general_batch_create_access,
    general_batch_activate_access,
    general_batch_deactivate_access,
    general_batch_drop_access
)

from ..routers.registry.system import (
    system_query_access,
    system_query_knowledge
)

from ..services import request_seed_qna_sync, system_query_seedqna

from ..schemas.knowledge import (
    PilSyncRequest,
    PilSyncResponse,
    SystemKnowledgeRequest,
    KnowledgeFilter,
    KnowledgeStringFilter
)


from ..routers.request import request_pil_sync

from ..services import request_seed_qna_sync

from ..database.registry.schemas.access import (
    AccessCreate,
    AccessCreateRequest,
    AccessBatchCreateRequest,
    AccessRequest,
    AccessBatchRequest
)


from ..utils import (
    download_from_blob_by_url,
    get_sync_blob,
    check_sync_blob,
    check_and_download_blob_by_url,
    get_sync_blob_url
)

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

if SETTINGS.BASE.APP_FUNC == True:
    from ..services import (
        request_seed_qna_sync
    )

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class SyncServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            api_call: bool=default_api_call,
        ):
        self.api_call = api_call
    
    

    def sync_pil_metadata(self) -> tuple[PilSyncResponse, Response]:
        logger.info(f"Processing : Sync PIL Metadata")
        response_data = PilSyncResponse()

        # Retrieve from Knowledge Table by knowledge_ingestion_stage = INGESTING
        system_query_knowledge_request = SystemKnowledgeRequest(data_filter=KnowledgeFilter(
                                                                            string_filter=KnowledgeStringFilter(knowledge_ingestion_stage_filter=[INGESTING]),
                                                                            sorting={"updated_at": "desc"},
                                                                            filter_no=1))
        try:
            system_query_knowledge_response = system_query_knowledge(request=system_query_knowledge_request, api_call=self.api_call)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge", str(e)))
            logger.error(response.detail)
            return response_data, response
        
        # If found ingesting knowledge and updated_at within 6 hours, return
        if system_query_knowledge_response.filtered_data and system_query_knowledge_response.filtered_data[0].updated_at > datetime.now(timezone.utc) - timedelta(hours=6):
            response = Response(status_code=200, detail=self.response_format.ok(f"Sync PIL Metadata Skipped : <{SETTINGS.BASE.APP_NAME}> Found Ingesting Knowledge"))
            logger.info(response.detail)
            return response_data, response

        # Check latest PIL Metadata from blob 
        try:
            file_url = get_sync_blob_url(
                folder_name=SETTINGS.BLOB.METADATA_FOLDER_NAME,
                file_name=SETTINGS.META.FILE_NAME,
                container=SETTINGS.BLOB.PIL_CONTAINER_NAME
            )
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Sync PIL Metadata Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Sync PIL Metadata", str(e)))
            logger.error(response.detail)
            return response_data, response
    
        # Return if Not Found
        if not file_url:
            response = Response(status_code=200, detail=self.response_format.error(f"Sync PIL Metadata Completed : <{SETTINGS.BASE.APP_NAME}> Did Not Find Latest PIL Metadata"))
            logger.info(response.detail)
            return response_data, response
    
        # Call Sync PIL Pipeline
        try:
            request = PilSyncRequest(
                pil_metadata_path = file_url
            )
            response_data = request_pil_sync(request=request, api_call=self.api_call)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Sync PIL Metadata Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))
            logger.error(response.detail)
            return response_data, response
        
        response = Response(status_code=200, detail=self.response_format.ok(f"Sync PIL Metadata Completed : <{SETTINGS.BASE.APP_NAME}> Completed Sync PIL Metadata"))
        logger.info(response.detail)
        return response_data, response

    def sync_pil_access_from_file(self, file_path: str, batch_order: str) -> Response:

        info_mapper = {
            "group_id": "Group ID",
            "group_display_name_en": "Group Display Name (EN)",
            "group_display_name_zh": "Group Display Name (ZH)",
            "owner": "Owner",
            "role_name": "Role Name",
            "designation_code": "Designation Code",
            "channel": "Channel",
            "sub_channel": "Sub Channel"
        }

        logger.info(f"Processing : Start Sync PIL Access From File")

        """ 1. Read the Content """
        logger.info(f"Processing : Parsing PIL Access File Content")
        create_requests = []
        file_name, file_extension = os.path.splitext(os.path.basename(file_path))  

        if file_extension.lower() == '.csv':
            with open(file_path, mode='r', newline='', encoding='utf-8-sig') as csv_file:

                first_line = csv_file.readline().strip()
                if first_line.startswith('"') and first_line.endswith('"'):
                    header_line = first_line.strip('"')                        
                    rest_of_file = csv_file.read()
                    csv_file = io.StringIO(header_line + '\n' + rest_of_file)

                elif first_line.startswith('\'') and first_line.endswith('\''):
                    header_line = first_line.strip('\'')                        
                    rest_of_file = csv_file.read()                        
                    csv_file = io.StringIO(header_line + '\n' + rest_of_file)

                else:
                    csv_file.seek(0)
                    
                csv_reader = csv.DictReader(csv_file)
            
                for _data in csv_reader:
                    create_requests.append(
                        AccessCreateRequest(
                            data=AccessCreate(
                                **{key: _data[value] for key, value in info_mapper.items()},
                                batch_order = batch_order
                            )
                        )
                    )

        else:
            response = Response(status_code=404, detail=self.response_format.error(f"Unfound Error : <{SETTINGS.BASE.APP_NAME}> Cannot Find Valid Sync File Type"))
            logger.error(response.detail)
            return response

        if not create_requests:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Data to be Updated : <{SETTINGS.BASE.APP_NAME}> Skipped Sync Seed QnA"))
            logger.info(response.detail)
            return response

        """ 3. Deactivating Previous Records """
        try:
            response_prev_data = system_query_access(
                request=SystemAccessRequest(
                    data_filter=AccessFilter(
                        numeric_filter=AccessNumericFilter(
                            access_status_min=1
                        )
                    )
                ),
                api_call=self.api_call
            )
            previous_data_ids = [_data.access_id for _data in response_prev_data.filtered_data]

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Access Deactivation Error : <{SETTINGS.BASE.APP_NAME}> Cannot Deactivate Previous Record"))
            logger.error(response.detail)
            return response
        
        """ 4. Create New Access Table """
        logger.info("Processing : Creating New Access Table")
        create_request = AccessBatchCreateRequest(create_requests = create_requests)
        try:
            response = general_batch_create_access(request=create_request, api_call=self.api_call)
            logger.info("Sync Processing : Registered New Records for Access Mapping")

            if previous_data_ids:
                response = general_batch_deactivate_access(
                    request = AccessBatchRequest(
                        batch_requests = [
                            AccessRequest(access_id=data_id)
                            for data_id in previous_data_ids
                        ]
                    ),
                    api_call=self.api_call
                )

                response = general_batch_drop_access(
                    request = AccessBatchRequest(
                        batch_requests = [
                            AccessRequest(access_id=data_id)
                            for data_id in previous_data_ids
                        ]
                    ),
                    api_call=self.api_call
                )
                logger.info("Dropped Previous Records")

        except:
            logger.error("Processing : Failed to Create New Access Records. Revert Original Access")
            
            if previous_data_ids:
                response = general_batch_activate_access(
                    request = AccessBatchRequest(
                        batch_requests = [
                            AccessRequest(access_id=data_id)
                            for data_id in previous_data_ids
                        ]
                    ),
                    api_call=self.api_call
                )
            
            response = Response(status_code=500, detail=self.response_format.error(f"Access Creation Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error when Creating New Table"))
            logger.error(response.detail)
            return response
        
        """ 6. Return Response """
        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Syncing Access"))
        logger.info(response.detail)

        return response

    def sync_pil_access(self) -> Response:
    
        logger.info(f"Processing : Sync Access QnA")
        
        try:
            response_db_data = system_query_access(
                request = SystemAccessRequest(
                    data_filter=AccessFilter(
                        numeric_filter=AccessNumericFilter(
                            access_status_min=1
                        ),
                        filter_no=1
                    )
                )
            )

            if not response_db_data.filtered_data:
                latest_batch_order = "00000000000000"  # YYYYMMDDHHMMSS
            else:
                data = response_db_data.filtered_data[0]
                latest_batch_order = data.batch_order if data.batch_order else "00000000000000"

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Sync Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Query Previous Record", str(e)))
            logger.error(response.detail)
            return response

        # Check Latest Sync File
        try:
            file_url, sync_file_timestamp = check_sync_blob(
                folder_name=SETTINGS.BLOB.ACCESS_FOLDER_NAME,
                date_str=latest_batch_order,
                file_name=SETTINGS.SCH.SYNC_ACCESS_FILE_NAME,
                container=SETTINGS.BLOB.PIL_CONTAINER_NAME
            )

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Access Sync Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Sync Access", str(e)))
            logger.error(response.detail)
            return response

        # Return if Not Found
        if not file_url:
            response = Response(status_code=200, detail=self.response_format.ok(f"Access Sync Completed : <{SETTINGS.BASE.APP_NAME}> Did Not Find Latest Access"))
            logger.info(response.detail)
            return response

        # Download Blob if Found
        local_dir = ''
        try:
            local_dir = os.path.join(os.getcwd(), f"temp_blob_access_{str(uuid.uuid4())}") # avoid file name conflict when multiple jobs are running at the same time
            os.makedirs(local_dir, exist_ok=True)

            local_file_path = os.path.join(local_dir, SETTINGS.SCH.SYNC_ACCESS_FILE_NAME)
            if os.path.exists(local_file_path):
                os.remove(local_file_path)

            blob_exist = check_and_download_blob_by_url(
                blob_file_url=file_url,
                local_path=local_file_path
            )

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Sync Access Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Download Access from Blob"))
            logger.error(response.detail)
            return response

        if blob_exist:
            response = self.sync_pil_access_from_file(file_path=local_file_path, batch_order=sync_file_timestamp)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                logger.error(f"Sync Access Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Sync Access")

            response = Response(status_code=200, detail=self.response_format.ok(f"Sync Access Success : <{SETTINGS.BASE.APP_NAME}> Completed Sync Access"))
            logger.info(response.detail)

        else:
            response = Response(status_code=200, detail=self.response_format.ok(f"Sync Access Completed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Updated Access"))
            logger.info(response.detail)

        if local_dir:
            try:
                if os.path.exists(local_dir):
                    shutil.rmtree(local_dir)
            except Exception as e:
                logger.error(f"Error : Cleaning Up Temporary Directory {local_dir}: {str(e)}")
            
        return response


    def sync_seed_qna(self) -> Response:
        logger.info(f"Processing : Sync Seed QnA")
        
        try:
            response_db_data = system_query_seedqna(
                request = SystemSeedQnARequest(
                    data_filter=SeedQnAFilter(
                        numeric_filter=SeedQnANumericFilter(
                            seed_qna_status_min=1
                        ),
                        filter_no=1
                    )
                )
            )

            if not response_db_data.filtered_data:
                latest_batch_order = "00000000000000"  # YYYYMMDDHHMMSS
            else:
                data = response_db_data.filtered_data[0]
                latest_batch_order = data.batch_order if data.batch_order else "00000000000000"

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Sync Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Query Previous Record", str(e)))
            logger.error(response.detail)
            return response

        # Check Latest Sync File
        try:
            file_url, sync_file_timestamp = check_sync_blob(
                folder_name=SETTINGS.BLOB.SEED_QNA_FOLDER_NAME,
                date_str=latest_batch_order,
                file_name=SETTINGS.SCH.SYNC_SEED_QNA_FILE_NAME,
                container=SETTINGS.BLOB.CONTAINER_NAME
            )

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Seed QnA Sync Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Sync Seed QnA", str(e)))
            logger.error(response.detail)
            return response

        # Return if Not Found
        if not file_url:
            response = Response(status_code=200, detail=self.response_format.error(f"Seed QnA Sync Completed : <{SETTINGS.BASE.APP_NAME}> Did Not Find Latest Seed QnA"))
            logger.info(response.detail)
            return response

        # Download Blob if Found
        local_dir = ''
        try:
            local_dir = os.path.join(os.getcwd(), f"temp_blob_seedqna_{str(uuid.uuid4())}") # avoid file name conflict when multiple jobs are running at the same time
            os.makedirs(local_dir, exist_ok=True)

            local_file_path = os.path.join(local_dir, SETTINGS.SCH.SYNC_SEED_QNA_FILE_NAME)
            if os.path.exists(local_file_path):
                os.remove(local_file_path)

            blob_exist = check_and_download_blob_by_url(
                blob_file_url=file_url,
                local_path=local_file_path
            )
            
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Sync Seed QnA Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Download Seed QnA from Blob"))
            logger.error(response.detail)

        if blob_exist:
            sync_request = SeedQnASyncRequest(
                qna_sync_origin="LOCAL",
                qna_sync_path=local_file_path,
                batch_order=sync_file_timestamp
            )

            try:
                _response_data = request_seed_qna_sync(request=sync_request)
                response = Response(status_code=200, detail=self.response_format.ok(f"Sync Seed QnA Success : <{SETTINGS.BASE.APP_NAME}> Completed Sync Seed QnA"))
                logger.info(response.detail)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Sync Seed QnA Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))
                logger.error(response.detail)
                
        else:
            response = Response(status_code=200, detail=self.response_format.ok(f"Sync Seed QnA Completed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Updated Seed QnA"))
            logger.info(response.detail)

        if local_dir:
            try:
                if os.path.exists(local_dir):
                    shutil.rmtree(local_dir)
            except Exception as e:
                logger.error(f"Error : Cleaning Up Temporary Directory {local_dir}: {str(e)}")
            
        return response  
