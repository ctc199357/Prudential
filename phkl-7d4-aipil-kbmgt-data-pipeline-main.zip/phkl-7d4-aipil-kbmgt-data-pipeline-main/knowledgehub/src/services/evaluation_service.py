from datetime import datetime, timezone
import time
import inspect
import httpx

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..schemas.evaluation import (
    SeedQnASyncRequest,
    SeedQnASyncResponse,
    QnACreateRequest,
    QnAUpdateRequest,
    QnARequest,
    QnAGenerationRequest,
    QnAGenerationResponse,
    EvaluationPipelineRequest,
    EvaluationPipelineResponse,
    SeedQnAExportRequest,
    QnAExportRequest,
    EvaluationExportRequest,
    SystemJobRequest,
    SystemJobResponse,
    SystemSeedQnARequest,
    SystemSeedQnAResponse,
    SystemQnARequest,
    SystemQnAResponse,
    SystemEvaluationRequest,
    SystemEvaluationResponse
)

from ..utils import (
    download_from_blob_by_url,
    get_sync_blob,
    check_and_download_blob_by_url
)

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False

if SETTINGS.BASE.APP_FUNC == True:
    from ..services import (
        request_execute_evaluation_pipeline,
        request_qna_knowledge_generation,
        general_create_qna,
        general_update_qna,
        general_drop_qna,
        request_seed_qna_sync,
        system_export_seedqna,
        system_export_qna,
        system_export_evaluation,
        system_query_job,
        system_query_seedqna,
        system_query_qna,
        system_query_evaluation
    )

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class EvaluationServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            api_call: bool=default_api_call,
        ):
        self.api_call = api_call

    def query_job(self, request: SystemJobRequest) -> tuple[SystemJobResponse, Response]:
        response_data = SystemJobResponse(**request.__dict__)
        try:
            response_data = system_query_job(request=request, api_call=False)
            response = Response(status_code=200, detail=self.response_format.ok(f"Query Job Success : <{SETTINGS.BASE.APP_NAME}> Completed Query Job"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Query Job Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))

        return response_data, response  

    def create_qna(self, request: QnACreateRequest) -> Response:
        try:
            response = general_create_qna(request=request, api_call=False)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Create Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))
        return response

    def update_qna(self, request: QnAUpdateRequest) -> Response:
        try:
            response = general_update_qna(request=request, api_call=False)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Update Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))
        return response

    def drop_qna(self, request: QnARequest) -> Response:
        try:
            response = general_drop_qna(request=request, api_call=False)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Drpop Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))
        return response

    def sync_seed_qna(self, request: SeedQnASyncRequest) -> tuple[SeedQnASyncResponse, Response]:
        response_data = SeedQnASyncResponse(**request.__dict__)
        try:
            response_data = request_seed_qna_sync(request=request, api_call=False)
            response = Response(status_code=200, detail=self.response_format.ok(f"Sync Seed QnA Success : <{SETTINGS.BASE.APP_NAME}> Completed Sync Seed QnA"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Sync Seed QnA Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))

        return response_data, response  

    def generate_knowledge_qna(self, request: QnAGenerationRequest) -> tuple[QnAGenerationResponse, Response]:
        response_data = QnAGenerationResponse(**request.__dict__)
        try:
            response_data = request_qna_knowledge_generation(request=request, api_call=False)
            response = Response(status_code=200, detail=self.response_format.ok(f"Evaluation Pipeline Success : <{SETTINGS.BASE.APP_NAME}> Completed Evaluation Pipeline"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))

        return response_data, response
        

    def execute_pipeline(self, request: EvaluationPipelineRequest) -> tuple[EvaluationPipelineResponse, Response]:
        response_data = EvaluationPipelineResponse(**request.__dict__)
        try:
            response_data = request_execute_evaluation_pipeline(request=request, api_call=False)
            response = Response(status_code=200, detail=self.response_format.ok(f"Evaluation Pipeline Success : <{SETTINGS.BASE.APP_NAME}> Completed Evaluation Pipeline"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))

        return response_data, response
    
    def export_seed_qna(self, request: SeedQnAExportRequest) -> Response:
        try:
            response = system_export_seedqna(request=request, api_call=False)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Seed QnA Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))
        return response
    
    def export_qna(self, request: QnAExportRequest) -> Response:
        try:
            response = system_export_qna(request=request, api_call=False)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"QnA Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))
        return response
    
    def export_evaluation(self, request: EvaluationExportRequest) -> Response:
        try:
            response = system_export_evaluation(request=request, api_call=False)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Evaluation Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))
        return response

    def query_seedqna(self, request: SystemSeedQnARequest) -> tuple[SystemSeedQnAResponse, Response]:
        try:
            response_data = system_query_seedqna(request=request, api_call=False)
            response = Response(status_code=200, detail=self.response_format.ok(f"Query Seed QnA Success : <{SETTINGS.BASE.APP_NAME}> Completed Query Seed QnA"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Query Seed QnA Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))

        return response_data, response

    def query_qna(self, request: SystemQnARequest) -> tuple[SystemQnAResponse, Response]:
        try:
            response_data = system_query_qna(request=request, api_call=False)
            response = Response(status_code=200, detail=self.response_format.ok(f"Query QnA Success : <{SETTINGS.BASE.APP_NAME}> Completed Query QnA"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Query QnA Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))

        return response_data, response
    
    def query_evaluation(self, request: SystemEvaluationRequest) -> tuple[SystemEvaluationResponse, Response]:
        try:
            response_data = system_query_evaluation(request=request, api_call=False)
            response = Response(status_code=200, detail=self.response_format.ok(f"Query Evaluation Success : <{SETTINGS.BASE.APP_NAME}> Completed Query Evaluation"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Query Evaluation Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Calling EvaluationHub Service", str(e)))

        return response_data, response