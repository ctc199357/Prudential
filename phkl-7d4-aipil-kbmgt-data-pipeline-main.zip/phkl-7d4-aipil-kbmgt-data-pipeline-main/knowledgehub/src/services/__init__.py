import os
import shutil

from ..settings import SETTINGS

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

if SETTINGS.BASE.APP_FUNC == False and SETTINGS.BASE.APP_API == False:
    err_msg = f"Failed to Inititate <{SETTINGS.BASE.APP_NAME}> : APP_FUNC and APP_API cannot be ALL False"
    logger.error(err_msg)
    raise Exception(err_msg)


# Import Functions if APP_FUNC == True
if SETTINGS.BASE.APP_FUNC == True:
    # Import KnowledgeInput Function
    try:
        module = __import__(SETTINGS.KWIN.REQUEST_INGEST_MODULE, fromlist=[SETTINGS.KWIN.REQUEST_INGEST_FUNC])
        request_knowledgeinput_ingest = getattr(module, SETTINGS.KWIN.REQUEST_INGEST_FUNC)
        module = __import__(SETTINGS.KWIN.REQUEST_DROP_MODULE, fromlist=[SETTINGS.KWIN.REQUEST_DROP_FUNC])
        request_knowledgeinput_drop = getattr(module, SETTINGS.KWIN.REQUEST_DROP_FUNC)
        module = __import__(SETTINGS.KWIN.INIT_TEMP_STORAGE_MODULE, fromlist=[SETTINGS.KWIN.INIT_TEMP_STORAGE_FUNC])
        init_knowledgeinput_temp_storage = getattr(module, SETTINGS.KWIN.INIT_TEMP_STORAGE_FUNC)
    except:
        err_msg = f"Import Error : <{SETTINGS.BASE.APP_NAME}> Failed to Import <KnowledgeInputHub> Module"
        logger.error(err_msg)
        raise Exception(err_msg)

    # Import Preprocessing Function
    try:
        module = __import__(SETTINGS.PREP.REQUEST_PREPKNOW_MODULE, fromlist=[SETTINGS.PREP.REQUEST_PREPKNOW_FUNC])
        request_exec_prepknow  = getattr(module, SETTINGS.PREP.REQUEST_PREPKNOW_FUNC)
        request_exec_prepmedia = getattr(module, SETTINGS.PREP.REQUEST_PREPMEDIA_FUNC)
        module = __import__(SETTINGS.PREP.INIT_TEMP_STORAGE_MODULE, fromlist=[SETTINGS.PREP.INIT_TEMP_STORAGE_FUNC])
        init_preprocessing_temp_storage = getattr(module, SETTINGS.PREP.INIT_TEMP_STORAGE_FUNC)
    except:
        err_msg = f"Import Error : <{SETTINGS.BASE.APP_NAME}> Failed to Import <PreprocessingHub> Module"
        logger.error(err_msg)
        raise Exception(err_msg)

    # Import Evaluation Function
    try:
        module = __import__(SETTINGS.EVAL.REQUEST_PIPELINE_MODULE, fromlist=[SETTINGS.EVAL.REQUEST_PIPELINE_FUNC])
        request_execute_evaluation_pipeline = getattr(module, SETTINGS.EVAL.REQUEST_PIPELINE_FUNC)
        time_trigger_pipeline_job = getattr(module, SETTINGS.EVAL.TRIGGER_JOB_FUNC)
        reset_pipeline_job = getattr(module, SETTINGS.EVAL.RESET_JOB_FUNC)
        clear_pipeline_job = getattr(module, SETTINGS.EVAL.CLEAR_JOB_FUNC)
        
        eval_general_module = __import__(SETTINGS.EVAL.QNA_GENERAL_MODULE, fromlist=[SETTINGS.EVAL.QNA_CREATE_FUNC])
        general_create_qna = getattr(eval_general_module, SETTINGS.EVAL.QNA_CREATE_FUNC)
        general_update_qna = getattr(eval_general_module, SETTINGS.EVAL.QNA_UPDATE_FUNC)
        general_drop_qna   = getattr(eval_general_module, SETTINGS.EVAL.QNA_DROP_FUNC)

        eval_system_moduel = __import__(SETTINGS.EVAL.SYSTEM_MODULE, fromlist=[SETTINGS.EVAL.QUERY_SEED_QNA_FUNC])
        system_query_seedqna    = getattr(eval_system_moduel, SETTINGS.EVAL.QUERY_SEED_QNA_FUNC)
        system_query_qna        = getattr(eval_system_moduel, SETTINGS.EVAL.QUERY_QNA_FUNC)
        system_query_evaluation = getattr(eval_system_moduel, SETTINGS.EVAL.QUERY_EVALUATION_FUNC)

        eval_request_module = __import__(SETTINGS.EVAL.QNA_REQUEST_MODULE, fromlist=[SETTINGS.EVAL.QNA_GENERATE_FUNC])
        request_qna_knowledge_generation = getattr(eval_request_module, SETTINGS.EVAL.QNA_GENERATE_FUNC)
        request_seed_qna_sync = getattr(eval_request_module, SETTINGS.EVAL.SEED_QNA_SYNC_FUNC)

        io_moduel = __import__(SETTINGS.EVAL.IO_MODULE, fromlist=[SETTINGS.EVAL.IO_QNA_EXPORT_FUNC])
        system_export_seedqna    = getattr(io_moduel, SETTINGS.EVAL.IO_SEED_QNA_EXPORT_FUNC)
        system_export_qna        = getattr(io_moduel, SETTINGS.EVAL.IO_QNA_EXPORT_FUNC)
        system_export_evaluation = getattr(io_moduel, SETTINGS.EVAL.IO_EVAL_EXPORT_FUNC)

        job_moduel = __import__(SETTINGS.EVAL.JOB_MODULE, fromlist=[SETTINGS.EVAL.JOB_QUERY_FUNC])
        system_query_job = getattr(job_moduel, SETTINGS.EVAL.JOB_QUERY_FUNC)

    except:
        err_msg = f"Import Error : <{SETTINGS.BASE.APP_NAME}> Failed to Import <EvaluationHub> Module"
        logger.error(err_msg)
        raise Exception(err_msg)
