import inspect
import os
import json
from datetime import datetime, timezone
from typing import Generator

from azure.search.documents import SearchClient

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.vector import (
    SecretVector,
    VectorCreate,
    VectorStringFilter,
    VectorNumericFilter,
    VectorFilter,
    SystemVectorRequest,
    KnowledgeVectorUpdateRequest,
    KnowledgeVectorCreateRequest,
    KnowledgeVectorCreateResponse,
    KnowledgeVectorUpdateRequest,
    KnowledgeVectorUpdateResponse,
    KnowledgeVectorRequest,
    KnowledgeVectorReadResponse
)

from ..routers.vector.system import system_query_vector

from ..database.vector.connections.vector_connection import get_vb_func, get_vb_api

from ..utils import (
    upload_to_blob,
    delete_blob_file,
    check_blob_file_exists,
    delete_blob_file_by_url
)

# API DB Session
if SETTINGS.BASE.APP_API == True:
    vb_api = get_vb_api()
    default_api_call = True
else:
    vb_api = None
    default_api_call = False

# Function DB Session
if SETTINGS.BASE.APP_FUNC == True:
    vb_func = get_vb_func
else:
    vb_func = None

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class AISearchServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    blob_url_prefix = f"https://{SETTINGS.BLOB.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BLOB.CONTAINER_NAME}/"

    def __init__(
            self, 
            api_call:        bool,
            vb_api:          SearchClient | None = vb_api, 
            vb_func:         Generator    | None = vb_func, 
            vector_storage:  str='AISEARCH', 
            vector_location: str='azure', 
            vector_config:   dict={},
        ):
        self.api_call        = api_call
        self.vb_api          = vb_api
        self.vb_func         = vb_func
        self.vector_storage  = vector_storage
        self.vector_location = vector_location
        self.vector_config   = vector_config

    """
        Knowledge-level General Operations
    """
    # Knowledge Create
    def create_knowledge(
            self, 
            request: KnowledgeVectorCreateRequest
        ) -> tuple[KnowledgeVectorCreateResponse, Response]:

        response_data = KnowledgeVectorCreateResponse()
        response = Response(status_code=500, detail="Failed to Register on Azure Vector DB")

        _data_list = []
        admin_list = []

        for _request in request.create_requests:
            if isinstance(_request.data, VectorCreate):
                _data_list.append(_request.data)
                admin_list.append(_request.is_admin)
            elif isinstance(_request.data, dict):
                _data_list.append(VectorCreate(**_request.data))
                admin_list.append(_request.is_admin)
            else:
                logger.error(f"Invalid Data Type for <{_request.data}>")

        # Validate parameters with creator role
        # for is_admin, data in zip(admin_list, _data_list):
        #     response = self.verify_vector_content(is_admin=is_admin, data=data)
        #     if response:
        #         return response

        vb_data_batch = [_data for _data in _data_list]
        if not vb_data_batch:
            response = Response(status_code=404, detail=self.response_format.error("Unfound Data Batch for Creation"))
            return response_data, response
        
        try:
            batch_size = SETTINGS.VTEX.BATCH_SIZE
            entities = [{key: value for key, value in data.__dict__.items()} for data in vb_data_batch]
            total_batches = (len(entities) + batch_size - 1) // batch_size

            # Process in batches
            for i in range(0, len(entities), batch_size):
                batch = entities[i:i + batch_size]
                logger.info(f"Processing batch {i // batch_size + 1} of {total_batches}")
                
                if self.api_call == True:
                    self.vb_api.upload_documents(
                        documents=batch
                    )
                else:
                    with self.vb_func() as vb:
                        vb.upload_documents(
                            documents=batch
                        )
            response = Response(status_code=201, detail=self.response_format.ok(f"Success : Batch Registered All <{len(request.create_requests)}> Vectors"))
            logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Batch Registering Vector", str(e)))
            logger.error(response.detail)
            return response_data, response

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Batch Registering Vector"))
            logger.error(response.detail)
            return response_data, response
        
        if response.status_code <= SETTINGS.STAT.SUCC_CODE_END:
            knowledge_vectorinfo = {
                "index_name": SETTINGS.VTDB.TABLE,
                "entity_num": len(request.create_requests)
            }

            response_data = KnowledgeVectorCreateResponse(
                knowledge_vectorstorage  = SETTINGS.VTDB.FORM,
                knowledge_vectorlocation = SETTINGS.VTDB.LOCA,
                knowledge_vectorinfo     = knowledge_vectorinfo
            )
        
            # Backup New Vector to Azure Blob Storage.
            response = self.backup_data_to_blob(data=vb_data_batch)

        return response_data, response

    def read_knowledge(self, request: KnowledgeVectorRequest) -> tuple[KnowledgeVectorReadResponse, Response]:
        response_data = KnowledgeVectorReadResponse(**request.__dict__)
        
        vector_filter = VectorFilter(
            string_filter=VectorStringFilter(knowledge_id_filter=[request.knowledge_id])
        )
        vector_request = SystemVectorRequest(vector_filter=vector_filter)
        
        try:
            response_vector = system_query_vector(request=vector_request, api_call=self.api_call)
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Knowledge Vector <knowledge_id: {request.knowledge_id}> Read"))

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Reading Knowledge Error : Failed to Query Vector Data", str(e)))
            logger.error(response.detail)
            return response_data, response
        
        response_data = KnowledgeVectorReadResponse(
            **request.__dict__,
            **response_vector.__dict__
        )

        return response_data, response

    def update_knowledge(self, request: KnowledgeVectorUpdateRequest) -> tuple[KnowledgeVectorUpdateResponse, Response]:
        response_data = KnowledgeVectorUpdateResponse(**request.__dict__)
        response = Response(status_code=500, detail="Failed to Register on Azure Vector DB")

        # Check Data
        if not request.update_request.create_requests:
            response = Response(status_code=404, detail=self.response_format.error("Knowledge Vector Update Fail : Unfound Data Batch for Update"))
            return response_data, response

        # Create Data
        response_create, response = self.create_knowledge(request.update_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response
        else:
            response_data.__dict__.update(**response_create.__dict__, updated_vector_count=len(request.update_request.create_requests))

        # Remove Data
        if request.overwrite:
            drop_request = KnowledgeVectorRequest(**request.__dict__)
            response = self.drop_knowledge(drop_request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response_data, response
            
        response = Response(status_code=200, detail=self.response_format.ok(f"Success : Knowledge Vector <knowledge_id: {request.knowledge_id}> Updated"))
        logger.info(response.detail)
        return response_data, response


    def drop_knowledge(self, request: KnowledgeVectorRequest) -> Response:
        vector_filter = VectorFilter(
            string_filter=VectorStringFilter(knowledge_id_filter=[request.knowledge_id])
        )
        vector_request = SystemVectorRequest(vector_filter=vector_filter)
        
        try:
            response_vector = system_query_vector(request=vector_request, api_call=self.api_call)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Dropping Knowledge Error : Failed to Query Vector Data", str(e)))
            logger.error(response.detail)
            return response
        
        data_ids = [{"data_id": _data.data_id} for _data in response_vector.filtered_vectors]
        data = [_data for _data in response_vector.filtered_vectors]
        if not data_ids:
            # response = Response(status_code=404, detail=self.response_format.error(f"Dropping Knowledge Unfound Error : No Vectors Found with <knowledge_id: {request.knowledge_id}>"))
            # logger.error(response.detail)
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : No Vectors Found with <knowledge_id: {request.knowledge_id}>"))
            logger.info(response.detail)
            return response

        try:
            if self.api_call:
                self.vb_api.delete_documents(documents=data_ids)
            else:
                with self.vb_func() as vb:
                    vb.delete_documents(documents=data_ids)

            response = Response(status_code=200, detail=self.response_format.ok(f"Success : Dropped Knowledge Vector by <knowledge_id: {request.knowledge_id}>"))
            logger.info(response.detail)
        
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Dropping Knowledge", str(e)))
            logger.error(response.detail)
            return response
        
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Dropping Knowledge"))
            logger.error(response.detail)
            return response
        
        # Delete data on Azure Blob Storage. 
        response = self.delete_data_from_blob(data=data, wiping=request.wiping)

        return response
    
    def backup_data_to_blob(self, data: list[VectorCreate], index: str = SETTINGS.VTDB.TABLE) -> Response:
        try:
            for _data in data:
                # Save data to json file
                local_dir = os.path.join(os.getcwd(), f"{index}")
                local_path = os.path.join(local_dir, f"{_data.data_id}.json")
                
                # Check if file exists, if yes, delete it
                if os.path.exists(local_path):
                    os.remove(local_path)
                
                os.makedirs(local_dir, exist_ok=True)
                
                # Save VectorCreate object to json file
                with open(local_path, 'w', encoding="utf-8") as json_file:
                    json.dump(_data.dict(), json_file, cls=ComplexEncoder, ensure_ascii=False, indent=4)
                
                blob_path = f"{SETTINGS.BLOB.VECTOR_FOLDER_NAME}/{index}/{_data.data_id}.json"

                # Upload the new blob file
                upload_to_blob(local_path=local_path, blob_path=blob_path, content_type="application/json")

                # Delete the local file
                if os.path.exists(local_path):
                    os.remove(local_path)

            response = Response(status_code=200, detail=self.response_format.ok("Success : Added Data to Blob"))
            logger.info(response.detail)

        except Exception as e:
            if os.path.exists(local_path):
                os.remove(local_path)

            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Add Data to Blob", str(e)))
            logger.error(response.detail)

        return response

    def delete_data_from_blob(self, data: list[SecretVector], wiping: bool=False) -> Response:
        try:
            for _data in data:
                blob_path = f"{SETTINGS.BLOB.VECTOR_FOLDER_NAME}/{SETTINGS.VTDB.TABLE}/{_data.data_id}.json"

                if check_blob_file_exists(blob_path=blob_path):
                    delete_blob_file(blob=blob_path)

                if wiping and _data.data_url and _data.data_url.startswith(self.blob_url_prefix):
                    delete_blob_file_by_url(blob_url=_data.data_url)

            response = Response(status_code=200, detail=self.response_format.ok("Success : Deleted Data from Blob"))
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Delete Data from Blob", str(e)))
            logger.error(response.detail)

        return response