"""
    Custom Config
"""
from ..schemas.job import (
    PipelineStatus,
    PipelineResponse
)

JOB_PENDING    = "PENDING"
JOB_PROCESSING = "PROCESSING"
JOB_COMPLETE   = "COMPLETED"
JOB_SUCCESS    = "SUCCESS"
JOB_FAIL       = "FAIL"
JOB_RELATIONSHIP_PIPELINE     = 'RELATIONSHIP_EXTRACTION'
JOB_KNOWLEDGE_INGEST_PIPELINE  = 'KNOWLEDGE_INGEST'
JOB_KNOWLEDGE_AUTO_INGEST_PIPELINE = 'KNOWLEDGE_AUTO_INGEST'
JOB_KNOWLEDGE_UPDATE_INGEST_PIPELINE = 'KNOWLEDGE_UPDATE_INGEST'
JOB_PIL_SYNC_PIPELINE = 'PIL_SYNC'
JOB_KNOWLEDGE_EXPORT_PIPEILNE = 'KNOWLEDGE_EXPORT'
JOB_DB_MIGRATION_EXPORT_PIPEILNE = 'DB_MIGRATION_EXPORT'
JOB_VB_MIGRATION_EXPORT_PIPEILNE = 'VB_MIGRATION_EXPORT'
JOB_BLOB_MIGRATION_EXPORT_PIPEILNE = 'BLOB_MIGRATION_EXPORT'
JOB_GB_MIGRATION_EXPORT_PIPEILNE = 'GB_MIGRATION_EXPORT'

from ..routers.request_graph import (
    request_knowledge_extract_relationship,
    KnowledgeRelationshipRequest
)

from ..routers.request import (
    request_knowledge_ingest,
    request_knowledge_auto_ingest,
    request_knowledge_update_ingest,
    request_pil_sync
)

from ..schemas.knowledge import (
    KnowledgeAutoIngestRequest,
    KnowledgeIngestRequest,
    KnowledgeUpdateIngestRequest,
    PilSyncRequest
)


from ..schemas.knowledge import (
    KnowledgeFilter,
    KnowledgeStringFilter,
    KnowledgeNumericFilter,
    SystemKnowledgeRequest
)

from ..schemas.evaluation import (
    SeedQnAFilter,
    SeedQnAStringFilter,
    SeedQnANumericFilter,
    QnAFilter,
    QnAStringFilter,
    QnANumericFilter,
    EvaluationFilter,
    EvaluationStringFilter,
    EvaluationNumericFilter
)

from ..routers.registry.system import (
    system_query_knowledge,
    system_query_keyword_mapping,
    SystemKMRequest
)

from ..routers.metadata.system import (
    system_query_metadata,
)

from ..database.metadata.schemas.metadata import (
    SystemMetadataRequest,
    MetadataFilter,
    MetadataStringFilter
)

from ..schemas.vector import (
    VectorFilter,
    VectorStringFilter,
    SystemVectorRequest
)

from ..database.registry.schemas.keyword_mapping import KeywordMappingFilter, KeywordMappingStringFilter

from ..routers.vector.system import (
    system_query_vector
)

from ..routers.registry.io import (
    system_export_knowledge,
    KnowledgeExportRequest
)

from ..routers.vector.io import (
    system_export_vector,
    VectorExportRequest
)

from ..routers.vector.system import (
    system_partition_vector,
    PartitionRequest
)


from ..routers.request_migration import (
    migrate_db_export,
    DBMigrationExportRequest,
    migrate_vb_export,
    VBMigrationExportRequest,
    migrate_vb_init, 
    VBInitMigrationRequest,
    migrate_blob_export,
    BlobMigrationExportRequest,
    migrate_gb_export,
    GBMigrationExportRequest
)

from ..routers.request_migration import (
    migrate_vb_init, 
    VBInitMigrationRequest,
    migrate_gb_init,
    GBConfig
)

from ..routers.request_evaluation import (
    system_query_seedqna,
    SystemSeedQnARequest,
    system_query_qna,
    SystemQnARequest,
    system_query_evaluation,
    SystemEvaluationRequest
)


pipeline_mapper = {
    "request_knowledge_extract_relationship": {
        "pipeline": request_knowledge_extract_relationship,
        "class":    KnowledgeRelationshipRequest
    },
    "request_knowledge_ingest": {
        "pipeline": request_knowledge_ingest,
        "class":    KnowledgeIngestRequest
    },
    "request_knowledge_auto_ingest": {
        "pipeline": request_knowledge_auto_ingest,
        "class":    KnowledgeAutoIngestRequest
    },
    "request_knowledge_update_ingest": {
        "pipeline": request_knowledge_update_ingest,
        "class":    KnowledgeUpdateIngestRequest
    },
    "request_pil_sync": {
        "pipeline": request_pil_sync,
        "class":    PilSyncRequest
    },
    "system_export_knowledge": {
        "pipeline": system_export_knowledge,
        "class":    KnowledgeExportRequest
    },
    "system_export_vector": {
        "pipeline": system_export_vector,
        "class":    VectorExportRequest
    },
    "migrate_db_export": {
        "pipeline": migrate_db_export,
        "class":    DBMigrationExportRequest
    },
    "migrate_vb_export": {
        "pipeline": migrate_vb_export,
        "class":    VBMigrationExportRequest
    },
    "migrate_blob_export": {
        "pipeline": migrate_blob_export,
        "class":    BlobMigrationExportRequest
    },
    "migrate_gb_export": {
        "pipeline": migrate_gb_export,
        "class":    GBMigrationExportRequest
    }
}


"""
    End of Custom Config
"""

import inspect
import asyncio
from datetime import datetime, timezone
from typing import Any
import importlib
import math
import time
import httpx

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
)

from ..job.schemas.job import (
    JobCreate,
    JobCreateRequest,
    JobBatchCreateRequest,
    JobUpdate,
    JobUpdateRequest,
    JobFilter,
    JobStringFilter,
    JobNumericFilter,
    JobBooleanFilter,
    SystemJobRequest,
    SystemJobResponse,
    JobRequest,
    JobBatchRequest,
    JobUpdate
)

from ..routers.job import general_batch_create_job, general_update_job, system_query_job, system_drop_condition_job

from ..logger.log_handler import get_logger

logger = get_logger(__name__)

class JobManager:

    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool):
        self.api_call = api_call

    @staticmethod
    def clear_job(job_type: str='ALL', job_stage: str=JOB_SUCCESS):

        logger.info(f"Job Cleansing : <job_type : {job_type}> <job_stage : {job_stage}> Pipeline")
        condition = JobUpdate(job_status = 1)

        if job_type != 'ALL':
            condition.job_type = job_type

        if job_stage != "ALL":
            condition.job_stage = job_stage

        try:
            response = system_drop_condition_job(
                request = condition
            )

            logger.info(f"Drop <job_type : {job_type}> <job_stage : {job_stage}> Jobs")
        
        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Failed to Drop <job_type : {job_type}> <job_stage : {job_stage}> Jobs"))
            raise Exception(response.detail)

    @staticmethod
    async def reset_job(job_type: str='ALL', job_stage: str=JOB_PROCESSING):
        if job_type.upper() in ['A', 'ALL']:
            job_type = 'ALL'
        
        logger.info(f"Knowledge Job Reset : {job_type} Pipeline")
        processing_data_request = SystemJobRequest(
            data_filter = JobFilter(
                numeric_filter = JobNumericFilter(
                    job_status_min = 0
                ),
                sorting={"created_at": "desc"}
            )
        )

        if job_type != 'ALL':
            if not processing_data_request.data_filter.string_filter:
                processing_data_request.data_filter.string_filter = JobStringFilter(job_type_filter=[job_type])
            else:
                processing_data_request.data_filter.string_filter.job_type_filter = [job_type]

        if job_stage != "ALL":
            if not processing_data_request.data_filter.string_filter:
                processing_data_request.data_filter.string_filter = JobStringFilter(job_stage_filter=[job_stage])
            else:
                processing_data_request.data_filter.string_filter.job_stage_filter = [job_stage]

        response_processing_data = system_query_job(request=processing_data_request)
        logger.info(f"Found <{len(response_processing_data.filtered_data)}> <job_type : {job_type}> <job_stage : {job_stage}> Knowledge Jobs")

        try:
            
            for data in response_processing_data.filtered_data:
                await JobManager._update_job_status(
                    data.job_id, 
                    PipelineStatus(
                        job_stage = JOB_PENDING,
                        processed_at = None
                    )
                )
            logger.info(f"Reset <{len(response_processing_data.filtered_data)}> <job_type : {job_type}> <job_stage : {job_stage}> Knowledge Jobs")
        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Failed to Reset {job_type} Knowledge Jobs"))
            raise Exception(response.detail)

    @staticmethod
    def create_relationship_job(request: KnowledgeRelationshipRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_RELATIONSHIP_PIPELINE} Pipeline Request")

        response_data = PipelineResponse()

        create_requests = JobBatchCreateRequest(
            create_requests = [
                JobCreateRequest(
                    data = JobCreate(
                        knowledge_id = knowledge_id,
                        job_type     = JOB_RELATIONSHIP_PIPELINE,
                        job_stage    = JOB_PENDING,
                        job_pipeline = "request_knowledge_extract_relationship",
                        job_config   = {"knowledge_ids": [knowledge_id]} | {key: value for key, value in request.__dict__.items() if key != "knowledge_ids"}
                    )
                )
                for knowledge_id in request.knowledge_ids
            ]
        )

        try:
            response = general_batch_create_job(request=create_requests)
            response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_RELATIONSHIP_PIPELINE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(request.knowledge_ids)}> Jobs"))
            response_data.pipeline_info = [request.data for request in create_requests.create_requests]
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_RELATIONSHIP_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
            logger.error(response.detail)

        return response_data, response
    
    @staticmethod
    async def create_knowledge_ingest(request: KnowledgeIngestRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_KNOWLEDGE_INGEST_PIPELINE} Pipeline Request")

        response_data = PipelineResponse()

        job = JobCreate(
            knowledge_id = 'NA',
            job_type     = JOB_KNOWLEDGE_INGEST_PIPELINE,
            job_stage    = JOB_PENDING,
            job_pipeline = "request_knowledge_ingest",
            job_config   = request.dict()
        )

        create_requests = JobBatchCreateRequest(
            create_requests = [JobCreateRequest(data=job)]
        )

        try:
            response = general_batch_create_job(request=create_requests)
            response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_KNOWLEDGE_INGEST_PIPELINE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(create_requests.create_requests)}> Jobs"))
            
            await JobManager.event_trigger_job(job=job)
            
            response_data.pipeline_info = [request.data for request in create_requests.create_requests]
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_KNOWLEDGE_INGEST_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
            logger.error(response.detail)

        return response_data, response

    @staticmethod
    async def create_knowledge_auto_ingest(request: KnowledgeAutoIngestRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_KNOWLEDGE_AUTO_INGEST_PIPELINE} Pipeline Request")

        response_data = PipelineResponse()

        job = JobCreate(
            knowledge_id = 'NA',
            job_type     = JOB_KNOWLEDGE_AUTO_INGEST_PIPELINE,
            job_stage    = JOB_PENDING,
            job_pipeline = "request_knowledge_auto_ingest",
            job_config   = request.dict()
        )

        create_requests = JobBatchCreateRequest(
            create_requests = [JobCreateRequest(data=job)]
        )

        try:
            response = general_batch_create_job(request=create_requests)
            response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_KNOWLEDGE_AUTO_INGEST_PIPELINE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(create_requests.create_requests)}> Jobs"))
            
            await JobManager.event_trigger_job(job=job)
            
            response_data.pipeline_info = [request.data for request in create_requests.create_requests]
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_KNOWLEDGE_AUTO_INGEST_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
            logger.error(response.detail)

        return response_data, response

    @staticmethod
    async def create_knowledge_update_ingest(request: KnowledgeUpdateIngestRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_KNOWLEDGE_UPDATE_INGEST_PIPELINE} Pipeline Request")

        response_data = PipelineResponse()

        job = JobCreate(
            knowledge_id = 'NA',
            job_type     = JOB_KNOWLEDGE_UPDATE_INGEST_PIPELINE,
            job_stage    = JOB_PENDING,
            job_pipeline = "request_knowledge_update_ingest",
            job_config   = request.dict()
        )

        create_requests = JobBatchCreateRequest(
            create_requests = [JobCreateRequest(data=job)]
        )

        try:
            response = general_batch_create_job(request=create_requests)
            response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_KNOWLEDGE_UPDATE_INGEST_PIPELINE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(create_requests.create_requests)}> Jobs"))
            
            await JobManager.event_trigger_job(job=job)
            
            response_data.pipeline_info = [request.data for request in create_requests.create_requests]
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_KNOWLEDGE_UPDATE_INGEST_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
            logger.error(response.detail)

        return response_data, response

    @staticmethod
    async def create_pil_sync(request: PilSyncRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_PIL_SYNC_PIPELINE} Pipeline Request")

        response_data = PipelineResponse()

        job = JobCreate(
            knowledge_id = 'NA',
            job_type     = JOB_PIL_SYNC_PIPELINE,
            job_stage    = JOB_PENDING,
            job_pipeline = "request_pil_sync",
            job_config   = request.dict()
        )

        create_requests = JobBatchCreateRequest(
            create_requests = [JobCreateRequest(data=job)]
        )

        try:
            response = general_batch_create_job(request=create_requests)
            response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_PIL_SYNC_PIPELINE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(create_requests.create_requests)}> Jobs"))
            
            await JobManager.event_trigger_job(job=job)
            
            response_data.pipeline_info = [request.data for request in create_requests.create_requests]
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_PIL_SYNC_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
            logger.error(response.detail)

        return response_data, response

    @staticmethod
    async def create_knowledge_export_job(request: KnowledgeExportRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_KNOWLEDGE_EXPORT_PIPEILNE} Pipeline Request")

        response_data = PipelineResponse()

        job = JobCreate(
            knowledge_id = 'NA',
            job_type     = JOB_KNOWLEDGE_EXPORT_PIPEILNE,
            job_stage    = JOB_PENDING,
            job_pipeline = "system_export_knowledge",
            job_config   = request.dict()
        )

        create_requests = JobBatchCreateRequest(
            create_requests = [JobCreateRequest(data=job)]
        )

        try:
            response = general_batch_create_job(request=create_requests)
            response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_KNOWLEDGE_EXPORT_PIPEILNE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(create_requests.create_requests)}> Jobs"))
            
            await JobManager.event_trigger_job(job=job)
            
            response_data.pipeline_info = [request.data for request in create_requests.create_requests]
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_KNOWLEDGE_EXPORT_PIPEILNE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
            logger.error(response.detail)

        return response_data, response


    @staticmethod
    async def create_db_migration_export_job(request: DBMigrationExportRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_DB_MIGRATION_EXPORT_PIPEILNE} Pipeline Request")

        response_data = PipelineResponse()

        if request.migration_type.lower() == "keyword_mapping":
            try:
                _response_data = system_query_keyword_mapping(
                    request = SystemKMRequest(
                        data_filter=KeywordMappingFilter(**request.data_filter)
                    )
                )
            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
        
            create_requests = []
            partitions = [_data.mapping_id for _data in _response_data.filtered_data]

            batch_count = math.ceil(len(partitions) / SETTINGS.EXPT.BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(partitions), SETTINGS.EXPT.BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                
                job_config = DBMigrationExportRequest(
                        **request.__dict__
                    )
                if not job_config.data_filter.get("string_filter"):
                    job_config.data_filter["string_filter"] = KeywordMappingStringFilter(mapping_id_filter=partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]).__dict__
                else:
                    job_config.data_filter["string_filter"]["mapping_id_filter"] = partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]

                job = JobCreate(
                    knowledge_id = "Partitioned",
                    job_type     = JOB_DB_MIGRATION_EXPORT_PIPEILNE,
                    job_stage    = JOB_PENDING,
                    job_pipeline = "migrate_db_export",
                    job_config   = job_config.dict()
                )
                create_requests.append(JobCreateRequest(data=job))

        if request.migration_type.lower() == "knowledge":
            try:
                response_db_data = system_query_knowledge(
                    request = SystemKnowledgeRequest(
                        data_filter=KnowledgeFilter(**request.data_filter)
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
            
            create_requests = []
            partitions = [_data.knowledge_id for _data in response_db_data.filtered_data]
                
            batch_count = math.ceil(len(partitions) / SETTINGS.EXPT.BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(partitions), SETTINGS.EXPT.BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                
                job_config = DBMigrationExportRequest(
                        **request.__dict__
                    )
                if not job_config.data_filter.get("string_filter"):
                    job_config.data_filter["string_filter"] = KnowledgeStringFilter(knowledge_id_filter=partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]).__dict__
                else:
                    job_config.data_filter["string_filter"]["knowledge_id_filter"] = partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]

                job = JobCreate(
                    knowledge_id = "Partitioned",
                    job_type     = JOB_DB_MIGRATION_EXPORT_PIPEILNE,
                    job_stage    = JOB_PENDING,
                    job_pipeline = "migrate_db_export",
                    job_config   = job_config.dict()
                )

                create_requests.append(JobCreateRequest(data=job))

        elif request.migration_type.lower() == "metadata":
            try:
                response_db_data = system_query_metadata(
                    request = SystemMetadataRequest(
                        data_filter=MetadataFilter(**request.data_filter)
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
            
            create_requests = []
            partitions = [_data.file_id for _data in response_db_data.filtered_data]
                
            batch_count = math.ceil(len(partitions) / SETTINGS.EXPT.BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(partitions), SETTINGS.EXPT.BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                
                job_config = DBMigrationExportRequest(
                        **request.__dict__
                    )
                if not job_config.data_filter.get("string_filter"):
                    job_config.data_filter["string_filter"] = MetadataStringFilter(file_id_filter=partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]).__dict__
                else:
                    job_config.data_filter["string_filter"]["file_id_filter"] = partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]

                job = JobCreate(
                    knowledge_id = "Partitioned",
                    job_type     = JOB_DB_MIGRATION_EXPORT_PIPEILNE,
                    job_stage    = JOB_PENDING,
                    job_pipeline = "migrate_db_export",
                    job_config   = job_config.dict()
                )

                create_requests.append(JobCreateRequest(data=job))

        elif request.migration_type.lower() == "seed_qna":
            try:
                response_db_data = system_query_seedqna(
                    request = SystemSeedQnARequest(
                        data_filter=SeedQnAFilter(**request.data_filter)
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
            
            create_requests = []
            partitions = [_data.seed_qna_id for _data in response_db_data.filtered_data]
                
            batch_count = math.ceil(len(partitions) / SETTINGS.EXPT.BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(partitions), SETTINGS.EXPT.BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                
                job_config = DBMigrationExportRequest(
                        **request.__dict__
                    )
                if not job_config.data_filter.get("string_filter"):
                    job_config.data_filter["string_filter"] = SeedQnAStringFilter(seed_qna_id_filter=partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]).__dict__
                else:
                    job_config.data_filter["string_filter"]["seed_qna_id_filter"] = partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]

                job = JobCreate(
                    knowledge_id = "Partitioned",
                    job_type     = JOB_DB_MIGRATION_EXPORT_PIPEILNE,
                    job_stage    = JOB_PENDING,
                    job_pipeline = "migrate_db_export",
                    job_config   = job_config.dict()
                )

                create_requests.append(JobCreateRequest(data=job))

        elif request.migration_type.lower() == "qna":
            try:
                response_db_data = system_query_qna(
                    request = SystemQnARequest(
                        data_filter=QnAFilter(**request.data_filter)
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
            
            create_requests = []
            partitions = [_data.qna_id for _data in response_db_data.filtered_data]
                
            batch_count = math.ceil(len(partitions) / SETTINGS.EXPT.BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(partitions), SETTINGS.EXPT.BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                
                job_config = DBMigrationExportRequest(
                        **request.__dict__
                    )

                if not job_config.data_filter.get("string_filter"):
                    job_config.data_filter["string_filter"] = QnAStringFilter(qna_id_filter=partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]).__dict__
                else:
                    job_config.data_filter["string_filter"]["qna_id_filter"] = partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]

                job = JobCreate(
                    knowledge_id = "Partitioned",
                    job_type     = JOB_DB_MIGRATION_EXPORT_PIPEILNE,
                    job_stage    = JOB_PENDING,
                    job_pipeline = "migrate_db_export",
                    job_config   = job_config.dict()
                )

                create_requests.append(JobCreateRequest(data=job))

        elif request.migration_type.lower() == "evaluation":
            try:
                response_db_data = system_query_evaluation(
                    request = SystemEvaluationRequest(
                        data_filter=EvaluationFilter(**request.data_filter)
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
            
            create_requests = []
            partitions = [_data.evaluation_id for _data in response_db_data.filtered_data]
                
            batch_count = math.ceil(len(partitions) / SETTINGS.EXPT.BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(partitions), SETTINGS.EXPT.BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                
                job_config = DBMigrationExportRequest(
                        **request.__dict__
                    )
                
                if not job_config.data_filter.get("string_filter"):
                    job_config.data_filter["string_filter"] = EvaluationStringFilter(evaluation_id_filter=partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]).__dict__
                else:
                    job_config.data_filter["string_filter"]["evaluation_id_filter"] = partitions[i:i+SETTINGS.EXPT.BATCH_SIZE]

                job = JobCreate(
                    knowledge_id = "Partitioned",
                    job_type     = JOB_DB_MIGRATION_EXPORT_PIPEILNE,
                    job_stage    = JOB_PENDING,
                    job_pipeline = "migrate_db_export",
                    job_config   = job_config.dict()
                )

                create_requests.append(JobCreateRequest(data=job))

        if not create_requests:
            response = Response(status_code=200, detail=JobManager.response_format.ok("No Matched Conditions for Job Creation"))

        try:
            batch_count = math.ceil(len(create_requests) / SETTINGS.JOB.JOB_CREATE_BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(create_requests), SETTINGS.JOB.JOB_CREATE_BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                response = general_batch_create_job(request=JobBatchCreateRequest(create_requests=create_requests[i:i+SETTINGS.JOB.JOB_CREATE_BATCH_SIZE]))
                response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_VB_MIGRATION_EXPORT_PIPEILNE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created Batch <{batch_index} / {batch_count}> Jobs"))
                # await JobManager.event_trigger_job(job=job)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_VB_MIGRATION_EXPORT_PIPEILNE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs for Batch <{batch_index} / {batch_count}>", str(e)))
            logger.error(response.detail)

        return response_data, response


    @staticmethod
    def create_vb_migration_export_job(request: VBMigrationExportRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_VB_MIGRATION_EXPORT_PIPEILNE} Pipeline Request")

        response_data = PipelineResponse()

        if request.method.upper() == "DB":
            migrate_vb_init(request=VBInitMigrationRequest(table_name=request.vb_config.table_name))
        else:
            payload = VBInitMigrationRequest(**request.vb_config.__dict__).json()            
            api_url = f"{SETTINGS.VTEX.EXPORT_URL}/{SETTINGS.VTEX.EXPORT_INIT_API}"
            try:
                resp = httpx.post(api_url, data=payload, verify=SETTINGS.BASE.APP_PRODUCTION, timeout=SETTINGS.BASE.APP_TIMEOUT)
                resp.raise_for_status()
            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Init Index for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
            
        logger.info("Success : Init Migration VB Index")     
        time.sleep(SETTINGS.VTEX.INIT_TABLE_SEC)

        if not request.vector_filter.string_filter or not request.vector_filter.string_filter.knowledge_id_filter:
            try:
                response_parititon = system_partition_vector(
                    request = PartitionRequest(
                        vector_filter = request.vector_filter,
                        field_name    = "knowledge_id"
                    )
                )
                partitions = response_parititon.partitions
                
            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export"))
                logger.error(response.detail)
                return response_data, response
        
        else:
            partitions = request.vector_filter.string_filter.knowledge_id_filter

        if not partitions:
            response = Response(status_code=404, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Found Empty Partitions for Export"))
            logger.error(response.detail)
            return response_data, response
        
        logger.info(f"Retrieve knowledge id for vector count: {len(partitions)}")

        # Retrieve all existing knowledge id from mongo
        try:
            response_knowledge = system_query_knowledge(
                request = SystemKnowledgeRequest(
                    data_filter=KnowledgeFilter(
                        numeric_filter=KnowledgeNumericFilter(
                            knowledge_status_min=0
                        )
                    )
                )
            )

            existing_knowledge_ids = [data.knowledge_id for data in response_knowledge.filtered_data]
            logger.info(f"Retrieve unique knowledge id count: {len(existing_knowledge_ids)}")

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", e))
            logger.error(response.detail)
            return response
        
        no_knowledge_ids = [know_id for know_id in existing_knowledge_ids if know_id not in partitions]
        if len(no_knowledge_ids) > 0:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> <{len(no_knowledge_ids)}> Found Partitions Do not Match Knowledge Table: <{SETTINGS.DATB.REGISTRY_TABLE}>"))
            logger.error(response.detail)
            return response
        
        create_requests = []
        for partition in existing_knowledge_ids:
            job_config = VBMigrationExportRequest(
                **request.__dict__
            )
            if not job_config.vector_filter.string_filter:
                job_config.vector_filter.__dict__.update(
                    **{
                        "string_filter": VectorStringFilter(knowledge_id_filter=[partition])
                    }
                )
            else:
                job_config.vector_filter.string_filter.knowledge_id_filter = [partition]

            job = JobCreate(
                knowledge_id = partition,
                job_type     = JOB_VB_MIGRATION_EXPORT_PIPEILNE,
                job_stage    = JOB_PENDING,
                job_pipeline = "migrate_vb_export",
                job_config   = job_config.dict()
            )

            create_request = JobCreateRequest(data=job)
            create_requests.append(create_request)

        try:
            batch_count = math.ceil(len(create_requests) / SETTINGS.JOB.JOB_CREATE_BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(create_requests), SETTINGS.JOB.JOB_CREATE_BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                response = general_batch_create_job(request=JobBatchCreateRequest(create_requests=create_requests[i:i+SETTINGS.JOB.JOB_CREATE_BATCH_SIZE]))
                response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_VB_MIGRATION_EXPORT_PIPEILNE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created Batch <{batch_index} / {batch_count}> Jobs"))
                # await JobManager.event_trigger_job(job=job)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_VB_MIGRATION_EXPORT_PIPEILNE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs for Batch <{batch_index} / {batch_count}>", str(e)))
            logger.error(response.detail)

        return response_data, response

    @staticmethod
    async def create_blob_migration_export_job(request: BlobMigrationExportRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_BLOB_MIGRATION_EXPORT_PIPEILNE} Pipeline Request")

        response_data = PipelineResponse()

        if request.migration_type.lower() == "knowledge":
            if not request.vector_filter.string_filter or not request.vector_filter.string_filter.knowledge_id_filter:
                try:
                    response_parititon = system_partition_vector(
                        request = PartitionRequest(
                            vector_filter = request.vector_filter,
                            field_name    = "knowledge_id"
                        )
                    )
                    partitions = response_parititon.partitions
                    
                except Exception as e:
                    response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export"))
                    logger.error(response.detail)
                    return response_data, response
            
            else:
                partitions = request.vector_filter.string_filter.knowledge_id_filter

            if not partitions:
                response = Response(status_code=404, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Found Empty Partitions for Export"))
                logger.error(response.detail)
                return response_data, response
            
            create_requests = []
            for partition in partitions:
                job_config = BlobMigrationExportRequest(
                    **request.__dict__
                )
                if not job_config.vector_filter.string_filter:
                    job_config.vector_filter.__dict__.update(
                        **{
                            "string_filter": VectorStringFilter(knowledge_id_filter=[partition])
                        }
                    )
                else:
                    job_config.vector_filter.string_filter.knowledge_id_filter = [partition]

                
                if not job_config.data_filter.get("string_filter"):
                    job_config.data_filter["string_filter"] = KnowledgeStringFilter(knowledge_id_filter=[partition]).__dict__
                else:
                    job_config.data_filter["string_filter"]["knowledge_id_filter"] = [partition]

                job = JobCreate(
                    knowledge_id = partition,
                    job_type     = JOB_BLOB_MIGRATION_EXPORT_PIPEILNE,
                    job_stage    = JOB_PENDING,
                    job_pipeline = "migrate_blob_export",
                    job_config   = job_config.dict()
                )

                create_request = JobCreateRequest(data=job)
                create_requests.append(create_request)

        elif request.migration_type.lower() == "metadata":
            try:
                response_db_data = system_query_metadata(
                    request = SystemMetadataRequest(
                        data_filter=MetadataFilter(**request.data_filter)
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Find Partitions for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
            
            create_requests = []
            partitions = [_data.file_id for _data in response_db_data.filtered_data]
            
            for partition in partitions:
                job_config = BlobMigrationExportRequest(
                    **request.__dict__
                )
                    
                if not job_config.data_filter.get("string_filter"):
                    job_config.data_filter["string_filter"] = MetadataStringFilter(file_id_filter=[partition]).__dict__
                else:
                    job_config.data_filter["string_filter"]["file_id_filter"] = [partition]
                
                job = JobCreate(
                    knowledge_id = "Partitioned",
                    job_type     = JOB_BLOB_MIGRATION_EXPORT_PIPEILNE,
                    job_stage    = JOB_PENDING,
                    job_pipeline = "migrate_blob_export",
                    job_config   = job_config.dict()
                )

                create_request = JobCreateRequest(data=job)
                create_requests.append(create_request)
            
        try:
            batch_count = math.ceil(len(create_requests) / SETTINGS.JOB.JOB_CREATE_BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(create_requests), SETTINGS.JOB.JOB_CREATE_BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                response = general_batch_create_job(request=JobBatchCreateRequest(create_requests=create_requests[i:i+SETTINGS.JOB.JOB_CREATE_BATCH_SIZE]))
                response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_BLOB_MIGRATION_EXPORT_PIPEILNE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(create_requests)}> Jobs"))

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_BLOB_MIGRATION_EXPORT_PIPEILNE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs for Batch <{batch_index} / {len(create_requests)}>", str(e)))
            logger.error(response.detail)

        return response_data, response

    @staticmethod
    def create_gb_migration_export_job(request: GBMigrationExportRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_GB_MIGRATION_EXPORT_PIPEILNE} Pipeline Request")

        response_data = PipelineResponse()

        if request.method.upper() == "DB":
            migrate_gb_init(request=GBConfig(**request.db_config.__dict__))
        else:
            payload = GBConfig(**request.db_config.__dict__).json()            
            api_url = f"{SETTINGS.GPEX.EXPORT_URL}/{SETTINGS.GPEX.EXPORT_INIT_API}"
            try:
                resp = httpx.post(api_url, data=payload, timeout=SETTINGS.BASE.APP_TIMEOUT)
                resp.raise_for_status()
            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Init GB for Export", str(e)))
                logger.error(response.detail)
                return response_data, response
        
        logger.info("Success : Init Migration GB")

        try:
            if request.knowledge_id:
                response_knowledge = system_query_knowledge(
                    SystemKnowledgeRequest(
                        data_filter = KnowledgeFilter(
                            string_filter = KnowledgeStringFilter(
                                knowledge_id_filter=[request.knowledge_id],
                                knowledge_graphstorage_filter=[SETTINGS.GPDB.FORM]
                            ),
                            numeric_filter = KnowledgeNumericFilter(
                                knowledge_status_min=1
                            ),
                            sorting = {"created_at": "asc"}
                        )
                    )
                )

            else:
                response_knowledge = system_query_knowledge(
                    SystemKnowledgeRequest(
                        data_filter = KnowledgeFilter(
                            string_filter = KnowledgeStringFilter(
                                knowledge_graphstorage_filter=[SETTINGS.GPDB.FORM]
                            ),
                            numeric_filter = KnowledgeNumericFilter(
                                knowledge_status_min=1
                            ),
                            sorting = {"created_at": "asc"}
                        )
                    )
                )

            knowledges = [knowledge for knowledge in response_knowledge.filtered_data if knowledge.knowledge_graphinfo.get("container", "") != "cms-dev"]

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_GB_MIGRATION_EXPORT_PIPEILNE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Query Knowledge", str(e)))
            logger.error(response.detail)
            return response_data, response  
        
        if not knowledges:
            response = Response(status_code=200, detail=JobManager.response_format.ok(f"{JOB_GB_MIGRATION_EXPORT_PIPEILNE} Pipeline Completed : <{SETTINGS.BASE.APP_NAME}> Does Not Find Matched Graph for Export"))
            logger.info(response.detail)
            return response_data, response

        create_requests = []
        for knowledge in knowledges:
            if not knowledge.knowledge_graphinfo.get("container", None):
                continue
            
            job_config = GBMigrationExportRequest(
                **request.__dict__
            )
            
            if not job_config.container_name:
                container_name = SETTINGS.GPDB.CONTAINER
                job_config.__dict__.update(
                    **{
                        "container_name": container_name
                    }
                )

            job_config.knowledge_id = knowledge.knowledge_id

            job = JobCreate(
                knowledge_id = knowledge.knowledge_id,
                job_type     = JOB_GB_MIGRATION_EXPORT_PIPEILNE,
                job_stage    = JOB_PENDING,
                job_pipeline = "migrate_gb_export",
                job_config   = job_config.dict()
            )

            create_request = JobCreateRequest(data=job)
            create_requests.append(create_request)

        try:
            batch_count = math.ceil(len(create_requests) / SETTINGS.JOB.JOB_CREATE_BATCH_SIZE)
            for batch_index, i in enumerate(range(0, len(create_requests), SETTINGS.JOB.JOB_CREATE_BATCH_SIZE), start=1):
                logger.info(f"Creating Job for Batch <{batch_index} / {batch_count}>")            
                response = general_batch_create_job(request=JobBatchCreateRequest(create_requests=create_requests[i:i+SETTINGS.JOB.JOB_CREATE_BATCH_SIZE]))
                response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_VB_MIGRATION_EXPORT_PIPEILNE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(create_requests)}> Jobs"))
                # await JobManager.event_trigger_job(job=job)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_VB_MIGRATION_EXPORT_PIPEILNE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs for Batch <{batch_index} / {len(create_requests)}>", str(e)))
            logger.error(response.detail)

        return response_data, response


    @staticmethod
    def auto_relationship_job(request: KnowledgeRelationshipRequest) -> tuple[PipelineResponse, Response]:
        logger.info(f"Processing : Received {JOB_RELATIONSHIP_PIPELINE} Pipeline Request")

        response_data = PipelineResponse()

        # Query Knowledge
        try:
            response_knowledge = system_query_knowledge(
                SystemKnowledgeRequest(
                    data_filter = KnowledgeFilter(
                        string_filter = KnowledgeStringFilter(
                            knowledge_graphstorage_filter=[""]
                        ),
                        numeric_filter = KnowledgeNumericFilter(
                            knowledge_status_min=1
                        ),
                        sorting = {"knowledge_id": "asc"}
                    )
                )
            )
            sorted_knowledges = sorted(response_knowledge.filtered_data, key=lambda x: x.knowledge_vectorinfo["entity_num"])
            pending_knowledge_ids = [knowledge.knowledge_id for knowledge in sorted_knowledges]

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Auto {JOB_RELATIONSHIP_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Query Knowledge", str(e)))
            logger.error(response.detail)
            return response_data, response
            
        create_requests = JobBatchCreateRequest(
            create_requests = [
                JobCreateRequest(
                    data = JobCreate(
                        knowledge_id = knowledge_id,
                        job_type     = JOB_RELATIONSHIP_PIPELINE,
                        job_stage    = JOB_PENDING,
                        job_pipeline = "request_knowledge_extract_relationship",
                        job_config   = KnowledgeRelationshipRequest(knowledge_ids=[knowledge_id]).__dict__
                    )
                )
                for knowledge_id in pending_knowledge_ids
            ]
        )

        try:
            response = general_batch_create_job(request=create_requests)
            response = Response(status_code=201, detail=JobManager.response_format.ok(f"{JOB_RELATIONSHIP_PIPELINE} Pipeline Created : <{SETTINGS.BASE.APP_NAME}> Created <{len(request.knowledge_ids)}> Jobs"))
            response_data.pipeline_info = [request.data for request in create_requests.create_requests]
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"{JOB_RELATIONSHIP_PIPELINE} Pipeline Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
            logger.error(response.detail)

        return response_data, response

    @staticmethod
    async def time_trigger_job(
        job_type: str='ALL'
    ):
        logger.info(f"Exploring Pending and Processing <{job_type}> Jobs")
        processing_data_request = SystemJobRequest(
            data_filter = JobFilter(
                string_filter = JobStringFilter(
                    job_stage_filter = [JOB_PROCESSING]
                ),
                numeric_filter = JobNumericFilter(
                    job_status_min = 1
                ),
                boolean_filter = JobBooleanFilter(
                    job_complete_filter = False
                ),
                sorting={"created_at": "desc"},
                filter_no=SETTINGS.JOB.PIPELINE_JOB_LIMIT
            )
        )
        
        pending_data_request = SystemJobRequest(
            data_filter = JobFilter(
                string_filter = JobStringFilter(
                    job_stage_filter = [JOB_PENDING]
                ),
                numeric_filter = JobNumericFilter(
                    job_status_min = 1
                ),
                boolean_filter = JobBooleanFilter(
                    job_complete_filter = False
                ),
                sorting={"created_at": "desc"},
                filter_no=SETTINGS.JOB.PIPELINE_JOB_LIMIT
            )
        )

        if not job_type.upper() == 'ALL':
            processing_data_request.data_filter.string_filter.job_type_filter = [job_type]
            pending_data_request.data_filter.string_filter.job_type_filter = [job_type]
        
        try:
            response_processing_data = system_query_job(request=processing_data_request)
            response_pending_data    = system_query_job(request=pending_data_request)
            logger.info(f"Found <{len(response_processing_data.filtered_data)}> Processing Jobs and <{len(response_pending_data.filtered_data)}> Pending Jobs")

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Query Jobs", str(e)))
            logger.error(response.detail)
            raise Exception(response.detail)

        job_capacity = SETTINGS.JOB.PIPELINE_JOB_LIMIT - response_processing_data.data_count
        if response_pending_data.data_count > 0 and job_capacity <= 0:
            logger.info(f"Reached Maximum Pipeline Job Capacity : <{response_pending_data.data_count}> Pending Jobs on Hold")

        else:
            if response_pending_data.filtered_data:
                try:
                    pending_data = response_pending_data.filtered_data[:job_capacity]
                    
                    tasks = []
                    for job in pending_data:
                        await JobManager._update_job_status(
                            job.job_id, 
                            PipelineStatus(
                                job_stage = JOB_PROCESSING,
                                processed_at = datetime.now(timezone.utc)
                            )
                        )

                        pipeline_setup = pipeline_mapper.get(job.job_pipeline, None)
                        if not pipeline_setup:
                            response = Response(status_code=404, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Map Pipeline Setup"))
                            logger.error(response.detail)
                            await JobManager._update_job_status(
                                job.job_id, 
                                PipelineStatus(
                                    job_complete = True,
                                    job_success  = False,
                                    job_stage    = JOB_FAIL,
                                    job_reason   = response.detail,
                                    completed_at = datetime.now(timezone.utc)
                                )
                            )
                        
                        else:
                            task = JobManager._run_job(
                                    job.job_id, 
                                    job.job_type,
                                    pipeline_setup.get("pipeline"),
                                    pipeline_setup.get("class")(**job.job_config)
                                )
                            tasks.append(task)
                    
                    if tasks:
                        logger.info(f"Triggered <{len(pending_data)}> {job_type} Jobs")
                        await asyncio.gather(*tasks)
                    # await asyncio.sleep(SETTINGS.JOB.EVALUATION_SCAN_JOB_SEC)

                except Exception as e:
                    response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
                    logger.error(response.detail)

    @staticmethod
    async def event_trigger_job(
        job: JobCreate
    ):
        logger.info(f"Exploring Processing {job.job_type} Jobs")
        processing_data_request = SystemJobRequest(
            data_filter = JobFilter(
                string_filter = JobStringFilter(
                    job_stage_filter = [JOB_PROCESSING],
                    job_type_filter  = [job.job_type]
                ),
                numeric_filter = JobNumericFilter(
                    job_status_min = 1
                ),
                boolean_filter = JobBooleanFilter(
                    job_complete_filter = False
                ),
                sorting={"created_at": "desc"}
            )
        )

        try:
            response_processing_data = system_query_job(request=processing_data_request)
            logger.info(f"Found <{len(response_processing_data.filtered_data)}> Processing Jobs")

        except Exception as e:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Query Jobs", str(e)))
            logger.error(response.detail)
            raise Exception(response.detail)

        job_capacity = SETTINGS.JOB.PIPELINE_JOB_LIMIT - response_processing_data.data_count
        if job_capacity <= 0:
            response = Response(status_code=500, detail=JobManager.response_format.error(f"Failed to Create Job : Reached Maximum <{job.job_type}> Pipeline Job Capacity"))
            logger.error(response.detail)
            raise Exception(response.detail)

        else:
            try:
                await JobManager._update_job_status(
                    job.job_id, 
                    PipelineStatus(
                        job_stage = JOB_PROCESSING,
                        processed_at = datetime.now(timezone.utc)
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Update Job Stage", str(e)))
                logger.error(response.detail)
                raise Exception(response.detail)

            try:
                pipeline_setup = pipeline_mapper.get(job.job_pipeline, None)
                if not pipeline_setup:
                    response = Response(status_code=404, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Cannot Map Pipeline Setup"))
                    logger.error(response.detail)
                    await JobManager._update_job_status(
                        job.job_id, 
                        PipelineStatus(
                            job_complete = True,
                            job_success  = False,
                            job_stage    = JOB_FAIL,
                            job_reason   = response.detail,
                            completed_at = datetime.now(timezone.utc)
                        )
                    )

                else:
                    # start async job processing
                    asyncio.get_running_loop().create_task(
                        JobManager._run_job(
                            job.job_id, 
                            job.job_type,
                            pipeline_setup.get("pipeline"),
                            pipeline_setup.get("class")(**job.job_config)
                        )
                    )                    

                    logger.info(f"Event-Triggered <{job.job_type}> Job <job_id: {job.job_id}>")

            except Exception as e:
                response = Response(status_code=500, detail=JobManager.response_format.error(f"Job Triggering Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Create Jobs", str(e)))
                logger.error(response.detail)
                raise Exception(response.detail)

    @staticmethod
    async def _run_job(
            job_id:   str, 
            job_type: str,
            pipeline: Any,
            request:  Any
        ):

        try:
            if job_type.upper() != "BLOB_MIGRATION_EXPORT":
                response_pipeline = await asyncio.get_running_loop().run_in_executor(
                    None, pipeline, request
                )
            else:
                response_pipeline = await pipeline(request)

            job_info = PipelineStatus(
                job_complete = True,
                job_success  = True,
                job_stage    = JOB_SUCCESS,
                job_reason   = f"Completed with Success",
                completed_at = datetime.now(timezone.utc)
            )

            await JobManager._update_job_status(job_id, job_info)
            logger.info(f"Completed : Job <{job_id}>")
        
        except Exception as e:
            job_info = PipelineStatus(
                job_complete = True,
                job_success  = False,
                job_stage    = JOB_FAIL,
                job_reason   = str(e),
                completed_at = datetime.now(timezone.utc)
            )
            await JobManager._update_job_status(job_id, job_info)
            logger.error(f"Failed : Job <{job_id}> - {str(e)}")

    @staticmethod
    async def _update_job_status(job_id: str, job_info: PipelineStatus):

        """Update job status in MongoDB"""
        try:
            response = general_update_job(
                request = JobUpdateRequest(
                    job_id = job_id,
                    update_data = JobUpdate(
                        **job_info.__dict__
                    ),
                    overwrite=True
                )
            )
            logger.info(f"Updated Job Status <job_id: {job_id}>")
        
        except Exception as e:
            logger.error(f"Failed to Update Job Status <job_id: {job_id}> due to {str(e)}")
            raise e
    
    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
            response_data = None

            try:
                if method.lower() == "post":

                    if isinstance(data, str):
                        if timeout:
                            resp = httpx.post(api_url, data=data, timeout=timeout)
                        else:
                            resp = httpx.post(api_url, data=data)

                    else:
                        if timeout:
                            resp = httpx.post(api_url, json=data, timeout=timeout)
                        else:
                            resp = httpx.post(api_url, json=data)

                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                    logger.error(response.detail)
                    return response_data, response

                if not resp.status_code == httpx.codes.ok:
                    response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                    logger.error(response.detail)
                
                else:
                    response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                    response_data = resp

            except httpx.TimeoutException as e:
                response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
                logger.error(response.detail)

            except httpx.HTTPError as e:
                response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
                logger.error(response.detail)

            # Handle common exceptions that might occur
            except (BaseException, Exception) as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
                logger.error(response.detail)

            # Handle any other exceptions that might occur
            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
                logger.error(response.detail)

            return response_data, response