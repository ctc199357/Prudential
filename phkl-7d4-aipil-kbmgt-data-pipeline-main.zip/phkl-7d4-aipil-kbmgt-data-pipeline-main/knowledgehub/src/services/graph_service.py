import os
from typing import Callable, Any
from datetime import datetime, timezone
import uuid
import inspect

import asyncio
import sys

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from azure.cosmos import CosmosClient, DatabaseProxy, ContainerProxy, PartitionKey
import azure.cosmos.exceptions as exceptions
# from gremlin_python.structure.graph import Graph
# from gremlin_python.driver.driver_remote_connection import DriverRemoteConnection
from gremlin_python.driver import client, serializer
from gremlin_python.structure.graph import Graph
from gremlin_python.driver.driver_remote_connection import DriverRemoteConnection

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..database.graph.connections.graph_connection import (
    get_gb_func,
    get_gb_api,
    create_gb_client
)

from ..routers.graph.general import (
    GraphCreateRequest,
    GraphRequest,
    GraphUpdateRequest,
    general_create_graph,
    general_delete_graph,
    general_drop_graph,
    general_condition_drop_graph
)

from ..routers.graph.system import (
    SystemGraphRequest,
    SystemGraphResponse,
    system_query_graph,
    system_drop_graph_container
)

from ..schemas.graph import (
    KnowledgeGraphCreateRequest,
    KnowledgeGraphCreateResponse,
    KnowledgeGraphUpdateRequest,
    KnowledgeGraphCreateResponse,
    KnowledgeGraphRequest,
    KnowledgeGraphReadResponse,
    KnowledgeGraphUpdateResponse,
    GraphFilter,
    NodeStringFilter,
    EdgeStringFilter,
    NodeFilter,
    EdgeFilter,
    NodeNumericFilter,
    EdgeNumericFilter,
    KnowledgeGraphDBInfo
)

from ..schemas.knowledge import (
    SystemKnowledgeRequest,
    KnowledgeFilter,
    KnowledgeStringFilter,
    KnowledgeUpdate,
    KnowledgeUpdateRequest
)

from ..routers.registry.general import (
    general_update_knowledge
)

from ..routers.registry.system import (
    system_query_knowledge
)

# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


from ..logger.log_handler import get_logger

logger = get_logger(__name__)


def date_to_str(date: datetime):
    return date.isoformat()

class GraphServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(
            self, 
            api_call:       bool = default_api_call,
            graph_storage:  str='COSMOS', 
            graph_location: str='azure', 
            graph_config:   dict={},
        ):
        self.api_call    = api_call
        self.graph_storage  = graph_storage
        self.graph_location = graph_location
        self.graph_config   = graph_config

    """
        General Operation
    """
    def partition_formatter(self, name: str) -> str:
        formated_name = name.replace(' ', '_')
        formated_name = formated_name.replace('.', '_')
        return f'{SETTINGS.GPDB.CONTAINER_PREFIX}{formated_name}'
    

    """
        Knowledge-level General Operations
    """
    # Knowledge Create
    def create_knowledge(self, request: KnowledgeGraphCreateRequest) -> tuple[KnowledgeGraphCreateResponse, Response]:

        response_data = KnowledgeGraphCreateResponse()
        
        if not request.create_request.container_name:
            request.create_request.container_name = self.partition_formatter(request.create_request.data.nodes[0].knowledge_id)

        response = Response(status_code=500, detail="Failed to Register on Azure Graph DB")

        try:
            response = general_create_graph(request=request.create_request, api_call=self.api_call)
            response = Response(status_code=201, detail=self.response_format.ok(f"Success : Registered Graph Data"))
            logger.info(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Registering Graph", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Registering Graph"))
            logger.error(response.detail)
        
        if response.status_code <= SETTINGS.STAT.SUCC_CODE_END:
            knowledge_graphinfo={
                "db_name":   SETTINGS.GPDB.NAME, 
                "container": request.create_request.container_name
            }

            response_data = KnowledgeGraphCreateResponse(
                knowledge_graphstorage  = self.gb_storage,
                knowledge_graphlocation = self.gb_location,
                knowledge_graphinfo     = knowledge_graphinfo
            )

            update_request = KnowledgeUpdateRequest(
                knowledge_id = request.create_request.knowledge_id,
                update_data  = KnowledgeUpdate(
                    **response_data.__dict__
                ),
                overwrite=True
            )
            try:
                response = general_update_knowledge(request=update_request, api_call=self.api_call)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Failed to Update Knowledge After Graph Generation : <{SETTINGS.BASE.APP_NAME}> Failed to Update Knowledge DB After Graph Create"))

        return response_data, response

    def read_knowledge(self, request: KnowledgeGraphRequest) -> tuple[KnowledgeGraphReadResponse, Response]:
        response_data = KnowledgeGraphReadResponse(**request.__dict__)

        response_gb_info, response = self.get_knowledge_gb_info(knowledge_id=request.knowledge_id)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response


        graph_request = SystemGraphRequest(**request.__dict__)
        graph_request.container_name = response_gb_info.knowledge_graphinfo.get("container", self.partition_formatter(request.knowledge_id))

        graph_request.data_filter = GraphFilter(
            node_filter=NodeFilter(
                string_filter=NodeStringFilter(knowledge_id_filter=[request.knowledge_id])
            ),
            edge_filter=EdgeFilter(
                string_filter=EdgeStringFilter(knowledge_id_filter=[request.knowledge_id])
            ),
            partition_keys=[request.knowledge_id]
        )

        try:
            response_graph = system_query_graph(request=graph_request, api_call=self.api_call)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Reading Knowledge Error : Failed to Query Graph Data", str(e)))
            logger.error(response.detail)
            return response_data, response
        
        response_data = KnowledgeGraphReadResponse(
            **request.__dict__,
            **response_graph.__dict__
        )

        return response_data, response

    def update_knowledge(self, request: KnowledgeGraphUpdateRequest) -> tuple[KnowledgeGraphUpdateResponse, Response]:
        response_data = KnowledgeGraphUpdateResponse(**request.__dict__)
        response = Response(status_code=500, detail="Failed to Register on Azure Graph DB")

        # Remove Data
        if request.overwrite:
            drop_request = KnowledgeGraphRequest(**request.__dict__)
            response = self.drop_knowledge(drop_request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response_data, response
            
        # Create Data
        response_create, response = self.create_knowledge(create_request = request.update_request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response_data, response
        else:
            update_request = KnowledgeUpdateRequest(
                knowledge_id = request.create_request.knowledge_id,
                update_data  = KnowledgeUpdate(
                    **response_data.__dict__
                ),
                overwrite=True
            )
            try:
                response = general_update_knowledge(request=update_request, api_call=self.api_call)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Failed to Update Knowledge After Graph Generation : <{SETTINGS.BASE.APP_NAME}> Failed to Update Knowledge DB After Graph Create"))
                return response_data, response

            response_data.__dict__.update(**response_create.__dict__, updated_graph_count=1)

        response = Response(status_code=200, detail=self.response_format.ok(f"Success : Knowledge Graph <knowledge_id: {request.knowledge_id}> Updated"))
        logger.info(response.detail)
        return response_data, response


    def drop_knowledge(self, request: KnowledgeGraphRequest) -> Response:

        response_gb_info, response = self.get_knowledge_gb_info(knowledge_id=request.knowledge_id)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response
        
        container_name = response_gb_info.knowledge_graphinfo.get("container", self.partition_formatter(request.knowledge_id))

        try:
            response = general_condition_drop_graph(request=GraphUpdateRequest(
                partition_key=request.knowledge_id,
                container_name=container_name
            ))
        except Exception as e:
            response= Response(status_code=500, detail=self.response_format.error(f"Graph Drop Fail : <{SETTINGS.BASE.APP_NAME}> Failed to Drop Graph"))

        return response
    

    def get_knowledge_gb_info(self, knowledge_id: str) -> tuple[KnowledgeGraphDBInfo, Response]:
        response_data = KnowledgeGraphDBInfo()

        try:        
            response_knowledge = system_query_knowledge(
                request = SystemKnowledgeRequest(
                    data_filter = KnowledgeFilter(
                        string_filter = KnowledgeStringFilter(
                            knowledge_id_filter = [knowledge_id]
                        )
                    )
                ),
                api_call=self.api_call
            )
            if not response_knowledge.filtered_data:
                response = Response(status_code=404, detail=self.response_format.error(f"Reading Knowledge Error : Unfound Knowledge for Graph"))
                logger.error(response.detail)
                return response_data, response

            response_data = KnowledgeGraphDBInfo(
                **response_knowledge.filtered_data[0].__dict__
            )
            response = Response(status_code=200, detail=self.response_format.ok(f"Reading Knowledge Success : Found Graph Info"))

            if not response_data.knowledge_graphinfo.get("container", None):
                response = Response(status_code=404, detail=self.response_format.error(f"Reading Knowledge Error : Unfound Graph Info"))
                logger.error(response.detail)
                return response_data, response

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Reading Knowledge Error : Failed to Query Knowledge Data for Graph", str(e)))
            logger.error(response.detail)
            return response_data, response
        
        return response_data, response