
"""
    Knowledge Ingestion Stage
"""

PENDING_TO_INGEST = "Pending to Ingest"
INGESTING = "Ingesting"
INGESTED_FOR_REVIEW = "Ingested for Review"

"""
    Knowledge Processing Stage
"""

METADATA_REGISTERED = "Metadata Registered"
KNOWLEDGEINPUT_REGISTERED = "KnowledgeInput Registered"
PREPROCESSING_COMPLETED = "Preprocessing Completed"
VECTOR_REGISTERED = "Vector Registered"
GRAPH_REGISTERED = "Graph Registered"
INGEST_DONE = "Ingest Done"

from datetime import datetime, timezone
import time
import os
import shutil
import inspect
import httpx
import uuid
import pandas as pd
from pathlib import Path
import urllib.parse

from ..settings import SETTINGS

from ..utils import (
    upload_to_blob,
    download_from_blob_by_url,
    ensure_blob_url
)

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..database.registry.schemas.knowledge import (
    KnowledgeRequest,
    KnowledgeCreate,
    KnowledgeCreateRequest,
    KnowledgeBatchCreateRequest,
    KnowledgeUpdate,
    KnowledgeUpdateRequest,
    SystemKnowledgeRequest,
    KnowledgeFilter,
    KnowledgeNumericFilter,
    KnowledgeStringFilter
)

from ..schemas.knowledge import(
    KnowledgeIngestObject,
    KnowledgeIngestRequest,
    KnowledgeIngestResponse,
    KnowledgeIngestPipeline,
    KnowledgeAutoIngestRequest,
    KnowledgeUpdateIngestRequest,
    PilSyncRequest,
    PilSyncMetadataObject,
    PilSyncMetadataResult,
    PilSyncResponse
)

from ..database.metadata.schemas.metadata import (
    MetadataCreate,
    MetadataUpdate,
    SystemMetadataRequest,
    MetadataCreateRequest,
    MetadataUpdateRequest,
    MetadataDropRequest
)

from ..database.vector.schemas.vector import (
    VectorCreate,
    VectorCreateRequest
)

from ..schemas.vector import (
    KnowledgeVectorCreateRequest,
    KnowledgeVectorUpdateRequest,
    KnowledgeVectorRequest
)

from ..schemas.relationship import (
    KnowledgeRelationshipRequest
)

from ..schemas.graph import (
    KnowledgeGraphRequest
)

from ..schemas.utils import (
    KnowledgeInputCreate,
    KnowledgeInputIngestRequest,
    KnowledgeInputIngestObject,
    KnowledgeInputIngestResponse,
    KnowledgeInputRequest,
    PrepKnowPipelineRequest,
    PrepKnowPipelineResponse,
    PrepMediaPipelineRequest,
    PrepMediaPipelineResponse,
    PrepKnowInput
)

from ..routers.registry.general import (
    general_create_knowledge,
    general_update_knowledge,
    general_drop_knowledge,
    general_batch_create_knowledge
)

from ..routers.registry.system import (
    system_query_knowledge
)

from ..routers.metadata.general import (
    general_create_metadata,
    general_update_metadata,
    general_drop_metadata
)

from ..routers.metadata.system import (
    system_query_metadata
)

from ..routers.request_vector import (
    general_create_knowledge_vector,
    general_update_knowledge_vector,
    general_drop_knowledge_vector,
    general_read_knowledge_vector
)

from ..routers.request_graph import (
    request_knowledge_extract_relationship
)

from ..routers.graph.system import system_drop_graph_container

from ..services import (
    request_knowledgeinput_ingest, 
    request_knowledgeinput_drop,
    request_exec_prepknow, 
    request_exec_prepmedia, 
    init_knowledgeinput_temp_storage, 
    init_preprocessing_temp_storage
)

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class KnowledgeIngestManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool, pipeline: KnowledgeIngestPipeline | None = None):
        self.api_call = api_call
        self.pipeline = pipeline

    """
        Request Operation
    """
    def pil_sync_pipeline(self, request: PilSyncRequest) -> tuple[PilSyncResponse | None, Response]:
        response_pil_sync = PilSyncResponse(**request.__dict__)
        start_at = time.time()

        """ 1. Retrieve PIL csv from sharepoint """
        pil_csv_data, response = self.read_pil_metadata_from_file(metadata_file_url=request.pil_metadata_path)
        if not pil_csv_data or response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            if not pil_csv_data:
                response_pil_sync.pil_sync_status = f"Failed to Retrieve PIL csv: No PIL csv data is found"
            else:
                response_pil_sync.pil_sync_status = f"Failed to Retrieve PIL csv: {response.detail}"
            response = Response(status_code=500, detail=self.response_format.error(f"PIL Sync Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve PIL csv", response_pil_sync.pil_sync_status))
            logger.error(response.detail)
            response_pil_sync.__dict__.update(
                pil_sync_time = time.time() - start_at,
                pil_response_at = datetime.now(),
                pil_sync_status = response.detail
            )
            return response_pil_sync, response

        """ 2. Retrieve Metadata from Relational DB"""
        metadata_list, response = self.read_pil_metadata()
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            logger.error(response.detail)
            response_pil_sync.__dict__.update(
                pil_sync_time = time.time() - start_at,
                pil_response_at = datetime.now(),
                pil_sync_status = response.detail
            )
            return response_pil_sync, response

        """ 3. Classify Metadata on Relational DB based on PIL data """
        pil_csv_data_id_map = {}
        metadata_data_id_map = {}
        
        for data in pil_csv_data:
            _data = self.create_metadata_from_pil_csv(data)
            pil_csv_data_id = self.generate_metadata_id(_data.library_id, _data.category_id, _data.document_id, _data.file_nm)
            pil_csv_data_id_map[pil_csv_data_id] = _data
            # pil_csv_data_id_map[_data.file_id] = _data

        for metadata in metadata_list:
            metadata_data_id = self.generate_metadata_id(metadata.library_id, metadata.category_id, metadata.document_id, metadata.file_nm)
            metadata_data_id_map[metadata_data_id] = metadata
            # metadata_data_id_map[metadata.file_id] = metadata

        update_data = []
        delete_data = []
        for metadata_data_id, metadata in metadata_data_id_map.items():
            pil_csv_data = pil_csv_data_id_map.get(metadata_data_id, None)
            if pil_csv_data:
                if metadata.file_lastmodified_dt < pil_csv_data.file_lastmodified_dt:
                    update_data.append(pil_csv_data)
            else:
                delete_data.append(metadata)

        create_data = []
        for pil_csv_data_id, pil_csv_data in pil_csv_data_id_map.items():
            if pil_csv_data_id not in metadata_data_id_map.keys():
                create_data.append(pil_csv_data)
        
        """ 4. Update Metadata on Relational DB based on PIL data and execute update ingestion pipeline"""
        _knowledge_success_objects_update = []
        _knowledge_fail_objects_update = []
        sequence = 1
        for metadata in update_data:
            # Perserve previous metadata
            metadata_data_id = self.generate_metadata_id(metadata.library_id, metadata.category_id, metadata.document_id, metadata.file_nm)
            previous_metadata = metadata_data_id_map.get(metadata_data_id)
            # previous_metadata = metadata_data_id_map.get(metadata.file_id)

            # Update Metadata
            metadata_update_request = MetadataUpdateRequest(**request.__dict__, file_id=metadata.file_id, update_data=MetadataUpdate(**metadata.__dict__), overwrite=True)
            response = general_update_metadata(request=metadata_update_request, api_call=self.api_call)
            metadata_object = PilSyncMetadataObject(
                metadata_sequence=sequence, 
                metadata_code=response.status_code, 
                metadata_reason=response.detail,
                file_id=metadata.file_id,
                library_id=metadata.library_id, 
                category_id=metadata.category_id, 
                document_id=metadata.document_id, 
                file_name=metadata.file_nm, 
                file_sync_url_from=metadata.file_sync_url_from
            )

            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                _knowledge_fail_objects_update.append(metadata_object)
            else:
                # Update Knowledge
                knowledge = self.create_knowledge_from_metadata(metadata)
                request_update = KnowledgeUpdateIngestRequest(knowledge_updates=[KnowledgeUpdate(**knowledge.__dict__)], prepknow_id='test_prepknow_1')
                _, response = self.knowledge_update_ingest_pipeline(request=request_update)
                metadata_object.__dict__.update(metadata_code=response.status_code, metadata_reason=response.detail)

                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    response = Response(status_code=500, detail=self.response_format.error(f"PIL Sync Error : <{SETTINGS.BASE.APP_NAME}> Failed to Update Knowledge"))
                    logger.error(response.detail)
                    _knowledge_fail_objects_update.append(metadata_object)
                    # roll back metadata to previous_metadata
                    metadata_update_request = MetadataUpdateRequest(**request.__dict__, file_id=metadata.file_id, update_data=MetadataUpdate(**previous_metadata.__dict__))
                    response = general_update_metadata(request=metadata_update_request, api_call=self.api_call)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        response = Response(status_code=500, detail=self.response_format.error(f"PIL Sync Error : <{SETTINGS.BASE.APP_NAME}> Failed to Rollback Metadata"))
                        logger.error(response.detail)
                else:
                    _knowledge_success_objects_update.append(metadata_object)
            sequence += 1
    
        response_pil_sync.__dict__.update(
            pil_update_result = PilSyncMetadataResult(
                metadata_success_objects = _knowledge_success_objects_update,
                metadata_fail_objects = _knowledge_fail_objects_update,
                metadata_total_no = len(update_data),
                metadata_success_no = len(_knowledge_success_objects_update),
                metadata_fail_no = len(_knowledge_fail_objects_update)
            )
        )

        """ 5. Create or Drop Extra Metadata on Relational DB and execute auto ingestion pipeline"""
        _knowledge_success_objects_create = []
        _knowledge_fail_objects_create = []
        sequence = 1
        for metadata in create_data:
            metadata_create_request = MetadataCreateRequest(**request.__dict__, data=MetadataCreate(**metadata.__dict__))
            response = general_create_metadata(request=metadata_create_request, api_call=self.api_call)
            metadata_object = PilSyncMetadataObject(
                metadata_sequence=sequence, 
                metadata_code=response.status_code, 
                metadata_reason=response.detail, 
                file_id=metadata.file_id,
                library_id=metadata.library_id, 
                category_id=metadata.category_id, 
                document_id=metadata.document_id, 
                file_name=metadata.file_nm, 
                file_sync_url_from=metadata.file_sync_url_from
            )
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                response = Response(status_code=500, detail=self.response_format.error(f"PIL Sync Error : <{SETTINGS.BASE.APP_NAME}> Failed to Create Metadata"))
                logger.error(response.detail)
                _knowledge_fail_objects_create.append(metadata_object)
            else:
                _knowledge_success_objects_create.append(metadata_object)
            sequence += 1

        _knowledge_success_objects_delete = []
        _knowledge_fail_objects_delete = []
        sequence = 1
        for metadata in delete_data:
            metadata_drop_request = MetadataDropRequest(**request.__dict__, file_id=metadata.file_id)
            response = general_drop_metadata(request=metadata_drop_request, api_call=self.api_call)
            metadata_object = PilSyncMetadataObject(
                metadata_sequence=sequence, 
                metadata_code=response.status_code, 
                metadata_reason=response.detail, 
                file_id=metadata.file_id,
                library_id=metadata.library_id, 
                category_id=metadata.category_id, 
                document_id=metadata.document_id, 
                file_name=metadata.file_nm, 
                file_sync_url_from=metadata.file_sync_url_from
            )
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                response = Response(status_code=500, detail=self.response_format.error(f"PIL Sync Error : <{SETTINGS.BASE.APP_NAME}> Failed to Drop Metadata"))
                logger.error(response.detail)
                _knowledge_fail_objects_delete.append(metadata_object)
            else:
                _knowledge_success_objects_delete.append(metadata_object)
            sequence += 1
        
        _, response = self.knowledge_auto_ingest_pipeline(request=KnowledgeAutoIngestRequest(batch_size=0, prepknow_id='test_prepknow_1'))

        response_pil_sync.__dict__.update(
            pil_create_result = PilSyncMetadataResult(
                metadata_success_objects = _knowledge_success_objects_create,
                metadata_fail_objects = _knowledge_fail_objects_create,
                metadata_total_no = len(create_data),
                metadata_success_no = len(_knowledge_success_objects_create),
                metadata_fail_no = len(_knowledge_fail_objects_create)
            ),
            pil_delete_result = PilSyncMetadataResult(
                metadata_success_objects = _knowledge_success_objects_delete,
                metadata_fail_objects = _knowledge_fail_objects_delete,
                metadata_total_no = len(delete_data),
                metadata_success_no = len(_knowledge_success_objects_delete),
                metadata_fail_no = len(_knowledge_fail_objects_delete)
            )
        )

        """ 6. Update Final Response """
        if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
            response = Response(status_code=200, detail=self.response_format.ok(f"PIL Sync Success : <{SETTINGS.BASE.APP_NAME}> PIL Sync Success"))

        response_pil_sync.__dict__.update(
            pil_sync_time = time.time() - start_at,
            pil_response_at = datetime.now(),
            pil_sync_status = response.detail
        )

        return response_pil_sync, response

    def knowledge_update_ingest_pipeline(self, request: KnowledgeUpdateIngestRequest) -> tuple[KnowledgeIngestResponse | None, Response]:
        # if storage_directory_origin not exits, retrieve from metadata mongodb and update storage_directory_origin
        response_knowledge = KnowledgeIngestResponse(**request.__dict__)
        response_knowledge.__dict__.update(knowledgeinput_total_no=len(request.knowledge_updates))
        start_at = time.time()

        _knowledge_success_objects = []
        _knowledge_fail_objects    = []
        
        """ 1. Retrieve Knowledge by knowledge_id from Relational DB and Update Knowledge by storage_directory_origin """
        # First check if knowledge_id exists for all knowledge objects
        identifier = None
        if all(knowledge.library_id for knowledge in request.knowledge_updates) and all(knowledge.category_id for knowledge in request.knowledge_updates) and \
             all(knowledge.document_id for knowledge in request.knowledge_updates) and all(knowledge.file_name for knowledge in request.knowledge_updates):
            identifier = 'metadata_id'
        elif all(knowledge.knowledge_id for knowledge in request.knowledge_updates):
            identifier = 'knowledge_id'

        if identifier is None:
            response = Response(status_code=400, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Missing knowledge_id or library_id or category_id or document_id or file_name in knowledge_updates objects"))
            logger.error(response.detail)
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response

        """ 2. Retrieve Knowledge from Relational DB """
        system_query_knowledge_request = SystemKnowledgeRequest(data_filter=KnowledgeFilter(numeric_filter=KnowledgeNumericFilter(knowledge_status_min=0)))
        try:
            system_query_knowledge_response = system_query_knowledge(request=system_query_knowledge_request, api_call=self.api_call)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge", str(e)))
            logger.error(response.detail)
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response

        # Prepare KnowledgeCreate Objects
        metadata_id_map = {}
        for knowledge in request.knowledge_updates:
            if identifier == 'metadata_id':
                metadata_id = self.generate_metadata_id(knowledge.library_id, knowledge.category_id, knowledge.document_id, knowledge.file_name)
                metadata_id_map[metadata_id] = knowledge
            else:
                metadata_id_map[knowledge.knowledge_id] = knowledge
       
        knowledge_creates = []
        for knowledge in system_query_knowledge_response.filtered_data:
            if identifier == 'metadata_id':
                metadata_id = self.generate_metadata_id(knowledge.library_id, knowledge.category_id, knowledge.document_id, knowledge.file_name)
            else:
                metadata_id = knowledge.knowledge_id

            if metadata_id in metadata_id_map.keys():
                knowledge_update = metadata_id_map.get(metadata_id)
                knowledge_update.__dict__.update(knowledge_id=knowledge.knowledge_id) # Update the existing knowledge_id to knowledge_update

                knowledge.__dict__.update({k: v for k, v in knowledge_update.__dict__.items() if v is not None})
                knowledge_creates.append(KnowledgeCreate(**knowledge.__dict__))

        """ 3. Process each KnowledgeCreate Object """
        request_ingest = KnowledgeIngestRequest(**request.__dict__, knowledge_creates = knowledge_creates)
        _knowledge_success_objects, _knowledge_fail_objects, response = self.ingest_knowledge(request=request_ingest, is_update=True)

        """ 4. Update Final Response """
        response_knowledge.__dict__.update(
            knowledge_success_objects = _knowledge_success_objects,
            knowledge_fail_objects    = _knowledge_fail_objects,
            knowledge_total_no        = len(knowledge_creates),
            knowledge_success_no      = len(_knowledge_success_objects),
            knowledge_fail_no         = len(_knowledge_fail_objects),
            knowledge_ingest_time     = time.time() - start_at,
            knowledge_response_at     = datetime.now()
        )
        return response_knowledge, response
    
    def knowledge_auto_ingest_pipeline(self, request: KnowledgeAutoIngestRequest) -> tuple[KnowledgeIngestResponse | None, Response]:
        response_knowledge = KnowledgeIngestResponse(**request.__dict__)
        start_at = time.time()
        _knowledge_success_objects = []
        _knowledge_fail_objects    = []

        """ 1. Retrieve PIL Metadata from Mongodb """
        metadata_list, response = self.read_pil_metadata()
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response
        
        """ 2. Retrieve Knowledge from Relational DB """
        system_query_knowledge_request = SystemKnowledgeRequest(data_filter=KnowledgeFilter(numeric_filter=KnowledgeNumericFilter(knowledge_status_min=0)))
        try:
            system_query_knowledge_response = system_query_knowledge(request=system_query_knowledge_request, api_call=self.api_call)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge", str(e)))
            logger.error(response.detail)
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response
        
        """ 3. Construct List of KnowledgeCreate Objects by Filtering from Relational DB """
        knowledge_creates_to_be_register = []
        knowledge_creates_registered = []
        knowledge_creates = []
        knowledge_deletes = []
        existing_knowledge = system_query_knowledge_response.filtered_data      

        try:     
            metadata_id_map = {}
            for knowledge in existing_knowledge:
                metadata_id = self.generate_metadata_id(knowledge.library_id, knowledge.category_id, knowledge.document_id, knowledge.file_name)
                metadata_id_map[metadata_id] = KnowledgeCreate(**knowledge.__dict__)

            matched_knowledge_ids = []
            for metadata in metadata_list:
                metadata_id = self.generate_metadata_id(metadata.library_id, metadata.category_id, metadata.document_id, metadata.file_nm)
                knowledge = metadata_id_map.get(metadata_id, None)
                if knowledge:
                    matched_knowledge_ids.append(knowledge.knowledge_id)
                    if knowledge.knowledge_status == 0:
                        knowledge_creates_registered.append(knowledge)
                else:
                    if metadata.file_sync_url_from:
                        knowledge_creates_to_be_register.append(
                            self.create_knowledge_from_metadata(metadata)
                        )
            knowledge_creates = knowledge_creates_to_be_register + knowledge_creates_registered

            for knowledge in existing_knowledge:
                if knowledge.knowledge_id not in matched_knowledge_ids:
                    knowledge_deletes.append(knowledge)
            
            logger.info(f"Knowledge to be Created: <{len(knowledge_creates_to_be_register)}>; Knowledege Created But Rerun: <{len(knowledge_creates_registered)}>; Not Matching Knowledge to be Delete: <{len(knowledge_deletes)}>")

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Construct List of KnowledgeCreate Objects", str(e)))
            logger.error(response.detail)
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response

        # Update Response
        response_knowledge.__dict__.update(knowledgeinput_total_no=len(knowledge_creates))

        """ 4. Delete Knowledge by unmatched knowledge_id from Relational DB """
        for knowledge in knowledge_deletes:
            response = self.drop_knowledge(ingest_object=knowledge, request=request, drop_graph=True)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                response_knowledge.__dict__.update(
                    knowledge_ingest_time     = time.time() - start_at,
                    knowledge_response_at     = datetime.now()
                )
                return response_knowledge, response

        """ 5. Register Knowledge by batch on Relational DB with knowledge_status = 0"""
        [ingest_object.__dict__.update(knowledge_status=0, 
                                       knowledge_vectorstorage=SETTINGS.VTDB.FORM, 
                                       knowledge_vectorlocation=SETTINGS.VTDB.LOCA,
                                       knowledge_processing_stage=METADATA_REGISTERED, 
                                       knowledge_ingestion_stage=PENDING_TO_INGEST) for ingest_object in knowledge_creates]
        
        _, response = self.create_knowledges(knowledge_creates=knowledge_creates_to_be_register, request=request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response

        """ 6. Process each KnowledgeCreate Object """
        batch_size = len(knowledge_creates)
        if 0 < request.batch_size < batch_size:
            batch_size = request.batch_size
            knowledge_creates = knowledge_creates[:batch_size]

        request_ingest = KnowledgeIngestRequest(**request.__dict__, knowledge_creates = knowledge_creates)
        _knowledge_success_objects, _knowledge_fail_objects, response = self.ingest_knowledge(request=request_ingest, is_update=False)

        """ 7. Update Final Response """
        response_knowledge.__dict__.update(
            knowledge_success_objects = _knowledge_success_objects,
            knowledge_fail_objects    = _knowledge_fail_objects,
            knowledge_total_no        = len(knowledge_creates),
            knowledge_success_no      = len(_knowledge_success_objects),
            knowledge_fail_no         = len(_knowledge_fail_objects),
            knowledge_ingest_time     = time.time() - start_at,
            knowledge_response_at     = datetime.now()
        )
        return response_knowledge, response

    def knowledge_ingest_pipeline(self, request: KnowledgeIngestRequest) -> tuple[KnowledgeIngestResponse | None, Response]:
        response_knowledge = KnowledgeIngestResponse(**request.__dict__)
        response_knowledge.__dict__.update(knowledgeinput_total_no=len(request.knowledge_creates))
        start_at = time.time()

        _knowledge_success_objects = []
        _knowledge_fail_objects    = []

        """ 1. Retrieve Knowledge from Relational DB and Check if Knowledge is already registered """
        for ingest_object in request.knowledge_creates:
            if not ingest_object.storage_directory_origin:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Storage Directory Origin is Required"))
                logger.error(response.detail)
                response_knowledge.__dict__.update(
                    knowledge_ingest_time     = time.time() - start_at,
                    knowledge_response_at     = datetime.now()
                )
                return response_knowledge, response
            
            system_query_knowledge_request = SystemKnowledgeRequest(data_filter=KnowledgeFilter(string_filter=KnowledgeStringFilter(
                                                                        storage_directory_origin_filter=[ingest_object.storage_directory_origin])))
            try:
                system_query_knowledge_response = system_query_knowledge(request=system_query_knowledge_request, api_call=self.api_call)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Knowledge", str(e)))
                logger.error(response.detail)
                response_knowledge.__dict__.update(
                    knowledge_ingest_time     = time.time() - start_at,
                    knowledge_response_at     = datetime.now()
                )
                return response_knowledge, response

            if len(system_query_knowledge_response.filtered_data) > 0:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Storage Directory Origin <{ingest_object.storage_directory_origin}> is Already Registered with Knowledge_id <{system_query_knowledge_response.filtered_data[0].knowledge_id}>"))
                logger.error(response.detail)
                response_knowledge.__dict__.update(
                    knowledge_ingest_time     = time.time() - start_at,
                    knowledge_response_at     = datetime.now()
                )
                return response_knowledge, response

        """ 1. Retrieve PIL Metadata from Mongodb """
        metadata_list, response = self.read_pil_metadata()
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response
        
        """ 2. Update knowledge_creates by mapping metadata_list """
        metadata_id_map = {}
        metadata_url_map = {}
        for metadata in metadata_list:
            metadata_id = self.generate_metadata_id(metadata.library_id, metadata.category_id, metadata.document_id, metadata.file_nm)
            metadata_id_map[metadata_id] = metadata
            metadata_url_map[metadata.file_sync_url_from] = metadata

        try:
            for ingest_object in request.knowledge_creates:
                ingest_object_id = self.generate_metadata_id(ingest_object.library_id, ingest_object.category_id, ingest_object.document_id, ingest_object.file_name)
                metadata = metadata_id_map.get(ingest_object_id, None)
                if metadata:
                    self.map_knowledge_from_metadata(ingest_object, metadata)
                else:
                    metadata = metadata_url_map.get(ingest_object.storage_directory_origin, None)
                    if metadata:
                        self.map_knowledge_from_metadata(ingest_object, metadata)
                    else:
                        raise Exception(f"No Metadata Found for <{ingest_object.storage_directory_origin}>")
                
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Construct List of KnowledgeCreate Objects", str(e)))
            logger.error(response.detail)
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response

        """ 3. Register Knowledge by batch on Relational DB with knowledge_status = 0"""
        [ingest_object.__dict__.update(knowledge_status=0, 
                                       knowledge_vectorstorage=SETTINGS.VTDB.FORM, 
                                       knowledge_vectorlocation=SETTINGS.VTDB.LOCA,
                                       knowledge_processing_stage=METADATA_REGISTERED, 
                                       knowledge_ingestion_stage=PENDING_TO_INGEST) for ingest_object in request.knowledge_creates]
        
        _, response = self.create_knowledges(knowledge_creates=request.knowledge_creates, request=request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_knowledge.__dict__.update(
                knowledge_ingest_time     = time.time() - start_at,
                knowledge_response_at     = datetime.now()
            )
            return response_knowledge, response

        """ 4. Process each KnowledgeCreate Object """
        _knowledge_success_objects, _knowledge_fail_objects, response = self.ingest_knowledge(request=request, is_update=False)

        """ 5. Update Final Response """
        response_knowledge.__dict__.update(
            knowledge_success_objects = _knowledge_success_objects,
            knowledge_fail_objects    = _knowledge_fail_objects,
            knowledge_total_no        = len(request.knowledge_creates),
            knowledge_success_no      = len(_knowledge_success_objects),
            knowledge_fail_no         = len(_knowledge_fail_objects),
            knowledge_ingest_time     = time.time() - start_at,
            knowledge_response_at     = datetime.now()
        )
        return response_knowledge, response

    def create_knowledges(self, knowledge_creates: list[KnowledgeCreate], request: KnowledgeIngestRequest) -> tuple[list[str], Response]:
        created_knowledge_ids = []
        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Created Metadata"))
        try:
            batch_size = SETTINGS.EXPT.BATCH_SIZE
            for i in range(0, len(knowledge_creates), batch_size):
                batch = knowledge_creates[i:i + batch_size]

                # Create a batch request
                request_registration = KnowledgeBatchCreateRequest(
                    create_requests=[
                        KnowledgeCreateRequest(**request.__dict__, data=ingest_object) for ingest_object in batch
                    ]
                )
                response = general_batch_create_knowledge(request=request_registration, api_call=self.api_call)
                created_knowledge_ids.extend([ingest_object.knowledge_id for ingest_object in batch])

        except Exception as e:
            # Rollback created knowledge
            try:
                for knowledge_id in created_knowledge_ids:
                    request_drop = KnowledgeRequest(knowledge_id=knowledge_id)
                    response = general_drop_knowledge(request=request_drop, api_call=self.api_call)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Metadata Registration Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Rollback Metadata", str(e)))
                logger.error(response.detail)
        
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Metadata Registration Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Register Metadata", str(e)))
            logger.error(response.detail)

        return created_knowledge_ids, response

    def update_knowledge(self, ingest_object: KnowledgeCreate, request: KnowledgeIngestRequest) -> Response:
        # Update Knowledge on Relational DB
        _knowledge_update = KnowledgeUpdate(**ingest_object.__dict__)
        knowledge_update_request = KnowledgeUpdateRequest(
            **request.__dict__,
            update_data = _knowledge_update,
            knowledge_id = ingest_object.knowledge_id,
            overwrite = True
        )
        try:
            response = general_update_knowledge(request=knowledge_update_request, api_call=self.api_call)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Update Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Update Knowledge", str(e)))
            logger.error(response.detail)
        
        return response

    def drop_knowledge(self, ingest_object: KnowledgeCreate, request: KnowledgeIngestRequest, drop_graph: bool=True) -> Response:
        # # Drop Graph
        # if drop_graph and (ingest_object.knowledge_processing_stage == GRAPH_REGISTERED or \
        #     ingest_object.knowledge_processing_stage == INGEST_DONE):
        #     try:
        #         response = system_drop_graph_container(containter_name=ingest_object.knowledge_id)
        #     except Exception as e:
        #         response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Graph Dropping Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Drop Graph", str(e)))
        #         logger.error(response.detail)
        #         return response

        # Deep Drop Vector
        if ingest_object.knowledge_processing_stage == VECTOR_REGISTERED or \
            ingest_object.knowledge_processing_stage == GRAPH_REGISTERED or \
            ingest_object.knowledge_processing_stage == INGEST_DONE:
            request_vector = KnowledgeVectorRequest(**request.__dict__, knowledge_id=ingest_object.knowledge_id, wiping=True)
            try:
                response = general_drop_knowledge_vector(request=request_vector)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Vector Dropping Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Drop Vector", str(e)))
                logger.error(response.detail)
                return response
        
        # Drop Knowledge
        request_drop = KnowledgeRequest(knowledge_id=ingest_object.knowledge_id)
        try:
            response = general_drop_knowledge(request=request_drop, api_call=self.api_call)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Dropping Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Drop Knowledge", str(e)))
            logger.error(response.detail)
            # Reset knowledge stage since graph and vector has been dropped
            ingest_object.__dict__.update(knowledge_processing_stage=METADATA_REGISTERED, knowledge_ingestion_stage=PENDING_TO_INGEST)
            _response = self.update_knowledge(ingest_object=ingest_object, request=request)
            if _response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                response = _response

        return response

    def update_vector(self, prev_knowledge_id: str, new_knowledge_id: str, request: KnowledgeIngestRequest) -> Response:
        # Retrieve the vector objects from the vector db by previous knowledge id
        request_vector_read = KnowledgeVectorRequest(**request.__dict__, knowledge_id=prev_knowledge_id)
        try:
            response = general_read_knowledge_vector(request=request_vector_read)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Vector Update Knowledge_id Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Read Old Vector", str(e)))
            logger.error(response.detail)
            return response
        
        # Update the current vector objects with new knowledge_id
        know_data_list = response.filtered_vectors
        for _data in know_data_list:
            _data.__dict__.update(knowledge_id=new_knowledge_id)
        
        request_vector_update = KnowledgeVectorUpdateRequest(
            **request.__dict__,
            knowledge_id = prev_knowledge_id,
            update_request = KnowledgeVectorCreateRequest(
                create_requests = [
                    VectorCreateRequest(
                        **request.__dict__,
                        data = VectorCreate(**_data.__dict__)
                    )  for _data in know_data_list if _data.processed_data
                ]
            ),
            overwrite = True,
        )

        if request_vector_update.update_request.create_requests:
            try:
                response = general_update_knowledge_vector(request=request_vector_update)
                response = Response(status_code=200, detail=self.response_format.ok(f"Knowledge Vector Updated knowledge_id from <{prev_knowledge_id} to <{new_knowledge_id}>"))
                logger.info(response.detail)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Vector Update Knowledge_id Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Update Old Knowledge Vector", str(e)))
                logger.error(response.detail)
                return response
        else:
            response = Response(status_code=200, detail=self.response_format.ok(f"No Knowledge Vector Found by knowledge_id <{prev_knowledge_id}"))
            logger.info(response.detail)
        return response

    def rollback_knowledge(self, prev_ingest_object: KnowledgeCreate, new_ingest_object: KnowledgeCreate, request: KnowledgeIngestRequest) -> Response:
        original_knowledge_id = new_ingest_object.knowledge_id
        original_knowledge = KnowledgeCreate(**prev_ingest_object.__dict__)
        original_knowledge.__dict__.update(knowledge_id=original_knowledge_id)
        
        # Drop new knowledge
        response = self.drop_knowledge(ingest_object=new_ingest_object, request=request, drop_graph=False)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response

        # Add original knowledge with the original knowledge id
        _, response = self.create_knowledges(knowledge_creates=[original_knowledge], request=request)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response
        
        # Update the vector db with previous knowledge id
        if original_knowledge.knowledge_processing_stage == VECTOR_REGISTERED or \
            original_knowledge.knowledge_processing_stage == GRAPH_REGISTERED or \
            original_knowledge.knowledge_processing_stage == INGEST_DONE:
            response = self.update_vector(prev_knowledge_id=prev_ingest_object.knowledge_id, new_knowledge_id=original_knowledge_id, request=request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response
            # Reset backup knowledge knowledge_processing_stage to avoid deleting shared blobs
            prev_ingest_object.__dict__.update(knowledge_processing_stage=METADATA_REGISTERED, knowledge_ingestion_stage=PENDING_TO_INGEST)
            response = self.update_knowledge(ingest_object=prev_ingest_object, request=request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                return response
            
        # Rollback Graph
        # relationship_request = KnowledgeRelationshipRequest(
        #     **request.__dict__,
        #     knowledge_ids = [original_knowledge_id]
        # )
        
        # try:
        #     response_relationship = request_knowledge_extract_relationship(request=relationship_request)
        # except Exception as e:
        #     response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Relationship Rollback Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Rollback Relationship", str(e)))
        #     logger.error(response.detail)
        #     return response

        # Drop previous backup knowledge
        response = self.drop_knowledge(ingest_object=prev_ingest_object, request=request, drop_graph=False)
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            return response

        return response

    def ingest_knowledge(self, request: KnowledgeIngestRequest, is_update: bool = True) -> tuple[list[KnowledgeIngestObject], list[KnowledgeIngestObject], Response]:
        _knowledge_success_objects = []
        _knowledge_fail_objects    = []
        _knowledgeinput_creates    = []
        last_knowledgeinput_id = None
        for i, ingest_object in enumerate(request.knowledge_creates, start=1):
            logger.info(f"Processing <{i} / {len(request.knowledge_creates)}> Document ...")
            ingestion_start_at     = time.time()
            knowledgeingest_object = KnowledgeIngestObject(**ingest_object.__dict__, knowledge_sequence=i)

            # Clear Temporary Storage and KnowledgeInput Before Each Knowledge Ingestion
            response = self.reset_temp_storage_and_knowledgeinput(knowledegeinput_id=last_knowledgeinput_id)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                last_knowledgeinput_id = None
                knowledgeingest_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgeingest_object)
                continue

            if is_update:
                # Create a copy of ingest_object with original attributes and new knowledge_id
                prev_knowledge = KnowledgeCreate(**ingest_object.__dict__)
                prev_knowledge.__dict__.update(knowledge_id=str(uuid.uuid4()))

                _, response = self.create_knowledges(knowledge_creates=[prev_knowledge], request=request)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    knowledgeingest_object.knowledge_reason = response.detail
                    _knowledge_fail_objects.append(knowledgeingest_object)
                    continue

                # Update the vector db with new knowledge id
                if ingest_object.knowledge_processing_stage == VECTOR_REGISTERED or \
                    ingest_object.knowledge_processing_stage == GRAPH_REGISTERED or \
                    ingest_object.knowledge_processing_stage == INGEST_DONE:
                    response = self.update_vector(prev_knowledge_id=ingest_object.knowledge_id, new_knowledge_id=prev_knowledge.knowledge_id, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                        _knowledge_fail_objects.append(knowledgeingest_object)
                        continue

            """ 1. Instruct KnowledgeInputHub to Ingest Data to Temporary Storage """
            # Update KnowledgeInputHub
            _knowledgeinput_creates = [
                KnowledgeInputCreate(
                    **ingest_object.__dict__,
                    knowledgeinput_name          = ingest_object.knowledge_name,
                    knowledgeinput_version       = ingest_object.knowledge_version,
                    knowledgeinput_group         = ingest_object.knowledge_group,
                    knowledgeinput_type          = ingest_object.knowledge_type,
                    knowledgeinput_location      = ingest_object.knowledge_location,
                    knowledgeinput_status        = ingest_object.knowledge_status,
                    knowledgeinput_permission    = ingest_object.knowledge_permission,
                    knowledgeinput_management    = ingest_object.knowledge_management,
                    knowledgeinput_secrets       = ingest_object.knowledge_secrets,
                    knowledgeinput_record        = ingest_object.knowledge_record,
                    knowledgeinput_key           = ingest_object.knowledge_key,
                    knowledgeinput_filename      = ingest_object.knowledge_filename,
                    knowledgeinput_fileextension = ingest_object.knowledge_fileextension,
                    knowledgeinput_filesize      = ingest_object.knowledge_filesize,
                    knowledgeinput_tags          = ingest_object.knowledge_tags
                )
            ]

            data_request = KnowledgeInputIngestRequest(**request.__dict__, knowledgeinput_creates=_knowledgeinput_creates)
            response_knowledgeinput, response = self.ingest_knowledgeinput(request=data_request)

            """ 2. Validate KnowledgeInput Results """
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END or not response_knowledgeinput.knowledgeinput_success_objects:
                knowledgeingest_object.knowledge_code   = SETTINGS.KNOW.STATUS_CODE.get("FAIL", 500)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    knowledgeingest_object.knowledge_reason = response.detail
                else:
                    knowledgeingest_object.knowledge_reason = "No KnowledgeInput Success Objects are Found"
                _knowledge_fail_objects.append(knowledgeingest_object)

                last_knowledgeinput_id = _knowledgeinput_creates[0].knowledgeinput_id

                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                else:   
                    # Update Knowledge on Relational DB
                    ingest_object.__dict__.update(knowledge_ingestion_stage = PENDING_TO_INGEST, knowledge_processing_reason = knowledgeingest_object.knowledge_reason, knowledge_ingestion_reason = knowledgeingest_object.knowledge_reason)
                    response = self.update_knowledge(ingest_object=ingest_object, request=request) 
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                continue
            
            # Update Storage Dir After KnowledgeInputHub
            knowledgeinput_object = response_knowledgeinput.knowledgeinput_success_objects[0]
            last_knowledgeinput_id = knowledgeinput_object.knowledgeinput_id
            ingest_object.__dict__.update(
                knowledgeinput_id        = knowledgeinput_object.knowledgeinput_id,
                storage_type             = knowledgeinput_object.storage_type,
                storage_type_origin      = knowledgeinput_object.storage_type_origin,
                storage_provider         = knowledgeinput_object.storage_provider,
                storage_provider_origin  = knowledgeinput_object.storage_provider_origin,
                storage_directory        = knowledgeinput_object.storage_directory,
                storage_directory_origin = knowledgeinput_object.storage_directory_origin,
                knowledge_filename       = knowledgeinput_object.knowledgeinput_filename,
                knowledge_fileextension  = knowledgeinput_object.knowledgeinput_fileextension,
                knowledge_filesize       = knowledgeinput_object.knowledgeinput_filesize,
                knowledge_processing_stage = KNOWLEDGEINPUT_REGISTERED,
                knowledge_ingestion_stage  = INGESTING
            )

            # Upload Local Temporary PDF to Azure Blob Storage
            try:
                local_path = ingest_object.storage_directory
                file_name = local_path.split(os.path.sep)[-1]
                blob_path = f"{SETTINGS.BLOB.FOLDER_NAME}/pdf/{file_name}"
                blob_file_url = upload_to_blob(local_path=local_path, blob_path=blob_path, content_type='application/pdf')
            except Exception as e:
                response = Response(status_code=SETTINGS.KNOW.STATUS_CODE.get("FAIL", 500), detail=self.response_format.error(f"Knowledge Metadata Update Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Upload PDF to Blob Storage", str(e)))
                knowledgeingest_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgeingest_object)
                logger.error(response.detail)

                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                else:   
                    # Update Knowledge on Relational DB
                    ingest_object.__dict__.update(knowledge_ingestion_stage = PENDING_TO_INGEST, knowledge_processing_reason = knowledgeingest_object.knowledge_reason, knowledge_ingestion_reason = knowledgeingest_object.knowledge_reason)
                    response = self.update_knowledge(ingest_object=ingest_object, request=request) 
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                continue

            ingest_object.__dict__.update(storage_directory=blob_file_url)

            # Update Knowledge on Relational DB
            response = self.update_knowledge(ingest_object=ingest_object, request=request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                knowledgeingest_object.knowledge_reason = response.detail

                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail

                _knowledge_fail_objects.append(knowledgeingest_object)
                continue
            
            """ 3. Preprocessing Knowledge """
            _prepknow_input = PrepKnowInput(**ingest_object.__dict__)
            data_request = PrepKnowPipelineRequest(
                **request.__dict__, 
                prepknow_input = _prepknow_input
            )
            
            response_preprocessing, response = self.preprocess_knowledge(request=data_request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END or not response_preprocessing.prepknow_pipeline_output.prepknow_output.know_data:
                knowledgeingest_object.knowledge_code   = SETTINGS.KNOW.STATUS_CODE.get("FAIL", 500)
                if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                    knowledgeingest_object.knowledge_reason = response.detail
                else:
                    knowledgeingest_object.knowledge_reason = "No KnowDataObjects are Found in the Preprocessing Result"
                logger.error(knowledgeingest_object.knowledge_reason)
                _knowledge_fail_objects.append(knowledgeingest_object)

                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                else:   
                    # Update Knowledge on Relational DB
                    ingest_object.__dict__.update(knowledge_ingestion_stage = PENDING_TO_INGEST, knowledge_processing_reason = knowledgeingest_object.knowledge_reason, knowledge_ingestion_reason = knowledgeingest_object.knowledge_reason)
                    response = self.update_knowledge(ingest_object=ingest_object, request=request) 
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail  
                continue

            ingest_object.__dict__.update(
                prepknow_id         = response_preprocessing.prepknow_pipeline_output.prepknow_metric.prepknow_id,
                total_input_tokens  = response_preprocessing.prepknow_total_input_tokens,
                total_output_tokens = response_preprocessing.prepknow_total_output_tokens,
                total_tool_tokens   = response_preprocessing.prepknow_total_tool_tokens,
                knowledge_processing_stage = PREPROCESSING_COMPLETED
            )
                
            # Update Knowledge on Relational DB
            response = self.update_knowledge(ingest_object=ingest_object, request=request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                knowledgeingest_object.knowledge_reason = response.detail

                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                
                _knowledge_fail_objects.append(knowledgeingest_object)
                continue

            """ 4. Register KnowDataObject on Vector DB """
            know_data_list = response_preprocessing.prepknow_pipeline_output.prepknow_output.know_data
            request_vector = KnowledgeVectorCreateRequest(
                create_requests = [
                    VectorCreateRequest(
                        **request.__dict__,
                        data = VectorCreate(**_data.__dict__)
                     )  for _data in know_data_list if _data.processed_data
                ]
            )

            if not request_vector.create_requests:
                knowledgeingest_object.knowledge_code   = SETTINGS.KNOW.STATUS_CODE.get("FAIL", 500)
                knowledgeingest_object.knowledge_reason = "All KnowDataObjects Have No Processed Data for Registering into Vector DB"
                logger.error(knowledgeingest_object.knowledge_reason)
                _knowledge_fail_objects.append(knowledgeingest_object)
                
                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                else:   
                    # Update Knowledge on Relational DB
                    ingest_object.__dict__.update(knowledge_ingestion_stage = PENDING_TO_INGEST, knowledge_processing_reason = knowledgeingest_object.knowledge_reason, knowledge_ingestion_reason = knowledgeingest_object.knowledge_reason)
                    response = self.update_knowledge(ingest_object=ingest_object, request=request) 
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                continue

            try:
                response_vector = general_create_knowledge_vector(request=request_vector)
            except Exception as e:
                response = Response(status_code=SETTINGS.KNOW.STATUS_CODE.get("FAIL", 500), detail=self.response_format.error(f"Knowledge Vector Registration Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Register Vector", str(e)))
                knowledgeingest_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgeingest_object)
                logger.error(response.detail)

                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                else:   
                    # Update Knowledge on Relational DB
                    ingest_object.__dict__.update(knowledge_ingestion_stage = PENDING_TO_INGEST, knowledge_processing_reason = knowledgeingest_object.knowledge_reason, knowledge_ingestion_reason = knowledgeingest_object.knowledge_reason)
                    response = self.update_knowledge(ingest_object=ingest_object, request=request) 
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                continue

            ingest_object.__dict__.update(
                response_vector.__dict__,
                knowledge_processing_stage=VECTOR_REGISTERED
            )
            
            # Update Knowledge on Relational DB
            response = self.update_knowledge(ingest_object=ingest_object, request=request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                knowledgeingest_object.knowledge_reason = response.detail

                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                
                _knowledge_fail_objects.append(knowledgeingest_object)
                continue

            # """ 5. Process Relationship Extraction """
            # relationship_request = KnowledgeRelationshipRequest(
            #     **request.__dict__,
            #     knowledge_ids = [ingest_object.knowledge_id]
            # )
            
            # try:
            #     response_relationship = request_knowledge_extract_relationship(request=relationship_request)
            # except Exception as e:
            #     response = Response(status_code=SETTINGS.KNOW.STATUS_CODE.get("FAIL", 500), detail=self.response_format.error(f"Knowledge Relationship Extraction Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Extract Relationship", str(e)))
            #     knowledgeingest_object.knowledge_reason = response.detail
            #     _knowledge_fail_objects.append(knowledgeingest_object)
            #     logger.error(response.detail)

            #     if is_update:
            #         # Drop new knowledge and rollback to old knowledge
            #         response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
            #         if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            #             knowledgeingest_object.knowledge_reason = response.detail
            #     else:   
            #         # Update Knowledge on Relational DB
            #         ingest_object.__dict__.update(knowledge_ingestion_stage = PENDING_TO_INGEST, knowledge_processing_reason = knowledgeingest_object.knowledge_reason, knowledge_ingestion_reason = knowledgeingest_object.knowledge_reason)
            #         response = self.update_knowledge(ingest_object=ingest_object, request=request) 
            #         if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            #             knowledgeingest_object.knowledge_reason = response.detail
            #     continue

            # ingest_object.__dict__.update(
            #     knowledge_processing_stage=GRAPH_REGISTERED
            # )
            
            # # Update Knowledge on Relational DB
            # response = self.update_knowledge(ingest_object=ingest_object, request=request)
            # if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            #     knowledgeingest_object.knowledge_reason = response.detail

            #     if is_update:
            #         # Drop new knowledge and rollback to old knowledge
            #         response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
            #         if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            #             knowledgeingest_object.knowledge_reason = response.detail
                
            #     _knowledge_fail_objects.append(knowledgeingest_object)
            #     continue

            """ 6. Update Knowledge Metadata on Relational DB"""
            # Determine Document Language and Keywords
            document_languages = ['en', 'zh_cht']
            document_keywords = []
            know_data_list = response_preprocessing.prepknow_pipeline_output.prepknow_output.know_data
            for chunk in know_data_list:
                if hasattr(chunk, 'data_type') and chunk.data_type.upper() == 'DOCUMENT':
                    if hasattr(chunk, 'data_languages') and chunk.data_languages:
                        document_languages = chunk.data_languages
                        document_keywords = chunk.data_keywords

            ingest_object.__dict__.update(
                response_vector.__dict__,
                knowledge_status=1, 
                knowledge_languages = document_languages,
                knowledge_keywords = document_keywords,
                processing_time=time.time() - ingestion_start_at, 
                knowledge_processing_stage=INGEST_DONE, 
                knowledge_processing_reason='',
                knowledge_ingestion_stage=INGESTED_FOR_REVIEW,
                knowledge_ingestion_reason='',
            )
            
            # Final Update Knowledge on Relational DB
            response = self.update_knowledge(ingest_object=ingest_object, request=request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                knowledgeingest_object.knowledge_reason = response.detail
                
                if is_update:
                    # Drop new knowledge and rollback to old knowledge
                    response = self.rollback_knowledge(prev_ingest_object=prev_knowledge, new_ingest_object=ingest_object, request=request)
                    if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                        knowledgeingest_object.knowledge_reason = response.detail
                
                _knowledge_fail_objects.append(knowledgeingest_object)
                continue

            # Deep Delete Old Knowledge
            if is_update:
                self.drop_knowledge(ingest_object=prev_knowledge, request=request, drop_graph=False)

            knowledgeingest_object.knowledge_code   = SETTINGS.KNOW.STATUS_CODE.get("SUCCESS", "200")
            knowledgeingest_object.knowledge_reason = "Completed"
            _knowledge_success_objects.append(knowledgeingest_object)
            
        # Clear Temporary Storage and KnowledgeInput After Knowledge Ingestion
        self.reset_temp_storage_and_knowledgeinput(knowledegeinput_id=last_knowledgeinput_id)

        if len(_knowledge_fail_objects) == 0:
            response = Response(status_code=SETTINGS.KNOW.STATUS_CODE.get("SUCCESS", 200), detail=self.response_format.ok(f"Knowledge Ingestion Completed : <{SETTINGS.BASE.APP_NAME}> Knowledge Ingestion Completed"))
            logger.info(response.detail)
        else:
            response = Response(status_code=SETTINGS.KNOW.STATUS_CODE.get("FAIL", 500), detail=self.response_format.ok(f"Knowledge Ingestion Failed : <{SETTINGS.BASE.APP_NAME}> Knowledge Ingestion Failed"))
            logger.error(response.detail)

        return _knowledge_success_objects, _knowledge_fail_objects, response

    def reset_temp_storage_and_knowledgeinput(self, knowledegeinput_id: str) -> Response:
        # Clear Temporary Storage
        response = self.clear_knowledgeinput_temp_storage()
        response = self.clear_preprocessing_temp_storage()
        # Ignore Response from Clear Temporary Storage
        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Cleared Temporary Storage"))
        # Clear KnowledgeInput
        if knowledegeinput_id:
            response = self.drop_knowledgeinput(request=KnowledgeInputRequest(knowledgeinput_id=knowledegeinput_id))
        return response
    
    def read_pil_metadata(self) -> tuple[list[MetadataCreate], Response]:
        metadata_request = SystemMetadataRequest()
        metadata_list = []
        try:
            metadata_response = system_query_metadata(request=metadata_request, api_call=self.api_call)
            metadata_list = metadata_response.filtered_data
            response = Response(status_code=200, detail=self.response_format.ok(f"Processing : <{SETTINGS.BASE.APP_NAME}> Successfully Retrieved PIL Metadata"))
            logger.info(response.detail)
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve PIL Metadata", str(e)))
            logger.error(response.detail)
            return metadata_list, response
        
        if not metadata_list:
            response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> No Metadata Found"))
            logger.error(response.detail)

        return metadata_list, response

    def read_pil_metadata_from_file(self, metadata_file_url: str) -> tuple[list[dict], Response]:
        logger.info("Processing : Reading PIL Metadata Data File")
        metadata_list = []
        blob_url = urllib.parse.unquote(metadata_file_url)
        _file = blob_url.split('/')[-1]
        file_name, file_extension = os.path.splitext(_file)

        # Download Metadata File from Azure blob Storage to current directory
        local_path = os.path.join(os.getcwd(), file_name + file_extension)
        # Check if file exists, if yes, delete it
        if os.path.exists(local_path):
            os.remove(local_path)

        try:
            response = download_from_blob_by_url(blob_file_url=metadata_file_url, local_path=local_path)
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"PIL Sync Error : <{SETTINGS.BASE.APP_NAME}> Failed to Download PIL Metadata File"))
            logger.error(response.detail)
            return metadata_list, response

        try:
            if file_extension in [".xlsx", ".xls"]:
                df = pd.read_excel(local_path) #, sheet_name="Full list of Report")
                df.fillna("", inplace=True)
            else:
                df = pd.read_csv(local_path)
                df = df.astype(object).fillna("")
            
            metadata_list = df.to_dict('records')

            # Delete Local Metadata File
            os.remove(local_path)
            response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Successfully Read PIL Metadata File"))
            logger.info(response.detail)

        except:
            response = Response(status_code=500, detail=self.response_format.error(f"PIL Sync Error : <{SETTINGS.BASE.APP_NAME}> Failed to Read PIL Metadata File"))
            logger.error(response.detail)
            return metadata_list, response
        
        return metadata_list, response

    def generate_metadata_id(self, library_id: str, category_id: str, document_id: str, file_name: str) -> str:
        return f"{library_id}-{category_id}-{document_id}-{file_name}"

    def map_knowledge_from_metadata(self, ingest_object: KnowledgeCreate, metadata: MetadataCreate):
        try:
            ingest_object.__dict__.update(
                library_name_en              = metadata.library_en_nm,
                library_name_tc              = metadata.library_tc_nm,
                category_name_en             = metadata.category_en_nm,
                category_name_tc             = metadata.category_tc_nm,
                title_name_en                = metadata.title_nm_en,
                title_name_tc                = metadata.title_nm_tc,
                item_type                    = metadata.item_type,
                item_url                     = metadata.item_url,
                item_status                  = metadata.item_status,
                document_id                  = metadata.document_id,
                file_name                    = metadata.file_nm,
                file_description             = metadata.file_desc,
                file_created_datetime        = metadata.file_created_dt,
                file_last_modified_datetime  = metadata.file_lastmodified_dt,
                group_id                     = metadata.access_group,
                file_sync_up_url             = metadata.file_sync_url_from,
                library_id                   = metadata.library_id,
                category_id                  = metadata.category_id,
                updated_by                   = metadata.file_lastmodified_author_nm,
                retention_at                 = metadata.file_lastmodified_dt,
                knowledge_name               = metadata.file_nm.split('.')[0],

                storage_type_origin          = 'azure',
                storage_directory_origin     = metadata.file_sync_url_from
            )
        except Exception as e:
            raise Exception(f"Failed to Map Metadata due to <{str(e)}>")

    def create_metadata_from_pil_csv(self, pil_metadata: dict) -> MetadataCreate:
        metadata_create = MetadataCreate()
        try:
            metadata_create.__dict__.update(
                file_id                    = pil_metadata.get("File ID", ""),
                library_id                 = pil_metadata.get("Library ID", ""),
                library_en_nm              = pil_metadata.get("Library Name (EN)", ""),
                library_tc_nm              = pil_metadata.get("Library Name (TC)", ""),
                category_id                = pil_metadata.get("Cateogry ID", ""),
                category_en_nm             = pil_metadata.get("Category Name (EN)", ""),
                category_tc_nm             = pil_metadata.get("Category Name (TC)", ""),
                title_nm_en                = pil_metadata.get("Title Name (EN)", ""),
                title_nm_tc                = pil_metadata.get("Title Name (TC)", ""),
                item_type                  = pil_metadata.get("Item Type", ""),
                item_url                   = pil_metadata.get("Item URL", ""),
                item_status                = pil_metadata.get("Item Status", ""),
                document_id                = pil_metadata.get("Document ID", ""),
                file_nm                    = pil_metadata.get("File Name", ""),
                file_desc                  = pil_metadata.get("File Description", ""),
                file_created_dt            = self.parse_datetime_str(pil_metadata.get("File Created Datetime", None)),
                file_lastmodified_dt       = self.parse_datetime_str(pil_metadata.get("File Last Modified Datetime", None)),
                file_lastmodified_author_email = pil_metadata.get("Last Update Author's Email address", ""),
                file_lastmodified_author_nm    = pil_metadata.get("Last Update Author's Name", ""),
                access_group               = pil_metadata.get("Group ID", "").split(","),
                file_sync_url_from         = ensure_blob_url(pil_metadata.get('File Sync Up URL', '')),
                file_sync_url_to           = ensure_blob_url(pil_metadata.get('File Sync Up URL', ''))
            )

        except Exception as e:
            raise Exception(f"Failed to Create MetadataCreate Object from PIL CSV due to <{str(e)}>")

        return metadata_create

    def create_knowledge_from_metadata(self, metadata: MetadataCreate) -> KnowledgeCreate:
        knowledge_create = KnowledgeCreate()
        try:
            knowledge_create.__dict__.update(
                library_name_en              = metadata.library_en_nm,
                library_name_tc              = metadata.library_tc_nm,
                category_name_en             = metadata.category_en_nm,
                category_name_tc             = metadata.category_tc_nm,
                title_name_en                = metadata.title_nm_en,
                title_name_tc                = metadata.title_nm_tc,
                item_type                    = metadata.item_type,
                item_url                     = metadata.item_url,
                item_status                  = metadata.item_status,
                document_id                  = metadata.document_id,
                file_name                    = metadata.file_nm,
                file_description             = metadata.file_desc,
                file_created_datetime        = metadata.file_created_dt,
                file_last_modified_datetime  = metadata.file_lastmodified_dt,
                group_id                     = metadata.access_group,
                file_sync_up_url             = metadata.file_sync_url_from,
                library_id                   = metadata.library_id,
                category_id                  = metadata.category_id,
                updated_by                   = metadata.file_lastmodified_author_nm,
                retention_at                 = metadata.file_lastmodified_dt,
                knowledge_name               = metadata.file_nm.split('.')[0],

                storage_type_origin          = 'azure',
                storage_directory_origin     = metadata.file_sync_url_from
            )

        except Exception as e:
            raise Exception(f"Failed to Create KnowledgeCreate Object from Metadata due to <{str(e)}>")

        return knowledge_create

    def parse_datetime_str(self, date_str) -> datetime:
        if date_str is None:
            return datetime(1970, 1, 1, 0, 0, 0)  # Default as a datetime object
        
        format = ["%d/%m/%Y %I:%M:%S %p", "%d/%m/%Y %H:%M", "%m/%d/%Y %I:%M:%S %p", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y"]
        
        for fmt in format:
            try:
                # Convert string to datetime object
                dt_object = datetime.strptime(date_str, fmt)
                # Set microseconds to zero
                dt_object = dt_object.replace(microsecond=0)
                return dt_object  # Returns datetime object
            except ValueError:
                continue

        # If none of the formats match, convert using pandas
        return datetime(1970, 1, 1, 0, 0, 0)

    def ingest_security_check(self, ingest_object: KnowledgeCreate) -> Response:
        # Security Check
        if ".." in ingest_object.storage_directory_origin or ".." in ingest_object.knowledge_filename:
            response = Response(status_code=403, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Declined Relative Path while Ingesting Knowledge from Local"))
            logger.error(response.detail)
        
        response = Response(status_code=200, detail=self.response_format.ok("Knowledge Ingestion Security Check Passed"))
        return response

    def ingest_knowledgeinput(self, request: KnowledgeInputIngestRequest) -> tuple[KnowledgeInputIngestResponse, Response]:
        response_data = KnowledgeInputIngestResponse(**request.__dict__)
        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.KWIN.HOST}:{SETTINGS.KWIN.PORT}/{SETTINGS.KWIN.REQUEST_INGEST_API}"
                payload = request.json()
                response_data, response = self.api_call_static(data=payload, service="KnowledgeInputHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response_data = response_data.json()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Ingested KnowledgeInput via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                if SETTINGS.BASE.APP_FUNC == True:
                    try:
                        response_data = request_knowledgeinput_ingest(request=request, api_call=False)
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Ingested KnowledgeInput via Function Call"))
                        logger.info(response.detail)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Ingest KnowledgeInput via Function Call", str(e)))
                        logger.error(response.detail)
                
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Ingest KnowledgeInput but <APP_FUNC> is False"))
                    logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Ingesting KnowledgeInput", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Ingesting KnowledgeInput"))
            logger.error(response.detail)

        return response_data, response

    def drop_knowledgeinput(self, request: KnowledgeInputRequest) -> Response:
        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.KWIN.HOST}:{SETTINGS.KWIN.PORT}/{SETTINGS.KWIN.REQUEST_DROP_API}"
                payload = request.json()
                response = self.api_call_static(data=payload, service="KnowledgeInputHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)

            # Function Call
            else:   
                if SETTINGS.BASE.APP_FUNC == True:
                    try:
                        response = request_knowledgeinput_drop(request=request, api_call=False)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Drop KnowledgeInput via Function Call", str(e)))
                        logger.error(response.detail)
                
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Drop KnowledgeInput but <APP_FUNC> is False"))
                    logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Dropping KnowledgeInput", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Dropping KnowledgeInput"))
            logger.error(response.detail)

        return response

    def clear_knowledgeinput_temp_storage(self) -> Response:
        try:
            if SETTINGS.BASE.APP_FUNC == True:
                try:
                    init_knowledgeinput_temp_storage()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Cleared KnowledgeInput Temp Storage via Function Call"))
                    logger.info(response.detail)
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Clear KnowledgeInput Temp Storage via Function Call", str(e)))
                    logger.error(response.detail)
                
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Clear KnowledgeInput Temp Storage but <APP_FUNC> is False"))
                logger.error(response.detail)
        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Clearing KnowledgeInput Temp Storage", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Clearing KnowledgeInput Temp Storage"))
            logger.error(response.detail)

        return response
    
    def clear_preprocessing_temp_storage(self) -> Response:
        try:
            if SETTINGS.BASE.APP_FUNC == True:
                try:
                    init_preprocessing_temp_storage()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Cleared Preprocessing Temp Storage via Function Call"))
                    logger.info(response.detail)
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Clear Preprocessing Temp Storage via Function Call", str(e)))
                    logger.error(response.detail)
                
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Clear Preprocessing Temp Storage but <APP_FUNC> is False"))
                logger.error(response.detail)
        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Clearing Preprocessing Temp Storage", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Clearing Preprocessing Temp Storage"))
            logger.error(response.detail)

        return response
    
    def preprocess_knowledge(self, request: PrepKnowPipelineRequest) -> tuple[PrepKnowPipelineResponse, Response]:
        response_data = PrepKnowPipelineResponse(**request.__dict__)

        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.PREP.HOST}:{SETTINGS.PREP.PORT}/{SETTINGS.PREP.REQUEST_PREPKNOW_API}"
                payload = request.json()
                response_data, response = self.api_call_static(data=payload, service="PreprocessingHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response_data = response_data.json()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Knowledge Preprocessing via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                if SETTINGS.BASE.APP_FUNC == True:
                    try:
                        response_data = request_exec_prepknow(request=request, api_call=False)
                        response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Knowledge Preprocessing via Function Call"))
                        logger.info(response.detail)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Complete Knowledge Preprocessing via Function Call", str(e)))
                        logger.error(response.detail)
                
                else:
                    response = Response(status_code=500, detail=self.response_format.error(f"Configuration Error : <{SETTINGS.BASE.APP_NAME}> Used Function Call to Knowledge Preprocessing but <APP_FUNC> is False"))
                    logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing Knowledge", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing KnowledgeInput"))
            logger.error(response.detail)

        return response_data, response

    def ingest_registration(self, request: KnowledgeIngestRequest, data: KnowledgeCreate) -> Response:
        create_request = KnowledgeCreateRequest(**request.__dict__, data=data)
        response = general_create_knowledge(
            request  = create_request, 
            api_call = self.api_call
        )
        
        if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            if data.storage_type == 'LOCAL' and data.storage_directory:
                try:
                    shutil.rmtree(data.storage_directory)
                except:
                    response = Response(status_code=500, detail=self.response_format.error(f"Temp Storage Ingestion Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Register Knowledge and Unable to Delete File <{data.knowledge_name}> in Temp Storage during Local Ingestion"))
                    logger.error(response.detail)
        else:
            response = Response(status_code=200, detail=self.response_format.ok(f"Knowledge Registration Completed : <{SETTINGS.BASE.APP_NAME}> Completed Ingestion and Registration for Knowledge <{data.knowledge_name}>"))
        
        return response

    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response
