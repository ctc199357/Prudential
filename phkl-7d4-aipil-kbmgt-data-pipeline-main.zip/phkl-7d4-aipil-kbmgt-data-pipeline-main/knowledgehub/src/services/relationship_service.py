from datetime import datetime, timezone
import time
import inspect
import httpx

import tiktoken

from ..settings import SETTINGS

from ..schemas.format import (
    ResponseFormatter,
    Response
)

from ..database.registry.schemas.knowledge import (
    KnowledgeUpdate,
    KnowledgeUpdateRequest,
    KnowledgeFilter,
    KnowledgeStringFilter,
    SystemKnowledgeRequest,
)

from ..database.vector.schemas.vector import (
    SystemVectorRequest,
    VectorFilter,
    VectorStringFilter,
    VectorUpdate,
    VectorUpdateRequest
)

from ..database.graph.schemas.graph import (
    GraphCreateRequest,
    GraphCreate,
    NodeCreate,
    EdgeCreate
)

from ..schemas.relationship import (
    KnowledgeRelationshipObject,
    KnowledgeRelationshipRequest,
    KnowledgeRelationshipResponse,
    KnowledgeRelationshipPipeline
)

from ..schemas.utils import (
    KnowDataObject,
    PrepMediaPipelineRequest,
    PrepMediaPipelineResponse,
)

from ..routers.registry.general import (
    general_update_knowledge 
)

from ..routers.registry.system import (
    system_query_knowledge
)

from ..routers.vector.general import (
    general_update_vector
)

from ..routers.vector.system import (
    system_query_vector
)

from ..routers.request_embedding import (
    request_query_embedding,
    EmbeddingRequest
)

from ..routers.graph.system import system_drop_graph_container

from ..routers.graph.general import (
    general_create_graph,
    general_condition_drop_graph,
    GraphUpdateRequest
)

from ..routers.request_vector import (
    request_vector_search,
    VectorSearchRequest
)

from ..services import request_exec_prepmedia

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class RelationshipServiceManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def __init__(self, api_call: bool, pipeline: KnowledgeRelationshipPipeline | None = None):
        self.api_call = api_call
        self.pipeline = pipeline

    def partition_formatter(self, name: str):
        formated_name = name.replace(' ', '_')
        formated_name = formated_name.replace('.', '_')
        return f'{SETTINGS.GPDB.CONTAINER_PREFIX}{formated_name}'

    """
        Request Operation
    """
    def knowledge_relationship_pipeline(self, request: KnowledgeRelationshipRequest) -> tuple[KnowledgeRelationshipResponse | None, Response]:
        logger.info("Processing : Start Knowledge Relationship Extraction")
        response_knowledge = KnowledgeRelationshipResponse(**request.__dict__, knowledge_total_no=len(request.knowledge_ids))
        start_at = time.time()

        """ 1. Knowledge Relationship Check """
        # Check if Empty Ingestion
        if not request.knowledge_ids:
            response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Found Empty <knowledge_ids>"))
            logger.error(response.detail)
            return response_knowledge, response
        
        """ 2. Start Processing Relationship Extraction """
        _knowledge_success_objects = []
        _knowledge_fail_objects    = []
        for i, knowledge_id in enumerate(request.knowledge_ids, start=1):
            logger.info(f"Processing <{i} / {len(request.knowledge_ids)}> Knowledge for Relationship Extraction ...")
            process_start_at = time.time()

            knowledgerelationship_object = KnowledgeRelationshipObject(
                knowledge_sequence=i, 
                knowledge_id=knowledge_id
            )

            """ 3. Retrieve Knowledge Metadata """
            logger.info("Processing : Retrieving Knowledge Metadata")
            metadata_request = SystemKnowledgeRequest(
                data_filter=KnowledgeFilter(
                    string_filter=KnowledgeStringFilter(knowledge_id_filter=[knowledge_id])
                )
            )
            try:
                response_metadata  = system_query_knowledge(request=metadata_request, api_call=self.api_call)
                # knowledge_metadata = response_metadata.filtered_data[0]
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Retrieval Failed : <{SETTINGS.BASE.APP_NAME}> Metadata Retrieval Error", str(e)))
                knowledgerelationship_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgerelationship_object)
                logger.error(response.detail)
                continue

            if response_metadata.data_count == 0:
                response = Response(status_code=404, detail=self.response_format.error(f"Failed to Extraction Relationship : <{SETTINGS.BASE.APP_NAME}> Cannot Found Matched Knowledge Metedata"))
                logger.error(response.detail)
                continue
            
            """ 4. Retrieve Knowledge Vectors """
            logger.info("Processing : Retrieving Knowledge Vectors")
            vector_request = SystemVectorRequest(
                vector_filter=VectorFilter(
                    string_filter=VectorStringFilter(
                        knowledge_id_filter=[knowledge_id],
                        data_type_filter=["DOCUMENT"]
                    )
                )
            )
            try:
                response_vector   = system_query_vector(request=vector_request, api_call=self.api_call)
                knowledge_vectors = response_vector.filtered_vectors
                logger.info(f"Processing : Retrieved <{len(knowledge_vectors)}> Vectors")
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Vector Retrieval Failed : <{SETTINGS.BASE.APP_NAME}> Vector Retrieval Error", str(e)))
                knowledgerelationship_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgerelationship_object)
                logger.error(response.detail)
                continue

            if len(knowledge_vectors) == 0 or not knowledge_vectors[0]:
                knowledgerelationship_object.knowledge_reason = "Failed to Retrieve Vectors for Relationship Generation"
                _knowledge_fail_objects.append(knowledgerelationship_object)
                logger.error(knowledgerelationship_object.knowledge_reason)
                continue 

            # Sumamry Chunk Processing
            summary = knowledge_vectors[0]
            summary_chunks = self.chunk_content(summary.raw_data)
            request_embedding = EmbeddingRequest(data_input=summary_chunks)
            try:
                response_embedding = request_query_embedding(request=request_embedding, api_call=self.api_call)
                
                # Parse Output

                processed_summaries = response_embedding.data_output

            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Summary Embedding Failed : <{SETTINGS.BASE.APP_NAME}> Embedding Failed", str(e)))
                continue
                
            vector_search_complete = True
            key_data = [summary]
            key_data_ids = [summary.data_id]
            for processed_summary in processed_summaries:
                try:
                    response_vectors = request_vector_search(
                        request=VectorSearchRequest(
                            knowledge_ids=[knowledge_id],
                            processed_query=processed_summary
                        )
                    )

                    for _vector in response_vectors.retrieved_data:
                        if _vector.data_id not in key_data_ids:
                            key_data.append(_vector)
                            key_data_ids.append(_vector.data_id)

                except Exception as e:
                    vector_search_complete = False
                    response = Response(status_code=500, detail=self.response_format.error(f"Summary Vector Retrieval Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Sumamry Vectors", str(e)))
                    logger.error(response.detail)
                    break
                
            if vector_search_complete == False:
                continue

            ### TODO : Update Relationship Extraction
            """" 5.  Relationship Extraction """
            logger.info("Processing : Extracting Relationship")
            knowdataobjects   = [KnowDataObject(**{k: v for k, v in _knowledge_vector.__dict__.items() if k != "processed_data"}) for _knowledge_vector in knowledge_vectors]
            prepmedia_request = PrepMediaPipelineRequest(**request.__dict__, prepmedia_input = knowdataobjects)
            response_data, response = self.preprocess_relationship(request=prepmedia_request)
            if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
                knowledgerelationship_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgerelationship_object)
                continue
            elif not response_data.prepmedia_relationship:
                knowledgerelationship_object.knowledge_reason = "Failed to Classify Any Relationships"
                _knowledge_fail_objects.append(knowledgerelationship_object)                
            else:
                graph_object = response_data.prepmedia_relationship

            """ 6. Register Relationship on GraphDB """
            logger.info("Processing : Registering Relationship on GraphDB")
            gb_container_name = SETTINGS.GPDB.CONTAINER
            graph_create_request = GraphCreateRequest(
                **request.__dict__, 
                container_name=gb_container_name,
                partition_key=knowledge_id,
                data=GraphCreate(
                    nodes=[NodeCreate(**_node.__dict__) for _node in graph_object.nodes],
                    edges=[EdgeCreate(**_edge.__dict__) for _edge in graph_object.edges]
                )
            )

            try:
                response = general_condition_drop_graph(
                    request=GraphUpdateRequest(
                        container_name=gb_container_name,
                        partition_key=knowledge_id
                    )
                )

                response = general_create_graph(request=graph_create_request, api_call=self.api_call)

            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Graph Creation Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Graph Creation Error", str(e)))
                knowledgerelationship_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgerelationship_object)
                logger.error(response.detail)
                continue

            except:
                response = Response(status_code=500, detail=self.response_format.error(f"Graph Creation Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Graph Creation Failed"))
                knowledgerelationship_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgerelationship_object)
                logger.error(response.detail)
                continue

            """ 7. Update Vector DB """
            logger.info("Processing : Updating Vecotr on VectorDB")
            vector_update_requests = []
            for i, _knowledge_vector in enumerate(knowledge_vectors):
                matched_objects = [_data for _data in graph_object.nodes if _data.data_id == _knowledge_vector.data_id]
                if not matched_objects:
                    continue
                update_data = VectorUpdate(
                    node_id   = matched_objects[0].node_id, 
                    node_type = matched_objects[0].node_type
                )
                vector_update_requests.append(
                    VectorUpdateRequest(
                        data_id     = _knowledge_vector.data_id, 
                        update_data = update_data,
                        overwrite   = True
                    )
                )

            if vector_update_requests:
                for _request in vector_update_requests:
                    try:
                        response = general_update_vector(request=_request, api_call=self.api_call)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Vector Update Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Vector Update Failed <data_id: {_request.data_id}>", str(e)))
                        logger.error(response.detail)      
                        continue
            else:
                response = Response(status_code=500, detail=self.response_format.error(f"Vector Update Unfound Error : <{SETTINGS.BASE.APP_NAME}> Vector Update Failed"))
                knowledgerelationship_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgerelationship_object)
                logger.error(response.detail)
                continue

            """ 8. Update Metadata DB """
            logger.info("Processing : Updating MetadataDB")
            update_data = KnowledgeUpdate(
                knowledge_graphstorage=SETTINGS.GPDB.FORM,
                knowledge_graphlocation=SETTINGS.GPDB.LOCA,
                knowledge_graphinfo={
                    "db_name":   SETTINGS.GPDB.NAME, 
                    "container": gb_container_name
                }
            )

            metadata_update_request = KnowledgeUpdateRequest(
                knowledge_id=knowledge_id,
                update_data=update_data,
                overwrite=True
            )
            try:
                response = general_update_knowledge(request=metadata_update_request, api_call=self.api_call)
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Update Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Knowledge Update Failed <knowledge_id: {knowledge_id}>", str(e)))
                knowledgerelationship_object.knowledge_reason = response.detail
                _knowledge_fail_objects.append(knowledgerelationship_object) 
                logger.error(response.detail)
                continue

            knowledgerelationship_object.knowledge_code = SETTINGS.KNOW.STATUS_CODE.get("SUCCESS", "200")
            knowledgerelationship_object.knowledge_reason = 'SUCCESS'
            _knowledge_success_objects.append(knowledgerelationship_object)

        """ 9. Update Final Response """
        logger.info("Processing : Preparing Final Response")
        response_knowledge.__dict__.update(
            knowledge_success_objects   = _knowledge_success_objects,
            knowledge_fail_objects      = _knowledge_fail_objects,
            knowledge_total_no          = len(request.knowledge_ids),
            knowledge_success_no        = len(_knowledge_success_objects),
            knowledge_fail_no           = len(_knowledge_fail_objects),
            knowledge_relationship_time = time.time() - start_at,
            knowledge_response_at       = datetime.now(timezone.utc)
        )
        response = Response(status_code=200, detail=self.response_format.ok(f"Relationship Extraction Completed : <{SETTINGS.BASE.APP_NAME}> Completed Relationship Extraction"))
        return response_knowledge, response
    

    def chunk_content(self, content: str, max_token: int=SETTINGS.EVAL.TOKEN_LIMIT, overlap: int=10) -> list[str]:

        # Token Check
        tokenizer  = tiktoken.encoding_for_model("text-embedding-ada-002")

        # Tokenize the long string
        tokens = tokenizer .encode(content)
        
        chunks = []
        while start < len(tokens):
            end = start + max_token
            chunk_tokens = tokens[start:end]
            chunk = tokenizer.decode(chunk_tokens)
            chunks.append(chunk)

            # Move the start index forward by (max_token - overlap) for the next chunk
            start += (max_token - overlap)

        return chunks


    # def knowledge_relationship_pipeline(self, request: KnowledgeRelationshipRequest) -> tuple[KnowledgeRelationshipResponse | None, Response]:
    #     logger.info("Processing : Start Knowledge Relationship Extraction")
    #     response_knowledge = KnowledgeRelationshipResponse(**request.__dict__, knowledge_total_no=len(request.knowledge_ids))
    #     start_at = time.time()

    #     """ 1. Knowledge Relationship Check """
    #     # Check if Empty Ingestion
    #     if not request.knowledge_ids:
    #         response = Response(status_code=404, detail=self.response_format.error(f"Knowledge Ingestion Error : <{SETTINGS.BASE.APP_NAME}> Found Empty <knowledge_ids>"))
    #         logger.error(response.detail)
    #         return response_knowledge, response
        
    #     """ 2. Start Processing Relationship Extraction """
    #     _knowledge_success_objects = []
    #     _knowledge_fail_objects    = []
    #     for i, knowledge_id in enumerate(request.knowledge_ids, start=1):
    #         logger.info(f"Processing <{i} / {len(request.knowledge_ids)}> Knowledge for Relationship Extraction ...")
    #         process_start_at = time.time()

    #         knowledgerelationship_object = KnowledgeRelationshipObject(
    #             knowledge_sequence=i, 
    #             knowledge_id=knowledge_id
    #         )

    #         """ 3. Retrieve Knowledge Metadata """
    #         logger.info("Processing : Retrieving Knowledge Metadata")
    #         metadata_request = SystemKnowledgeRequest(
    #             data_filter=KnowledgeFilter(
    #                 string_filter=KnowledgeStringFilter(knowledge_id_filter=[knowledge_id])
    #             )
    #         )
    #         try:
    #             response_metadata  = system_query_knowledge(request=metadata_request, api_call=self.api_call)
    #             # knowledge_metadata = response_metadata.filtered_data[0]
    #         except Exception as e:
    #             response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Retrieval Failed : <{SETTINGS.BASE.APP_NAME}> Metadata Retrieval Error", str(e)))
    #             knowledgerelationship_object.knowledge_reason = response.detail
    #             _knowledge_fail_objects.append(knowledgerelationship_object)
    #             logger.error(response.detail)
    #             continue

    #         if response_metadata.data_count == 0:
    #             response = Response(status_code=404, detail=self.response_format.error(f"Failed to Extraction Relationship : <{SETTINGS.BASE.APP_NAME}> Cannot Found Matched Knowledge Metedata"))
    #             logger.error(response.detail)
    #             continue
            
    #         """ 4. Retrieve Knowledge Vectors """
    #         logger.info("Processing : Retrieving Knowledge Vectors")
    #         vector_request = SystemVectorRequest(
    #             vector_filter=VectorFilter(
    #                 string_filter=VectorStringFilter(knowledge_id_filter=[knowledge_id])
    #             )
    #         )
    #         try:
    #             response_vector   = system_query_vector(request=vector_request, api_call=self.api_call)
    #             knowledge_vectors = response_vector.filtered_vectors
    #             logger.info(f"Processing : Retrieved <{len(knowledge_vectors)}> Vectors")
    #         except Exception as e:
    #             response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Vector Retrieval Failed : <{SETTINGS.BASE.APP_NAME}> Vector Retrieval Error", str(e)))
    #             knowledgerelationship_object.knowledge_reason = response.detail
    #             _knowledge_fail_objects.append(knowledgerelationship_object)
    #             logger.error(response.detail)
    #             continue

    #         if len(knowledge_vectors) == 0:
    #             knowledgerelationship_object.knowledge_reason = "Failed to Retrieve Vectors for Relationship Generation"
    #             _knowledge_fail_objects.append(knowledgerelationship_object)
    #             logger.error(knowledgerelationship_object.knowledge_reason)
    #             continue 

    #         """" 5.  Relationship Extraction """
    #         logger.info("Processing : Extracting Relationship")
    #         knowdataobjects   = [KnowDataObject(**{k: v for k, v in _knowledge_vector.__dict__.items() if k != "processed_data"}) for _knowledge_vector in knowledge_vectors]
    #         prepmedia_request = PrepMediaPipelineRequest(**request.__dict__, prepmedia_input = knowdataobjects)
    #         response_data, response = self.preprocess_relationship(request=prepmedia_request)
    #         if response.status_code >= SETTINGS.STAT.SUCC_CODE_END:
    #             knowledgerelationship_object.knowledge_reason = response.detail
    #             _knowledge_fail_objects.append(knowledgerelationship_object)
    #             continue
    #         elif not response_data.prepmedia_relationship:
    #             knowledgerelationship_object.knowledge_reason = "Failed to Classify Any Relationships"
    #             _knowledge_fail_objects.append(knowledgerelationship_object)                
    #         else:
    #             graph_object = response_data.prepmedia_relationship

    #         """ 6. Register Relationship on GraphDB """
    #         logger.info("Processing : Registering Relationship on GraphDB")
    #         gb_container_name = SETTINGS.GPDB.CONTAINER
    #         graph_create_request = GraphCreateRequest(
    #             **request.__dict__, 
    #             container_name=gb_container_name,
    #             partition_key=knowledge_id,
    #             data=GraphCreate(
    #                 nodes=[NodeCreate(**_node.__dict__) for _node in graph_object.nodes],
    #                 edges=[EdgeCreate(**_edge.__dict__) for _edge in graph_object.edges]
    #             )
    #         )

    #         try:
    #             response = general_condition_drop_graph(
    #                 request=GraphUpdateRequest(
    #                     container_name=gb_container_name,
    #                     partition_key=knowledge_id
    #                 )
    #             )

    #             response = general_create_graph(request=graph_create_request, api_call=self.api_call)

    #         except Exception as e:
    #             response = Response(status_code=500, detail=self.response_format.error(f"Graph Creation Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Graph Creation Error", str(e)))
    #             knowledgerelationship_object.knowledge_reason = response.detail
    #             _knowledge_fail_objects.append(knowledgerelationship_object)
    #             logger.error(response.detail)
    #             continue

    #         except:
    #             response = Response(status_code=500, detail=self.response_format.error(f"Graph Creation Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Graph Creation Failed"))
    #             knowledgerelationship_object.knowledge_reason = response.detail
    #             _knowledge_fail_objects.append(knowledgerelationship_object)
    #             logger.error(response.detail)
    #             continue

    #         """ 7. Update Vector DB """
    #         logger.info("Processing : Updating Vecotr on VectorDB")
    #         vector_update_requests = []
    #         for i, _knowledge_vector in enumerate(knowledge_vectors):
    #             matched_objects = [_data for _data in graph_object.nodes if _data.data_id == _knowledge_vector.data_id]
    #             if not matched_objects:
    #                 continue
    #             update_data = VectorUpdate(
    #                 node_id   = matched_objects[0].node_id, 
    #                 node_type = matched_objects[0].node_type
    #             )
    #             vector_update_requests.append(
    #                 VectorUpdateRequest(
    #                     data_id     = _knowledge_vector.data_id, 
    #                     update_data = update_data,
    #                     overwrite   = True
    #                 )
    #             )

    #         if vector_update_requests:
    #             for _request in vector_update_requests:
    #                 try:
    #                     response = general_update_vector(request=_request, api_call=self.api_call)
    #                 except Exception as e:
    #                     response = Response(status_code=500, detail=self.response_format.error(f"Vector Update Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Vector Update Failed <data_id: {_request.data_id}>", str(e)))
    #                     logger.error(response.detail)      
    #                     continue
    #         else:
    #             response = Response(status_code=500, detail=self.response_format.error(f"Vector Update Unfound Error : <{SETTINGS.BASE.APP_NAME}> Vector Update Failed"))
    #             knowledgerelationship_object.knowledge_reason = response.detail
    #             _knowledge_fail_objects.append(knowledgerelationship_object)
    #             logger.error(response.detail)
    #             continue

    #         """ 8. Update Metadata DB """
    #         logger.info("Processing : Updating MetadataDB")
    #         update_data = KnowledgeUpdate(
    #             knowledge_graphstorage=SETTINGS.GPDB.FORM,
    #             knowledge_graphlocation=SETTINGS.GPDB.LOCA,
    #             knowledge_graphinfo={
    #                 "db_name":   SETTINGS.GPDB.NAME, 
    #                 "container": gb_container_name
    #             }
    #         )

    #         metadata_update_request = KnowledgeUpdateRequest(
    #             knowledge_id=knowledge_id,
    #             update_data=update_data,
    #             overwrite=True
    #         )
    #         try:
    #             response = general_update_knowledge(request=metadata_update_request, api_call=self.api_call)
    #         except Exception as e:
    #             response = Response(status_code=500, detail=self.response_format.error(f"Knowledge Update Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Knowledge Update Failed <knowledge_id: {knowledge_id}>", str(e)))
    #             knowledgerelationship_object.knowledge_reason = response.detail
    #             _knowledge_fail_objects.append(knowledgerelationship_object) 
    #             logger.error(response.detail)
    #             continue

    #         knowledgerelationship_object.knowledge_code = SETTINGS.KNOW.STATUS_CODE.get("SUCCESS", "200")
    #         knowledgerelationship_object.knowledge_reason = 'SUCCESS'
    #         _knowledge_success_objects.append(knowledgerelationship_object)

    #     """ 9. Update Final Response """
    #     logger.info("Processing : Preparing Final Response")
    #     response_knowledge.__dict__.update(
    #         knowledge_success_objects   = _knowledge_success_objects,
    #         knowledge_fail_objects      = _knowledge_fail_objects,
    #         knowledge_total_no          = len(request.knowledge_ids),
    #         knowledge_success_no        = len(_knowledge_success_objects),
    #         knowledge_fail_no           = len(_knowledge_fail_objects),
    #         knowledge_relationship_time = time.time() - start_at,
    #         knowledge_response_at       = datetime.now(timezone.utc)
    #     )
    #     response = Response(status_code=200, detail=self.response_format.ok(f"Relationship Extraction Completed : <{SETTINGS.BASE.APP_NAME}> Completed Relationship Extraction"))
    #     return response_knowledge, response
    
    def preprocess_relationship(self, request: PrepMediaPipelineRequest) -> tuple[PrepMediaPipelineResponse, Response]:
        response_data = PrepMediaPipelineResponse(**request.__dict__)

        try:
            # API Call
            if self.api_call == True:
                api_url = f"http://{SETTINGS.PREP.HOST}:{SETTINGS.PREP.PORT}/{SETTINGS.PREP.REQUEST_PREPMEDIA_API}"
                payload = request.json()
                response_data, response = self.api_call_static(data=payload, service="KnowledgeHub", api_url=api_url, method="post", timeout=SETTINGS.BASE.APP_TIMEOUT)
                response_data = PrepMediaPipelineResponse(**response_data)
                if response.status_code < SETTINGS.STAT.SUCC_CODE_END:
                    response_data = response_data.json()
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Relationship Preprocessing via API"))
                    logger.info(response.detail)

            # Function Call
            else:   
                try:
                    response_data = request_exec_prepmedia(request=request, api_call=False)
                    response_data = PrepMediaPipelineResponse(**response_data.__dict__)
                    response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed Relationship Preprocessing via Function Call"))
                    logger.info(response.detail)
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Function Retrieval Error : <{SETTINGS.BASE.APP_NAME}> Failed to Complete Relationship Preprocessing via Function Call", str(e)))
                    logger.error(response.detail)
            
        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing Relationship", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Preprocessing RelationshipInput"))
            logger.error(response.detail)

        return response_data, response
        # try:
        #     request_registration = RelationshipCreateRequest(**request.__dict__, data=response_data.prepmedia_relationship)
        #     response = general_create_relationship(request=request_registration, gb_api=self.gb_api, api_call=self.api_call)
        #     response = Response(status_code=200, detail=self.response_format.ok(f"Success : <{SETTINGS.BASE.APP_NAME}> Completed & Relationship Preprocessing and Stored via Function Call"))
        #     logger.info(response.detail)

        # # Handle common exceptions that might occur
        # except (BaseException, Exception) as e:
        #     response = Response(status_code=500, detail=self.response_format.error(f"Common Error : <{SETTINGS.BASE.APP_NAME}> Storing Relationship", str(e)))
        #     logger.error(response.detail)

        # # Handle any other exceptions that might occur
        # except:
        #     response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : <{SETTINGS.BASE.APP_NAME}> Storing RelationshipInput"))
        #     logger.error(response.detail)

        # return response_data, response
    

    def api_call_static(self, data, service: str, api_url: str, method: str, timeout: float | None) -> tuple[httpx.Response | None, Response]:
        response_data = None

        try:
            if method.lower() == "post":

                if isinstance(data, str):
                    if timeout:
                        resp = httpx.post(api_url, data=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, data=data)

                else:
                    if timeout:
                        resp = httpx.post(api_url, json=data, timeout=timeout)
                    else:
                        resp = httpx.post(api_url, json=data)

            else:
                response = Response(status_code=500, detail=self.response_format.error(f"API Method Error : Unknown API Method <{method}>"))
                logger.error(response.detail)
                return response_data, response

            if not resp.status_code == httpx.codes.ok:
                response = Response(status_code=resp.status_code, detail=self.response_format.error(f"Response Error : Retrieving Data from <{service}> API Server", resp["detail"]))
                logger.error(response.detail)
            
            else:
                response = Response(status_code=resp.status_code, detail=self.response_format.ok(f"Success : Retrieved Data from <{service}> API Server"))
                response_data = resp

        except httpx.TimeoutException as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Timeout Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        except httpx.HTTPError as e:
            response = Response(status_code=502, detail=self.response_format.error(f"Connection Error : Retrieving Data <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle common exceptions that might occur
        except (BaseException, Exception) as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Common Error : Connecting to <{service}> API Server", str(e)))
            logger.error(response.detail)

        # Handle any other exceptions that might occur
        except:
            response = Response(status_code=500, detail=self.response_format.error(f"Unexpected Error : Connecting to <{service}> API Server"))
            logger.error(response.detail)

        return response_data, response