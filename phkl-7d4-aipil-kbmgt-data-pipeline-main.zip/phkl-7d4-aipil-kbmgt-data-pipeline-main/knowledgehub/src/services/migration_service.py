import inspect
from datetime import datetime, timezone
import time
import os
import shutil
from typing import Generator
import uuid
import httpx
import math

from ..settings import SETTINGS
from ..utils import (
    check_and_download_blob_by_url,
    get_blob_path
)

from ..schemas.format import (
    ResponseFormatter,
    Response,
    ComplexEncoder
)

from ..schemas.knowledge import (
    KnowledgeExportRequest,
    IOConfig as KnowledgeIOConfig,
    SystemKnowledgeRequest,
    KnowledgeCreate
)

from ..schemas.vector import (
    VectorExportRequest,
    IOConfig as VectorIOConfig,
    SystemVectorRequest,
    VectorCreate
)


from ..routers.request_graph import (
    general_read_knowledge_graph,
    KnowledgeGraphRequest
)

from ..schemas.graph import (
    NodeCreate,
    EdgeCreate
)

from ..schemas.evaluation import (
    SeedQnACreate,
    QnACreate,
    EvaluationCreate,
    SeedQnAFilter,
    QnAFilter,
    EvaluationFilter
)

from ..schemas.migration import (
    DBMigrationExportRequest,
    VBMigrationExportRequest,
    BlobMigrationExportRequest,
    GBMigrationExportRequest
)

from ..database.registry.schemas.knowledge import (
    SystemKnowledgeRequest,
    KnowledgeFilter,
    KnowledgeNumericFilter
)

from ..database.metadata.schemas.metadata import (
    SystemMetadataRequest,
    MetadataFilter,
    MetadataCreate
)

from ..database.registry.schemas.keyword_mapping import KeywordMappingCreate, KeywordMappingFilter

from ..migration.migration_db.schemas.migration import BatchMigrateRequest as DBBatchMigrateRequest
from ..migration.migration_vb.schemas.migration import BatchMigrateRequest as VBBatchMigrateRequest
from ..migration.migration_blob.schemas.migration import BatchMigrateRequest as BlobBatchMigrateRequest, FileConfig
from ..migration.migration_gb.schemas.migration import BatchMigrateRequest as GBBatchMigrateRequest

from ..routers.registry.system import (
    system_query_knowledge,
    system_query_keyword_mapping,
    SystemKMRequest
)

from ..routers.registry.io import system_export_knowledge

from ..routers.metadata.system import system_query_metadata

from ..routers.request_evaluation import (
    system_query_seedqna,
    SystemSeedQnARequest,
    system_query_qna,
    SystemQnARequest,
    system_query_evaluation,
    SystemEvaluationRequest
)

from ..routers.vector.system import system_query_vector, system_partition_vector
from ..routers.vector.io import system_export_vector

from ..routers.graph.system import system_query_graph

from ..database.vector.connections.io_connection import init_ex_index


# API DB Session
if SETTINGS.BASE.APP_API == True:
    default_api_call = True
else:
    default_api_call = False


from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class MigrationManager:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")
    blob_url_prefix = f"https://{SETTINGS.BBEX.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BBEX.CONTAINER_NAME}/"
    metadata_blob_url_prefix = f"https://{SETTINGS.BBEX.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BBEX.METADATA_CONTAINER_NAME}/"

    def __init__(
            self, 
            api_call: bool = default_api_call
        ):
        self.api_call = api_call

    def export_db_by_partition(self, request: DBMigrationExportRequest) -> Response:
        logger.info("Processing : Started DB Migration")

        if request.method.upper() == "DB":

            try:
                response = system_export_knowledge(
                    request=KnowledgeExportRequest(
                        data_filter=KnowledgeFilter(**request.data_filter),
                        io_config = KnowledgeIOConfig(
                            format="MODB",
                            table=request.meta.get("collection", "data_export")
                        ),
                        include_datetime=False
                    ),
                    api_call=False
                )
            
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Export", str(e)))
                logger.error(response.detail)
                return response
        
        elif request.method.upper() == "API":
            if request.migration_type == "knowledge":
                try:
                    response_knowledge = system_query_knowledge(
                        request = SystemKnowledgeRequest(
                            data_filter=KnowledgeFilter(**request.data_filter)
                        ),
                        api_call=False
                    )
                    data = [KnowledgeCreate(**_data.__dict__).__dict__ for _data in response_knowledge.filtered_data]
                #     request.meta['indexes'] = [
                #     'knowledge_name',
                #     'knowledge_version',
                #     'knowledge_ingestion_stage',
                #     'knowledge_processing_stage',
                #     'batch_order',
                #     'library_name_en',
                #     'library_name_tc',
                #     'category_name_en',
                #     'category_name_tc',
                #     'title_name_en',
                #     'title_name_tc',
                #     'item_type',
                #     'item_status',
                #     'document_id',
                #     'file_name',
                #     'file_created_datetime',
                #     'file_last_modified_datetime',
                #     'group_id',
                #     'library_id',
                #     'category_id',
                #     'reference_start_date',
                #     'reference_end_date',
                #     'updated_by',
                #     'retention_at',
                #     'pil_active_status',
                #     'knowledge_group',
                #     'knowledge_type',
                #     'knowledge_status',
                #     'knowledge_filename',
                #     'knowledge_fileextension',
                #     'knowledge_filesize',
                #     'knowledge_issue_date',
                #     'knowledge_effective_from',
                #     'knowledge_effective_to',
                #     'created_at',
                #     'updated_at',
                #     {"fields": ['knowledge_id'], 'unique': True}
                # ]

                    request.meta['indexes'] = [
                        'knowledge_name',
                        'knowledge_version',
                        'knowledge_ingestion_stage',
                        'knowledge_processing_stage',
                        'batch_order',
                        'library_name_en',
                        'library_name_tc',
                        'category_name_en',
                        'category_name_tc',
                        'title_name_en',
                        'title_name_tc',
                        'item_type',
                        'item_status',
                        'document_id',
                        'file_name',
                        'file_created_datetime',
                        'file_last_modified_datetime',
                        'group_id',
                        'library_id',
                        'category_id',
                        'reference_start_date',
                        'reference_end_date',
                        'updated_by',
                        'retention_at',
                        'pil_active_status',
                        'knowledge_group',
                        'knowledge_type',
                        'knowledge_status',
                        'knowledge_filename',
                        'knowledge_fileextension',
                        'knowledge_filesize',
                        'knowledge_issue_date',
                        'knowledge_effective_from',
                        'knowledge_effective_to',
                        'created_at',
                        'updated_at',
                        {"fields": ['knowledge_id'], 'unique': True}
                    ]

                    # Conversion Logic Here
                    for _data in data:
                        # if _data.get("knowledge_vectorinfo", {}).get("index_name", None):                        
                        #     _data.get("knowledge_vectorinfo")["index_name"] = "ai-pil-uat-v1"
                        # if _data.get("storage_directory"):
                        #     _data["storage_directory"] = self.get_new_blob_url(blob_url=_data["storage_directory"], migration_type="knowledge")
                        # if _data.get("storage_directory_origin"):
                        #     _data["storage_directory_origin"] = self.get_new_blob_url(blob_url=_data["storage_directory_origin"], migration_type="knowledge")
                        # if _data.get("file_sync_up_url"):
                        #     _data["file_sync_up_url"] = _data["file_sync_up_url"].replace("stahklifedevaz2z5oxk5002", SETTINGS.BBEX.ACCOUNT_NAME)
                        # if _data.get("knowledge_graphinfo") and _data["knowledge_graphinfo"].get("container"):
                        #     _data["knowledge_graphinfo"]["container"] = "ai-pil-uat-v1"

                        _data["knowledge_ingestion_stage"] = "Ingested for Review"
                        _data["average_groundedness"] = 0.0
                        _data["average_relevance"] = 0.0
                        _data["average_retrieval"] = 0.0
                        _data["average_similarity"] = 0.0
                        _data["knowledge_processing_reason"] = "Ingested for Review"

                        for key, value in _data.items():
                            if key in [
                            "file_created_datetime",
                            "file_last_modified_datetime",
                            "reference_start_date",
                            "reference_end_date",
                            "knowledge_issue_date",
                            "retention_at",
                            "knowledge_effective_from",
                            "knowledge_effective_to",
                            "created_at",
                            "updated_at"
                            ]:
                                _data[key] = value.strftime('%Y-%m-%dT%H:%M:%S.%f')

                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                    logger.error(response.detail)
                    return response
                
            elif request.migration_type == "keyword_mapping":
                try:
                    response_kw = system_query_keyword_mapping(
                        request = SystemKMRequest(
                            data_filter=KeywordMappingFilter(**request.data_filter)
                        ),
                        api_call=False
                    )

                    data = [KeywordMappingCreate(**_data.__dict__).__dict__ for _data in response_kw.filtered_data]

                    request.meta['indexes'] = [
                        {"fields": ['mapping_id'], 'unique': True}
                        ]
                    
                    # Conversion Logic Here
                    for _data in data:
                        for key, value in _data.items():
                            if key in [
                            "created_at",
                            "updated_at"
                            ]:
                                _data[key] = value.strftime('%Y-%m-%dT%H:%M:%S.%f')

                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                    logger.error(response.detail)
                    return response

            elif request.migration_type == "seed_qna":
                try:
                    _response_data = system_query_seedqna(
                        request = SystemSeedQnARequest(
                            data_filter=SeedQnAFilter(**request.data_filter)
                        )
                    )
                    data = [SeedQnACreate(**_data.__dict__).__dict__ for _data in _response_data.filtered_data]
                
                    request.meta['indexes'] = [
                        'seed_qna_version',
                        'batch_order',
                        'knowledge_id',
                        'knowledge_version',
                        'library_name_en',
                        'seed_qna_status',
                        'qna_query_language',
                        'qna_response_language',
                        'created_at',
                        'updated_at',
                        {"fields": ['seed_qna_id'], 'unique': True}
                        ]
                    
                    # Conversion Logic Here
                    for _data in data:
                        for key, value in _data.items():
                            if key in [
                            "created_at",
                            "updated_at"
                            ]:
                                _data[key] = value.strftime('%Y-%m-%dT%H:%M:%S.%f')

                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                    logger.error(response.detail)
                    return response

            elif request.migration_type == "qna":
                try:
                    _response_data = system_query_qna(
                        request = SystemQnARequest(
                            data_filter=QnAFilter(**request.data_filter)
                        )
                    )
                    data = [QnACreate(**_data.__dict__).__dict__ for _data in _response_data.filtered_data]
                
                    request.meta['indexes'] = [
                        'qna_version',
                        'seed_qna_id',
                        'seed_qna_version',
                        'batch_order',
                        'knowledge_id',
                        'knowledge_version',
                        'document_name',
                        'qna_status',
                        'qna_query_language',
                        'qna_response_language',
                        'created_at',
                        'updated_at',
                        {"fields": ['qna_id'], 'unique': True}
                        ]
                    # Conversion Logic Here
                    for _data in data:
                        for key, value in _data.items():
                            if key in [
                            "created_at",
                            "updated_at"
                            ]:
                                _data[key] = value.strftime('%Y-%m-%dT%H:%M:%S.%f')

                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                    logger.error(response.detail)
                    return response

            elif request.migration_type == "evaluation":
                try:
                    _response_data = system_query_evaluation(
                        request = SystemEvaluationRequest(
                            data_filter=EvaluationFilter(**request.data_filter)
                        )
                    )
                    data = [EvaluationCreate(**_data.__dict__).__dict__ for _data in _response_data.filtered_data]
                
                    request.meta['indexes'] = [
                        'evaluation_version',
                        'batch_order',
                        'knowledge_id',
                        'knowledge_version',
                        'document_name',
                        'evaluation_status',
                        'qna_id',
                        'qna_query_language',
                        'qna_response_language',
                        'actual_language',
                        'similarity',
                        'relevance',
                        'groundedness',
                        'retrieval',
                        'input_tokens',
                        'output_tokens',
                        'tool_tokens',
                        'response_time',
                        'evaluation_code',
                        'evaluation_time',
                        'created_at',
                        'updated_at',
                        {"fields": ['evaluation_id'], 'unique': True}
                        ]
                    # Conversion Logic Here
                    for _data in data:
                        for key, value in _data.items():
                            if key in [
                            "created_at",
                            "updated_at"
                            ]:
                                _data[key] = value.strftime('%Y-%m-%dT%H:%M:%S.%f')
                    
                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                    logger.error(response.detail)
                    return response
            
            elif request.migration_type == "metadata":
                try:
                    _response_data = system_query_metadata(
                        request = SystemMetadataRequest(
                            data_filter=MetadataFilter(**request.data_filter)
                        ),
                        api_call=False
                    )
                    data = [MetadataCreate(**_data.__dict__).__dict__ for _data in _response_data.filtered_data]
                
                    request.meta['indexes'] = [
                        'library_id',
                        'category_id',
                        'document_id',
                        'file_nm',
                        {"fields": ['file_id'], 'unique': True}
                    ]

                    # Conversion Logic Here
                    for _data in data:
                        if _data.get("file_sync_url_to"):
                            _data["file_sync_url_to"] = self.get_new_blob_url(blob_url=_data["file_sync_url_to"], migration_type="metadata")
                        if _data.get("file_sync_url_from"):
                            _data["file_sync_url_from"] = self.get_new_blob_url(blob_url=_data["file_sync_url_from"], migration_type="metadata")
                        
                        for key, value in _data.items():
                            if key in [
                            "file_created_dt",
                            "file_lastmodified_dt",
                            "file_launch_dt",
                            "file_expiry_eff_dt",
                            "file_archive_dt"
                            ]:
                                _data[key] = value.strftime('%Y-%m-%dT%H:%M:%S.%f')

                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                    logger.error(response.detail)
                    return response
                
            ### End of Custom Logic


            total_data_count = len(data)
            batch_count = math.ceil(total_data_count / SETTINGS.EXPT.BATCH_SIZE)
            logger.info(f"Exporting Data : Detected <{total_data_count}> Data. Divided into <{batch_count}> Batches with <{SETTINGS.EXPT.BATCH_SIZE}> Each for Processing")

            try:

                for batch_index, i in enumerate(range(0, total_data_count, SETTINGS.EXPT.BATCH_SIZE), start=1):
                    logger.info(f"Exporting Data to Migration DB : <{batch_index} / {batch_count}> Batch")
                    migration_request = DBBatchMigrateRequest(
                        **request.__dict__,
                        data = data[i : i + SETTINGS.EXPT.BATCH_SIZE]
                    )

                    # Call API
                    api_url = f"{SETTINGS.EXPT.EXPORT_URL}/{SETTINGS.EXPT.EXPORT_API}"
                    payload = migration_request.json()

                    try:
                        resp = httpx.post(api_url, data=payload, verify=SETTINGS.BASE.APP_PRODUCTION, timeout=SETTINGS.BASE.APP_TIMEOUT)
                        resp.raise_for_status()
                        response = Response(status_code=201, detail=self.response_format.ok(f"Migrated <{batch_index} / {batch_count}> Batch Data via API"))
                        logger.info(response.detail)
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Exporting <{batch_index} / {batch_count}> Batch Data", str(e)))
                        logger.error(response.detail)
                        return response
                    time.sleep(3)
                    logger.info(f"[Data Export Batch <{batch_index}>] Success")

                response = Response(status_code=201, detail=self.response_format.ok(f"Success : Exporting All <{len(data)}> Data"))
                logger.info(response.detail)

            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Calling Import API", str(e)))
                logger.error(response.detail)
                return response
            
        return response


    def export_vb_by_partition(self, request: VBMigrationExportRequest) -> Response:
        logger.info("Processing : Started VB Migration")

        if request.method.upper() == "DB":
        
            try:
                response = system_export_vector(
                    request=VectorExportRequest(
                        vector_filter=request.vector_filter,
                        io_config = VectorIOConfig(
                            format="AISEARCH",
                            location="azure",
                            name="AISEARCH",
                            table=request.vb_config.table_name
                        ),
                        include_datetime=False
                    ),
                    api_call=False
                )
            
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Export", str(e)))
                logger.error(response.detail)
                return response
        
        elif request.method.upper() == "API":
            
            try:
                vector_filter = request.vector_filter
                vector_filter.batch_index = -1
                response_vector = system_query_vector(
                    request = SystemVectorRequest(
                        vector_filter=vector_filter
                    ),
                    api_call=False
                )
            
            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                logger.error(response.detail)
                return response

            data_count = response_vector.vector_no

            if data_count <= 0:
                response = Response(status_code=200, detail=self.response_format.ok("Export Completed : No Matched Data for Export"))
                logger.info(response.detail)
                return response

            if request.vector_filter.batch_size < 0:
                batch_size = data_count
            else:
                batch_size = SETTINGS.VTEX.BATCH_SIZE

            batch_count = math.ceil(data_count / batch_size)

            logger.info(f"Detected <{data_count}> Data and Divided into <{batch_count}> Batches. Each Batch Contains <{batch_size}> Data")
            if request.vector_filter.batch_index <= 0:
                range_start = 1
                range_end   = batch_count + 1
            else:
                range_start = request.vector_filter.batch_index
                range_end   = request.vector_filter.batch_index + 1

            for _i, _batch_index in enumerate(range(range_start, range_end), start=1):
                logger.info(f"Export In Progress : Processing <{_i} / {len(range(range_start, range_end))}> Batch")
                vector_filter = request.vector_filter
                vector_filter.__dict__.update(
                    **{
                        "batch_index": _batch_index,
                        "batch_size": batch_size
                    }
                )

                try:
                    response_vector = system_query_vector(
                        request = SystemVectorRequest(
                            vector_filter=vector_filter
                        ),
                        api_call=False
                    )

                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Query Data in <{_i} / {len(range(range_start, range_end))}> Batch", str(e)))
                    logger.error(response.detail)
                    return response
        
                data = [VectorCreate(**_vector.__dict__).__dict__ for _vector in response_vector.filtered_vectors]

                # Conversion Logic
                for _data in data:
                    if _data.get("data_url"):
                        _data["data_url"] = self.get_new_blob_url(blob_url=_data["data_url"], migration_type="vector")

                migration_request = VBBatchMigrateRequest(
                    **request.__dict__,
                    table_name = request.vb_config.table_name,
                    data       = data
                )

                # Call API
                api_url = f"{SETTINGS.VTEX.EXPORT_URL}/{SETTINGS.VTEX.EXPORT_API}"
                payload = migration_request.json()

                try:
                    resp = httpx.post(api_url, data=payload, verify=SETTINGS.BASE.APP_PRODUCTION, timeout=SETTINGS.BASE.APP_TIMEOUT)
                    resp.raise_for_status()
                    response = Response(status_code=201, detail=self.response_format.ok(f"Migrated <{len(data)}> Data via API"))
                    logger.info(response.detail)

                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Export via API", str(e)))
                    logger.error(response.detail)
                    return response
        
                time.sleep(1)
        else:
            response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Found Invalid Export Method"))
            logger.error(response.detail)
            return response

        return response
    

    def export_gb_by_partition(self, request: GBMigrationExportRequest) -> Response:
        logger.info("Processing : Started GB Migration")

        if request.method.upper() == "API":

            try:
                response_graph = general_read_knowledge_graph(
                    request = KnowledgeGraphRequest(
                        knowledge_id=request.knowledge_id
                    )
                )

            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                logger.error(response.detail)
                return response

            nodes = [NodeCreate(**_node.__dict__).__dict__ for _node in response_graph.filtered_data.nodes]
            edges = [EdgeCreate(**{k: v for k, v in _edge.__dict__.items() if k != 'knowledge_id'}, knowledge_id=nodes[0].get("knowledge_id")).__dict__ for _edge in response_graph.filtered_data.edges]

            if not nodes or not edges:
                response = Response(status_code=200, detail=self.response_format.ok("Export Completed : No Matched Data for Export"))
                logger.info(response.detail)
                return response
            
            node_count = len(nodes)
            total_data_count = node_count
            batch_count = math.ceil(total_data_count / SETTINGS.GPEX.BATCH_SIZE)
            logger.info(f"Exporting Data : Detected <{total_data_count}> Node. Divided into <{batch_count}> Batches with <{SETTINGS.GPEX.BATCH_SIZE}> Each for Processing")

            try:

                for batch_index, i in enumerate(range(0, total_data_count, SETTINGS.GPEX.BATCH_SIZE), start=1):
                    logger.info(f"Exporting Node to Migration DB : <{batch_index} / {batch_count}> Batch")
                    migration_request = GBBatchMigrateRequest(
                        **request.__dict__,
                        graph_uid_field="knowledge_id",
                        graph_uid_value=request.knowledge_id,
                        data = {"nodes": nodes[i : i + SETTINGS.GPEX.BATCH_SIZE]}
                    )

                    # Call API
                    api_url = f"{SETTINGS.GPEX.EXPORT_URL}/{SETTINGS.GPEX.EXPORT_API}"
                    payload = migration_request.json()

                    try:
                        resp = httpx.post(api_url, data=payload, verify=SETTINGS.BASE.APP_PRODUCTION, timeout=SETTINGS.BASE.APP_TIMEOUT)
                        resp.raise_for_status()
                        response = Response(status_code=201, detail=self.response_format.ok(f"Migrated <{batch_index} / {batch_count}> Batch Node via API"))
                        logger.info(response.detail)

                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Exporting <{batch_index} / {batch_count}> Batch Node", str(e)))
                        logger.error(response.detail)
                        return response
                    time.sleep(SETTINGS.GPDB.CREATE_WAIT_SEC)
                    logger.info(f"[Node Export Batch <{batch_index}>] Success")

                response = Response(status_code=201, detail=self.response_format.ok(f"Success : Exporting All <{len(nodes)}> Node"))
                logger.info(response.detail)

            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Calling Import API", str(e)))
                logger.error(response.detail)
                return response
    
            edge_count = len(edges)
            total_data_count = edge_count
            batch_count = math.ceil(total_data_count / SETTINGS.GPEX.BATCH_SIZE)
            logger.info(f"Exporting Data : Detected <{total_data_count}> Edge. Divided into <{batch_count}> Batches with <{SETTINGS.GPEX.BATCH_SIZE}> Each for Processing")

            try:

                for batch_index, i in enumerate(range(0, total_data_count, SETTINGS.GPEX.BATCH_SIZE), start=1):
                    logger.info(f"Exporting Edge to Migration DB : <{batch_index} / {batch_count}> Batch")
                    migration_request = GBBatchMigrateRequest(
                        **request.__dict__,
                        graph_uid_field="knowledge_id",
                        graph_uid_value=request.knowledge_id,
                        data = {"edges": edges[i : i + SETTINGS.GPEX.BATCH_SIZE]}
                    )

                    # Call API
                    api_url = f"{SETTINGS.GPEX.EXPORT_URL}/{SETTINGS.GPEX.EXPORT_API}"
                    payload = migration_request.json()

                    try:
                        resp = httpx.post(api_url, data=payload, verify=SETTINGS.BASE.APP_PRODUCTION, timeout=SETTINGS.BASE.APP_TIMEOUT)
                        resp.raise_for_status()
                        response = Response(status_code=201, detail=self.response_format.ok(f"Migrated <{batch_index} / {batch_count}> Batch Edge via API"))
                        logger.info(response.detail)

                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Exporting <{batch_index} / {batch_count}> Batch Edge", str(e)))
                        logger.error(response.detail)
                        return response
                
                    logger.info(f"[Edge Export Batch <{batch_index}>] Success")

                response = Response(status_code=201, detail=self.response_format.ok(f"Success : Exporting All <{len(edges)}> Edge"))
                logger.info(response.detail)

            except Exception as e:
                response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Calling Import API", str(e)))
                logger.error(response.detail)
                return response
    

        else:
            response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Found Invalid Export Method"))
            logger.error(response.detail)
            return response

        return response


    async def export_blob_by_partition(self, request: BlobMigrationExportRequest) -> Response:
        logger.info("Processing : Started Blob Migration")

        if request.method.upper() == "DB":
            response = Response(status_code=200, detail=self.response_format.ok(f"Vector Json blob and image blob migration completed by exporting vector data via DB"))
            logger.info(response.detail)

        elif request.method.upper() == "API":
            migration_data = []
            migration_data_file = []
            local_dir = os.path.join(os.getcwd(), f"temp_blob_files_{str(uuid.uuid4())}") # avoid file name conflict when multiple jobs are running at the same time
            os.makedirs(local_dir, exist_ok=True)
            if request.migration_type == "knowledge":
                if 'IMAGE' in request.data_types or 'JSON' in request.data_types:
                    try:
                        vector_filter = request.vector_filter
                        vector_filter.batch_index = -1
                        response_vector = system_query_vector(
                            request = SystemVectorRequest(
                                vector_filter=vector_filter
                            ),
                            api_call=False
                        )
                    
                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                        logger.error(response.detail)
                        return response

                    data_count = response_vector.vector_no

                    if data_count <= 0:
                        response = Response(status_code=200, detail=self.response_format.ok("Export Completed : No Matched Data for Export"))
                        logger.info(response.detail)
                        return response

                    if request.vector_filter.batch_size < 0:
                        batch_size = data_count
                    else:
                        batch_size = SETTINGS.VTEX.BATCH_SIZE

                    batch_count = math.ceil(data_count / batch_size)

                    logger.info(f"Detected <{data_count}> Data and Divided into <{batch_count}> Batches. Each Batch Contains <{batch_size}> Data")
                    if request.vector_filter.batch_index <= 0:
                        range_start = 1
                        range_end   = batch_count + 1
                    else:
                        range_start = request.vector_filter.batch_index
                        range_end   = request.vector_filter.batch_index + 1

                    image_data = []
                    image_data_file = []
                    image_data_drop = []
                    json_data = []
                    json_data_file = []
                    json_data_drop = []
                    for _i, _batch_index in enumerate(range(range_start, range_end), start=1):
                        logger.info(f"Export In Progress : Processing <{_i} / {len(range(range_start, range_end))}> Batch")
                        vector_filter = request.vector_filter
                        vector_filter.__dict__.update(
                            **{
                                "batch_index": _batch_index,
                                "batch_size": batch_size
                            }
                        )

                        try:
                            response_vector = system_query_vector(
                                request = SystemVectorRequest(
                                    vector_filter=vector_filter
                                ),
                                api_call=False
                            )
                            vector_data = response_vector.filtered_vectors

                        except Exception as e:
                            response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed to Query Data in <{_i} / {len(range(range_start, range_end))}> Batch", str(e)))
                            logger.error(response.detail)
                            return response

                        # Prepare local files for upload
                        try:
                            for _data in vector_data:
                                if 'JSON' in request.data_types:
                                    json_blob_url = f"https://{SETTINGS.BLOB.ACCOUNT_NAME}.blob.core.windows.net/{SETTINGS.BLOB.CONTAINER_NAME}/{SETTINGS.BLOB.VECTOR_FOLDER_NAME}/{SETTINGS.VTDB.TABLE}/{_data.data_id}.json"
                                    if request.action.upper() != "DROP":
                                        # Download the file from the URL
                                        local_file_path = os.path.join(local_dir, f"{_data.data_id}.json")
                                        if os.path.exists(local_file_path):
                                            os.remove(local_file_path)
                                        if check_and_download_blob_by_url(blob_file_url=json_blob_url, local_path=local_file_path):
                                            json_data.append(FileConfig (
                                                    blob_path = f"{SETTINGS.BLOB.VECTOR_FOLDER_NAME}/{request.table_name}/{_data.data_id}.json",
                                                    file_type = "json"
                                            ))
                                            json_data_file.append(local_file_path)
                                    else:
                                        json_data_drop.append(FileConfig (
                                            blob_url = json_blob_url
                                        ))

                                if 'IMAGE' in request.data_types:
                                    if _data.data_url:
                                        if request.action.upper() != "DROP":
                                            # Download the file from the URL
                                            local_image_path = os.path.join(local_dir, _data.data_url.split("/")[-1])
                                            if os.path.exists(local_image_path):
                                                os.remove(local_image_path)
                                            if check_and_download_blob_by_url(blob_file_url=_data.data_url, local_path=local_image_path):
                                                image_data.append(FileConfig (
                                                        blob_path = get_blob_path(blob_url=_data.data_url),
                                                        file_type = "jpeg"
                                                ))
                                                image_data_file.append(local_image_path)
                                        else:
                                            image_data_drop.append(FileConfig (
                                                blob_url= _data.data_url
                                            ))

                        except Exception as e:
                            try:
                                if os.path.exists(local_dir):
                                    shutil.rmtree(local_dir)
                            except Exception as e:
                                logger.error(f"Error cleaning up temporary directory {local_dir}: {str(e)}")
                            
                            response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Preparing Data", str(e)))
                            logger.error(response.detail)
                            return response

                    if request.action.upper() != "DROP":
                        logger.info(f"Found <{len(json_data)}> JSON Data and <{len(image_data)}> Image Data for {request.action}")
                    else:
                        logger.info(f"Found <{len(json_data_drop)}> JSON Data and <{len(image_data_drop)}> Image Data for {request.action}")

                    # Upload/drop local/blob files to/from blob storage
                    if 'IMAGE' in request.data_types:
                        if request.action.upper() == "DROP":
                            migration_data.extend(image_data_drop)
                        else:
                            migration_data.extend(image_data)
                            migration_data_file.extend(image_data_file)

                    if 'JSON' in request.data_types:
                        if request.action.upper() == "DROP":
                            migration_data.extend(json_data_drop)
                        else:
                            migration_data.extend(json_data)
                            migration_data_file.extend(json_data_file)
                        
                if 'PDF' in request.data_types:
                    # Retrieve knowledge data from mongodb
                    pdf_data = []
                    pdf_data_file = []
                    pdf_data_drop = []
                    try:
                        response_knowledge = system_query_knowledge(
                            request = SystemKnowledgeRequest(
                                data_filter=KnowledgeFilter(**request.data_filter)
                            ),
                            api_call=False
                        )

                        know_data = response_knowledge.filtered_data

                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                        logger.error(response.detail)
                        return response
                    
                    try:
                        for _data in know_data:
                            if _data.storage_directory:
                                if request.action.upper() != "DROP":
                                    # Download the file from the URL
                                    file_name = _data.file_name
                                    if _data.file_name.endswith('.doc'):
                                       file_name = _data.file_name.replace('.doc', '.pdf')
                                    elif _data.file_name.endswith('.docx'):
                                       file_name = _data.file_name.replace('.docx', '.pdf')
                                    elif _data.file_name.endswith('.pptx'):
                                       file_name = _data.file_name.replace('.pptx', '.pdf') 
                                    local_file = os.path.join(local_dir, file_name)
                                    if os.path.exists(local_file):
                                        os.remove(local_file)
                                    if check_and_download_blob_by_url(blob_file_url=_data.storage_directory, local_path=local_file):
                                        pdf_data.append(FileConfig (
                                                blob_path = get_blob_path(blob_url=_data.storage_directory),
                                                file_type = "pdf"
                                        ))
                                        pdf_data_file.append(local_file)
                                else:
                                    pdf_data_drop.append(FileConfig (
                                        blob_url= _data.storage_directory
                                    ))

                    except Exception as e:
                        try:
                            if os.path.exists(local_dir):
                                shutil.rmtree(local_dir)
                        except Exception as e:
                            logger.error(f"Error cleaning up temporary directory {local_dir}: {str(e)}")
                        
                        response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Preparing Data", str(e)))
                        logger.error(response.detail)
                        return response
                    
                    if request.action.upper() != "DROP":
                        logger.info(f"Found <{len(pdf_data)}> PDF Data for {request.action}")
                    else:
                        logger.info(f"Found <{len(pdf_data_drop)}> PDF Data for {request.action}")

                    if request.action.upper() == "DROP":
                        migration_data.extend(pdf_data_drop)
                    else:
                        migration_data.extend(pdf_data)
                        migration_data_file.extend(pdf_data_file)

            elif request.migration_type == "metadata":
                if 'PDF' in request.data_types:
                    # Retrieve knowledge data from mongodb
                    pdf_data = []
                    pdf_data_file = []
                    pdf_data_drop = []
                    try:
                        response_metadata = system_query_metadata(
                            request = SystemMetadataRequest(
                                data_filter=MetadataFilter(**request.data_filter)
                            ),
                            api_call=False
                        )

                        meta_data = response_metadata.filtered_data

                    except Exception as e:
                        response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Query Data for Export", str(e)))
                        logger.error(response.detail)
                        return response
                    
                    try:
                        for _data in meta_data:
                            if _data.file_sync_url_from:
                                if request.action.upper() != "DROP":
                                    # Download the file from the URL
                                    local_file = os.path.join(local_dir, _data.file_nm)
                                    if os.path.exists(local_file):
                                        os.remove(local_file)
                                    if check_and_download_blob_by_url(blob_file_url=_data.file_sync_url_from, local_path=local_file):
                                        pdf_data.append(FileConfig (
                                                blob_path = get_blob_path(blob_url=_data.file_sync_url_from),
                                                file_type = "pdf"
                                        ))
                                        pdf_data_file.append(local_file)
                                else:
                                    pdf_data_drop.append(FileConfig (
                                        blob_url= _data.file_sync_url_from
                                    ))

                    except Exception as e:
                        try:
                            if os.path.exists(local_dir):
                                shutil.rmtree(local_dir)
                        except Exception as e:
                            logger.error(f"Error cleaning up temporary directory {local_dir}: {str(e)}")
                        
                        response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Preparing Data", str(e)))
                        logger.error(response.detail)
                        return response
                    
                    if request.action.upper() != "DROP":
                        logger.info(f"Found <{len(pdf_data)}> PDF Data for {request.action}")
                    else:
                        logger.info(f"Found <{len(pdf_data_drop)}> PDF Data for {request.action}")

                    if request.action.upper() == "DROP":
                        migration_data.extend(pdf_data_drop)
                    else:
                        migration_data.extend(pdf_data)
                        migration_data_file.extend(pdf_data_file)

            for _migration_data, _migration_data_file in zip(migration_data, migration_data_file):
                # Upload to Blob
                try:
                    migration_request = BlobBatchMigrateRequest(
                        **request.__dict__,
                        data = _migration_data
                    )

                    # Call API
                    api_url = f"{SETTINGS.BBEX.EXPORT_URL}/{SETTINGS.BBEX.EXPORT_API}"
                    payload = migration_request.json()
                    response = await self.send_migrate_blob_request(api_url=api_url, payload=payload, file_path=_migration_data_file)

                except Exception as e:
                    response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Encountered Error During Calling Import API", str(e)))
                    logger.error(response.detail)
                    return response

            try:
                if os.path.exists(local_dir):
                    shutil.rmtree(local_dir)
            except Exception as e:
                logger.error(f"Error cleaning up temporary directory {local_dir}: {str(e)}")

        else:
            response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Found Invalid Export Method"))
            logger.error(response.detail)
            return response

        return response
    
    async def send_migrate_blob_request(self, api_url: str, payload: str, file_path: str) -> Response:
        try:
            # Create multipart form data with both JSON and file
            data = {
                "blob_batch_migrate_request": payload
            }

            async with httpx.AsyncClient(verify=SETTINGS.BASE.APP_PRODUCTION) as client:
                with open(file_path, "rb") as file:
                    resp = await client.post(
                        api_url,
                        files={"file": file},
                        data=data,
                        timeout=SETTINGS.BASE.APP_TIMEOUT
                    )
                
            resp.raise_for_status()
            response = Response(status_code=201, detail=self.response_format.ok(f"Migrated 1 Data via API"))
            logger.info(response.detail)

        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Export Failed : <{SETTINGS.BASE.APP_NAME}> Failed in Export via API", str(e)))
            logger.error(response.detail)
            return response
        
        return response
    
    def get_new_blob_url(self, blob_url: str, migration_type: str) -> str:
        new_blob_url = ""
        try:
            blob_path = get_blob_path(blob_url=blob_url)
            if migration_type == "metadata":
                new_blob_url = f"{self.metadata_blob_url_prefix}{blob_path}"
            else:
                new_blob_url = f"{self.blob_url_prefix}{blob_path}"

            logger.debug(f"Success : Replace Data Url from {blob_url} to {new_blob_url}")
        except Exception as e:
            new_blob_url = blob_url # Reset
            logger.error(f"Unexpected Error : Replace Blob Data Url | {str(e)}")
            
        return new_blob_url
