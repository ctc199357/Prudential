from datetime import datetime, timezone
import inspect

from ..schemas.format import ResponseFormatter, Response
from ..schemas.health import Health

from ..routers.registry.db import db_primary_status, DBTableInfoResponse

from ..routers.vector.vb import vb_primary_status, VBTableInfoResponse

from ..routers.graph.gb import gb_primary_status, GBGraphInfoResponse

from ..settings import SETTINGS

from ..logger.log_handler import get_logger

logger = get_logger(__name__)


class HealthService:
    response_format = ResponseFormatter(suffix = f"{inspect.stack()[0][3]}")

    def health_check(self) -> Health:
        response_health = Health(app_name=SETTINGS.BASE.APP_NAME)
        
        logger.info("Loading Config ...")
        if SETTINGS.BASE.APP_API == False:
            response_health.api_call = 'INACTIVE'
        if SETTINGS.BASE.APP_FUNC == False:
            response_health.function_call = 'INACTIVE'

        # DB Connection
        logger.info("Checking DB Health ...")
        response_primary_db_info, response_db = self.primary_database_connection_check()

        if response_db.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_health.primary_db        = 'OFFLINE'
            response_health.primary_db_reason = response_db.detail
            response_health.status_code       = 500
        else:
            if response_primary_db_info.table_info:
                response_health.primary_db_info = response_primary_db_info.table_info[0]
 
        # VB Connection
        logger.info("Checking VB Health ...")
        response_primary_vb_info, response_vb = self.primary_vector_connection_check()

        if response_vb.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_health.primary_vb        = 'OFFLINE'
            response_health.primary_vb_reason = response_vb.detail
            response_health.status_code       = 500
        else:
            if response_primary_vb_info.table_info:
                response_health.primary_vb_info = response_primary_vb_info.table_info[0]

        # GB Connection
        logger.info("Checking GB Health ...")
        response_primary_gb_info, response_gb = self.primary_graph_connection_check()

        if response_gb.status_code >= SETTINGS.STAT.SUCC_CODE_END:
            response_health.primary_gb        = 'OFFLINE'
            response_health.primary_gb_reason = response_gb.detail
            response_health.status_code       = 500
        else:
            if response_primary_gb_info:
                response_health.primary_gb_info = response_primary_gb_info

        return response_health


    def primary_database_connection_check(self) -> tuple[DBTableInfoResponse, Response]:
        response_data = DBTableInfoResponse()
        try:
            response_data = db_primary_status()
            response = Response(status_code=200, detail=self.response_format.ok("Primary DB : Connected"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Primary DB Connection Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Priamry DB Info", str(e)))

        return response_data, response
    
    def primary_vector_connection_check(self) -> tuple[VBTableInfoResponse, Response]:
        response_data = VBTableInfoResponse()
        try:
            response_data = vb_primary_status()
            response = Response(status_code=200, detail=self.response_format.ok("Primary VB : Connected"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Primary VB Connection Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Priamry VB Info", str(e)))

        return response_data, response
    
    def primary_graph_connection_check(self) -> tuple[GBGraphInfoResponse, Response]:
        response_data = GBGraphInfoResponse()
        try:
            response_data = gb_primary_status()
            response = Response(status_code=200, detail=self.response_format.ok("Primary GB : Connected"))
        except Exception as e:
            response = Response(status_code=500, detail=self.response_format.error(f"Primary GB Connection Error : <{SETTINGS.BASE.APP_NAME}> Failed to Retrieve Priamry GB Info", str(e)))

        return response_data, response