import sys
import os
import json
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
# sys.path.append(os.getcwd())
from knowledgehub.src.routers.request import request_relationship_ingest
from knowledgehub.src.schemas.utils import (
    KnowDataObject,
)
from knowledgehub.src.schemas.graph import (
    RelationshipExtractRequest,
)

from knowledgehub.src.schemas.vector import (
    ListDataByKnowledgeReRequest
)

with open("response_sample.json", "r", encoding="utf-8") as sample:
    data = json.load(sample)
success_data = []
index = 0
for obj in data["layout_success_objects"]["text"]:
    index+=1
    if index < 6:
        obj["knowledge_id"]="gggggggggg444444444444"
        success_data.append(KnowDataObject(**obj))

request = RelationshipExtractRequest(data_input=success_data)

def old_main():
    response = request_relationship_ingest(request=request, api_call=False)
    print("success: ", response)

def main():
    knowledge_id="0a50c3c4-875a-43f1-bffc-a44c791d1e03"
    request = ListDataByKnowledgeReRequest(knowledge_id=knowledge_id)
    response = request_relationship_ingest(request=request, api_call=False)
    print("success: ", response)


if __name__ == '__main__':
    main()
